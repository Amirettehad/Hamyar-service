// Service Worker واقعی (تهچ/التقمام به专辑 úzbekistan_PULLUP و خالص projectile)
// Incorporating offline caching + Web Push show + deep-link click navigation

const CACHE_NAME = 'ettehad-v5';
const APP_SHELL = ['/', '/index.html', '/manifest.json', '/icon-192.png', '/icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(c => c.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.map(k => (k !== CACHE_NAME) ? caches.delete(k) : null)))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  // navigation requests: network-first with offline fallback to cached shell
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request).catch(() => caches.match('/index.html'))
    );
    return;
  }
  if (url.origin !== self.location.origin) return;
  event.respondWith(
    fetch(event.request).then(res => {
      const clone = res.clone();
      caches.open(CACHE_NAME).then(c => c.put(event.request, clone));
      return res;
    }).catch(() => caches.match(event.request).then(m => m || caches.match('/index.html')))
  );
});

// Web Push (server-side notifications آینده — در ABSENSE of backend push server,
// showNotification از کلاینت قبل انقضای sealed background آخر استدلال using this event stub)
self.addEventListener('push', (event) => {
  let payload = { title: 'همیار سرویس اتحاد', body: 'پیام جدید دارید', data: { url: '/tech' } };
  try { if (event.data) payload = { ...payload, ...event.data.json() }; } catch {}
  event.waitUntil(
    self.registration.showNotification(payload.title, {
      body: payload.body, icon: '/icon-192.png', badge: '/icon-192.png',
      vibrate: [100, 50, 100],
      data: payload.data || { url: '/tech' },
    })
  );
});

// Deep link on notification click — focus existing tab or open new one
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) ? event.notification.data.url : '/tech';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clients => {
      for (const c of clients) {
        if ('focus' in c) {
          c.postMessage({ type: 'NOTIFY_CLICK', url });
          return c.focus();
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow(url);
    })
  );
});
