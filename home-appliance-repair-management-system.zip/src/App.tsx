import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import { ToastProvider, LoadingScreen } from './components/ui';
import { Layout } from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Orders from './pages/Orders';
import Customers from './pages/Customers';
import { Technicians, Missions, Devices, Inventory, Invoices } from './pages/Business';
import { CMMS, Scheduler, Chat, Knowledge, Contacts, Reports, Audit, Settings, CustomerTracking } from './pages/Modules';
import Accounting from './pages/Accounting';
import Agent from './pages/Agent';
import Reminders from './pages/Reminders';
import Notifications from './pages/Notifications';
import EditorApp from './editor/EditorApp';
import { TechPanel } from './tech/TechPanel';
import CustomerPortal from './pages/CustomerPortal';

function Guard({ children }: { children: React.ReactNode }) {
  const { currentUser, isLoading } = useApp();
  if (isLoading) return <LoadingScreen />;
  if (!currentUser) return <Navigate to="/login" replace />;
  return <Layout>{children}</Layout>;
}

function EditorRoute() {
  const { currentUser, isLoading } = useApp();
  if (isLoading) return <LoadingScreen />;
  if (!currentUser) return <Navigate to="/login" replace />;
  if (currentUser.role !== 'admin') return <Navigate to="/dashboard" replace />;
  return <EditorApp />;
}

function TechRoute() {
  const { currentUser, isLoading } = useApp();
  if (isLoading) return <LoadingScreen />;
  if (!currentUser) return <Navigate to="/login" replace />;
  if (currentUser.role !== 'technician') return <Navigate to="/dashboard" replace />;
  return <TechPanel />;
}

function AppRoutes() {
  const { currentUser, isLoading } = useApp();
  if (isLoading && !currentUser) return <LoadingScreen />;

  // redirect technician-login to the dedicated mobile tech panel
  const techLanding = currentUser?.role === 'technician' ? '/tech' : '/dashboard';
  return (
    <Routes>
      <Route path="/login" element={currentUser ? <Navigate to={techLanding} replace /> : <Login />} />
      <Route path="/track" element={<CustomerTracking />} />
      <Route path="/track/:code?" element={<CustomerTracking />} />
      <Route path="/t/:code?" element={<CustomerTracking />} />
      <Route path="/customer/track/:code?" element={<CustomerTracking />} />
      <Route path="/customer" element={<CustomerPortal />} />
      <Route path="/portal" element={<CustomerPortal />} />

      <Route path="/" element={<Guard><Dashboard /></Guard>} />
      <Route path="/dashboard" element={<Guard><Dashboard /></Guard>} />
      <Route path="/orders" element={<Guard><Orders /></Guard>} />
      <Route path="/orders/:id" element={<Guard><Orders /></Guard>} />
      <Route path="/missions" element={<Guard><Missions /></Guard>} />
      <Route path="/customers" element={<Guard><Customers /></Guard>} />
      <Route path="/technicians" element={<Guard><Technicians /></Guard>} />
      <Route path="/devices" element={<Guard><Devices /></Guard>} />
      <Route path="/inventory" element={<Guard><Inventory /></Guard>} />
      <Route path="/invoices" element={<Guard><Invoices /></Guard>} />
      <Route path="/accounting" element={<Guard><Accounting /></Guard>} />
      <Route path="/cmms" element={<Guard><CMMS /></Guard>} />
      <Route path="/scheduler" element={<Guard><Scheduler /></Guard>} />
      <Route path="/reminders" element={<Guard><Reminders /></Guard>} />
      <Route path="/chat" element={<Guard><Chat /></Guard>} />
      <Route path="/knowledge" element={<Guard><Knowledge /></Guard>} />
      <Route path="/contacts" element={<Guard><Contacts /></Guard>} />
      <Route path="/reports" element={<Guard><Reports /></Guard>} />
      <Route path="/audit" element={<Guard><Audit /></Guard>} />
      <Route path="/settings" element={<Guard><Settings /></Guard>} />
      <Route path="/agent" element={<Guard><Agent /></Guard>} />
      <Route path="/notifications" element={<Guard><Notifications /></Guard>} />
      <Route path="/editor" element={<EditorRoute />} />
      <Route path="/tech/*" element={<TechRoute />} />
      <Route path="*" element={<Navigate to={currentUser ? techLanding : '/login'} replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AppProvider>
      <ToastProvider>
        <HashRouter>
          <AppRoutes />
        </HashRouter>
      </ToastProvider>
    </AppProvider>
  );
}
