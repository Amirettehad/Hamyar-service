import { useState, useRef, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { compressImage } from '../utils/imageCompressor';
import {
  MessageSquare, User, Wrench, Send, Paperclip, Mic, Square,
  X, Check, CheckCheck, ShieldCheck, Sparkles
} from 'lucide-react';
import { toPersianDigits } from '../lib/jalali';
import { cn } from '../utils/cn';
import type { ServiceOrder } from '../lib/types';

interface Props {
  order: ServiceOrder;
  customerName?: string;
}

export function CustomerSupportChat({ order, customerName }: Props) {
  const { db, sendMessage, currentUser } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [target, setTarget] = useState<'manager' | 'technician' | null>(null);
  const [messageText, setMessageText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<number | null>(null);

  // یافتن اطلاعات مدیر و تکنسین
  const managerUser = db.users.find(u => u.role === 'admin') || {
    id: 'user-admin',
    fullName: 'مدیریت تعمیرگاه',
  };

  const techInfo = db.technicians.find(t => t.id === order.technicianId);
  const techUser = db.users.find(u => u.technicianId === order.technicianId);

  // شناسه فرستنده مشتری
  const customerId = currentUser?.id || `cust-portal-${order.customerId}`;
  const senderDisplayName = customerName || currentUser?.fullName || 'مشتری گرامی';

  // شناسه دریافت‌کننده
  const activeRecipientId = target === 'manager'
    ? managerUser.id
    : (techUser?.id || `tech-user-${order.technicianId}`);

  const activeRecipientName = target === 'manager'
    ? managerUser.fullName
    : (techInfo?.fullName || 'تکنسین سرویس');

  // پیام‌های مربوط به این گفتگو
  const conversation = useMemo(() => {
    if (!target) return [];
    return db.messages.filter(m =>
      (m.senderId === customerId && m.receiverId === activeRecipientId) ||
      (m.senderId === activeRecipientId && m.receiverId === customerId)
    ).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }, [db.messages, customerId, activeRecipientId, target]);

  // اسکرول به آخرین پیام
  useEffect(() => {
    if (isOpen && target) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [conversation.length, isOpen, target]);

  // تایمر ضبط صدا
  useEffect(() => {
    if (isRecording) {
      setRecordingSeconds(0);
      recordingTimerRef.current = window.setInterval(() => {
        setRecordingSeconds(s => s + 1);
      }, 1000);
    } else {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    }
    return () => {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    };
  }, [isRecording]);

  // ارسال پیام متنی
  const handleSendText = (textToSend?: string) => {
    const text = (textToSend || messageText).trim();
    if (!text || !target) return;

    sendMessage({
      senderId: customerId,
      senderName: `${senderDisplayName} (سفارش ${order.requestNumber})`,
      receiverId: activeRecipientId,
      content: text,
      type: 'text',
    });

    if (!textToSend) setMessageText('');
  };

  // ارسال عکس با فشرده‌سازی خودکار
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !target) return;

    try {
      // فشرده‌سازی تا حجم زیر ۳۰ کیلوبایت
      const compressedUrl = await compressImage(file, 600, 600, 0.75);
      sendMessage({
        senderId: customerId,
        senderName: `${senderDisplayName} (سفارش ${order.requestNumber})`,
        receiverId: activeRecipientId,
        content: 'تصویر ارسالی مشتری',
        type: 'image',
        mediaUrl: compressedUrl,
      });
    } catch (err) {
      console.error('Error compressing image', err);
    }
    e.target.value = '';
  };

  // شروع یا توقف ضبط پیام صوتی
  const toggleRecording = async () => {
    if (isRecording) {
      // پایان ضبط و ارسال
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      setIsRecording(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          sendMessage({
            senderId: customerId,
            senderName: `${senderDisplayName} (سفارش ${order.requestNumber})`,
            receiverId: activeRecipientId,
            content: `پیام صوتی (${recordingSeconds} ثانیه)`,
            type: 'voice',
            mediaUrl: reader.result as string,
          });
        };
        reader.readAsDataURL(audioBlob);
        stream.getTracks().forEach(t => t.stop());
      };

      recorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error('Mic access error', err);
      // شبیه‌سازی در صورت عدم پشتیبانی یا عدم دسترسی
      alert('دسترسی به میکروفون داده نشد یا در این محیط فعال نیست.');
    }
  };

  // سوالات پرتکرار و آماده
  const quickQuestions = [
    'دستگاه در چه مرحله‌ای است؟',
    'هزینه نهایی تعمیر چقدر می‌شود؟',
    'فیش واریزی را پرداخت کردم.',
    'چه زمانی برای تحویل هماهنگ کنم؟',
  ];

  return (
    <>
      {/* دکمه شناور چت و پشتیبانی */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 left-6 z-40 bg-gradient-to-r from-teal-600 to-emerald-600 text-white rounded-full p-3.5 shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center gap-2 group border-2 border-white/40"
        title="پشتیبانی و ارتباط آنلاین"
      >
        <span className="relative flex items-center justify-center">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-300 opacity-75" />
          <MessageSquare className="w-5 h-5 relative" />
        </span>
        <span className="text-xs font-bold pl-1 hidden sm:inline-block">
          گفتگوی آنلاین با مدیریت و سرویسکار
        </span>
      </button>

      {/* پنجره گفتگو */}
      {isOpen && (
        <div className="fixed inset-0 sm:inset-auto sm:bottom-6 sm:left-6 z-50 flex items-end sm:items-start justify-center pointer-events-auto">
          {/* بک‌دراپ در موبایل */}
          <div
            className="fixed inset-0 bg-black/40 backdrop-blur-sm sm:hidden"
            onClick={() => setIsOpen(false)}
          />

          <div className="relative w-full sm:w-96 bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col h-[85vh] sm:h-[550px] overflow-hidden animate-slide-up">
            {/* Header */}
            <div className="bg-gradient-to-l from-teal-600 to-teal-700 p-3.5 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center font-bold text-sm">
                  {target === 'technician' ? <Wrench className="w-4 h-4" /> : <ShieldCheck className="w-4 h-4" />}
                </div>
                <div>
                  <p className="font-bold text-xs sm:text-sm">
                    {target ? activeRecipientName : 'مرکز پشتیبانی اتحاد'}
                  </p>
                  <p className="text-[10px] text-teal-100 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-300 inline-block" />
                    <span>پاسخگوی آنلاین • سفارش {order.requestNumber}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                {target && (
                  <button
                    onClick={() => setTarget(null)}
                    className="text-[10px] bg-white/20 hover:bg-white/30 px-2 py-1 rounded-lg text-white font-medium"
                    title="تغییر مخاطب"
                  >
                    تغییر
                  </button>
                )}
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1 rounded-lg hover:bg-white/20 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* صفحه انتخاب مخاطب (مدیر یا تکنسین) */}
            {!target ? (
              <div className="p-4 flex-1 flex flex-col justify-center space-y-4">
                <div className="text-center space-y-1">
                  <div className="w-14 h-14 bg-teal-50 dark:bg-teal-900/30 text-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-2">
                    <Sparkles className="w-7 h-7" />
                  </div>
                  <h4 className="font-bold text-sm text-slate-800 dark:text-slate-100">
                    مایلید با کدام بخش گفتگو کنید؟
                  </h4>
                  <p className="text-xs text-slate-500">
                    پیام‌های شما مستقیماً در پنل مدیریت یا تکنسین ثبت و بررسی می‌شود.
                  </p>
                </div>

                <div className="space-y-2.5">
                  {/* گزینه ۱: ارتباط با مدیریت */}
                  <button
                    onClick={() => setTarget('manager')}
                    className="w-full text-right p-3.5 rounded-2xl border-2 border-slate-200 dark:border-slate-800 hover:border-teal-500 hover:bg-teal-50/50 dark:hover:bg-teal-900/10 transition-all flex items-center justify-between gap-3 group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
                        <User className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-bold text-xs text-slate-900 dark:text-white">
                          ارتباط با مدیریت تعمیرگاه
                        </p>
                        <p className="text-[11px] text-slate-500">
                          پیگیری فاکتور، هماهنگی تحویل، شکایات و امور مالی
                        </p>
                      </div>
                    </div>
                    <span className="text-teal-600 font-bold text-xs group-hover:-translate-x-1 transition-transform">
                      شروع ←
                    </span>
                  </button>

                  {/* گزینه ۲: ارتباط با تکنسین */}
                  <button
                    onClick={() => {
                      if (!techInfo) {
                        alert('در حال حاضر هنوز تکنسینی برای این سفارش تعیین نشده است؛ لطفاً با مدیریت گفتگو فرمایید.');
                        return;
                      }
                      setTarget('technician');
                    }}
                    className="w-full text-right p-3.5 rounded-2xl border-2 border-slate-200 dark:border-slate-800 hover:border-teal-500 hover:bg-teal-50/50 dark:hover:bg-teal-900/10 transition-all flex items-center justify-between gap-3 group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                        <Wrench className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-bold text-xs text-slate-900 dark:text-white">
                          ارتباط مستقیم با تکنسین
                        </p>
                        <p className="text-[11px] text-slate-500">
                          {techInfo ? `سرویسکار: ${techInfo.fullName} (${techInfo.specialization || 'فنی'})` : 'هنوز تکنسین تخصیص نیافته است'}
                        </p>
                      </div>
                    </div>
                    <span className="text-blue-600 font-bold text-xs group-hover:-translate-x-1 transition-transform">
                      شروع ←
                    </span>
                  </button>
                </div>
              </div>
            ) : (
              /* صفحه پیام‌ها و فرم ارسال */
              <div className="flex-1 flex flex-col min-h-0">
                {/* لیست پیام‌ها */}
                <div className="flex-1 overflow-y-auto p-3 space-y-2.5 bg-slate-50 dark:bg-slate-950/60">
                  {conversation.length === 0 ? (
                    <div className="text-center py-8 text-xs text-slate-400 space-y-1">
                      <p>پیامی بین شما و {activeRecipientName} ارسال نشده است.</p>
                      <p>می‌توانید پیام متنی، صوتی یا تصویر فیش و قطعه را ارسال کنید.</p>
                    </div>
                  ) : (
                    conversation.map(msg => {
                      const isMe = msg.senderId === customerId;
                      return (
                        <div
                          key={msg.id}
                          className={cn('flex flex-col', isMe ? 'items-end' : 'items-start')}
                        >
                          <div
                            className={cn(
                              'max-w-[82%] rounded-2xl p-2.5 text-xs shadow-sm space-y-1',
                              isMe
                                ? 'bg-teal-600 text-white rounded-bl-sm'
                                : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-br-sm border border-slate-200 dark:border-slate-700'
                            )}
                          >
                            {/* تصویر */}
                            {msg.type === 'image' && msg.mediaUrl && (
                              <img
                                src={msg.mediaUrl}
                                alt="پیوست"
                                className="w-full max-h-48 object-cover rounded-xl"
                              />
                            )}

                            {/* پیام صوتی */}
                            {msg.type === 'voice' && msg.mediaUrl && (
                              <audio
                                controls
                                src={msg.mediaUrl}
                                className="w-48 h-8 rounded-lg"
                              />
                            )}

                            {/* متن */}
                            <p className="leading-5 whitespace-pre-wrap">{msg.content}</p>

                            <div
                              className={cn(
                                'text-[9px] flex items-center justify-end gap-1 font-mono pt-0.5',
                                isMe ? 'text-teal-100' : 'text-slate-400'
                              )}
                            >
                              <span>
                                {new Date(msg.timestamp).toLocaleTimeString('fa-IR', {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </span>
                              {isMe && (msg.read ? <CheckCheck className="w-3 h-3 text-teal-200" /> : <Check className="w-3 h-3 text-teal-200" />)}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* سوالات سریع آماده */}
                <div className="p-2 border-t border-slate-100 dark:border-slate-800 flex gap-1.5 overflow-x-auto bg-white dark:bg-slate-900 shrink-0">
                  {quickQuestions.map((q, i) => (
                    <button
                      key={i}
                      onClick={() => handleSendText(q)}
                      className="px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-teal-50 text-slate-600 dark:text-slate-300 text-[10px] whitespace-nowrap shrink-0 transition-colors"
                    >
                      {q}
                    </button>
                  ))}
                </div>

                {/* فرم ارسال */}
                <div className="p-2.5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 shrink-0">
                  {isRecording ? (
                    <div className="flex items-center justify-between bg-red-50 dark:bg-red-900/20 p-2 rounded-xl text-red-600 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full bg-red-600 animate-ping" />
                        <span className="font-bold">در حال ضبط صدا...</span>
                        <span className="font-mono">{toPersianDigits(recordingSeconds)} ثانیه</span>
                      </div>
                      <button
                        onClick={toggleRecording}
                        className="p-1.5 rounded-lg bg-red-600 text-white font-bold text-[11px] flex items-center gap-1"
                      >
                        <Square className="w-3.5 h-3.5" />
                        ارسال صدا
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1.5">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handlePhotoUpload}
                      />
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                        title="ارسال عکس یا فیش"
                      >
                        <Paperclip className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={toggleRecording}
                        className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                        title="ضبط پیام صوتی"
                      >
                        <Mic className="w-4 h-4" />
                      </button>

                      <input
                        type="text"
                        value={messageText}
                        onChange={e => setMessageText(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && handleSendText()}
                        placeholder="پیام خود را بنویسید..."
                        className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-slate-100 outline-none focus:ring-1 focus:ring-teal-500"
                      />

                      <button
                        type="button"
                        onClick={() => handleSendText()}
                        disabled={!messageText.trim()}
                        className="p-2 bg-teal-600 hover:bg-teal-700 disabled:opacity-40 text-white rounded-xl transition-colors"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
