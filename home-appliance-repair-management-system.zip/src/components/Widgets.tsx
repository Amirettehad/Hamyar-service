import { useState, useEffect, useMemo } from 'react';
import { Clock, Calculator, Search, Phone, FileText, User } from 'lucide-react';
import { Card, Input } from './ui';
import { toPersianDigits, formatJalali } from '../lib/jalali';
import { useApp } from '../context/AppContext';
import { useNavigate } from 'react-router-dom';
import { cn } from '../utils/cn';

export function ClockWidget() {
  const [now, setNow] = useState(new Date());
  useEffect(() => { const i = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(i); }, []);
  const hours = now.getHours(), minutes = now.getMinutes(), seconds = now.getSeconds();
  const hourDeg = (hours % 12) * 30 + minutes * 0.5;
  const minuteDeg = minutes * 6, secondDeg = seconds * 6;
  return (
    <Card className="p-4">
      <div className="flex items-center gap-4">
        <div className="relative w-20 h-20 rounded-full border-4 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex-shrink-0 shadow-inner">
          {[...Array(12)].map((_, i) => (<div key={i} className="absolute w-0.5 h-1.5 bg-slate-400 dark:bg-slate-500" style={{ top: '4px', left: '50%', transform: `translateX(-50%) rotate(${i * 30}deg)`, transformOrigin: '0 32px' }} />))}
          <div className="absolute left-1/2 top-1/2 w-1 h-5 bg-slate-800 dark:bg-slate-200 rounded-full origin-bottom" style={{ transform: `translateX(-50%) translateY(-100%) rotate(${hourDeg}deg)`, transformOrigin: 'bottom center' }} />
          <div className="absolute left-1/2 top-1/2 w-0.5 h-7 bg-slate-600 dark:bg-slate-400 rounded-full origin-bottom" style={{ transform: `translateX(-50%) translateY(-100%) rotate(${minuteDeg}deg)`, transformOrigin: 'bottom center' }} />
          <div className="absolute left-1/2 top-1/2 w-0.5 h-8 bg-red-500 rounded-full origin-bottom" style={{ transform: `translateX(-50%) translateY(-100%) rotate(${secondDeg}deg)`, transformOrigin: 'bottom center' }} />
          <div className="absolute left-1/2 top-1/2 w-2 h-2 bg-teal-500 rounded-full -translate-x-1/2 -translate-y-1/2" />
        </div>
        <div>
          <div className="flex items-center gap-1 text-slate-500 dark:text-slate-400 mb-1"><Clock className="w-4 h-4" /><span className="text-xs">ساعت</span></div>
          <p className="text-2xl font-bold tabular-nums text-slate-900 dark:text-white" dir="ltr">{toPersianDigits(String(hours).padStart(2, '0'))}:{toPersianDigits(String(minutes).padStart(2, '0'))}:{toPersianDigits(String(seconds).padStart(2, '0'))}</p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{formatJalali(now, { withWeekday: true })}</p>
        </div>
      </div>
    </Card>
  );
}

export function CalculatorWidget() {
  const [display, setDisplay] = useState('0');
  const [prev, setPrev] = useState<number | null>(null);
  const [op, setOp] = useState<string | null>(null);
  const [fresh, setFresh] = useState(true);
  const inputNum = (n: string) => { if (fresh) { setDisplay(n === '.' ? '0.' : n); setFresh(false); } else { if (n === '.' && display.includes('.')) return; setDisplay(display === '0' && n !== '.' ? n : display + n); } };
  const inputOp = (o: string) => { const cur = parseFloat(display); if (prev !== null && op && !fresh) { const r = calc(prev, cur, op); setDisplay(String(r)); setPrev(r); } else setPrev(cur); setOp(o); setFresh(true); };
  const calc = (a: number, b: number, o: string) => o === '+' ? a + b : o === '-' ? a - b : o === '×' ? a * b : a / b;
  const equals = () => { if (prev === null || op === null) return; setDisplay(String(calc(prev, parseFloat(display), op))); setPrev(null); setOp(null); setFresh(true); };
  const clear = () => { setDisplay('0'); setPrev(null); setOp(null); setFresh(true); };
  const del = () => setDisplay(display.length === 1 ? '0' : display.slice(0, -1));
  const percent = () => setDisplay(String(parseFloat(display) / 100));
  const buttons = [
    { l: 'C', c: 'bg-red-100 dark:bg-red-900/30 text-red-600', a: clear }, { l: '⌫', c: 'bg-slate-100 dark:bg-slate-700', a: del }, { l: '%', c: 'bg-slate-100 dark:bg-slate-700', a: percent }, { l: '÷', c: 'bg-teal-100 dark:bg-teal-900/30 text-teal-700', a: () => inputOp('/') },
    { l: '7', c: 'bg-white dark:bg-slate-800', a: () => inputNum('7') }, { l: '8', c: 'bg-white dark:bg-slate-800', a: () => inputNum('8') }, { l: '9', c: 'bg-white dark:bg-slate-800', a: () => inputNum('9') }, { l: '×', c: 'bg-teal-100 dark:bg-teal-900/30 text-teal-700', a: () => inputOp('×') },
    { l: '4', c: 'bg-white dark:bg-slate-800', a: () => inputNum('4') }, { l: '5', c: 'bg-white dark:bg-slate-800', a: () => inputNum('5') }, { l: '6', c: 'bg-white dark:bg-slate-800', a: () => inputNum('6') }, { l: '-', c: 'bg-teal-100 dark:bg-teal-900/30 text-teal-700', a: () => inputOp('-') },
    { l: '1', c: 'bg-white dark:bg-slate-800', a: () => inputNum('1') }, { l: '2', c: 'bg-white dark:bg-slate-800', a: () => inputNum('2') }, { l: '3', c: 'bg-white dark:bg-slate-800', a: () => inputNum('3') }, { l: '+', c: 'bg-teal-100 dark:bg-teal-900/30 text-teal-700', a: () => inputOp('+') },
    { l: '0', c: 'bg-white dark:bg-slate-800 col-span-2', a: () => inputNum('0') }, { l: '.', c: 'bg-white dark:bg-slate-800', a: () => inputNum('.') }, { l: '=', c: 'bg-teal-600 text-white', a: equals },
  ];
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-3"><Calculator className="w-4 h-4 text-teal-600" /><h3 className="text-sm font-semibold text-slate-900 dark:text-white">ماشین حساب سریع</h3></div>
      <div className="bg-slate-900 dark:bg-black rounded-xl p-3 mb-2 text-left" dir="ltr"><p className="text-2xl font-bold text-white tabular-nums truncate">{toPersianDigits(display)}</p></div>
      <div className="grid grid-cols-4 gap-1.5">{buttons.map((b, i) => <button key={i} onClick={b.a} className={cn('rounded-lg py-2.5 text-sm font-semibold transition-all active:scale-95 shadow-sm', b.c)}>{b.l}</button>)}</div>
    </Card>
  );
}

export function QuickSearchWidget() {
  const { db } = useApp();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [mode, setMode] = useState<'receipt' | 'customer' | 'phone'>('receipt');
  const results = useMemo(() => {
    if (!q) return [];
    const query = q.toLowerCase();
    if (mode === 'receipt') return db.orders.filter(o => o.requestNumber.toLowerCase().includes(query) || o.id.toLowerCase().includes(query)).slice(0, 5).map(o => { const c = db.customers.find(x => x.id === o.customerId); return { id: o.id, label: o.requestNumber, sub: c?.fullName || '', to: `/orders/${o.id}` }; });
    if (mode === 'customer') return db.customers.filter(c => c.fullName.includes(q) || c.phone.includes(q)).slice(0, 5).map(c => ({ id: c.id, label: c.fullName, sub: c.phone, to: `/customers` }));
    return db.contacts.filter(c => c.name.includes(q) || c.phone.includes(q)).slice(0, 5).map(c => ({ id: c.id, label: c.name, sub: c.phone, to: '/contacts' }));
  }, [q, mode, db]);
  const modeIcons = { receipt: <FileText className="w-4 h-4" />, customer: <User className="w-4 h-4" />, phone: <Phone className="w-4 h-4" /> };
  const modeLabels = { receipt: 'جستجوی قبض', customer: 'حساب مشتری', phone: 'تلفن' };
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 mb-3"><Search className="w-4 h-4 text-teal-600" /><h3 className="text-sm font-semibold text-slate-900 dark:text-white">جستجوی سریع</h3></div>
      <div className="flex gap-1 mb-2">{(['receipt', 'customer', 'phone'] as const).map(m => <button key={m} onClick={() => setMode(m)} className={cn('flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium flex-1 justify-center', mode === m ? 'bg-teal-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300')}>{modeIcons[m]}<span className="hidden sm:inline">{modeLabels[m]}</span></button>)}</div>
      <Input value={q} onChange={e => setQ(e.target.value)} placeholder={mode === 'receipt' ? 'شماره قبض...' : mode === 'customer' ? 'نام یا شماره مشتری...' : 'نام یا شماره...'} icon={<Search className="w-4 h-4" />} />
      {results.length > 0 && <div className="mt-2 space-y-1 max-h-48 overflow-y-auto">{results.map(r => <button key={r.id} onClick={() => { navigate(r.to); setQ(''); }} className="w-full flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 text-right"><div><p className="text-sm font-medium text-slate-900 dark:text-white">{r.label}</p><p className="text-xs text-slate-500">{r.sub}</p></div></button>)}</div>}
      {q && results.length === 0 && <p className="text-xs text-slate-500 mt-2 text-center py-2">موردی یافت نشد</p>}
    </Card>
  );
}

export function TodayInfoWidget() {
  const now = new Date();
  const isFriday = now.getDay() === 5;
  return (
    <Card className={cn('p-4', isFriday && 'bg-amber-50 dark:bg-amber-900/10 border-amber-200 dark:border-amber-800')}>
      <h3 className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">امروز</h3>
      <p className="text-lg font-bold text-slate-900 dark:text-white">{formatJalali(now, { withWeekday: true })}</p>
      {isFriday && <p className="text-xs text-amber-700 dark:text-amber-400 mt-1 flex items-center gap-1"><span>⚠️</span> امروز جمعه و تعطیل رسمی است</p>}
    </Card>
  );
}
