import { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Button, useToast } from './ui';
import { BellRing, X, Smartphone, CheckCircle2 } from 'lucide-react';

const SAFE_PREFIX = 'push_prompt_shown_';

/**
 * پس از ورود کاربر، یک‌بار (و فقط یک‌بار) پیشنهاد نصب PWA و سپس مجوز نوتیفیکیشن واقعی،
 * به‌صورت Bottom Sheet در انتهای صفحه نمایش داده می‌شود. برای هر کاربر جداگانه در localStorage ذخیره می‌شود.
 */
export function PushPermissionPrompt({ alsoInstallPrompt = true }: { alsoInstallPrompt?: boolean }) {
  const { db, currentUser } = useApp();
  const { showToast } = useToast();
  const [visible, setVisible] = useState<'hidden' | 'install' | 'ask' | 'done'>('hidden');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!currentUser) return;
    const key = `${SAFE_PREFIX}${currentUser.id}`;
    let already: string | null = null;
    try { already = localStorage.getItem(key); } catch { /* ignore */ }
    if (already) return;
    const t = setTimeout(() => {
      setVisible(alsoInstallPrompt ? 'install' : 'ask');
    }, 1600);
    return () => clearTimeout(t);
  }, [currentUser, alsoInstallPrompt]);

  const markShown = () => {
    try { if (currentUser) localStorage.setItem(`${SAFE_PREFIX}${currentUser.id}`, '1'); } catch { /* ignore */ }
  };

  const handleAsk = async () => {
    setBusy(true);
    try {
      const settings = db.settings;
      let result: 'granted' | 'denied' | 'unsupported' | 'pending' = 'pending';
      if (settings.oneSignalEnabled && settings.oneSignalAppId) {
        const mod = await import('../lib/onesignal');
        result = await mod.subscribeCurrentUser(settings, currentUser!.id);
      } else {
        const mod = await import('../lib/push');
        result = (await mod.requestPushPermission()) as typeof result;
      }
      markShown();
      if (result === 'granted') {
        showToast('نوتیفیکیشن فعال شد ✓ اعلان‌های جدید روی دستگاه‌تان می‌رسد');
        setVisible('done');
      } else if (result === 'denied') {
        showToast('مجوز داده نشد — بعداً از تنظیمات مجدداً درخواست کنید', 'error');
        setVisible('hidden');
      } else {
        setVisible('hidden');
      }
    } finally { setBusy(false); }
  };

  const handleSkip = () => { markShown(); setVisible('hidden'); };

  if (!currentUser || visible === 'hidden') return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-[480] px-3 pb-4 pointer-events-none safe-bottom">
      <div className="pointer-events-auto mx-auto max-w-md rounded-3xl shadow-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 overflow-hidden animate-slide-up">
        <div className="px-4 pt-3 pb-3 text-white" style={{ background: 'linear-gradient(135deg,#00A599,#008a84)' }}>
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
                {visible === 'install' ? <Smartphone className="w-5 h-5" /> : <BellRing className="w-5 h-5" />}
              </div>
              <div>
                <p className="font-extrabold text-sm">
                  {visible === 'install' ? 'نصب وب اپ روی گوشی خود' : 'فعال‌سازی اعلان روی دستگاه'}
                </p>
                <p className="text-[11px] text-white/80 mt-0.5">
                  {visible === 'install'
                    ? 'برای بهترین تجربه و دریافت اعلان‌های واقعی، وب اپ را نصب کنید و سپس اعلان را فعال می‌کنیم.'
                    : 'یک مجوز لازم است تا پیام‌های مدیریت و ماموریت‌ها به دستگاه شما برسد.'}
                </p>
              </div>
            </div>
            <button onClick={handleSkip} className="p-1.5 rounded-full bg-white/15 hover:bg-white/25 transition-colors shrink-0">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="p-4 space-y-2.5">
          {visible === 'install' && (
            <>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-5">
                برای اینکه اعلان‌های به‌موقع رسمی روی گوشی برسند، ابتدا وب اپ را روی صفحهٔ اصلی دستگاه‌تان نصب کنید. پس از آن درخواست مجوز اعلان خودکار ادامه می‌یابد.
              </p>
              <div className="flex gap-2">
                <Button variant="secondary" className="flex-1" onClick={() => setVisible('ask')}>تعلیق‌نمایش بده — بعداً</Button>
                <Button className="flex-1" onClick={() => setVisible('ask')}>
                  <CheckCircle2 className="w-4 h-4" />نصب و بعداً خاموش
                </Button>
              </div>
              <ol className="space-y-1 text-[10.5px] text-slate-500 list-decimal pr-4">
                <li>اگر سکه‌کتension Android دارید، روی «Add to Home Screen» بزنید یا از منو مرورگر «Install app» را انتخاب کنید.</li>
                <li>در iOS (Safari)، دکمه به «افزودن به صفحه اصلی» بزنید تا وب اپ به‌صورت مستقل اجرا شود.</li>
              </ol>
            </>
          )}

          {visible === 'ask' && (
            <>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-5">
                برای دریافت اعلان‌های ماموریت‌ها و پیام‌های مدیریت روی دستگاه‌تان، روی «فعال‌سازی» بزنید تا مجوز مرورگر داده شود.
              </p>
              <div className="flex gap-2">
                <Button variant="secondary" className="flex-1" onClick={handleSkip}>بعداً</Button>
                <Button className="flex-1" onClick={handleAsk} loading={busy}>
                  <BellRing className="w-4 h-4" />فعال‌سازی اعلان
                </Button>
              </div>
              <p className="text-[10px] text-slate-400 text-center leading-4">فقط یک‌بار پس از ورود از شما خواسته می‌شود — هر زمان از «تنظیمات/پروفایل» می‌توانید دوباره فعال کنید.</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
