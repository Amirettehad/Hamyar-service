import { useState, useMemo, useEffect, type ReactNode } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Users, User, Wrench, FileText, Package, MessageSquare,
  BookOpen, BarChart3, Settings as SettingsIcon, Bell, LogOut, Moon, Sun,
  ClipboardList, Wallet, CalendarClock, Phone, Menu, X, Shield, UserCog,
  Cpu, Briefcase, Bot, AlarmClock, PencilRuler, Megaphone,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { cn } from '../utils/cn';
import { Avatar, Badge } from './ui';
import { formatJalali, toPersianDigits, timeAgo } from '../lib/jalali';
import { InstallBanner } from './InstallBanner';
import { PushPermissionPrompt } from './PushPermissionPrompt';
import { RichNotificationCard } from '../pages/Notifications';

interface NavItem { to: string; label: string; icon: ReactNode; roles: Array<'admin' | 'technician' | 'customer'> }

export function Layout({ children }: { children: ReactNode }) {
  const { currentUser, logout, theme, toggleTheme, db, markNotificationRead, clearAllNotifications } = useApp();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [now, setNow] = useState(new Date());
  const [routeLoading, setRouteLoading] = useState(false);

  useEffect(() => { const i = setInterval(() => setNow(new Date()), 60000); return () => clearInterval(i); }, []);
  useEffect(() => { setSidebarOpen(false); setNotifOpen(false); setUserMenuOpen(false); setRouteLoading(true); const t = setTimeout(() => setRouteLoading(false), 420); return () => clearTimeout(t); }, [location.pathname]);

  const userNotifications = useMemo(() => db.notifications.filter(n => n.userId === currentUser?.id).slice(0, 20), [db.notifications, currentUser]);
  const unreadCount = userNotifications.filter(n => !n.read).length;

  const navItems: NavItem[] = useMemo(() => {
    const all: NavItem[] = [
      { to: '/dashboard', label: 'داشبورد', icon: <LayoutDashboard className="w-5 h-5" />, roles: ['admin', 'technician', 'customer'] },
      { to: '/orders', label: 'سفارشات', icon: <ClipboardList className="w-5 h-5" />, roles: ['admin', 'technician', 'customer'] },
      { to: '/missions', label: 'اعزام مامور', icon: <Briefcase className="w-5 h-5" />, roles: ['admin', 'technician'] },
      { to: '/customers', label: 'مشتریان', icon: <Users className="w-5 h-5" />, roles: ['admin'] },
      { to: '/technicians', label: 'تکنسین‌ها', icon: <UserCog className="w-5 h-5" />, roles: ['admin'] },
      { to: '/devices', label: 'دستگاه‌ها', icon: <Cpu className="w-5 h-5" />, roles: ['admin'] },
      { to: '/inventory', label: 'موجودی انبار', icon: <Package className="w-5 h-5" />, roles: ['admin', 'technician'] },
      { to: '/invoices', label: 'فاکتورها', icon: <FileText className="w-5 h-5" />, roles: ['admin', 'customer'] },
      { to: '/customer', label: 'پورتال اختصاصی مشتری', icon: <User className="w-5 h-5" />, roles: ['admin', 'customer'] },
      { to: '/accounting', label: 'حسابداری یکپارچه', icon: <Wallet className="w-5 h-5" />, roles: ['admin'] },
      { to: '/cmms', label: 'CMMS/نگهداری', icon: <Wrench className="w-5 h-5" />, roles: ['admin', 'technician'] },
      { to: '/scheduler', label: 'تقویم و زمان‌بندی', icon: <CalendarClock className="w-5 h-5" />, roles: ['admin', 'technician'] },
      { to: '/reminders', label: 'یادآورها', icon: <AlarmClock className="w-5 h-5" />, roles: ['admin', 'technician'] },
      { to: '/agent', label: 'دستیار هوشمند', icon: <Bot className="w-5 h-5" />, roles: ['admin', 'technician', 'customer'] },
      { to: '/chat', label: 'چت داخلی', icon: <MessageSquare className="w-5 h-5" />, roles: ['admin', 'technician', 'customer'] },
      { to: '/knowledge', label: 'پایگاه دانش', icon: <BookOpen className="w-5 h-5" />, roles: ['admin', 'technician', 'customer'] },
      { to: '/contacts', label: 'دفترچه تلفن', icon: <Phone className="w-5 h-5" />, roles: ['admin', 'technician'] },
      { to: '/reports', label: 'گزارش‌ها', icon: <BarChart3 className="w-5 h-5" />, roles: ['admin'] },
      { to: '/notifications', label: 'مرکز اعلان‌ها', icon: <Megaphone className="w-5 h-5" />, roles: ['admin'] },
      { to: '/editor', label: 'ویرایشگر قالب', icon: <PencilRuler className="w-5 h-5" />, roles: ['admin'] },
      { to: '/audit', label: 'گزارش حسابرسی', icon: <Shield className="w-5 h-5" />, roles: ['admin'] },
      { to: '/settings', label: 'تنظیمات', icon: <SettingsIcon className="w-5 h-5" />, roles: ['admin', 'technician', 'customer'] },
    ];
    return all.filter(i => i.roles.includes(currentUser?.role || 'admin'));
  }, [currentUser]);

  const roleLabel = currentUser?.role === 'admin' ? 'مدیر ارشد' : currentUser?.role === 'technician' ? 'تکنسین' : 'مشتری';
  const roleBadgeColor = currentUser?.role === 'admin' ? 'purple' : currentUser?.role === 'technician' ? 'blue' : 'teal';
  const mobileNav = navItems.slice(0, 5);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col">
      <header className="sticky top-0 z-40 app-bar border-b border-slate-200/70 dark:border-slate-800/70 no-print safe-top">
        {routeLoading && <div className="absolute bottom-0 left-0 right-0 h-0.5 overflow-hidden"><div className="h-full bg-gradient-to-l from-teal-400 via-teal-600 to-emerald-500 animate-route-bar" /></div>}
        <div className="flex items-center justify-between h-14 px-4">
          <div className="flex items-center gap-3">
            <button className="lg:hidden p-2 -mr-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800" onClick={() => setSidebarOpen(true)}><Menu className="w-5 h-5" /></button>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-md shadow-teal-200 dark:shadow-none"><span className="text-white font-bold text-lg">اتحاد</span></div>
              <div className="hidden sm:block"><h1 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">{db.settings.shopName}</h1><p className="text-[10px] text-slate-500 dark:text-slate-400 leading-tight">{formatJalali(now, { withWeekday: true })}</p></div>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">{theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-600" />}</button>
            <div className="relative">
              <button onClick={() => { setNotifOpen(!notifOpen); setUserMenuOpen(false); }} className="relative p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"><Bell className="w-5 h-5" />{unreadCount > 0 && <span className="absolute top-1 left-1 w-4 h-4 bg-red-500 rounded-full text-white text-[10px] font-bold flex items-center justify-center animate-pulse-soft">{toPersianDigits(unreadCount)}</span>}</button>
              {notifOpen && (<><div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} /><div className="absolute left-0 top-full mt-2 w-80 max-w-[calc(100vw-2rem)] bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 z-50 animate-slide-up overflow-hidden"><div className="flex items-center justify-between p-3 border-b border-slate-200 dark:border-slate-700"><h3 className="font-semibold text-sm">اعلان‌ها</h3>{unreadCount > 0 && <button onClick={clearAllNotifications} className="text-xs text-teal-600 hover:underline">علامت همه به‌عنوان خوانده</button>}</div><div className="max-h-[60vh] overflow-y-auto p-2 space-y-1.5">
  {userNotifications.length === 0 ? (
    <p className="text-center text-slate-500 dark:text-slate-400 py-8 text-sm">اعلانی ندارید</p>
  ) : (
    userNotifications.map(n => {
      const handleNotifClick = () => {
        markNotificationRead(n.id);
        setNotifOpen(false);
        if (n.internalLink) {
          navigate(n.internalLink);
        } else if (n.externalLink) {
          window.open(n.externalLink, '_blank');
        } else if (n.relatedId) {
          if (n.type === 'status_change' || n.type === 'assignment') {
            navigate(`/orders/${n.relatedId}`);
          } else if (n.type === 'payment' || n.type === 'accounting') {
            navigate('/accounting');
          }
        }
      };

      return (
        <div
          key={n.id}
          onClick={handleNotifClick}
          className={cn(
            'cursor-pointer transition-all hover:scale-[0.99] active:scale-[0.97]',
            !n.read && 'ring-1 ring-teal-400 rounded-2xl'
          )}
        >
          {n.type === 'broadcast' ? (
            <RichNotificationCard
              n={{
                title: n.title,
                body: n.body,
                icon: n.icon,
                imageUrl: n.imageUrl,
                internalLink: n.internalLink,
                externalLink: n.externalLink,
                accentColor: n.accentColor,
                senderName: n.senderName,
                createdAt: n.createdAt,
              }}
              compact
            />
          ) : (
            <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-100 dark:border-slate-700/60">
              <div className={cn('w-2 h-2 rounded-full mt-1.5 flex-shrink-0', !n.read ? 'bg-teal-500' : 'bg-slate-300')} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <p className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">{n.title}</p>
                  <span className="text-[9px] text-slate-400 shrink-0 font-mono">{timeAgo(new Date(n.createdAt))}</span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2 leading-5">{n.body}</p>
                {(n.internalLink || n.relatedId) && (
                  <span className="inline-flex items-center gap-1 text-[10px] text-teal-600 font-bold mt-1">
                    مشاهده بخش مربوطه ←
                  </span>
                )}
              </div>
            </div>
          )}
        </div>
      );
    })
  )}
</div></div></>)}
            </div>
            <div className="relative mr-1">
              <button onClick={() => { setUserMenuOpen(!userMenuOpen); setNotifOpen(false); }} className="flex items-center gap-2 p-1 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"><Avatar name={currentUser?.fullName || 'کاربر'} size="sm" /><div className="hidden sm:block text-right"><p className="text-xs font-semibold text-slate-900 dark:text-white leading-tight">{currentUser?.fullName}</p><p className="text-[10px] text-slate-500 dark:text-slate-400 leading-tight">{roleLabel}</p></div></button>
              {userMenuOpen && (<><div className="fixed inset-0 z-40" onClick={() => setUserMenuOpen(false)} /><div className="absolute left-0 top-full mt-2 w-56 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 z-50 animate-scale-in overflow-hidden"><div className="p-3 border-b border-slate-200 dark:border-slate-700"><div className="flex items-center gap-2"><Avatar name={currentUser?.fullName || ''} /><div><p className="font-semibold text-sm text-slate-900 dark:text-white">{currentUser?.fullName}</p><Badge color={roleBadgeColor}>{roleLabel}</Badge></div></div></div><div className="p-1"><button onClick={logout} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"><LogOut className="w-4 h-4" />خروج از حساب</button></div></div></>)}
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        <aside className="hidden lg:flex flex-col w-64 border-l border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 no-print flex-shrink-0">
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            {navItems.map(item => (
              <NavLink key={item.to} to={item.to} className={({ isActive }) => cn('flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all hover-lift', isActive ? 'nav-item-active' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800')}>
                {item.icon}<span className="flex-1">{item.label}</span>
                {item.to === '/orders' && db.orders.filter(o => o.status === 'در انتظار اعزام').length > 0 && <Badge color="amber">{toPersianDigits(db.orders.filter(o => o.status === 'در انتظار اعزام').length)}</Badge>}
              </NavLink>
            ))}
          </nav>
          <div className="p-3 border-t border-slate-200 dark:border-slate-800"><div className="bg-gradient-to-br from-teal-50 to-emerald-50 dark:from-teal-900/20 dark:to-emerald-900/20 rounded-xl p-3 text-xs"><p className="font-semibold text-teal-700 dark:text-teal-400">نسخه ۲.۰.۰</p><p className="text-slate-600 dark:text-slate-400 mt-1">توسعه: {db.settings.developerName}</p><p className="text-slate-500 dark:text-slate-500 text-[10px] mt-0.5">{db.settings.developerPhone}</p></div></div>
        </aside>

        {sidebarOpen && (
          <div className="fixed inset-0 z-50 lg:hidden">
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
            <aside className="absolute right-0 top-0 bottom-0 w-72 bg-white dark:bg-slate-900 shadow-2xl flex flex-col animate-slide-in-right">
              <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700"><div className="flex items-center gap-2"><div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-xl flex items-center justify-center"><span className="text-white font-bold text-lg">اتحاد</span></div><div><p className="font-bold text-sm">{db.settings.shopName}</p><p className="text-[10px] text-slate-500">{roleLabel}</p></div></div><button onClick={() => setSidebarOpen(false)} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"><X className="w-5 h-5" /></button></div>
              <nav className="flex-1 p-3 space-y-1 overflow-y-auto">{navItems.map(item => (<NavLink key={item.to} to={item.to} className={({ isActive }) => cn('flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all', isActive ? 'nav-item-active' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800')}>{item.icon}<span>{item.label}</span></NavLink>))}</nav>
            </aside>
          </div>
        )}

        <main className="flex-1 overflow-x-hidden pb-20 lg:pb-6">
          <div className="p-4 lg:p-6 page-transition">{children}</div>
        </main>
      </div>

      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 tab-bar no-print safe-bottom">
        <div className="flex items-stretch justify-around px-1.5 pt-1.5 pb-1">
          {mobileNav.map(item => {
            const isActive = location.pathname === item.to || (item.to === '/dashboard' && location.pathname === '/');
            return (
              <NavLink key={item.to} to={item.to} className={cn('tab-item relative flex flex-col items-center gap-1 px-1 py-1 min-w-0 flex-1', isActive ? 'text-teal-600 dark:text-teal-400' : 'text-slate-400 dark:text-slate-500')}>
                {isActive && <span className="absolute -top-1.5 w-8 h-1 rounded-full bg-teal-500 animate-tab-pop" />}
                <span className={cn('w-10 h-8 rounded-2xl flex items-center justify-center transition-all duration-250', isActive ? 'bg-teal-50 dark:bg-teal-900/30 scale-105' : 'bg-transparent')}>{item.icon}</span>
                <span className={cn('text-[10px] truncate w-full text-center', isActive ? 'font-bold' : 'font-medium')}>{item.label.split(' ')[0]}</span>
              </NavLink>
            );
          })}
        </div>
      </nav>

      <InstallBanner />
      <PushPermissionPrompt alsoInstallPrompt={false} />
    </div>
  );
}
