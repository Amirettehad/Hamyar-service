import { useMemo, useState } from 'react';
import { Printer, FileText, Star, X, Check, PencilRuler } from 'lucide-react';
import { Button, Modal, Badge } from './ui';
import { PrintSheet } from './PrintSheet';
import { useApp } from '../context/AppContext';
import { SYSTEM_FORM_TEMPLATES } from '../editor/formTemplates';
import { listPrintTemplates, type PrintTemplate, type FormType } from '../lib/printTemplates';
import { buildPrintDataContext } from '../lib/printData';
import { ElementRenderer } from '../editor/components/ElementRenderer';
import { getPagePx, resolveRect } from '../editor/utils';
import type { EditorElement } from '../editor/types';
import type { ServiceOrder, Invoice } from '../lib/types';
import { toPersianDigits } from '../lib/jalali';
import { cn } from '../utils/cn';
import { useNavigate } from 'react-router-dom';

type Choice =
  | { kind: 'official'; templateId: string }
  | { kind: 'saved'; templateId: string };

interface Props {
  open: boolean;
  onClose: () => void;
  order: ServiceOrder;
  invoice?: Invoice;
  printType: 'factor' | 'receipt';
}

export function PrintTemplateSelector({ open, onClose, order, invoice, printType }: Props) {
  const { db } = useApp();
  const navigate = useNavigate();
  const formType: FormType = printType === 'factor' ? 'invoice' : 'receipt';
  const data = useMemo(() => buildPrintDataContext(db, order, invoice), [db, order, invoice]);

  const officialTemplates = SYSTEM_FORM_TEMPLATES.filter(t => t.printType === printType);
  const savedTemplates = useMemo(() => listPrintTemplates(formType), [formType, open]);

  const [choice, setChoice] = useState<Choice>({ kind: 'official', templateId: 'official-invoice' });
  const [printing, setPrinting] = useState(false);

  const renderChoice = (): { document: PrintTemplate['document']; elements: EditorElement[] } | null => {
    if (choice.kind === 'official') {
      const t = SYSTEM_FORM_TEMPLATES.find(s => s.id === choice.templateId);
      if (!t) return null;
      return { document: { ...defaultDoc(), ...t.doc } as PrintTemplate['document'], elements: t.build() };
    }
    const t = savedTemplates.find(s => s.id === choice.templateId);
    if (!t) return null;
    return { document: t.document, elements: t.elements };
  };

  const active = renderChoice();
  const page = active ? getPagePx(active.document) : { width: 794, height: 1123 };

  const handlePrint = () => setPrinting(true);

  return (
    <Modal open={open} onClose={onClose} title="انتخاب قالب چاپ" size="xl">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Template list */}
        <div className="lg:col-span-4 space-y-2">
          <p className="text-xs font-bold text-slate-500 px-1">قالب‌های رسمی</p>
          {officialTemplates.map(t => (
            <TemplateCard key={t.id} active={choice.kind === 'official' && choice.templateId === t.id}
              onClick={() => setChoice({ kind: 'official', templateId: t.id })} title={t.name} desc={t.description} badge="رسمی" />
          ))}
          <p className="text-xs font-bold text-slate-500 px-1 pt-2">قالب‌های من</p>
          {savedTemplates.length === 0 ? (
            <div className="rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-700 p-4 text-center">
              <p className="text-xs text-slate-500 mb-2">هنوز قالب دلخواهی نساخته‌اید</p>
            </div>
          ) : savedTemplates.map(t => (
            <TemplateCard key={t.id} active={choice.kind === 'saved' && choice.templateId === t.id}
              onClick={() => setChoice({ kind: 'saved', templateId: t.id })} title={t.name} desc={`${toPersianDigits(t.elements.length)} عنصر • ${t.document.pageSize} ${t.document.orientation === 'portrait' ? 'عمودی' : 'افقی'}`} badge="دلخواه" />
          ))}
          <Button variant="outline" className="w-full mt-2" onClick={() => { onClose(); navigate('/editor'); }}>
            <PencilRuler className="w-4 h-4" />ساخت قالب جدید در ویرایشگر
          </Button>
        </div>

        {/* Preview */}
        <div className="lg:col-span-8">
          <div className="bg-slate-100 dark:bg-slate-950 rounded-2xl p-4 overflow-auto max-h-[70vh]">
            {active && (
              <div className="mx-auto bg-white shadow-xl" style={{ width: page.width }}>
                <div id="print-area" className="relative" style={{ width: page.width, height: page.height, background: active.document.backgroundColor, border: active.document.showBorder ? `${active.document.borderWidth}px ${active.document.borderStyle} ${active.document.borderColor}` : undefined }}>
                  {[...active.elements].sort((a, b) => a.zIndex - b.zIndex).map(el => {
                    const r = resolveRect(el, 'desktop');
                    if (r.hidden) return null;
                    return (
                      <div key={el.id} className="absolute" style={{ left: r.x, top: r.y, width: r.width, height: r.height, zIndex: el.zIndex, transform: el.rotation ? `rotate(${el.rotation}deg)` : undefined }}>
                        <ElementRenderer el={el} print data={data} />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 no-print">
        <Button variant="ghost" onClick={onClose}><X className="w-4 h-4" />بستن</Button>
        <Button onClick={handlePrint}><Printer className="w-4 h-4" />چاپ / ذخیره PDF</Button>
      </div>

      {printing && active && (
        <PrintSheet open title="پیش‌نمایش چاپ" onClose={() => setPrinting(false)}>
          <div id="print-area" className="relative bg-white shadow-2xl" style={{ width: page.width, minHeight: page.height, background: active.document.backgroundColor, border: active.document.showBorder ? `${active.document.borderWidth}px ${active.document.borderStyle} ${active.document.borderColor}` : undefined }}>
            {[...active.elements].sort((a, b) => a.zIndex - b.zIndex).map(el => {
              const r = resolveRect(el, 'desktop');
              if (r.hidden) return null;
              return (
                <div key={el.id} className="absolute" style={{ left: r.x, top: r.y, width: r.width, height: r.height, zIndex: el.zIndex, transform: el.rotation ? `rotate(${el.rotation}deg)` : undefined }}>
                  <ElementRenderer el={el} print data={data} />
                </div>
              );
            })}
          </div>
        </PrintSheet>
      )}
    </Modal>
  );
}

function defaultDoc() {
  return {
    id: 'preview', name: 'پیش‌نمایش', type: 'invoice', pageSize: 'A4', orientation: 'portrait',
    customWidth: 210, customHeight: 297, margins: { top: 12, right: 12, bottom: 12, left: 12 },
    backgroundColor: '#ffffff', backgroundImage: null, backgroundOpacity: 100,
    showBorder: false, borderColor: '#cbd5e1', borderWidth: 1, borderStyle: 'solid',
    gridColor: '#94a3b8', gridOpacity: 35, createdAt: '', updatedAt: '', version: 1, tags: [], description: '',
  } as PrintTemplate['document'];
}

function TemplateCard({ active, onClick, title, desc, badge }: { active: boolean; onClick: () => void; title: string; desc: string; badge: string }) {
  return (
    <button onClick={onClick} className={cn('w-full text-right p-3 rounded-xl border-2 transition-all', active ? 'border-teal-500 bg-teal-50/60 dark:bg-teal-900/20' : 'border-slate-200 dark:border-slate-700 hover:border-teal-300')}>
      <div className="flex items-center justify-between">
        <span className="font-bold text-sm text-slate-800 dark:text-slate-100 flex items-center gap-1.5">{active ? <Check className="w-4 h-4 text-teal-600" /> : badge === 'رسمی' ? <Star className="w-3.5 h-3.5 text-amber-500" /> : <FileText className="w-3.5 h-3.5 text-slate-400" />}{title}</span>
        <Badge color={badge === 'رسمی' ? 'amber' : 'teal'}>{badge}</Badge>
      </div>
      <p className="text-[11px] text-slate-500 mt-1 leading-4">{desc}</p>
    </button>
  );
}
