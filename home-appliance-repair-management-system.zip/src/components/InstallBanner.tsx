import { useState } from 'react';
import { Download, X, Smartphone, Sparkles } from 'lucide-react';
import { Button } from './ui';
import { useApp } from '../context/AppContext';
import { usePwaInstall } from '../hooks/usePwaInstall';
import { cn } from '../utils/cn';

export function InstallBanner() {
  const { db } = useApp();
  const { canInstall, promptInstall, dismiss } = usePwaInstall();
  const [busy, setBusy] = useState(false);
  if (!canInstall) return null;

  const handleInstall = async () => {
    setBusy(true);
    const result = await promptInstall();
    setBusy(false);
    if (result === 'unavailable') {
      // iOS Safari / unsupported — show manual instructions
      alert('برای نصب: دکمه «اشتراک‌گذاری» در مرورگر را بزنید و گزینه «افزودن به صفحه اصلی» را انتخاب کنید.');
    }
  };

  return (
    <div className="fixed bottom-24 lg:bottom-6 left-1/2 -translate-x-1/2 z-[200] w-[94%] max-w-md animate-slide-up no-print">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-teal-600 to-emerald-700 text-white shadow-2xl">
        <div className="absolute -top-8 -left-8 w-28 h-28 rounded-full bg-white/10" />
        <div className="absolute -bottom-10 -right-6 w-32 h-32 rounded-full bg-white/5" />
        <button onClick={dismiss} className="absolute top-2 left-2 p-1.5 rounded-full bg-white/15 hover:bg-white/25 transition-colors z-10">
          <X className="w-4 h-4" />
        </button>
        <div className="relative flex items-center gap-3 p-4">
          <div className="w-12 h-12 rounded-2xl bg-white/15 backdrop-blur flex items-center justify-center shrink-0">
            <Smartphone className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-extrabold text-sm flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              نصب {db.settings.shopName}
            </p>
            <p className="text-[11px] text-white/80 mt-0.5 leading-4">
              اپلیکیشن را روی گوشی خود نصب کنید تا دسترسی سریع و آفلین داشته باشید.
            </p>
            <Button size="sm" className="mt-2 bg-white text-teal-700 hover:bg-white/90 shadow-none" onClick={handleInstall} loading={busy}>
              <Download className="w-4 h-4" />نصب اپلیکیشن
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

/** Floating compact install button shown when banner dismissed but still installable */
export function InstallFab() {
  const { canInstall, promptInstall } = usePwaInstall();
  if (!canInstall) return null;
  return (
    <button
      onClick={() => promptInstall()}
      className={cn('fixed bottom-24 lg:bottom-6 right-4 z-[150] w-12 h-12 rounded-full bg-teal-600 text-white shadow-2xl flex items-center justify-center active:scale-90 transition-transform no-print')}
      title="نصب اپلیکیشن"
    >
      <Download className="w-5 h-5" />
    </button>
  );
}
