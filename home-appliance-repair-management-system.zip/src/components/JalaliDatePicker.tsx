import { useState, useEffect, useMemo } from 'react';
import { Calendar, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { cn } from '../utils/cn';
import { gregorianToJalali, getMonthGrid, getPersianMonths, getPersianWeekdaysShort, isHoliday, isToday, toPersianDigits, formatJalali, parseJalali } from '../lib/jalali';

interface JalaliDatePickerProps {
  value?: string;
  onChange: (isoDate: string, jalaliText: string) => void;
  label?: string;
  placeholder?: string;
  error?: string;
  className?: string;
  withTime?: boolean;
}
export function JalaliDatePicker({ value, onChange, label, placeholder = 'انتخاب تاریخ', error, className = '', withTime = false }: JalaliDatePickerProps) {
  const [open, setOpen] = useState(false);
  const today = new Date();
  const [jy, setJy] = useState(() => gregorianToJalali(today.getFullYear(), today.getMonth() + 1, today.getDate())[0]);
  const [jm, setJm] = useState(() => gregorianToJalali(today.getFullYear(), today.getMonth() + 1, today.getDate())[1]);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [timeHours, setTimeHours] = useState(10);
  const [timeMinutes, setTimeMinutes] = useState(0);
  const [inputValue, setInputValue] = useState('');

  useEffect(() => {
    if (value) {
      const dd = new Date(value);
      if (!isNaN(dd.getTime())) {
        const [y, m] = gregorianToJalali(dd.getFullYear(), dd.getMonth() + 1, dd.getDate());
        setJy(y); setJm(m); setSelectedDate(dd); setInputValue(formatJalali(dd));
      }
    }
  }, [value]);

  const monthDays = useMemo(() => getMonthGrid(jy, jm), [jy, jm]);
  const months = getPersianMonths();
  const prevMonth = () => { if (jm === 1) { setJm(12); setJy(jy - 1); } else setJm(jm - 1); };
  const nextMonth = () => { if (jm === 12) { setJm(1); setJy(jy + 1); } else setJm(jm + 1); };

  const selectDate = (d: Date) => { setSelectedDate(d); if (withTime) d.setHours(timeHours, timeMinutes, 0, 0); setInputValue(formatJalali(d, { withTime })); onChange(d.toISOString(), formatJalali(d, { withTime })); if (!withTime) setOpen(false); };
  const confirmTime = () => { if (selectedDate) { const d = new Date(selectedDate); d.setHours(timeHours, timeMinutes, 0, 0); setInputValue(formatJalali(d, { withTime: true })); onChange(d.toISOString(), formatJalali(d, { withTime: true })); setOpen(false); } };
  const handleManualInput = (text: string) => { setInputValue(text); const parsed = parseJalali(text); if (parsed) { setSelectedDate(parsed); const [y, m] = gregorianToJalali(parsed.getFullYear(), parsed.getMonth() + 1, parsed.getDate()); setJy(y); setJm(m); onChange(parsed.toISOString(), formatJalali(parsed, { withTime })); } };
  const clear = () => { setSelectedDate(null); setInputValue(''); onChange('', ''); };

  return (
    <div className={cn('space-y-1.5', className)}>
      {label && <label className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>}
      <div className="relative">
        <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
        <input type="text" value={toPersianDigits(inputValue)} onChange={e => handleManualInput(e.target.value)} onFocus={() => setOpen(true)} placeholder={placeholder} className={cn('w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 pr-10 text-sm cursor-pointer dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:placeholder:text-slate-500', error && 'border-red-400')} />
        {inputValue && <button onClick={clear} className="absolute left-3 top-1/2 -translate-y-1/2 p-0.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"><X className="w-3.5 h-3.5 text-slate-400" /></button>}
      </div>
      {error && <p className="text-xs text-red-500">{error}</p>}
      {open && (
        <div className="absolute z-40 mt-1 w-72 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 p-3 animate-scale-in">
          <div className="flex items-center justify-between mb-3"><button onClick={prevMonth} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"><ChevronRight className="w-4 h-4" /></button><div className="text-sm font-semibold text-slate-900 dark:text-slate-100">{months[jm - 1]} {toPersianDigits(jy)}</div><button onClick={nextMonth} className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"><ChevronLeft className="w-4 h-4" /></button></div>
          <div className="grid grid-cols-7 gap-1 mb-2">{getPersianWeekdaysShort().map(w => <div key={w} className="text-center text-[10px] text-slate-400 font-medium py-1">{w}</div>)}</div>
          <div className="grid grid-cols-7 gap-1">
            {monthDays.map((dd, idx) => {
              const [, m, day] = gregorianToJalali(dd.getFullYear(), dd.getMonth() + 1, dd.getDate());
              const inCurrentMonth = m === jm;
              const isSelectedDate = selectedDate && dd.toDateString() === selectedDate.toDateString();
              const t = isToday(dd); const holi = isHoliday(dd);
              return <button key={idx} onClick={() => selectDate(dd)} className={cn('cal-day', !inCurrentMonth && 'disabled', isSelectedDate && 'selected', t && !isSelectedDate && 'today', holi && !isSelectedDate && 'holiday')} disabled={!inCurrentMonth}>{toPersianDigits(day)}</button>;
            })}
          </div>
          {withTime && (
            <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700">
              <div className="flex items-center gap-2 justify-center">
                <div className="flex flex-col items-center"><label className="text-xs text-slate-500 mb-1">ساعت</label><input type="number" min={0} max={23} value={toPersianDigits(String(timeHours).padStart(2, '0'))} onChange={e => setTimeHours(parseInt(e.target.value) || 0)} className="w-14 text-center rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 py-1.5 text-sm" /></div>
                <span className="text-slate-400 mt-4">:</span>
                <div className="flex flex-col items-center"><label className="text-xs text-slate-500 mb-1">دقیقه</label><input type="number" min={0} max={59} value={toPersianDigits(String(timeMinutes).padStart(2, '0'))} onChange={e => setTimeMinutes(parseInt(e.target.value) || 0)} className="w-14 text-center rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 py-1.5 text-sm" /></div>
              </div>
              <div className="flex gap-2 mt-3"><button onClick={() => setOpen(false)} className="flex-1 py-1.5 text-sm rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700">انصراف</button><button onClick={confirmTime} className="flex-1 py-1.5 text-sm rounded-lg bg-teal-600 text-white hover:bg-teal-700">تایید</button></div>
            </div>
          )}
          {!withTime && <div className="mt-3 pt-2 flex justify-end"><button onClick={() => setOpen(false)} className="text-xs text-slate-500 hover:text-slate-700">بستن</button></div>}
        </div>
      )}
      {open && <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />}
    </div>
  );
}
