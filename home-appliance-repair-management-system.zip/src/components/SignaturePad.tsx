import { useRef, forwardRef, useImperativeHandle, useState } from 'react';
import SignatureCanvas from 'react-signature-canvas';
import { Eraser } from 'lucide-react';

export interface SignaturePadHandle { clear: () => void; isEmpty: () => boolean; toDataURL: () => string }
export const SignaturePad = forwardRef<SignaturePadHandle, { label?: string }>(({ label = 'امضا' }, ref) => {
  const sigRef = useRef<SignatureCanvas>(null);
  const [hasSigned, setHasSigned] = useState(false);
  useImperativeHandle(ref, () => ({ clear: () => { sigRef.current?.clear(); setHasSigned(false); }, isEmpty: () => sigRef.current?.isEmpty() ?? true, toDataURL: () => sigRef.current?.toDataURL('image/png') || '' }));
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>
        <button onClick={() => { sigRef.current?.clear(); setHasSigned(false); }} className="text-xs text-slate-500 flex items-center gap-1 hover:text-slate-700"><Eraser className="w-3.5 h-3.5" />پاک کردن</button>
      </div>
      <div className="signature-canvas w-full h-40"><SignatureCanvas ref={sigRef} penColor="#0f172a" canvasProps={{ className: 'w-full h-full rounded-lg touch-none' }} onEnd={() => setHasSigned(!sigRef.current?.isEmpty())} /></div>
      {hasSigned && <p className="text-xs text-emerald-600">✓ امضا ثبت شد</p>}
    </div>
  );
});
SignaturePad.displayName = 'SignaturePad';
