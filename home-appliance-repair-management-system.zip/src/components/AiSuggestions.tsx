import { useMemo, useState } from 'react';
import { AlertCircle, Check, Wrench } from 'lucide-react';
import { searchErrors, searchTestModes } from '../lib/kbEngine';
import { Button } from './ui';
import { cn } from '../utils/cn';

interface Props { deviceType: string; brand: string; text: string; onApply: (suggested: string) => void }

export function AiSuggestions({ deviceType, brand, text, onApply }: Props) {
  const [checked, setChecked] = useState<Record<string, boolean>>({});
  const [show, setShow] = useState(false);

  const matches = useMemo(() => {
    const q = text.trim() || brand || deviceType;
    if (!q.trim()) return [];
    const errs = searchErrors(q, { brand: brand || undefined, deviceType: deviceType || undefined, model: undefined }).slice(0, 3)
      .map(e => ({ id: `err-${e.code}`, kind: 'error' as const, label: `${e.code} — ${e.label}`, brand: e.brand, deviceType: e.deviceType, solution: e.solution }));
    const tms = searchTestModes(q, { brand: brand || undefined, deviceType: deviceType || undefined, model: undefined }).slice(0, 3)
      .map(tm => ({ id: `tm-${tm.id}`, kind: 'testmode' as const, label: tm.title, brand: tm.brand, deviceType: tm.deviceType, solution: tm.steps }));
    return [...errs, ...tms];
  }, [text, brand, deviceType]);

  const applySelected = () => {
    const chosen = matches.filter(m => checked[m.id]);
    if (chosen.length === 0) return;
    const lines = chosen.map(m => `• ${m.label}${'solution' in m && m.solution?.length ? ` (${m.solution[0]})` : ''}`).join('\n');
    onApply(lines);
    setChecked({});
  };

  if (matches.length === 0) return null;

  return (
    <div className="mt-3 border border-teal-200 dark:border-teal-800 rounded-xl overflow-hidden">
      <button type="button" onClick={() => setShow(s => !s)}
        className="w-full flex items-center justify-between gap-2 px-3 py-2 bg-teal-50 dark:bg-teal-900/20 text-teal-800 dark:text-teal-300 text-xs font-bold">
        <span className="flex items-center gap-1.5"><Wrench className="w-4 h-4" />پیشنهاد هوشمند بر اساس شرح خرابی</span>
        <span className="text-[10px] bg-white/70 dark:bg-slate-800 rounded-full px-2 py-0.5">{matches.length} مورد</span>
      </button>
      {show && (
        <div className="p-2 space-y-1.5 bg-white dark:bg-slate-900">
          {matches.map(m => (
            <label key={m.id} className="flex items-start gap-2 p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer">
              <input type="checkbox" checked={!!checked[m.id]} onChange={e => setChecked(prev => ({ ...prev, [m.id]: e.target.checked }))} className="mt-1 w-4 h-4 accent-teal-600 shrink-0" />
              <span className="flex-1 min-w-0">
                <span className="flex items-center gap-1.5 flex-wrap">
                  <span className={cn('text-[9px] px-1.5 py-0.5 rounded font-bold', m.kind === 'error' ? 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300' : 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300')}>{m.kind === 'error' ? 'ارور' : 'تست‌مود'}</span>
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-100">{m.label}</span>
                </span>
                {'solution' in m && m.solution?.length ? <span className="text-[10px] text-slate-500 block mt-0.5 line-clamp-2">{m.solution[0]}</span> : null}
              </span>
              {checked[m.id] && <Check className="w-4 h-4 text-teal-600 mt-0.5 shrink-0" />}
            </label>
          ))}
          <Button size="sm" className="w-full" onClick={applySelected} disabled={!Object.values(checked).some(Boolean)}>
            <AlertCircle className="w-4 h-4" />
            درج انتخاب‌شده‌ها در شرح خرابی
          </Button>
        </div>
      )}
    </div>
  );
}
