import { useState, useEffect, useContext, useCallback, createContext, type ReactNode, type ButtonHTMLAttributes, type InputHTMLAttributes, type TextareaHTMLAttributes, type SelectHTMLAttributes } from 'react';
import { X, Search, ChevronDown, Check } from 'lucide-react';
import { cn } from '../utils/cn';
import { toPersianDigits, toEnglishDigits } from '../lib/jalali';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline' | 'success';
  size?: 'sm' | 'md' | 'lg' | 'icon';
  loading?: boolean;
}
export function Button({ variant = 'primary', size = 'md', loading = false, className = '', children, disabled, ...props }: ButtonProps) {
  const variants = {
    primary: 'bg-gradient-to-b from-teal-500 to-teal-600 hover:to-teal-700 text-white shadow-lg shadow-teal-500/25',
    secondary: 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200',
    ghost: 'hover:bg-slate-100 text-slate-700 dark:hover:bg-slate-800 dark:text-slate-200',
    danger: 'bg-gradient-to-b from-rose-500 to-red-600 text-white shadow-lg shadow-red-500/25',
    outline: 'border border-slate-300 hover:bg-slate-50 text-slate-700 dark:border-slate-600 dark:hover:bg-slate-800 dark:text-slate-200',
    success: 'bg-gradient-to-b from-emerald-500 to-emerald-600 text-white shadow-lg shadow-emerald-500/25',
  };
  const sizes = { sm: 'px-3 py-2 text-xs rounded-xl', md: 'px-4 py-2.5 text-sm rounded-xl', lg: 'px-6 py-3.5 text-base rounded-2xl', icon: 'p-2.5 rounded-xl' };
  return (
    <button className={cn('inline-flex items-center justify-center gap-2 font-semibold transition-all duration-200 active:scale-[0.96] disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100', variants[variant], sizes[size], className)} disabled={disabled || loading} {...props}>
      {loading && (<svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeOpacity="0.25" /><path d="M4 12a8 8 0 018-8" stroke="currentColor" strokeWidth="3" strokeLinecap="round" /></svg>)}
      {children}
    </button>
  );
}

interface CardProps { children: ReactNode; className?: string; onClick?: () => void; hover?: boolean }
export function Card({ children, className = '', onClick, hover = false }: CardProps) {
  return <div onClick={onClick} className={cn('bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/60 dark:border-slate-700/60 shadow-sm', hover && 'hover-lift cursor-pointer active:scale-[0.99]', className)}>{children}</div>;
}

interface InputProps extends InputHTMLAttributes<HTMLInputElement> { label?: string; error?: string; icon?: ReactNode; persianDigits?: boolean }
export function Input({ label, error, icon, persianDigits: pd = false, className = '', onChange, value, ...props }: InputProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => { if (onChange) { if (pd && typeof e.target.value === 'string') { e.target.value = toEnglishDigits(e.target.value); } onChange(e); } };
  return (
    <div className="space-y-1.5">
      {label && <label className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>}
      <div className="relative">
        {icon && <div className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none">{icon}</div>}
        <input className={cn('w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm placeholder:text-slate-400 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:placeholder:text-slate-500', icon && 'pr-10', error && 'border-red-400 dark:border-red-500', className)} value={pd && typeof value === 'string' ? toPersianDigits(value) : value} onChange={handleChange} {...props} />
      </div>
      {error && <p className="text-xs text-red-500">{error}</p>}
    </div>
  );
}

interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> { label?: string }
export function Textarea({ label, className = '', ...props }: TextareaProps) {
  return <div className="space-y-1.5">{label && <label className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>}<textarea className={cn('w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm placeholder:text-slate-400 resize-y min-h-[80px] dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:placeholder:text-slate-500', className)} {...props} /></div>;
}

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> { label?: string; options: { value: string; label: string }[] }
export function Select({ label, options, className = '', ...props }: SelectProps) {
  return <div className="space-y-1.5">{label && <label className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>}<div className="relative"><select className={cn('w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm appearance-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100', className)} {...props}>{options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</select><ChevronDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" /></div></div>;
}

export function Badge({ children, color = 'slate', className = '' }: { children: ReactNode; color?: string; className?: string }) {
  const colors: Record<string, string> = {
    slate: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300', teal: 'bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-400',
    amber: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400', blue: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
    purple: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400', orange: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400',
    green: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400', red: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
  };
  return <span className={cn('inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium', colors[color] || colors.slate, className)}>{children}</span>;
}

interface ModalProps { open: boolean; onClose: () => void; title?: string; children: ReactNode; size?: 'sm' | 'md' | 'lg' | 'xl' }
export function Modal({ open, onClose, title, children, size = 'md' }: ModalProps) {
  useEffect(() => { if (open) { document.body.style.overflow = 'hidden'; return () => { document.body.style.overflow = ''; }; } }, [open]);
  if (!open) return null;
  const sizes = { sm: 'max-w-md', md: 'max-w-2xl', lg: 'max-w-4xl', xl: 'max-w-6xl' };
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in">
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className={cn('relative w-full bg-white dark:bg-slate-900 rounded-t-[28px] sm:rounded-2xl shadow-2xl max-h-[92vh] overflow-hidden flex flex-col animate-sheet-up safe-bottom', sizes[size])}>
        <div className="sm:hidden w-10 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 mx-auto mt-2.5" />
        {title && (<div className="flex items-center justify-between px-4 py-3 border-b border-slate-100 dark:border-slate-800"><h3 className="text-base font-bold text-slate-900 dark:text-slate-100">{title}</h3><button onClick={onClose} className="p-2 -ml-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full active:scale-90 transition-transform"><X className="w-5 h-5" /></button></div>)}
        <div className="overflow-y-auto p-4 flex-1">{children}</div>
      </div>
    </div>
  );
}

const LOADING_STEPS = ['راه‌اندازی هسته سامانه', 'بارگذاری دفاتر حسابداری', 'همگام‌سازی سفارشات و ماموریت‌ها', 'آماده‌سازی داشبورد'];
export function LoadingScreen() {
  const [step, setStep] = useState(0);
  const [progress, setProgress] = useState(8);
  useEffect(() => { const s = setInterval(() => setStep(p => (p < LOADING_STEPS.length - 1 ? p + 1 : p)), 220); const p = setInterval(() => setProgress(v => (v < 96 ? v + Math.max(2, (100 - v) * 0.18) : v)), 90); return () => { clearInterval(s); clearInterval(p); }; }, []);
  return (
    <div className="fixed inset-0 z-[100] bg-gradient-to-b from-teal-600 via-teal-700 to-emerald-800 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 flex items-center justify-center flex-col gap-7 px-10">
      <div className="relative w-32 h-32 flex items-center justify-center">
        <div className="absolute inset-0 rounded-full border-2 border-white/15" />
        <div className="absolute inset-0 animate-orbit"><span className="absolute top-0 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-white shadow-lg" /></div>
        <div className="w-20 h-20 rounded-[24px] bg-white/15 backdrop-blur-xl border border-white/25 flex items-center justify-center shadow-2xl animate-breathe"><span className="text-white font-black text-2xl">اتحاد</span></div>
      </div>
      <div className="text-center space-y-1.5"><h2 className="text-xl font-extrabold text-white">همیار سرویس اتحاد</h2><p className="text-xs text-white/75">سامانه جامع مدیریت تعمیرگاه لوازم خانگی</p></div>
      <div className="w-full max-w-xs space-y-2.5">
        <div className="h-1.5 w-full rounded-full bg-white/20 overflow-hidden"><div className="h-full rounded-full bg-white transition-all duration-200 ease-out" style={{ width: `${progress}%` }} /></div>
        <div className="flex items-center justify-between text-[11px] text-white/80"><span key={step} className="animate-fade-in">{LOADING_STEPS[step]}</span><span className="font-mono">{toPersianDigits(Math.round(progress))}٪</span></div>
      </div>
    </div>
  );
}

export function EmptyState({ icon, title, description, action }: { icon?: ReactNode; title: string; description?: string; action?: ReactNode }) {
  return <div className="flex flex-col items-center justify-center py-12 px-4 text-center">{icon && <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 mb-4">{icon}</div>}<h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 mb-1">{title}</h3>{description && <p className="text-sm text-slate-500 dark:text-slate-400 max-w-sm mb-4">{description}</p>}{action}</div>;
}

export function SearchInput({ value, onChange, placeholder = 'جستجو...', className = '' }: { value: string; onChange: (v: string) => void; placeholder?: string; className?: string }) {
  return <div className={cn('relative', className)}><Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" /><input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 pr-10 text-sm dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:placeholder:text-slate-500" /></div>;
}

interface StatCardProps { title: string; value: string | number; icon?: ReactNode; change?: string; changeType?: 'positive' | 'negative' | 'neutral'; color?: 'teal' | 'blue' | 'amber' | 'purple' | 'rose' | 'green' | 'orange' }
export function StatCard({ title, value, icon, change, changeType = 'neutral', color = 'teal' }: StatCardProps) {
  const colors: Record<string, string> = { teal: 'bg-teal-500', blue: 'bg-blue-500', amber: 'bg-amber-500', purple: 'bg-purple-500', rose: 'bg-rose-500', green: 'bg-green-500', orange: 'bg-orange-500' };
  return (
    <Card className="p-4 kpi-card" hover>
      <div className="flex items-start justify-between relative">
        <div><p className="text-xs text-slate-500 dark:text-slate-400 mb-1">{title}</p><p className="text-xl font-bold text-slate-900 dark:text-white">{value}</p>{change && <p className={cn('text-xs mt-1', changeType === 'positive' && 'text-emerald-600 dark:text-emerald-400', changeType === 'negative' && 'text-red-600 dark:text-red-400', changeType === 'neutral' && 'text-slate-500 dark:text-slate-400')}>{change}</p>}</div>
        {icon && <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center text-white', colors[color])}>{icon}</div>}
      </div>
    </Card>
  );
}

export function Avatar({ name, size = 'md', className = '' }: { name: string; size?: 'sm' | 'md' | 'lg'; className?: string }) {
  const sizes = { sm: 'w-8 h-8 text-xs', md: 'w-10 h-10 text-sm', lg: 'w-12 h-12 text-base' };
  const initials = name.split(' ').map(n => n[0]).slice(0, 2).join('');
  const colorSet = ['bg-teal-500', 'bg-blue-500', 'bg-amber-500', 'bg-purple-500', 'bg-rose-500', 'bg-indigo-500', 'bg-orange-500'];
  const colorIdx = name.charCodeAt(0) % colorSet.length;
  return <div className={cn('rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0', sizes[size], colorSet[colorIdx], className)}>{initials}</div>;
}

interface TabsProps { tabs: { value: string; label: string; icon?: ReactNode }[]; value: string; onChange: (v: string) => void; className?: string }
export function Tabs({ tabs, value, onChange, className = '' }: TabsProps) {
  return <div className={cn('inline-flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl', className)}>{tabs.map(t => <button key={t.value} onClick={() => onChange(t.value)} className={cn('flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all', value === t.value ? 'bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200')}>{t.icon}{t.label}</button>)}</div>;
}

export function Stepper({ steps, current }: { steps: { label: string }[]; current: number }) {
  return <div className="flex items-center justify-between w-full px-2">{steps.map((s, i) => (<div key={i} className="flex items-center flex-1 relative">{i < steps.length - 1 && <div className={cn('absolute top-4 right-8 h-0.5 flex-1', i < current ? 'bg-teal-500' : 'bg-slate-200 dark:bg-slate-700')} style={{ left: '-50%' }}></div>}<div className="flex flex-col items-center gap-1 relative z-10"><div className={cn('w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all', i < current ? 'bg-teal-500 border-teal-500 text-white' : i === current ? 'border-teal-500 text-teal-600 bg-white dark:bg-slate-900' : 'border-slate-300 dark:border-slate-600 text-slate-400')}>{i < current ? <Check className="w-4 h-4" /> : i + 1}</div><span className={cn('text-xs font-medium whitespace-nowrap', i === current ? 'text-teal-600' : 'text-slate-500 dark:text-slate-400')}>{s.label}</span></div></div>))}</div>;
}

type ToastType = 'success' | 'error' | 'info';
interface Toast { id: string; message: string; type: ToastType }
interface ToastContextValue { showToast: (message: string, type?: ToastType) => void }
const ToastContext = createContext<ToastContextValue | null>(null);
export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const showToast = useCallback((message: string, type: ToastType = 'success') => { const id = Math.random().toString(36); setToasts(t => [...t, { id, message, type }]); setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3500); }, []);
  const typeStyles: Record<ToastType, string> = { success: 'bg-emerald-500', error: 'bg-red-500', info: 'bg-blue-500' };
  return (<ToastContext.Provider value={{ showToast }}>{children}<div className="fixed bottom-20 sm:bottom-6 left-1/2 -translate-x-1/2 z-[999] space-y-2 w-full max-w-sm px-4 pointer-events-none">{toasts.map(t => <div key={t.id} className={cn('px-4 py-3 rounded-xl text-white text-sm font-medium shadow-lg animate-slide-up flex items-center gap-2', typeStyles[t.type])}>{t.type === 'success' && <Check className="w-4 h-4" />}{t.type === 'error' && <X className="w-4 h-4" />}{t.type === 'info' && <span>ℹ️</span>}{t.message}</div>)}</div></ToastContext.Provider>);
}
export function useToast() { const ctx = useContext(ToastContext); if (!ctx) throw new Error('useToast must be used within ToastProvider'); return ctx; }

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return <div className="flex items-start justify-between mb-6 gap-3"><div><h1 className="text-2xl font-bold text-slate-900 dark:text-white">{title}</h1>{subtitle && <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{subtitle}</p>}</div>{action}</div>;
}

export function CurrencyInput({ value, onChange, label, placeholder, className = '' }: { value: number; onChange: (n: number) => void; label?: string; placeholder?: string; className?: string }) {
  const [display, setDisplay] = useState('');
  useEffect(() => { setDisplay(value ? value.toLocaleString('en-US') : ''); }, [value]);
  return (
    <div className="space-y-1.5">
      {label && <label className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</label>}
      <input type="text" value={toPersianDigits(display)} onChange={e => { const raw = toEnglishDigits(e.target.value).replace(/[^\d]/g, ''); const num = parseInt(raw) || 0; setDisplay(num ? num.toLocaleString('en-US') : ''); onChange(num); }} placeholder={placeholder} className={cn('w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100', className)} />
    </div>
  );
}
