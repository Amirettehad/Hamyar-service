import { useEffect, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Printer, X } from 'lucide-react';
import { Button } from './ui';

interface PrintSheetProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
}

/**
 * Full-screen isolated print preview rendered in a body-level portal.
 * When printing, body gets the `printing` class which hides the entire app UI
 * and shows ONLY this sheet's content — guaranteeing a clean, professional print.
 */
export function PrintSheet({ open, onClose, title = 'پیش‌نمایش چاپ', children }: PrintSheetProps) {
  useEffect(() => {
    const cleanup = () => document.body.classList.remove('printing');
    if (open) {
      const handler = () => cleanup();
      window.addEventListener('afterprint', handler);
      return () => { window.removeEventListener('afterprint', handler); cleanup(); };
    }
    return undefined;
  }, [open]);

  if (!open) return null;

  const doPrint = () => {
    document.body.classList.add('printing');
    requestAnimationFrame(() => setTimeout(() => window.print(), 60));
  };

  return createPortal(
    <div className="print-sheet-host" style={{ direction: 'rtl' }}>
      <div className="sticky top-0 z-10 flex items-center justify-center gap-2 p-3 bg-slate-900/95 backdrop-blur no-print" style={{ position: 'sticky' }}>
        {title && <span className="text-white text-sm font-bold">{title}</span>}
        <Button onClick={doPrint}><Printer className="w-4 h-4" />چاپ / ذخیره PDF</Button>
        <Button variant="secondary" onClick={onClose}><X className="w-4 h-4" />بستن</Button>
      </div>
      <div className="flex justify-center p-4 md:p-6">{children}</div>
    </div>,
    document.body
  );
}
