import { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, Input, PageHeader, Badge, Textarea, Select, useToast } from '../components/ui';
import { JalaliDatePicker } from '../components/JalaliDatePicker';
import { Search, CalendarClock, Bot, CheckCircle, Clock, Phone, Sparkles } from 'lucide-react';
import { formatJalali, toPersianDigits, formatJalaliLong } from '../lib/jalali';
import { QRCodeSVG } from 'qrcode.react';
import { SERVICE_TYPES, DEVICE_TYPES } from '../lib/types';
import { cn } from '../utils/cn';

const TIME_SLOTS = ['08:00', '09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00', '18:00'];

export default function Agent() {
  const { db, addOrder, addCustomer, currentUser } = useApp();
  const { showToast } = useToast();
  const [mode, setMode] = useState<'query' | 'book'>('query');
  const [query, setQuery] = useState('');
  const [searched, setSearched] = useState(false);
  const [bookName, setBookName] = useState(currentUser?.fullName || '');
  const [bookPhone, setBookPhone] = useState(currentUser?.phone || '');
  const [bookAddress, setBookAddress] = useState('');
  const [bookDevice, setBookDevice] = useState(DEVICE_TYPES[0]);
  const [bookService, setBookService] = useState(SERVICE_TYPES[0]);
  const [bookDate, setBookDate] = useState('');
  const [bookTime, setBookTime] = useState('');
  const [bookTech, setBookTech] = useState('');
  const [bookDesc, setBookDesc] = useState('');
  const [bookedId, setBookedId] = useState<string | null>(null);

  const order = useMemo(() => { if (!query.trim()) return null; const q = query.trim(); return db.orders.find(o => o.requestNumber.includes(q) || o.id === q || db.customers.find(c => c.id === o.customerId)?.phone === q || db.customers.find(c => c.id === o.customerId)?.phone.includes(q)) || null; }, [db.orders, db.customers, query, searched]);
  const customer = order ? db.customers.find(c => c.id === order.customerId) : null;
  const tech = order ? db.technicians.find(t => t.id === order.technicianId) : null;
  const bookedSlots = useMemo(() => { if (!bookDate) return new Set<string>(); const day = new Date(bookDate).toDateString(); return new Set(db.orders.filter(o => o.visitDate && new Date(o.visitDate).toDateString() === day && o.visitTime).map(o => `${o.technicianId || ''}|${o.visitTime}`)); }, [db.orders, bookDate]);
  const availableTechs = db.technicians.filter(t => t.isActive);

  const submitBooking = () => {
    if (!bookName || !bookPhone) { showToast('نام و شماره تماس الزامی است', 'error'); return; }
    if (!bookDate || !bookTime) { showToast('تاریخ و ساعت مراجعه را انتخاب کنید', 'error'); return; }
    if (!bookDesc.trim()) { showToast('شرح خرابی را بنویسید', 'error'); return; }
    let customerId = currentUser?.customerId;
    if (!customerId) { const existing = db.customers.find(c => c.phone === bookPhone); customerId = existing?.id || addCustomer({ fullName: bookName, phone: bookPhone, address: bookAddress }); }
    const id = addOrder({ customerId, technicianId: bookTech || undefined, visitDate: bookDate, visitTime: bookTime, serviceType: bookService, status: 'در انتظار اعزام', problemDescription: `نوع دستگاه: ${bookDevice}\n${bookDesc}` });
    setBookedId(id); showToast('نوبت شما با موفقیت ثبت شد');
  };
  const bookedOrder = bookedId ? db.orders.find(o => o.id === bookedId) : null;

  return (
    <div className="space-y-4">
      <PageHeader title="دستیار هوشمند اتحاد" subtitle="استعلام وضعیت دستگاه و رزرو نوبت سرویسکار" />
      <div className="flex gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
        <button onClick={() => setMode('query')} className={cn('flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-medium transition-all', mode === 'query' ? 'bg-white dark:bg-slate-700 shadow text-teal-600' : 'text-slate-600 dark:text-slate-400')}><Search className="w-4 h-4" />استعلام وضعیت</button>
        <button onClick={() => setMode('book')} className={cn('flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-medium transition-all', mode === 'book' ? 'bg-white dark:bg-slate-700 shadow text-teal-600' : 'text-slate-600 dark:text-slate-400')}><CalendarClock className="w-4 h-4" />رزرو نوبت</button>
      </div>
      {mode === 'query' && (
        <div className="space-y-4 animate-fade-in">
          <Card className="p-5"><div className="flex items-start gap-3 mb-4"><div className="w-10 h-10 rounded-xl bg-teal-100 dark:bg-teal-900/30 flex items-center justify-center"><Bot className="w-5 h-5 text-teal-600" /></div><div><h3 className="font-semibold text-sm">دستیار پیگیری سفارش</h3><p className="text-xs text-slate-500 mt-0.5">شماره سفارش، شماره قبض یا شماره موبایل خود را وارد کنید.</p></div></div><div className="flex flex-col sm:flex-row gap-2"><Input value={query} onChange={e => setQuery(e.target.value)} placeholder="SRV-1403-0001 یا ۰۹۱۵..." className="flex-1" /><Button onClick={() => setSearched(true)}>استعلام</Button></div></Card>
          {searched && order && <Card className="p-5 animate-slide-up space-y-4"><div className="flex items-center justify-between"><div><p className="font-mono font-bold text-teal-600">{order.requestNumber}</p><p className="text-sm mt-1">{customer?.fullName}</p></div><Badge color="teal">{order.status}</Badge></div><div className="grid grid-cols-2 gap-3 text-sm"><div><p className="text-xs text-slate-500">نوع سرویس</p><p>{order.serviceType}</p></div><div><p className="text-xs text-slate-500">تکنسین</p><p>{tech?.fullName || 'در حال تخصیص'}</p></div>{order.visitDate && <div><p className="text-xs text-slate-500">تاریخ مراجعه</p><p className="font-mono">{toPersianDigits(formatJalali(new Date(order.visitDate)))} {order.visitTime && toPersianDigits(order.visitTime)}</p></div>}</div>{order.technicianReport && <div className="p-3 rounded-xl bg-teal-50 dark:bg-teal-900/20 text-sm">{order.technicianReport}</div>}<div className="flex justify-center"><div className="qr-wrapper"><QRCodeSVG value={order.requestNumber} size={110} /></div></div></Card>}
          {searched && !order && <Card className="p-8 text-center"><p className="text-sm font-semibold">سفارشی با این مشخصات پیدا نشد</p><p className="text-xs text-slate-500 mt-1">شماره سفارش یا موبایل را بررسی کنید</p></Card>}
        </div>
      )}
      {mode === 'book' && !bookedOrder && (
        <div className="space-y-4 animate-fade-in">
          <Card className="p-5 space-y-4"><div className="flex items-center gap-2 mb-1"><Sparkles className="w-4 h-4 text-amber-500" /><h3 className="font-semibold text-sm">رزرو نوبت با تکنسین</h3></div><div className="grid grid-cols-1 sm:grid-cols-2 gap-3"><Input label="نام و نام خانوادگی" value={bookName} onChange={e => setBookName(e.target.value)} /><Input label="شماره تماس" value={bookPhone} onChange={e => setBookPhone(e.target.value)} /><div className="sm:col-span-2"><Input label="آدرس" value={bookAddress} onChange={e => setBookAddress(e.target.value)} /></div><Select label="نوع دستگاه" value={bookDevice} onChange={e => setBookDevice(e.target.value as typeof DEVICE_TYPES[number])} options={DEVICE_TYPES.map(d => ({ value: d, label: d }))} /><Select label="نوع سرویس" value={bookService} onChange={e => setBookService(e.target.value as typeof SERVICE_TYPES[number])} options={SERVICE_TYPES.map(s => ({ value: s, label: s }))} /><JalaliDatePicker label="تاریخ مراجعه" value={bookDate} onChange={iso => { setBookDate(iso); setBookTime(''); }} /><Select label="تکنسین (اختیاری)" value={bookTech} onChange={e => setBookTech(e.target.value)} options={[{ value: '', label: 'اولین تکنسین آزاد' }, ...availableTechs.map(t => ({ value: t.id, label: `${t.fullName}${t.specialization ? ' — ' + t.specialization : ''}` }))]} /></div>{bookDate && <div><p className="text-sm font-medium mb-2 flex items-center gap-1"><Clock className="w-4 h-4" />ساعت‌های آزاد {toPersianDigits(formatJalaliLong(new Date(bookDate)))}</p><div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5">{TIME_SLOTS.map(slot => { const taken = bookedSlots.has(`${bookTech}|${slot}`) || (!bookTech && availableTechs.every(t => bookedSlots.has(`${t.id}|${slot}`))); return <button key={slot} disabled={taken} onClick={() => setBookTime(slot)} className={cn('py-2 rounded-lg text-xs font-mono font-semibold border transition-all', taken && 'opacity-40 cursor-not-allowed bg-slate-100 dark:bg-slate-800', !taken && bookTime === slot && 'bg-teal-600 text-white border-teal-600', !taken && bookTime !== slot && 'hover:border-teal-400 border-slate-200 dark:border-slate-700')}>{toPersianDigits(slot)}</button>; })}</div></div>}<Textarea label="شرح خرابی / درخواست" value={bookDesc} onChange={e => setBookDesc(e.target.value)} rows={3} placeholder="مثلاً یخچال سرمای کافی ندارد..." /><Button className="w-full" size="lg" onClick={submitBooking}>ثبت نوبت</Button></Card>
        </div>
      )}
      {bookedOrder && <Card className="p-6 text-center animate-scale-in space-y-3"><div className="w-14 h-14 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mx-auto"><CheckCircle className="w-7 h-7 text-emerald-600" /></div><h3 className="font-bold text-lg">نوبت شما ثبت شد</h3><p className="font-mono text-teal-600 font-bold">{bookedOrder.requestNumber}</p><p className="text-sm text-slate-500">{bookedOrder.visitDate && toPersianDigits(formatJalaliLong(new Date(bookedOrder.visitDate)))}{bookedOrder.visitTime && ` — ساعت ${toPersianDigits(bookedOrder.visitTime)}`}</p><div className="flex justify-center py-2"><div className="qr-wrapper"><QRCodeSVG value={bookedOrder.requestNumber} size={130} /></div></div><p className="text-xs text-slate-500 flex items-center justify-center gap-1"><Phone className="w-3 h-3" />در صورت نیاز با {toPersianDigits(db.settings.phone)} تماس بگیرید</p><Button variant="outline" onClick={() => { setBookedId(null); setBookDesc(''); setBookTime(''); }}>رزرو نوبت دیگر</Button></Card>}
    </div>
  );
}
