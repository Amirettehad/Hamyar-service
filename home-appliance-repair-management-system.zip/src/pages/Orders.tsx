import { useState, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, Input, Select, Textarea, PageHeader, SearchInput, Modal, Tabs, Stepper, useToast, EmptyState, CurrencyInput } from '../components/ui';
import { JalaliDatePicker } from '../components/JalaliDatePicker';
import { SignaturePad } from '../components/SignaturePad';
import { AiSuggestions } from '../components/AiSuggestions';
import { PrintTemplateSelector } from '../components/PrintTemplateSelector';
import { Plus, PlusCircle, Trash2, Eye, Printer, FileText, Calendar, Wrench, User, MapPin, ClipboardCheck, DollarSign, Package, CheckCircle, Share2, MessageSquare, Image as ImageIcon } from 'lucide-react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { formatJalali, toPersianDigits, formatCurrency, timeAgo } from '../lib/jalali';
import { partyBalance } from '../lib/accounting';
import { buildTrackingUrl, buildSmsTrackingText } from '../lib/shortLink';
import { DEVICE_TYPES, BRANDS, SERVICE_TYPES, ORDER_STATUSES, STATUS_COLORS, type PartItem, type OrderStatus, type ServiceOrder } from '../lib/types';
import { cn } from '../utils/cn';

export default function Orders() {
  const { id } = useParams();
  const navigate = useNavigate();
  if (id === 'new') return <NewOrderPage onDone={(oid) => navigate(`/orders/${oid}`)} />;
  if (id) return <OrderDetail orderId={id} />;
  return <OrdersList />;
}

function OrdersList() {
  const { db, currentUser } = useApp();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [view, setView] = useState<'list' | 'kanban'>('list');

  const orders = useMemo(() => {
    let list = db.orders;
    if (currentUser?.role === 'technician') list = list.filter(o => o.technicianId === currentUser.technicianId);
    if (currentUser?.role === 'customer') list = list.filter(o => o.customerId === currentUser.customerId);
    if (statusFilter !== 'all') list = list.filter(o => o.status === statusFilter);
    if (search) { const q = search.toLowerCase(); list = list.filter(o => { const customer = db.customers.find(c => c.id === o.customerId); return o.requestNumber.toLowerCase().includes(q) || customer?.fullName.includes(search) || customer?.phone.includes(search); }); }
    return list;
  }, [db.orders, db.customers, statusFilter, search, currentUser]);

  const statusCounts = useMemo(() => { const counts: Record<string, number> = { all: orders.length }; ORDER_STATUSES.forEach(s => { counts[s] = orders.filter(o => o.status === s).length; }); return counts; }, [orders]);

  return (
    <div className="space-y-4">
      <PageHeader title="مدیریت سفارشات" subtitle={`${toPersianDigits(orders.length)} سفارش ثبت شده`} action={currentUser?.role === 'admin' ? <Link to="/orders/new"><Button><Plus className="w-4 h-4" />سفارش جدید</Button></Link> : null} />
      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput value={search} onChange={setSearch} placeholder="جستجو بر اساس شماره، نام مشتری یا موبایل..." className="flex-1" />
        <Select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} options={[{ value: 'all', label: 'همه وضعیت‌ها' }, ...ORDER_STATUSES.map(s => ({ value: s, label: `${s} (${toPersianDigits(statusCounts[s] || 0)})` }))]} className="sm:w-60" />
        <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1"><button onClick={() => setView('list')} className={cn('px-3 py-1.5 rounded-lg text-xs font-medium', view === 'list' ? 'bg-white dark:bg-slate-700 shadow-sm text-teal-600' : 'text-slate-600 dark:text-slate-400')}>لیست</button><button onClick={() => setView('kanban')} className={cn('px-3 py-1.5 rounded-lg text-xs font-medium', view === 'kanban' ? 'bg-white dark:bg-slate-700 shadow-sm text-teal-600' : 'text-slate-600 dark:text-slate-400')}>برد کانبان</button></div>
      </div>
      {view === 'list' ? (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="data-table hidden md:table"><thead><tr><th>شماره</th><th>مشتری</th><th>سرویس</th><th>تکنسین</th><th>تاریخ مراجعه</th><th>مبلغ</th><th>وضعیت</th><th className="text-left">عملیات</th></tr></thead><tbody>{orders.map(o => { const customer = db.customers.find(c => c.id === o.customerId); const tech = db.technicians.find(t => t.id === o.technicianId); return (<tr key={o.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer" onClick={() => navigate(`/orders/${o.id}`)}><td className="font-mono text-xs font-semibold text-teal-700 dark:text-teal-400">{o.requestNumber}</td><td><div><p className="font-medium text-slate-900 dark:text-white text-sm">{customer?.fullName}</p><p className="text-xs text-slate-500">{customer?.phone}</p></div></td><td className="text-xs">{o.serviceType}</td><td className="text-xs">{tech?.fullName || '—'}</td><td className="text-xs">{o.visitDate ? toPersianDigits(formatJalali(new Date(o.visitDate))) : '—'}</td><td className="font-mono text-xs">{o.finalAmount > 0 ? formatCurrency(o.finalAmount) : '—'}</td><td><span className={cn('status-badge', STATUS_COLORS[o.status])}>{o.status}</span></td><td className="text-left"><Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); navigate(`/orders/${o.id}`); }}><Eye className="w-4 h-4" /></Button></td></tr>); })}</tbody></table>
            <div className="md:hidden divide-y divide-slate-100 dark:divide-slate-800">{orders.length === 0 && <EmptyState title="سفارشی یافت نشد" description="با تغییر فیلترها یا ثبت سفارش جدید شروع کنید." />}{orders.map(o => { const customer = db.customers.find(c => c.id === o.customerId); return (<div key={o.id} onClick={() => navigate(`/orders/${o.id}`)} className="p-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer"><div className="flex items-start justify-between mb-2"><div><p className="font-mono text-xs font-bold text-teal-700 dark:text-teal-400">{o.requestNumber}</p><p className="font-semibold text-sm text-slate-900 dark:text-white">{customer?.fullName}</p></div><span className={cn('status-badge text-[10px]', STATUS_COLORS[o.status])}>{o.status}</span></div><div className="flex items-center justify-between text-xs text-slate-500"><span>{o.serviceType}</span>{o.finalAmount > 0 && <span className="font-mono">{formatCurrency(o.finalAmount)}</span>}</div></div>); })}</div>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">{ORDER_STATUSES.map(status => (<div key={status} className="space-y-2"><div className={cn('px-3 py-2 rounded-xl font-semibold text-xs flex items-center justify-between', STATUS_COLORS[status])}><span>{status}</span><span>{toPersianDigits(orders.filter(o => o.status === status).length)}</span></div><div className="space-y-2 max-h-[500px] overflow-y-auto">{orders.filter(o => o.status === status).map(o => { const customer = db.customers.find(c => c.id === o.customerId); return (<Card key={o.id} className="p-3 hover-lift cursor-pointer" onClick={() => navigate(`/orders/${o.id}`)}><p className="font-mono text-[10px] text-teal-600 mb-1">{o.requestNumber}</p><p className="font-semibold text-xs text-slate-900 dark:text-white">{customer?.fullName}</p><p className="text-[10px] text-slate-500 mt-1">{o.serviceType}</p>{o.finalAmount > 0 && <p className="text-[10px] font-mono text-slate-700 dark:text-slate-300 mt-1">{formatCurrency(o.finalAmount)}</p>}</Card>); })}</div></div>))}</div>
      )}
    </div>
  );
}

function OrderDetail({ orderId }: { orderId: string }) {
  const { db, updateOrderStatus, generateInvoice, currentUser, updateOrder, addOrderPart, removeOrderPart } = useApp();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const order = db.orders.find(o => o.id === orderId);
  const [showPrint, setShowPrint] = useState(false);
  const [printType, setPrintType] = useState<'factor' | 'receipt'>('factor');
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [newPartName, setNewPartName] = useState('');
  const [newPartQty, setNewPartQty] = useState(1);
  const [newPartPrice, setNewPartPrice] = useState(0);
  const [showShareLink, setShowShareLink] = useState(false);

  if (!order) return <EmptyState title="سفارش یافت نشد" action={<Link to="/orders"><Button>بازگشت به لیست</Button></Link>} />;
  const customer = db.customers.find(c => c.id === order.customerId);
  const tech = db.technicians.find(t => t.id === order.technicianId);
  const device = db.devices.find(d => d.id === order.deviceId);
  const invoice = db.invoices.find(i => i.orderId === order.id);
  const shareLink = buildTrackingUrl(order);
  const smsText = buildSmsTrackingText(order, customer?.fullName || 'مشتری گرامی', db.settings.shopName);

  const handleChangeStatus = (newStatus: OrderStatus) => { updateOrderStatus(order.id, newStatus); showToast(`وضعیت به «${newStatus}» تغییر کرد`); setShowStatusModal(false); };
  const handleAddPart = () => { if (!newPartName) return; const part: PartItem = { id: `p-${Date.now()}`, name: newPartName, quantity: newPartQty, unitPrice: newPartPrice }; addOrderPart(order.id, part); setNewPartName(''); setNewPartQty(1); setNewPartPrice(0); showToast('قطعه اضافه شد'); };
  const statusStep = ORDER_STATUSES.indexOf(order.status);
  const steps = [{ label: 'ثبت' }, { label: 'اعزام' }, { label: 'تعمیر' }, { label: 'آماده' }, { label: 'تحویل' }];
  const currentStep = Math.min(Math.floor(statusStep / 2), 4);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-2"><Button variant="ghost" size="sm" onClick={() => navigate('/orders')}>← بازگشت</Button></div>
      <Card className="p-5">
        <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
          <div><div className="flex items-center gap-3 mb-2"><h2 className="text-xl font-bold text-slate-900 dark:text-white font-mono">{order.requestNumber}</h2><span className={cn('status-badge', STATUS_COLORS[order.status])}>{order.status}</span></div><p className="text-sm text-slate-600 dark:text-slate-400">{customer?.fullName} • {order.serviceType} • {tech?.fullName || 'بدون تکنسین'}</p><p className="text-xs text-slate-500 dark:text-slate-500 mt-1">ثبت شده در {formatJalali(new Date(order.registrationDate), { withWeekday: true, withTime: true })}</p></div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowShareLink(true)}><Share2 className="w-4 h-4" />لینک پیگیری مشتری</Button>
            <Button variant="outline" size="sm" onClick={() => { setPrintType('receipt'); setShowPrint(true); }}><Printer className="w-4 h-4" />رسید پذیرش</Button>
            {order.invoiceGenerated ? <Button variant="outline" size="sm" onClick={() => { setPrintType('factor'); setShowPrint(true); }}><FileText className="w-4 h-4" />مشاهده فاکتور</Button> : currentUser?.role === 'admin' ? <Button size="sm" onClick={() => { const r = generateInvoice(order.id); showToast(r.success ? 'فاکتور صادر و سند ثبت شد' : (r.error || 'خطا'), r.success ? 'success' : 'error'); }}><FileText className="w-4 h-4" />صدور فاکتور</Button> : null}
            {currentUser?.role === 'admin' && <Button size="sm" onClick={() => setShowStatusModal(true)}><CheckCircle className="w-4 h-4" />تغییر وضعیت</Button>}
          </div>
        </div>
        <div className="mt-6"><Stepper steps={steps} current={currentStep} /></div>
      </Card>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2 text-slate-900 dark:text-white"><User className="w-4 h-4 text-teal-600" />اطلاعات مشتری و دستگاه</h3><div className="grid grid-cols-2 gap-4 text-sm"><div><p className="text-xs text-slate-500 mb-1">نام مشتری</p><p className="font-semibold text-slate-900 dark:text-white">{customer?.fullName}</p></div><div><p className="text-xs text-slate-500 mb-1">شماره تماس</p><p className="font-mono ltr text-slate-900 dark:text-white inline-block">{toPersianDigits(customer?.phone || '')}</p></div>{customer?.phone2 && <div><p className="text-xs text-slate-500 mb-1">شماره تماس دوم</p><p className="font-mono ltr text-slate-900 dark:text-white inline-block">{toPersianDigits(customer.phone2)}</p></div>}{customer?.address && <div className="col-span-2"><p className="text-xs text-slate-500 mb-1 flex items-center gap-1"><MapPin className="w-3 h-3" />آدرس</p><p className="text-slate-900 dark:text-slate-200">{customer.address}</p></div>}<div className="col-span-2 border-t border-slate-100 dark:border-slate-700 pt-3 mt-1"><div className="grid grid-cols-2 sm:grid-cols-4 gap-3"><div><p className="text-xs text-slate-500 mb-1">نوع دستگاه</p><p className="font-semibold text-slate-900 dark:text-white">{device?.type || '—'}</p></div><div><p className="text-xs text-slate-500 mb-1">برند</p><p className="font-semibold text-slate-900 dark:text-white">{device?.brand || '—'}</p></div><div><p className="text-xs text-slate-500 mb-1">مدل</p><p className="font-semibold text-slate-900 dark:text-white">{device?.model || '—'}</p></div><div><p className="text-xs text-slate-500 mb-1">گارانتی</p><p className="font-semibold text-slate-900 dark:text-white">{device?.warrantyStatus || '—'}</p></div></div></div></div></Card>
          <Card className="p-5"><h3 className="font-semibold text-sm mb-3 flex items-center gap-2 text-slate-900 dark:text-white"><ClipboardCheck className="w-4 h-4 text-amber-500" />شرح خرابی اعلام شده</h3><p className="text-sm leading-7 text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg">{order.problemDescription || 'توضیحی ثبت نشده'}</p></Card>
          {(currentUser?.role === 'admin' || currentUser?.role === 'technician') ? (
            <Card className="p-5"><h3 className="font-semibold text-sm mb-3 flex items-center gap-2 text-slate-900 dark:text-white"><Wrench className="w-4 h-4 text-blue-500" />گزارش سرویسکار</h3><Textarea value={order.technicianReport || ''} onChange={e => updateOrder(order.id, { technicianReport: e.target.value })} placeholder="گزارش عملیات انجام شده، عیب‌یابی، اقدامات، تست‌ها..." rows={4} /></Card>
          ) : order.technicianReport ? <Card className="p-5"><h3 className="font-semibold text-sm mb-3 flex items-center gap-2 text-slate-900 dark:text-white"><Wrench className="w-4 h-4 text-blue-500" />گزارش سرویسکار</h3><p className="text-sm leading-7 text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg">{order.technicianReport}</p></Card> : null}
          <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2 text-slate-900 dark:text-white"><Package className="w-4 h-4 text-purple-500" />قطعات و خدمات مصرفی</h3><div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-xs text-slate-500 border-b border-slate-200 dark:border-slate-700"><th className="text-right pb-2">نام قطعه/خدمت</th><th className="text-center pb-2 w-16">تعداد</th><th className="text-left pb-2 w-28">قیمت واحد</th><th className="text-left pb-2 w-28">قیمت کل</th>{(currentUser?.role === 'admin' || currentUser?.role === 'technician') && <th className="w-10"></th>}</tr></thead><tbody>{order.parts.map(p => (<tr key={p.id} className="border-b border-slate-100 dark:border-slate-800"><td className="py-2 text-slate-900 dark:text-slate-100">{p.name}</td><td className="py-2 text-center font-mono">{toPersianDigits(p.quantity)}</td><td className="py-2 text-left font-mono">{formatCurrency(p.unitPrice)}</td><td className="py-2 text-left font-mono font-semibold">{formatCurrency(p.quantity * p.unitPrice)}</td>{(currentUser?.role === 'admin' || currentUser?.role === 'technician') && <td className="py-2"><button onClick={() => removeOrderPart(order.id, p.id)} className="text-red-500 hover:text-red-700 p-1"><Trash2 className="w-3.5 h-3.5" /></button></td>}</tr>))}{order.parts.length === 0 && <tr><td colSpan={5} className="py-4 text-center text-sm text-slate-400">قطعه‌ای ثبت نشده</td></tr>}</tbody></table></div>{(currentUser?.role === 'admin' || currentUser?.role === 'technician') && <div className="mt-4 grid grid-cols-1 sm:grid-cols-4 gap-2 pt-4 border-t border-slate-100 dark:border-slate-700"><input value={newPartName} onChange={e => setNewPartName(e.target.value)} placeholder="نام قطعه..." className="sm:col-span-2 rounded-lg border border-slate-200 dark:border-slate-700 dark:bg-slate-900 px-3 py-2 text-sm" /><input type="number" value={newPartQty} onChange={e => setNewPartQty(parseInt(e.target.value) || 1)} placeholder="تعداد" className="rounded-lg border border-slate-200 dark:border-slate-700 dark:bg-slate-900 px-3 py-2 text-sm" /><div className="flex gap-2"><input type="text" value={newPartPrice ? newPartPrice.toLocaleString('en-US') : ''} onChange={e => setNewPartPrice(parseInt(e.target.value.replace(/,/g, '')) || 0)} placeholder="قیمت" className="flex-1 rounded-lg border border-slate-200 dark:border-slate-700 dark:bg-slate-900 px-3 py-2 text-sm" /><Button size="sm" onClick={handleAddPart}><PlusCircle className="w-4 h-4" /></Button></div></div>}</Card>
          <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2 text-slate-900 dark:text-white"><DollarSign className="w-4 h-4 text-emerald-500" />خلاصه هزینه</h3><CostsEditor order={order} /></Card>
          {(currentUser?.role === 'admin' || currentUser?.role === 'technician') && <Card className="p-5"><h3 className="font-semibold text-sm mb-3 flex items-center gap-2 text-slate-900 dark:text-white"><ImageIcon className="w-4 h-4 text-rose-500" />پیوست‌ها</h3><input type="file" accept="image/*,application/pdf" className="block w-full text-xs mb-3" onChange={e => { const f = e.target.files?.[0]; if (!f) return; const reader = new FileReader(); reader.onload = () => { updateOrder(order.id, { attachments: [...order.attachments, { name: f.name, type: f.type, dataUrl: reader.result as string }] }); showToast('فایل پیوست شد'); }; reader.readAsDataURL(f); e.target.value = ''; }} /><div className="grid grid-cols-2 sm:grid-cols-3 gap-2">{order.attachments.map((a, i) => <div key={i} className="rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700">{a.type.startsWith('image/') ? <img src={a.dataUrl} alt={a.name} className="w-full h-28 object-cover" /> : <div className="h-28 flex items-center justify-center text-xs p-2">{a.name}</div>}<p className="text-[10px] p-1 truncate">{a.name}</p></div>)}</div></Card>}
          <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2 text-slate-900 dark:text-white"><Calendar className="w-4 h-4 text-indigo-500" />تاریخچه وضعیت</h3><div className="space-y-3">{order.statusHistory.map((h, i) => { const user = db.users.find(u => u.id === h.userId); return (<div key={i} className="flex gap-3"><div className="flex flex-col items-center"><div className="w-8 h-8 rounded-full bg-teal-100 dark:bg-teal-900/30 flex items-center justify-center flex-shrink-0"><CheckCircle className="w-4 h-4 text-teal-600" /></div>{i < order.statusHistory.length - 1 && <div className="w-0.5 flex-1 bg-teal-100 dark:bg-teal-900/30 mt-1"></div>}</div><div className="pb-3 flex-1"><div className="flex items-center justify-between"><p className="text-sm font-semibold text-slate-900 dark:text-white">{h.status}</p><span className="text-[10px] text-slate-500">{timeAgo(new Date(h.date))}</span></div><p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">توسط {user?.fullName || 'سیستم'}</p></div></div>); })}</div></Card>
        </div>
        <div className="space-y-4">
          <Card className="p-4"><h3 className="text-xs font-medium text-slate-500 mb-3">QR کد سفارش</h3><div className="flex justify-center p-4 bg-white rounded-xl border border-slate-200 dark:border-slate-700"><QRCodeSVG value={order.requestNumber} size={140} level="M" /></div><p className="text-[10px] text-slate-500 text-center mt-2">اسکن برای مشاهده اطلاعات سفارش</p></Card>
          <Card className="p-4"><h3 className="text-xs font-medium text-slate-500 mb-3">وضعیت حساب مشتری</h3>{(() => { const balance = partyBalance(db, 'customer', order.customerId); return (<div className="space-y-2"><div className="flex items-center justify-between"><span className="text-xs text-slate-500">مانده حساب</span><span className={cn('text-sm font-bold font-mono', balance > 0 ? 'text-red-600' : balance < 0 ? 'text-purple-600' : 'text-emerald-600')}>{formatCurrency(Math.abs(balance))} {balance > 0 ? '(بدهکار)' : balance < 0 ? '(بستانکار)' : ''}</span></div>{currentUser?.role === 'admin' && <Link to="/accounting"><Button variant="outline" size="sm" className="w-full mt-1">مشاهده در حسابداری</Button></Link>}</div>); })()}</Card>
          <Card className="p-4"><h3 className="text-xs font-medium text-slate-500 mb-3">اعلان‌رسانی به مشتری</h3><div className="space-y-2"><button onClick={() => { const text = encodeURIComponent(`سلام ${customer?.fullName || ''}\nوضعیت سفارش ${order.requestNumber}: ${order.status}\n${db.settings.shopName}`); const phone = (customer?.phone || '').replace(/^0/, '98'); window.open(`https://wa.me/${phone}?text=${text}`, '_blank'); showToast('واتساپ باز شد'); }} className="w-full flex items-center gap-2 p-2 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 text-xs font-medium hover:bg-emerald-100 dark:hover:bg-emerald-900/30 transition-colors"><MessageSquare className="w-4 h-4" />ارسال پیام واتساپ</button><button onClick={() => { const text = encodeURIComponent(`وضعیت سفارش ${order.requestNumber}: ${order.status}`); window.open(`https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${text}`, '_blank'); showToast('تلگرام باز شد'); }} className="w-full flex items-center gap-2 p-2 rounded-lg bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 text-xs font-medium hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors"><Share2 className="w-4 h-4" />ارسال از تلگرام</button><button onClick={() => { const body = encodeURIComponent(`وضعیت سفارش ${order.requestNumber}: ${order.status}`); window.open(`sms:${customer?.phone || ''}?body=${body}`); showToast('پیامک آماده ارسال است'); }} className="w-full flex items-center gap-2 p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"><ImageIcon className="w-4 h-4" />ارسال پیامک</button></div></Card>
        </div>
      </div>
      <Modal open={showStatusModal} onClose={() => setShowStatusModal(false)} title="تغییر وضعیت سفارش" size="sm"><div className="grid grid-cols-2 gap-2">{ORDER_STATUSES.map(s => <button key={s} onClick={() => handleChangeStatus(s)} className={cn('p-3 rounded-xl text-sm font-medium border-2 transition-all hover:scale-[0.98]', order.status === s ? 'border-teal-500 bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-300' : 'border-slate-200 dark:border-slate-700 hover:border-teal-300')}>{s}</button>)}</div></Modal>
      <Modal open={showShareLink} onClose={() => setShowShareLink(false)} title="لینک پیگیری آنلاین مشتری" size="md">
        <div className="space-y-3.5">
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-5">
            با ارسال این لینک کوتاه، مشتری می‌تواند <b>بدون نیاز به ثبت نام یا ورود</b>، وضعیت زنده دستگاه، فاکتور و امضای دیجیتال خود را ببیند و با مدیر و تکنسین گفتگو کند:
          </p>
          <div className="flex gap-2">
            <input readOnly value={shareLink} className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-2.5 text-xs font-mono ltr text-teal-700 font-bold" dir="ltr" />
            <Button size="sm" onClick={() => { navigator.clipboard.writeText(shareLink); showToast('لینک کوتاه کپی شد ✓', 'success'); }}>کپی لینک</Button>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-200">متن پیامک آماده اطلاع‌رسانی:</span>
              <button
                onClick={() => { navigator.clipboard.writeText(smsText); showToast('متن پیامک کپی شد ✓', 'success'); }}
                className="text-[11px] text-teal-600 font-bold hover:underline"
              >
                کپی متن پیامک
              </button>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 whitespace-pre-wrap leading-5 font-sans bg-white dark:bg-slate-950 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
              {smsText}
            </p>
            <div className="flex gap-2 pt-1">
              <a
                href={`sms:${customer?.phone || ''}?body=${encodeURIComponent(smsText)}`}
                className="flex-1 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold text-center"
              >
                ارسال پیامک به {customer?.fullName || 'مشتری'}
              </a>
              <a
                href={`https://wa.me/${(customer?.phone || '').replace(/^0/, '98')}?text=${encodeURIComponent(smsText)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold text-center"
              >
                ارسال از واتساپ
              </a>
            </div>
          </div>

          <div className="flex flex-col items-center justify-center py-2 gap-1">
            <div className="qr-wrapper shadow-sm">
              <QRCodeSVG value={shareLink} size={120} level="M" />
            </div>
            <span className="text-[10px] text-slate-400 font-mono">اسکن مستقیم لینک پیگیری</span>
          </div>
        </div>
      </Modal>
      <PrintTemplateSelector open={showPrint} onClose={() => setShowPrint(false)} order={order} invoice={invoice} printType={printType} />
    </div>
  );
}

function CostsEditor({ order }: { order: ServiceOrder }) {
  const { updateOrder } = useApp();
  const { showToast } = useToast();
  const [transportation, setTransportation] = useState(order.transportationCost);
  const [labor, setLabor] = useState(order.laborCost);
  const [discount, setDiscount] = useState(order.discount);
  const [other, setOther] = useState(order.otherCosts);
  const partsTotal = order.parts.reduce((s, p) => s + p.quantity * p.unitPrice, 0);
  const final = labor + partsTotal + transportation + other - discount;
  const save = () => { updateOrder(order.id, { transportationCost: transportation, laborCost: labor, discount, otherCosts: other }); showToast('هزینه‌ها به‌روز شد'); };
  return (
    <div className="space-y-3">
      <CurrencyInput label="اجرت تعمیر" value={labor} onChange={setLabor} />
      <CurrencyInput label="هزینه ایاب و ذهاب" value={transportation} onChange={setTransportation} />
      <CurrencyInput label="سایر هزینه‌ها" value={other} onChange={setOther} />
      <CurrencyInput label="تخفیف" value={discount} onChange={setDiscount} />
      <div className="flex justify-between items-center p-3 rounded-xl bg-teal-50 dark:bg-teal-900/20 border border-teal-200 dark:border-teal-800"><span className="text-sm font-semibold text-teal-800 dark:text-teal-300">مبلغ نهایی</span><span className="text-lg font-bold text-teal-700 dark:text-teal-300 font-mono">{formatCurrency(final)}</span></div>
      <Button size="sm" onClick={save} className="w-full">ذخیره هزینه‌ها</Button>
    </div>
  );
}

function NewOrderPage({ onDone }: { onDone: (id: string) => void }) {
  const { db, addOrder, addCustomer, addDevice } = useApp();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const sigRef = useRef<{ isEmpty: () => boolean; toDataURL: () => string; clear: () => void }>(null);
  const [customerId, setCustomerId] = useState('');
  const [newCustomerMode, setNewCustomerMode] = useState(false);
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustPhone2, setNewCustPhone2] = useState('');
  const [newCustAddr, setNewCustAddr] = useState('');
  const [deviceType, setDeviceType] = useState(DEVICE_TYPES[0]);
  const [deviceBrand, setDeviceBrand] = useState(BRANDS[0]);
  const [deviceModel, setDeviceModel] = useState('');
  const [serialNumber, setSerialNumber] = useState('');
  const [warrantyStatus, setWarrantyStatus] = useState<'داخل گارانتی' | 'خارج از گارانتی'>('خارج از گارانتی');
  const [technicianId, setTechnicianId] = useState('');
  const [visitDate, setVisitDate] = useState('');
  const [visitTime, setVisitTime] = useState('10:00');
  const [serviceType, setServiceType] = useState<typeof SERVICE_TYPES[number]>('تعمیر');
  const [problemDescription, setProblemDescription] = useState('');

  const handleSubmit = (asDraft = false) => {
    if (!newCustomerMode && !customerId) { showToast('مشتری را انتخاب کنید یا مشتری جدید ایجاد کنید', 'error'); return; }
    if (!problemDescription.trim()) { showToast('شرح خرابی را وارد کنید', 'error'); return; }
    let cId = customerId;
    if (newCustomerMode) { if (!newCustName || !newCustPhone) { showToast('نام و شماره مشتری را وارد کنید', 'error'); return; } cId = addCustomer({ fullName: newCustName, phone: newCustPhone, phone2: newCustPhone2, address: newCustAddr }); }
    const deviceId = addDevice({ customerId: cId, type: deviceType, brand: deviceBrand, model: deviceModel, serialNumber, warrantyStatus });
    let sig: string | undefined; if (sigRef.current && !sigRef.current.isEmpty()) sig = sigRef.current.toDataURL();
    const orderId = addOrder({ customerId: cId, deviceId, technicianId: technicianId || undefined, visitDate: visitDate || undefined, visitTime, serviceType, status: asDraft ? 'ثبت اولیه' : 'در انتظار اعزام', problemDescription, customerSignature: sig, confirmerName: newCustomerMode ? newCustName : db.customers.find(c => c.id === cId)?.fullName });
    showToast('سفارش با موفقیت ثبت شد'); onDone(orderId);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2"><Button variant="ghost" size="sm" onClick={() => navigate('/orders')}>← انصراف</Button><h2 className="text-xl font-bold text-slate-900 dark:text-white">فرم اعزام مامور / سفارش جدید</h2></div>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2 text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-700 pb-2"><User className="w-4 h-4 text-teal-600" />اطلاعات مشتری</h3><Tabs tabs={[{ value: 'existing', label: 'مشتری موجود' }, { value: 'new', label: 'مشتری جدید' }]} value={newCustomerMode ? 'new' : 'existing'} onChange={v => setNewCustomerMode(v === 'new')} className="mb-4" />{!newCustomerMode ? <Select label="انتخاب مشتری" value={customerId} onChange={e => setCustomerId(e.target.value)} options={[{ value: '', label: '-- انتخاب کنید --' }, ...db.customers.map(c => ({ value: c.id, label: `${c.fullName} - ${c.phone}` }))]} /> : <div className="grid grid-cols-1 sm:grid-cols-2 gap-3"><Input label="نام و نام خانوادگی *" value={newCustName} onChange={e => setNewCustName(e.target.value)} /><Input label="شماره تماس اصلی *" value={newCustPhone} onChange={e => setNewCustPhone(e.target.value)} placeholder="09..." /><Input label="شماره تماس دوم" value={newCustPhone2} onChange={e => setNewCustPhone2(e.target.value)} /><Input label="آدرس کامل" value={newCustAddr} onChange={e => setNewCustAddr(e.target.value)} /></div>}</Card>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2 text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-700 pb-2"><Wrench className="w-4 h-4 text-blue-600" />اطلاعات دستگاه</h3><div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3"><Select label="نوع دستگاه" value={deviceType} onChange={e => setDeviceType(e.target.value as typeof DEVICE_TYPES[0])} options={DEVICE_TYPES.map(d => ({ value: d, label: d }))} /><Select label="برند" value={deviceBrand} onChange={e => setDeviceBrand(e.target.value as typeof BRANDS[0])} options={BRANDS.map(b => ({ value: b, label: b }))} /><Input label="مدل دستگاه" value={deviceModel} onChange={e => setDeviceModel(e.target.value)} /><Input label="شماره سریال" value={serialNumber} onChange={e => setSerialNumber(e.target.value)} /><Select label="وضعیت گارانتی" value={warrantyStatus} onChange={e => setWarrantyStatus(e.target.value as 'داخل گارانتی' | 'خارج از گارانتی')} options={[{ value: 'داخل گارانتی', label: 'داخل گارانتی' }, { value: 'خارج از گارانتی', label: 'خارج از گارانتی' }]} /></div></Card>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2 text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-700 pb-2"><Calendar className="w-4 h-4 text-amber-500" />اطلاعات ماموریت</h3><div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3"><Select label="نوع سرویس" value={serviceType} onChange={e => setServiceType(e.target.value as typeof SERVICE_TYPES[number])} options={SERVICE_TYPES.map(s => ({ value: s, label: s }))} /><Select label="تکنسین" value={technicianId} onChange={e => setTechnicianId(e.target.value)} options={[{ value: '', label: 'بعداً تعیین می‌شود' }, ...db.technicians.filter(t => t.isActive).map(t => ({ value: t.id, label: t.fullName }))]} /><JalaliDatePicker label="تاریخ مراجعه" value={visitDate} onChange={iso => setVisitDate(iso)} /><Input label="ساعت مراجعه" value={visitTime} onChange={e => setVisitTime(e.target.value)} placeholder="10:00" /></div></Card>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-3 flex items-center gap-2 text-slate-900 dark:text-white"><ClipboardCheck className="w-4 h-4 text-purple-600" />شرح خرابی اعلام شده توسط مشتری</h3><Textarea value={problemDescription} onChange={e => setProblemDescription(e.target.value)} placeholder="علائم خرابی، صداها، زمان شروع مشکل، ارورها و..." rows={4} />
        <AiSuggestions deviceType={deviceType} brand={deviceBrand} text={problemDescription} onApply={(s) => setProblemDescription(prev => prev ? `${prev}\n${s}` : s)} />
      </Card>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-3 flex items-center gap-2 text-slate-900 dark:text-white"><CheckCircle className="w-4 h-4 text-emerald-600" />تایید مشتری</h3><SignaturePad ref={sigRef} label="امضای مشتری" /></Card>
      <div className="flex gap-2 justify-end sticky bottom-20 lg:bottom-4 bg-white dark:bg-slate-900 p-3 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-700 z-10"><Button variant="outline" onClick={() => handleSubmit(true)}>ذخیره پیش‌نویس</Button><Button onClick={() => handleSubmit(false)}>ثبت نهایی و اعزام</Button></div>
    </div>
  );
}
