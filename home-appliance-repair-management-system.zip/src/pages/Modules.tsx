import { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, Input, Modal, PageHeader, SearchInput, Badge, EmptyState, Select as UI_Select, Textarea, useToast, Tabs } from '../components/ui';
import { JalaliDatePicker } from '../components/JalaliDatePicker';
import { checkEnvironment, registerBiometric, describeBiometricError, type EnvironmentReport } from '../lib/biometric';
import { Wrench, Plus, BookOpen, MessageSquare, Phone, Send, Paperclip, Mic, Image as ImageIcon, Check, CheckCheck, Trash2, Save, UploadCloud, Bell, Building2, DollarSign, UserCog, Fingerprint, ShieldCheck, AlertCircle, ChevronRight, Search as SearchIcon, Globe } from 'lucide-react';
import { Link } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { formatCurrency, toPersianDigits, formatJalali, timeAgo, getMonthGrid, getPersianMonths, gregorianToJalali, isToday, isHoliday } from '../lib/jalali';
import { dailySeries, accountBalance } from '../lib/accounting';
import { cn } from '../utils/cn';
import type { KnowledgeBaseArticle, WorkOrderPM, DeviceType } from '../lib/types';
import { ERROR_CODES, TEST_MODES, searchErrors, searchTestModes, searchArticles, searchOnline, listExtSources, addExtSource, removeExtSource, type OnlineResult } from '../lib/kbEngine';
import { resolveOrderFromShortCode } from '../lib/shortLink';
import { CustomerSupportChat } from '../components/CustomerSupportChat';

/* ================= CMMS ================= */
export function CMMS() {
  const { db, addWorkOrder, updateWorkOrder, currentUser } = useApp();
  const [tab, setTab] = useState<'all' | 'PM' | 'CM' | 'EM'>('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [newWO, setNewWO] = useState<Partial<WorkOrderPM>>({ title: '', deviceType: 'یخچال', frequency: 'ماهانه', status: 'برنامه‌ریزی', description: '', priority: 'متوسط', orderType: 'PM', cost: 0, checklist: [], partsUsed: [] });
  const wos = useMemo(() => { if (currentUser?.role === 'technician') return db.workOrders.filter(w => w.assigneeId === currentUser.technicianId); if (tab === 'all') return db.workOrders; return db.workOrders.filter(w => w.orderType === tab); }, [db.workOrders, tab, currentUser]);
  const save = () => { if (!newWO.title) return; addWorkOrder(newWO as Omit<WorkOrderPM, 'id' | 'createdAt'>); setModalOpen(false); };
  const toggleCheck = (woId: string, idx: number) => { const wo = db.workOrders.find(w => w.id === woId); if (!wo) return; updateWorkOrder(woId, { checklist: wo.checklist.map((c, i) => i === idx ? { ...c, done: !c.done } : c) }); };
  return (
    <div className="space-y-4">
      <PageHeader title="CMMS / نگهداری و تعمیرات" subtitle="PM پیشگیرانه، CM اصلاحی، EM اضطراری" action={currentUser?.role === 'admin' ? <Button onClick={() => setModalOpen(true)}><Plus className="w-4 h-4" />دستور کار جدید</Button> : null} />
      <Tabs tabs={[{ value: 'all', label: 'همه' }, { value: 'PM', label: 'PM پیشگیرانه' }, { value: 'CM', label: 'CM اصلاحی' }, { value: 'EM', label: 'EM اضطراری' }]} value={tab} onChange={v => setTab(v as 'all' | 'PM' | 'CM' | 'EM')} />
      <div className="space-y-2">{wos.length === 0 && <EmptyState title="دستور کاری ثبت نشده" icon={<Wrench className="w-8 h-8" />} />}{wos.map(wo => { const assignee = db.technicians.find(t => t.id === wo.assigneeId); const doneCount = wo.checklist.filter(c => c.done).length; return (
        <Card key={wo.id} className="p-4 hover-lift"><div className="flex items-start justify-between mb-2"><div><div className="flex items-center gap-2 flex-wrap"><h4 className="font-semibold text-sm">{wo.title}</h4><Badge color={wo.orderType === 'PM' ? 'teal' : wo.orderType === 'CM' ? 'amber' : 'red'}>{wo.orderType}</Badge><Badge color={wo.priority === 'بحرانی' ? 'red' : wo.priority === 'زیاد' ? 'orange' : wo.priority === 'متوسط' ? 'amber' : 'slate'}>{wo.priority}</Badge></div><p className="text-xs text-slate-500 mt-1">{wo.deviceType} • {assignee?.fullName || 'تعیین نشده'}</p></div><Badge color={wo.status === 'تکمیل شده' ? 'green' : wo.status === 'در حال انجام' ? 'blue' : wo.status === 'معوق' ? 'red' : 'slate'}>{wo.status}</Badge></div>{wo.checklist.length > 0 && <div className="mt-3 space-y-1"><div className="flex items-center justify-between text-xs text-slate-500 mb-1"><span>چک‌لیست</span><span>{toPersianDigits(doneCount)} از {toPersianDigits(wo.checklist.length)}</span></div><div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5"><div className="bg-teal-500 h-1.5 rounded-full transition-all" style={{ width: `${(doneCount / wo.checklist.length) * 100}%` }} /></div><div className="space-y-0.5 mt-2">{wo.checklist.map((c, i) => <button key={i} onClick={() => toggleCheck(wo.id, i)} className="flex items-center gap-2 text-xs w-full text-right py-1"><div className={cn('w-4 h-4 rounded border-2 flex items-center justify-center', c.done ? 'bg-teal-500 border-teal-500' : 'border-slate-300 dark:border-slate-600')}>{c.done && <Check className="w-3 h-3 text-white" />}</div><span className={c.done ? 'line-through text-slate-400' : ''}>{c.text}</span></button>)}</div></div>}</Card>
      ); })}</div>
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="دستور کار جدید" size="md"><div className="space-y-3"><Input label="عنوان" value={newWO.title} onChange={e => setNewWO({ ...newWO, title: e.target.value })} /><div className="grid grid-cols-2 gap-2"><UI_Select label="نوع" value={newWO.orderType} onChange={e => setNewWO({ ...newWO, orderType: e.target.value as 'PM' | 'CM' | 'EM' })} options={[{ value: 'PM', label: 'PM پیشگیرانه' }, { value: 'CM', label: 'CM اصلاحی' }, { value: 'EM', label: 'EM اضطراری' }]} /><UI_Select label="اولویت" value={newWO.priority} onChange={e => setNewWO({ ...newWO, priority: e.target.value as 'کم' | 'متوسط' | 'زیاد' | 'بحرانی' })} options={[{ value: 'کم', label: 'کم' }, { value: 'متوسط', label: 'متوسط' }, { value: 'زیاد', label: 'زیاد' }, { value: 'بحرانی', label: 'بحرانی' }]} /></div><UI_Select label="نوع دستگاه" value={newWO.deviceType} onChange={e => setNewWO({ ...newWO, deviceType: e.target.value as DeviceType })} options={[{ value: 'یخچال', label: 'یخچال' }, { value: 'لباسشویی', label: 'لباسشویی' }, { value: 'ظرفشویی', label: 'ظرفشویی' }, { value: 'کولر گازی', label: 'کولر گازی' }, { value: 'پکیج', label: 'پکیج' }]} /><JalaliDatePicker label="تاریخ سررسید" value={newWO.dueDate} onChange={iso => setNewWO({ ...newWO, dueDate: iso })} /><Textarea label="توضیحات" value={newWO.description} onChange={e => setNewWO({ ...newWO, description: e.target.value })} /></div><div className="flex gap-2 mt-4 justify-end"><Button variant="secondary" onClick={() => setModalOpen(false)}>انصراف</Button><Button onClick={save}>ذخیره</Button></div></Modal>
    </div>
  );
}

/* ================= Scheduler ================= */
export function Scheduler() {
  const { db } = useApp();
  const [jy, setJy] = useState(() => gregorianToJalali(new Date().getFullYear(), new Date().getMonth() + 1, new Date().getDate())[0]);
  const [jm, setJm] = useState(() => gregorianToJalali(new Date().getFullYear(), new Date().getMonth() + 1, new Date().getDate())[1]);
  const [selectedDay, setSelectedDay] = useState<Date | null>(new Date());
  const days = useMemo(() => getMonthGrid(jy, jm), [jy, jm]);
  const months = getPersianMonths();
  const ordersForSelectedDay = useMemo(() => selectedDay ? db.orders.filter(o => o.visitDate && new Date(o.visitDate).toDateString() === selectedDay.toDateString()) : [], [db.orders, selectedDay]);
  const remindersForDay = useMemo(() => selectedDay ? db.reminders.filter(r => new Date(r.date).toDateString() === selectedDay.toDateString()) : [], [db.reminders, selectedDay]);
  const ordersByDate = useMemo(() => { const m: Record<string, number> = {}; db.orders.forEach(o => { if (o.visitDate) { const dd = new Date(o.visitDate); const key = `${dd.getFullYear()}-${dd.getMonth()}-${dd.getDate()}`; m[key] = (m[key] || 0) + 1; } }); return m; }, [db.orders]);
  const prevMonth = () => { if (jm === 1) { setJm(12); setJy(jy - 1); } else setJm(jm - 1); };
  const nextMonth = () => { if (jm === 12) { setJm(1); setJy(jy + 1); } else setJm(jm + 1); };
  return (
    <div className="space-y-4">
      <PageHeader title="تقویم و زمان‌بندی" subtitle="برنامه هفتگی و مشاهده سفارش‌ها بر اساس تاریخ" />
      <Card className="p-4"><div className="flex items-center justify-between mb-4"><button onClick={prevMonth} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg">‹</button><h3 className="font-bold text-lg">{months[jm - 1]} {toPersianDigits(jy)}</h3><button onClick={nextMonth} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg">›</button></div><div className="grid grid-cols-7 gap-1 mb-1">{['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'].map(w => <div key={w} className="text-center text-xs text-slate-500 font-semibold py-1">{w}</div>)}</div><div className="grid grid-cols-7 gap-1">{days.map((dd, idx) => { const [, m, day] = gregorianToJalali(dd.getFullYear(), dd.getMonth() + 1, dd.getDate()); const inMonth = m === jm; const key = `${dd.getFullYear()}-${dd.getMonth()}-${dd.getDate()}`; const orderCount = ordersByDate[key] || 0; const isSelected = selectedDay && dd.toDateString() === selectedDay.toDateString(); const t = isToday(dd); const holi = isHoliday(dd); return <button key={idx} onClick={() => setSelectedDay(dd)} className={cn('cal-day relative aspect-square flex flex-col items-center justify-center rounded-lg text-sm p-1', !inMonth && 'text-slate-300 dark:text-slate-600', isSelected && 'bg-teal-600 text-white', t && !isSelected && 'border-2 border-teal-500 font-bold', holi && !isSelected && 'text-red-500', inMonth && 'hover:bg-slate-100 dark:hover:bg-slate-800')}><span>{toPersianDigits(day)}</span>{orderCount > 0 && inMonth && <span className={cn('absolute bottom-1 w-1.5 h-1.5 rounded-full', isSelected ? 'bg-white' : 'bg-teal-500')}></span>}</button>; })}</div></Card>
      {selectedDay && <Card className="p-4"><h3 className="font-semibold text-sm mb-3">رویدادهای {toPersianDigits(formatJalali(selectedDay))}</h3>{ordersForSelectedDay.length === 0 && remindersForDay.length === 0 && <p className="text-center text-slate-500 py-4 text-sm">رویدادی برای این روز ثبت نشده</p>}<div className="space-y-2">{ordersForSelectedDay.map(o => { const c = db.customers.find(c => c.id === o.customerId); return <Link to={`/orders/${o.id}`} key={o.id}><div className="flex items-center justify-between p-2 rounded-lg bg-blue-50 dark:bg-blue-900/20"><div><p className="text-sm font-semibold">{o.serviceType} - {c?.fullName}</p><p className="text-xs text-slate-500">{o.visitTime && `${toPersianDigits(o.visitTime)} - `}{o.requestNumber}</p></div><ChevronRight className="w-4 h-4 text-slate-400" /></div></Link>; })}{remindersForDay.map(r => <div key={r.id} className="flex items-center gap-2 p-2 rounded-lg bg-amber-50 dark:bg-amber-900/20"><Bell className="w-4 h-4 text-amber-600" /><div><p className="text-sm font-semibold">{r.title}</p>{r.time && <p className="text-xs text-slate-500">ساعت {toPersianDigits(r.time)}</p>}</div></div>)}</div></Card>}
    </div>
  );
}

/* ================= Chat ================= */
export function Chat() {
  const { db, currentUser, sendMessage, getMessagesForUser, markConversationRead } = useApp();
  const [selectedPeer, setSelectedPeer] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const [recording, setRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const peers = useMemo(() => { const peerIds = new Set<string>(); db.messages.forEach(m => { if (m.senderId === currentUser?.id) peerIds.add(m.receiverId); if (m.receiverId === currentUser?.id) peerIds.add(m.senderId); }); return Array.from(peerIds).map(id => db.users.find(u => u.id === id)).filter(Boolean); }, [db.messages, currentUser, db.users]);
  const conversationMessages = useMemo(() => selectedPeer ? getMessagesForUser(selectedPeer) : [], [selectedPeer, db.messages, getMessagesForUser]);
  useEffect(() => { if (selectedPeer) markConversationRead(selectedPeer); }, [selectedPeer, markConversationRead]);
  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [conversationMessages.length]);
  const handleSend = () => { if (!message.trim() || !selectedPeer) return; sendMessage({ senderId: currentUser!.id, senderName: currentUser!.fullName, receiverId: selectedPeer, content: message, type: 'text' }); setMessage(''); };
  const sendImage = (file: File) => { if (!selectedPeer) return; const reader = new FileReader(); reader.onload = () => sendMessage({ senderId: currentUser!.id, senderName: currentUser!.fullName, receiverId: selectedPeer, content: 'تصویر', type: 'image', mediaUrl: reader.result as string }); reader.readAsDataURL(file); };
  const toggleVoice = async () => { if (!selectedPeer) return; if (recording) { mediaRecorderRef.current?.stop(); setRecording(false); return; } try { const stream = await navigator.mediaDevices.getUserMedia({ audio: true }); const rec = new MediaRecorder(stream); chunksRef.current = []; rec.ondataavailable = e => { if (e.data.size) chunksRef.current.push(e.data); }; rec.onstop = () => { const blob = new Blob(chunksRef.current, { type: 'audio/webm' }); const reader = new FileReader(); reader.onload = () => sendMessage({ senderId: currentUser!.id, senderName: currentUser!.fullName, receiverId: selectedPeer, content: 'پیام صوتی', type: 'voice', mediaUrl: reader.result as string }); reader.readAsDataURL(blob); stream.getTracks().forEach(t => t.stop()); }; mediaRecorderRef.current = rec; rec.start(); setRecording(true); } catch { sendMessage({ senderId: currentUser!.id, senderName: currentUser!.fullName, receiverId: selectedPeer, content: 'پیام صوتی (دسترسی میکروفون موجود نیست)', type: 'voice' }); } };
  const peerInfo = db.users.find(u => u.id === selectedPeer);
  const unreadByPeer = useMemo(() => { const map: Record<string, number> = {}; db.messages.filter(m => m.receiverId === currentUser?.id && !m.read).forEach(m => { map[m.senderId] = (map[m.senderId] || 0) + 1; }); return map; }, [db.messages, currentUser]);
  return (
    <div className="space-y-4">
      <PageHeader title="چت داخلی" subtitle="ارتباط با همکاران" />
      <Card className="overflow-hidden h-[calc(100vh-240px)] flex flex-col lg:flex-row">
        <div className={cn('lg:w-72 border-l border-slate-200 dark:border-slate-700 overflow-y-auto', selectedPeer ? 'hidden lg:block' : 'block')}><div className="p-3 border-b border-slate-200 dark:border-slate-700"><p className="font-semibold text-sm">مخاطبین</p></div><div className="divide-y divide-slate-100 dark:divide-slate-800">{peers.length === 0 && <p className="text-xs text-slate-500 p-4 text-center">گفتگویی شروع نشده</p>}{peers.map(p => p && <button key={p.id} onClick={() => setSelectedPeer(p.id)} className={cn('w-full p-3 flex items-center gap-2 text-right hover:bg-slate-50 dark:hover:bg-slate-800', selectedPeer === p.id && 'bg-teal-50 dark:bg-teal-900/20')}><div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-400 to-emerald-500 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">{p.fullName.split(' ').map(n => n[0]).slice(0, 2).join('')}</div><div className="flex-1 min-w-0"><p className="font-semibold text-sm">{p.fullName}</p><p className="text-xs text-slate-500 truncate">{p.role === 'admin' ? 'مدیر' : p.role === 'technician' ? 'تکنسین' : 'مشتری'}</p></div>{unreadByPeer[p.id] && <span className="bg-red-500 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">{toPersianDigits(unreadByPeer[p.id])}</span>}</button>)}</div><div className="p-3 border-t border-slate-200 dark:border-slate-700"><p className="text-xs font-semibold text-slate-500 mb-2">شروع گفتگوی جدید:</p><div className="space-y-1">{db.users.filter(u => u.id !== currentUser?.id).map(u => <button key={u.id} onClick={() => setSelectedPeer(u.id)} className="w-full text-right text-xs p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded">{u.fullName}</button>)}</div></div></div>
        <div className={cn('flex-1 flex flex-col', selectedPeer ? 'flex' : 'hidden lg:flex')}>{selectedPeer ? (<div className="flex-1 flex flex-col"><div className="p-3 border-b border-slate-200 dark:border-slate-700 flex items-center gap-2 shrink-0"><button onClick={() => setSelectedPeer(null)} className="lg:hidden p-1">‹</button><div className="w-9 h-9 rounded-full bg-gradient-to-br from-teal-400 to-emerald-500 flex items-center justify-center text-white font-bold text-xs">{peerInfo?.fullName.split(' ').map(n => n[0]).slice(0, 2).join('')}</div><div><p className="font-semibold text-sm">{peerInfo?.fullName}</p><p className="text-[10px] text-emerald-500">آنلاین</p></div></div><div className="flex-1 overflow-y-auto p-4 space-y-2 bg-slate-50 dark:bg-slate-950">{conversationMessages.map(m => { const isMe = m.senderId === currentUser?.id; return <div key={m.id} className={cn('flex', isMe ? 'justify-start' : 'justify-end')}><div className={cn('msg-bubble', isMe ? 'msg-sent' : 'msg-received')}>{m.type === 'image' && m.mediaUrl && <img src={m.mediaUrl} alt="تصویر" className="max-w-[220px] rounded-lg mb-1" />}{m.type === 'voice' && m.mediaUrl && <audio controls src={m.mediaUrl} className="max-w-[220px] h-8 mb-1" />}<p className="text-sm">{m.content}</p><div className={cn('flex items-center gap-1 mt-0.5 text-[9px]', isMe ? 'text-teal-100' : 'text-slate-400')}><span>{new Date(m.timestamp).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}</span>{isMe && (m.read ? <CheckCheck className="w-3 h-3" /> : <Check className="w-3 h-3" />)}</div></div></div>; })}<div ref={messagesEndRef} /></div><div className="p-3 border-t border-slate-200 dark:border-slate-700 flex items-center gap-2 bg-white dark:bg-slate-900 shrink-0"><input ref={imageInputRef} type="file" accept="image/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) sendImage(f); e.target.value = ''; }} /><button onClick={() => imageInputRef.current?.click()} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg" title="ارسال تصویر"><ImageIcon className="w-4 h-4 text-slate-500" /></button><button onClick={() => imageInputRef.current?.click()} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg" title="پیوست"><Paperclip className="w-4 h-4 text-slate-500" /></button><button onClick={toggleVoice} className={cn('p-2 rounded-lg', recording ? 'bg-red-100 text-red-600 animate-pulse' : 'hover:bg-slate-100 dark:hover:bg-slate-800')} title="پیام صوتی"><Mic className="w-4 h-4" /></button><input value={message} onChange={e => setMessage(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend()} placeholder="پیام خود را بنویسید..." className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-xl px-3 py-2 text-sm outline-none" /><button onClick={handleSend} className="p-2 bg-teal-600 text-white rounded-xl hover:bg-teal-700"><Send className="w-4 h-4" /></button></div></div>) : (<div className="flex-1 flex items-center justify-center text-slate-400"><div className="text-center"><MessageSquare className="w-12 h-12 mx-auto mb-2 opacity-30" /><p className="text-sm">یک گفتگو را انتخاب کنید</p></div></div>)}</div>
      </Card>
    </div>
  );
}

/* ================= Smart Knowledge Base ================= */
export function Knowledge() {
  const { db, addKB, deleteKB, incrementKBView, currentUser } = useApp();
  const { showToast } = useToast();
  const [tab, setTab] = useState<'errors' | 'testmodes' | 'articles'>('errors');
  const [query, setQuery] = useState('');
  const [brand, setBrand] = useState('all');
  const [deviceType, setDeviceType] = useState('all');
  const [model, setModel] = useState('');
  const [results, setResults] = useState<typeof ERROR_CODES>([]);
  const [tmResults, setTmResults] = useState<typeof TEST_MODES>([]);
  const [artResults, setArtResults] = useState<KnowledgeBaseArticle[]>(db.knowledgeBase);
  const [online, setOnline] = useState<OnlineResult | null>(null);
  const [onlineLoading, setOnlineLoading] = useState(false);
  const [showSources, setShowSources] = useState(false);
  const [extSources, setExtSources] = useState(() => listExtSources());
  const [srcName, setSrcName] = useState('');
  const [srcUrl, setSrcUrl] = useState('');
  const [srcNote, setSrcNote] = useState('');
  const [viewId, setViewId] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState<Partial<KnowledgeBaseArticle>>({ title: '', brand: 'بوش', deviceType: 'یخچال', category: 'عیب‌یابی', content: '', tags: [] });
  const [tagsInput, setTagsInput] = useState('');

  const runSearch = useCallback((q: string) => {
    setResults(searchErrors(q, { brand, deviceType, model }));
    setTmResults(searchTestModes(q, { brand, deviceType, model }));
    setArtResults(searchArticles(db.knowledgeBase, q));
  }, [brand, deviceType, model, db.knowledgeBase]);

  useEffect(() => { runSearch(query); }, [query, brand, deviceType, model, runSearch]);
  useEffect(() => { setOnline(null); }, [query, tab]);

  const doOnline = async () => {
    if (!query.trim()) { showToast('ابتدا ارور یا تست‌مود را بنویسید', 'error'); return; }
    setOnlineLoading(true); setOnline(null);
    try {
      const res = await searchOnline(query, { brand, deviceType });
      setOnline(res);
      if (!res) showToast('هیچ نتیجه مرتبط و فارسی یافت نشد', 'error');
    } catch { showToast('خطا در جستجوی آنلاین', 'error'); }
    setOnlineLoading(false);
  };

  const saveOnline = () => {
    if (!online) return;
    const srcLines = [...online.sources.map(s => `• ${s.title} — ${s.url}`), ...extSources.map(s => `• ${s.name} — ${s.url}`)].join('\n');
    addKB({
      title: `${query} — پاسخ آنلاین`,
      brand: 'همه', deviceType: 'همه', category: 'عیب‌یابی',
      content: `${online.summary}${online.translatedSummary && online.lang === 'en' ? `\n\n(ترجمه فارسی)\n${online.translatedSummary}` : ''}\n\nمنابع:\n${srcLines}`,
      tags: [query, online.title, 'آنلاین'],
      createdBy: currentUser?.id || 'user-admin',
    });
    showToast('پاسخ آنلاین در بانک دانش ذخیره شد ✓');
    setOnline(null);
  };

  const submitSource = () => {
    if (!srcName.trim() || !srcUrl.trim()) { showToast('نام منبع و لینک الزامی است', 'error'); return; }
    addExtSource(srcName, srcUrl, srcNote || undefined);
    setExtSources(listExtSources());
    setSrcName(''); setSrcUrl(''); setSrcNote('');
    showToast('منبع ذخیره شد ✓');
  };

  const article = db.knowledgeBase.find(a => a.id === viewId);
  const saveArticle = () => { if (!form.title || !form.content) { showToast('عنوان و متن الزامی است', 'error'); return; } addKB({ title: form.title!, brand: form.brand as KnowledgeBaseArticle['brand'], deviceType: form.deviceType as KnowledgeBaseArticle['deviceType'], category: form.category as KnowledgeBaseArticle['category'], content: form.content!, tags: tagsInput.split(',').map(t => t.trim()).filter(Boolean), createdBy: currentUser?.id || 'user-admin' }); showToast('مقاله ذخیره شد'); setModalOpen(false); setForm({ title: '', brand: 'بوش', deviceType: 'یخچال', category: 'عیب‌یابی', content: '', tags: [] }); setTagsInput(''); };

  return (
    <div className="space-y-4">
      <PageHeader title="بانک دانش تکنسین‌ها" subtitle="کتابخانهٔ جامع ارورها و تست‌مودها به تفکیک برند و دستگاه" action={currentUser?.role === 'admin' ? <Button onClick={() => setModalOpen(true)}><Plus className="w-4 h-4" />مقاله جدید</Button> : null} />

      <Card className="p-4 bg-gradient-to-br from-teal-600 to-emerald-700 text-white border-none">
        <div className="flex items-center gap-2 mb-2"><BookOpen className="w-5 h-5" /><h3 className="font-bold text-sm">جستجوی ارور یا تست‌مود</h3><span className="text-[10px] bg-white/20 rounded-full px-2 py-0.5">مثلاً E19 ظرفشویی بوش</span></div>
        <div className="flex gap-2">
          <input value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === 'Enter' && doOnline()} placeholder="کد خطا یا تست‌مود را بنویسید..." className="flex-1 rounded-xl px-3 py-2.5 text-sm text-slate-900 outline-none" />
          <Button variant="secondary" onClick={doOnline} loading={onlineLoading} className="bg-white/90 text-teal-700 hover:bg-white"><Globe className="w-4 h-4" />آنلاین</Button>
        </div>
        <div className="grid grid-cols-3 gap-2 mt-2">
          <select value={brand} onChange={e => setBrand(e.target.value)} className="rounded-xl px-2 py-2 text-xs text-slate-900 outline-none">{['all', 'بوش', 'آاگ', 'ال‌جی', 'سامسونگ', 'پاکشوما', 'اسنوا', 'دوو', 'بکو', 'هایسنس'].map(b => <option key={b} value={b}>{b === 'all' ? 'همه برندها' : b}</option>)}</select>
          <select value={deviceType} onChange={e => setDeviceType(e.target.value)} className="rounded-xl px-2 py-2 text-xs text-slate-900 outline-none">{['all', 'یخچال', 'لباسشویی', 'ظرفشویی', 'کولر گازی', 'پکیج'].map(d => <option key={d} value={d}>{d === 'all' ? 'همه دستگاه‌ها' : d}</option>)}</select>
          <input value={model} onChange={e => setModel(e.target.value)} placeholder="مدل (اختیاری)" className="rounded-xl px-2 py-2 text-xs text-slate-900 outline-none" />
        </div>
      </Card>

      {onlineLoading && <div className="skeleton h-24 rounded-2xl" />}
      {online && (
        <Card className="p-4 border-2 border-teal-400 dark:border-teal-600">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0"><Globe className="w-5 h-5" /></div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-bold text-sm text-teal-700 dark:text-teal-300">پاسخ آنلاین برای «{query}»</p>
                <Badge color={online.lang === 'fa' ? 'green' : 'blue'}>{online.lang === 'fa' ? 'فارسی' : 'انگلیسی'}</Badge>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-50">امتیاز ارتباط: {toPersianDigits(Math.round(online.score))}</span>
              </div>
              <p className="text-xs text-slate-700 dark:text-slate-200 mt-1.5 leading-6 whitespace-pre-wrap">{online.summary}</p>
              {online.lang === 'en' && online.translatedSummary && (
                <div className="mt-2.5 p-3 rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800">
                  <p className="text-[10px] font-bold text-amber-700 dark:text-amber-300 mb-1">ترجمه فارسی:</p>
                  <p className="text-xs text-slate-700 dark:text-slate-200 leading-5 whitespace-pre-wrap">{online.translatedSummary}</p>
                </div>
              )}
              {online.sources.length > 0 && (
                <div className="mt-2.5">
                  <p className="text-[10px] font-bold text-slate-500 mb-1">منابع:</p>
                  <div className="space-y-1">{online.sources.map((s, i) => <a key={i} href={s.url} target="_blank" rel="noopener noreferrer" className="block text-[11px] text-teal-700 dark:text-teal-300 hover:underline truncate">• {s.title}</a>)}</div>
                </div>
              )}
              <div className="flex gap-2 mt-3"><Button size="sm" onClick={saveOnline}><Save className="w-3.5 h-3.5" />ذخیره در بانک دانش</Button><Button size="sm" variant="ghost" onClick={() => setOnline(null)}>بستن</Button></div>
            </div>
          </div>
        </Card>
      )}

      <div className="flex items-center gap-2">
        <div className="flex-1">
          <Tabs tabs={[{ value: 'errors', label: 'ارورها' }, { value: 'testmodes', label: 'تست‌مودها' }, { value: 'articles', label: 'مقالات' }]} value={tab} onChange={v => setTab(v as typeof tab)} />
        </div>
        <Button variant="outline" size="sm" onClick={() => setShowSources(true)}><Globe className="w-4 h-4" />منابع ({toPersianDigits(extSources.length)})</Button>
      </div>

      {/* Sources management modal */}
      <Modal open={showSources} onClose={() => setShowSources(false)} title="مدیریت منابع جستجو" size="md">
        <div className="space-y-3">
          <p className="text-xs text-slate-500 leading-5">مدیر می‌توان لینک منابع معتبر (فوم‌های تعمیرات، صفحات پیشنهادی تولیدکنندگان، کانال‌های اختصاصی) را ثبت کند تا سیستم در هنگام جستجی آنلاین آن‌ها را هم به‌صورت خودکار در نتایج قرار دهد و هنگام ذخیره پاسخ، به‌عنوان رفرنس ماندگار در بانک دانش شود.</p>
          <div className="grid grid-cols-1 gap-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700">
            <Input label="نام منبع" value={srcName} onChange={e => setSrcName(e.target.value)} placeholder="مثلاً وب‌سایت راهنمای تعمیر ظرفشویی بوش" />
            <Input label="لینک (URL)" value={srcUrl} onChange={e => setSrcUrl(e.target.value)} placeholder="https://..." dir="ltr" />
            <Textarea label="توضیحات" value={srcNote} onChange={e => setSrcNote(e.target.value)} rows={2} placeholder="اختیاری: حوزه تخصص منبع، زبان و محدوده موضوع" />
            <Button className="w-full" onClick={submitSource}><Plus className="w-4 h-4" />ثبت منبع جدید</Button>
          </div>
          <div className="space-y-2 max-h-56 overflow-y-auto">
            {extSources.length === 0 && <p className="text-xs text-slate-500 text-center py-6">هنوز منبعی ثبت نشده است.</p>}
            {extSources.map(s => (
              <div key={s.id} className="flex items-start gap-2 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                <Globe className="w-4 h-4 text-teal-600 shrink-0 mt-1" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold">{s.name}</p>
                  <a href={s.url} target="_blank" rel="noopener noreferrer" className="text-[10px] text-teal-600 hover:underline block truncate" dir="ltr">{s.url}</a>
                  {s.note && <p className="text-[10px] text-slate-500 mt-0.5">{s.note}</p>}
                </div>
                <div className="flex gap-1">
                  <a href={s.url} target="_blank" rel="noopener noreferrer" className="p-1 text-teal-600"><Globe className="w-3.5 h-3.5" /></a>
                  <button onClick={() => { removeExtSource(s.id); setExtSources(listExtSources()); }} className="p-1 text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Modal>

      {tab === 'errors' && (
        <div className="space-y-2">
          {results.length === 0 && <EmptyState title="در بانک محلی یافت نشد" description="فیلترها را تغییر دهید یا روی «آنلاین» بزنید." action={<Button size="sm" onClick={doOnline} loading={onlineLoading}><Globe className="w-4 h-4" />جستجو در اینترنت</Button>} />}
          {results.map((e, idx) => (
            <Card key={`${e.code}-${idx}`} className="p-4">
              <div className="flex items-start gap-3">
                <span className="px-3 py-1.5 rounded-xl bg-slate-900 dark:bg-teal-700 text-white font-black text-sm font-mono shrink-0" dir="ltr">{e.code}</span>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm">{e.label}</p>
                  <div className="flex gap-1 flex-wrap mt-1">{[<Badge key="b" color="red">{e.brand}</Badge>, <Badge key="d" color="blue">{e.deviceType}</Badge>, ...(e.models || []).map(m => <span key={m} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">{m}</span>)]}</div>
                  {e.causes.length > 0 && <div className="mt-2"><p className="text-[10px] font-bold text-amber-600 mb-0.5">علل احتمالی:</p><ul className="list-disc pr-4 text-xs text-slate-600 dark:text-slate-300 space-y-0.5">{e.causes.map((c, i) => <li key={i}>{c}</li>)}</ul></div>}
                  {e.solution.length > 0 && <div className="mt-2 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-900/20"><p className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300 mb-1">راه‌حل:</p><ol className="list-decimal pr-4 text-xs text-slate-700 dark:text-slate-200 space-y-0.5">{e.solution.map((s, i) => <li key={i}>{s}</li>)}</ol></div>}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {tab === 'testmodes' && (
        <div className="space-y-2">
          {tmResults.length === 0 && <EmptyState title="تست‌مودی یافت نشد" />}
          {tmResults.map(t => (
            <Card key={t.id} className="p-4">
              <p className="font-bold text-sm">{t.title}</p>
              <div className="flex gap-1 flex-wrap mt-1">{[<Badge key="b" color="blue">{t.brand}</Badge>, <Badge key="d" color="teal">{t.deviceType}</Badge>, ...(t.models || []).map(m => <span key={m} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">{m}</span>)]}</div>
              <ol className="mt-3 space-y-1.5">{t.steps.map((s, i) => <li key={i} className="flex gap-2 text-xs"><span className="w-5 h-5 rounded-full bg-teal-600 text-white flex items-center justify-center font-bold shrink-0">{i + 1}</span><span className="text-slate-700 dark:text-slate-200 pt-0.5">{s}</span></li>)}</ol>
              {t.note && <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-2 bg-amber-50 dark:bg-amber-900/20 p-2 rounded-lg">{t.note}</p>}
            </Card>
          ))}
        </div>
      )}

      {tab === 'articles' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {artResults.map(a => (
            <Card key={a.id} hover onClick={() => { setViewId(a.id); incrementKBView(a.id); }} className="p-4 cursor-pointer">
              <div className="flex items-start justify-between mb-2"><Badge color={a.brand === 'بوش' ? 'red' : a.brand === 'آاگ' ? 'blue' : 'teal'}>{a.brand}</Badge><span className="text-[10px] text-slate-400">{toPersianDigits(a.views)} بازدید</span></div>
              <h4 className="font-semibold text-sm mb-1 line-clamp-2">{a.title}</h4>
              <p className="text-xs text-slate-500 line-clamp-2">{a.category} • {a.deviceType}</p>
              <div className="flex gap-1 flex-wrap mt-2">{a.tags.slice(0, 3).map(t => <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">#{t}</span>)}</div>
            </Card>
          ))}
          {artResults.length === 0 && <div className="col-span-full"><EmptyState title="مقاله‌ای یافت نشد" /></div>}
        </div>
      )}

      <Modal open={!!viewId} onClose={() => setViewId(null)} title={article?.title || ''} size="lg">{article && <div className="space-y-4"><div className="flex items-center gap-2 flex-wrap"><Badge color="teal">{article.brand}</Badge><Badge color="blue">{article.deviceType}</Badge><Badge>{article.category}</Badge><span className="text-xs text-slate-500 ml-auto">{toPersianDigits(article.views)} بازدید</span></div><div className="prose prose-sm max-w-none dark:prose-invert whitespace-pre-wrap text-sm leading-7 text-slate-700 dark:text-slate-300">{article.content}</div><div className="flex gap-1 flex-wrap">{article.tags.map(t => <span key={t} className="text-xs px-2 py-1 rounded bg-slate-100 dark:bg-slate-800">#{t}</span>)}</div>{currentUser?.role === 'admin' && <div className="flex justify-end"><Button variant="danger" size="sm" onClick={() => { if (confirm('حذف؟')) { deleteKB(article.id); setViewId(null); } }}><Trash2 className="w-3.5 h-3.5" />حذف</Button></div>}</div>}</Modal>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="مقاله جدید" size="lg"><div className="space-y-3"><Input label="عنوان" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} /><div className="grid grid-cols-3 gap-2"><UI_Select label="برند" value={form.brand} onChange={e => setForm({ ...form, brand: e.target.value as KnowledgeBaseArticle['brand'] })} options={[{ value: 'بوش', label: 'بوش' }, { value: 'آاگ', label: 'آاگ' }, { value: 'ال‌جی', label: 'ال‌جی' }, { value: 'سامسونگ', label: 'سامسونگ' }, { value: 'همه', label: 'همه' }]} /><UI_Select label="نوع دستگاه" value={form.deviceType} onChange={e => setForm({ ...form, deviceType: e.target.value as KnowledgeBaseArticle['deviceType'] })} options={[{ value: 'یخچال', label: 'یخچال' }, { value: 'لباسشویی', label: 'لباسشویی' }, { value: 'ظرفشویی', label: 'ظرفشویی' }, { value: 'کولر گازی', label: 'کولر گازی' }, { value: 'همه', label: 'همه' }]} /><UI_Select label="دسته" value={form.category} onChange={e => setForm({ ...form, category: e.target.value as KnowledgeBaseArticle['category'] })} options={[{ value: 'عیب‌یابی', label: 'عیب‌یابی' }, { value: 'راهنمای تعمیر', label: 'راهنمای تعمیر' }, { value: 'کد خطا', label: 'کد خطا' }, { value: 'نقشه فنی', label: 'نقشه فنی' }, { value: 'گارانتی', label: 'گارانتی' }]} /></div><Textarea label="متن کامل" value={form.content} onChange={e => setForm({ ...form, content: e.target.value })} rows={10} /><Input label="برچسب‌ها (با ویرگول جدا کنید)" value={tagsInput} onChange={e => setTagsInput(e.target.value)} placeholder="عیب‌یابی، E19، تخلیه" /></div><div className="flex gap-2 mt-4 justify-end"><Button variant="secondary" onClick={() => setModalOpen(false)}>انصراف</Button><Button onClick={saveArticle}>ذخیره</Button></div></Modal>
    </div>
  );
}

/* ================= Contacts ================= */
export function Contacts() {
  const { db, addContact, deleteContact } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ name: '', phone: '', category: 'تأمین‌کننده' as 'مشتری' | 'تأمین‌کننده' | 'همکار' | 'سایر', notes: '' });
  const filtered = db.contacts.filter(c => c.name.includes(search) || c.phone.includes(search));
  const save = () => { if (!form.name || !form.phone) return; addContact(form); setForm({ name: '', phone: '', category: 'تأمین‌کننده', notes: '' }); setModalOpen(false); };
  return (
    <div className="space-y-4">
      <PageHeader title="دفترچه تلفن" subtitle="مخاطبان و تامین‌کنندگان" action={<Button onClick={() => setModalOpen(true)}><Plus className="w-4 h-4" />افزودن</Button>} />
      <SearchInput value={search} onChange={setSearch} placeholder="جستجو..." />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">{filtered.map(c => <Card key={c.id} className="p-4"><div className="flex items-start justify-between"><div><p className="font-semibold text-sm">{c.name}</p><Badge color={c.category === 'تأمین‌کننده' ? 'blue' : c.category === 'مشتری' ? 'teal' : 'slate'} className="mt-1">{c.category}</Badge></div><button onClick={() => { if (confirm('حذف؟')) deleteContact(c.id); }} className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"><Trash2 className="w-3.5 h-3.5" /></button></div><a href={`tel:${c.phone}`} className="flex items-center gap-2 mt-3 text-sm font-mono text-teal-600 ltr inline-block"><Phone className="w-3.5 h-3.5" />{toPersianDigits(c.phone)}</a>{c.notes && <p className="text-xs text-slate-500 mt-2">{c.notes}</p>}</Card>)}</div>
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="مخاطب جدید"><div className="space-y-3"><Input label="نام *" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /><Input label="شماره تماس *" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /><UI_Select label="دسته" value={form.category} onChange={e => setForm({ ...form, category: e.target.value as typeof form.category })} options={[{ value: 'مشتری', label: 'مشتری' }, { value: 'تأمین‌کننده', label: 'تأمین‌کننده' }, { value: 'همکار', label: 'همکار' }, { value: 'سایر', label: 'سایر' }]} /><Input label="یادداشت" value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></div><div className="flex gap-2 mt-4 justify-end"><Button variant="secondary" onClick={() => setModalOpen(false)}>انصراف</Button><Button onClick={save}>ذخیره</Button></div></Modal>
    </div>
  );
}

/* ================= Reports ================= */
export function Reports() {
  const { db } = useApp();
  const daily = useMemo(() => dailySeries(db, 7), [db]);
  const totalRevenue = accountBalance(db, db.accounting.laborRevenueAccount) + accountBalance(db, db.accounting.partsRevenueAccount) + accountBalance(db, db.accounting.transportRevenueAccount);
  const totalOutstanding = accountBalance(db, db.accounting.arAccount);
  const byTech = db.technicians.map(t => { const orders = db.orders.filter(o => o.technicianId === t.id); return { name: t.fullName, count: orders.length, revenue: orders.reduce((s, o) => s + o.finalAmount, 0) }; });
  const byDevice: Record<string, number> = {};
  db.orders.forEach(o => { const dd = db.devices.find(x => x.id === o.deviceId); if (dd) byDevice[dd.type] = (byDevice[dd.type] || 0) + 1; });
  const deviceStats = Object.entries(byDevice).map(([name, count]) => ({ name, count }));
  return (
    <div className="space-y-4">
      <PageHeader title="گزارش‌ها و آمار" subtitle="تحلیل عملکرد تعمیرگاه" action={<Button variant="outline" onClick={() => { const rows = [['شماره', 'مشتری', 'وضعیت', 'مبلغ', 'تاریخ'], ...db.orders.map(o => { const c = db.customers.find(x => x.id === o.customerId); return [o.requestNumber, c?.fullName || '', o.status, String(o.finalAmount), o.registrationDate]; })]; const csv = rows.map(r => r.join(',')).join('\n'); const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'orders-report.csv'; a.click(); }}>خروجی CSV</Button>} />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3"><Card className="p-4 kpi-card"><p className="text-xs text-slate-500">درآمد</p><p className="text-lg font-bold mt-1 text-emerald-600">{formatCurrency(totalRevenue)}</p></Card><Card className="p-4 kpi-card"><p className="text-xs text-slate-500">مطالبات</p><p className="text-lg font-bold mt-1 text-red-600">{formatCurrency(totalOutstanding)}</p></Card><Card className="p-4 kpi-card"><p className="text-xs text-slate-500">تعداد سفارش</p><p className="text-lg font-bold mt-1">{toPersianDigits(db.orders.length)}</p></Card><Card className="p-4 kpi-card"><p className="text-xs text-slate-500">درآمد ۷ روز اخیر</p><p className="text-lg font-bold mt-1 text-teal-600">{formatCurrency(daily.reduce((s, d) => s + d.revenue, 0))}</p></Card></div>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4">عملکرد تکنسین‌ها</h3><div className="space-y-3">{byTech.map(t => <div key={t.name}><div className="flex justify-between text-xs mb-1"><span className="font-medium">{t.name}</span><span className="text-slate-500">{toPersianDigits(t.count)} سفارش • {formatCurrency(t.revenue)}</span></div><div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2"><div className="bg-teal-500 h-2 rounded-full" style={{ width: `${Math.min(100, (t.count / Math.max(...byTech.map(x => x.count, 1))) * 100)}%` }} /></div></div>)}</div></Card>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4">توزیع سفارشات بر اساس نوع دستگاه</h3><div className="space-y-2">{deviceStats.length === 0 ? <p className="text-xs text-slate-500 text-center py-4">داده‌ای موجود نیست</p> : deviceStats.sort((a, b) => b.count - a.count).map(d => <div key={d.name} className="flex items-center gap-3"><span className="text-xs w-24 font-medium">{d.name}</span><div className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-full h-2"><div className="bg-gradient-to-r from-teal-500 to-emerald-500 h-2 rounded-full" style={{ width: `${(d.count / Math.max(...deviceStats.map(x => x.count))) * 100}%` }} /></div><span className="text-xs font-bold w-6 text-left">{toPersianDigits(d.count)}</span></div>)}</div></Card>
    </div>
  );
}

/* ================= Audit ================= */
export function Audit() {
  const { db } = useApp();
  const [search, setSearch] = useState('');
  const filtered = db.auditLogs.filter(l => l.userName.includes(search) || l.action.includes(search) || l.entityType.includes(search));
  return (
    <div className="space-y-4">
      <PageHeader title="گزارش حسابرسی" subtitle="تاریخچه کامل عملیات کاربران" />
      <SearchInput value={search} onChange={setSearch} placeholder="جستجو..." />
      <Card className="overflow-x-auto"><table className="data-table"><thead><tr><th>زمان</th><th>کاربر</th><th>عملیات</th><th>موجودیت</th><th>شناسه</th><th>جزئیات</th></tr></thead><tbody>{filtered.slice(0, 200).map(l => <tr key={l.id}><td className="text-xs font-mono">{timeAgo(new Date(l.timestamp))}</td><td className="text-sm font-medium">{l.userName}</td><td><Badge color="teal">{l.action}</Badge></td><td className="text-xs">{l.entityType}</td><td className="text-[10px] font-mono text-slate-500">{l.entityId ? l.entityId.slice(0, 8) + '...' : '—'}</td><td className="text-xs text-slate-500">{l.details || '—'}</td></tr>)}</tbody></table></Card>
    </div>
  );
}

/* ================= Settings ================= */
export function Settings() {
  const { db, updateSettings, resetAllData } = useApp();
  const { showToast } = useToast();
  const [settings, setSettings] = useState(db.settings);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const stampInputRef = useRef<HTMLInputElement>(null);
  useEffect(() => { setSettings(prev => ({ ...prev, biometricEnabled: db.settings.biometricEnabled, biometricAllowedRoles: db.settings.biometricAllowedRoles, biometricRequireUserVerification: db.settings.biometricRequireUserVerification, biometricTimeoutSeconds: db.settings.biometricTimeoutSeconds, theme: db.settings.theme })); }, [db.settings.biometricEnabled, db.settings.biometricAllowedRoles, db.settings.biometricRequireUserVerification, db.settings.biometricTimeoutSeconds, db.settings.theme]);
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, field: 'logoDataUrl' | 'stampDataUrl') => { const file = e.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => setSettings(s => ({ ...s, [field]: reader.result as string })); reader.readAsDataURL(file); };
  const save = () => { const { biometricEnabled: _b, biometricAllowedRoles: _r, biometricRequireUserVerification: _v, biometricTimeoutSeconds: _t, ...rest } = settings; updateSettings(rest); showToast('تنظیمات ذخیره شد'); };
  return (
    <div className="space-y-4">
      <PageHeader title="تنظیمات" subtitle="پیکربندی سامانه" />
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2"><Building2 className="w-4 h-4 text-teal-600" />اطلاعات تعمیرگاه</h3><div className="grid grid-cols-1 md:grid-cols-2 gap-3"><Input label="نام تعمیرگاه" value={settings.shopName} onChange={e => setSettings({ ...settings, shopName: e.target.value })} /><Input label="نام (انگلیسی)" value={settings.shopNameEn} onChange={e => setSettings({ ...settings, shopNameEn: e.target.value })} /><Input label="آدرس" value={settings.address} onChange={e => setSettings({ ...settings, address: e.target.value })} /><Input label="تلفن اصلی" value={settings.phone} onChange={e => setSettings({ ...settings, phone: e.target.value })} /><Input label="تلفن دوم" value={settings.phone2} onChange={e => setSettings({ ...settings, phone2: e.target.value })} /></div></Card>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2"><Save className="w-4 h-4 text-purple-600" />لوگو و مهر</h3><div className="grid grid-cols-1 md:grid-cols-2 gap-4"><div><p className="text-xs font-medium text-slate-600 mb-2">لوگو تعمیرگاه</p><div className="flex items-center gap-3">{settings.logoDataUrl ? <img src={settings.logoDataUrl} alt="logo" className="w-20 h-20 object-contain border rounded-lg p-2 bg-white" /> : <div className="w-20 h-20 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-2xl">اتحاد</div>}<div><input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={e => handleFileUpload(e, 'logoDataUrl')} /><Button size="sm" variant="outline" onClick={() => fileInputRef.current?.click()}><UploadCloud className="w-3.5 h-3.5" />آپلود لوگو</Button>{settings.logoDataUrl && <Button size="sm" variant="ghost" onClick={() => setSettings({ ...settings, logoDataUrl: undefined })} className="mt-1">حذف</Button>}</div></div></div><div><p className="text-xs font-medium text-slate-600 mb-2">مهر تعمیرگاه</p><div className="flex items-center gap-3">{settings.stampDataUrl ? <img src={settings.stampDataUrl} alt="stamp" className="w-20 h-20 object-contain border rounded-lg p-2 bg-white" /> : <div className="w-20 h-20 border-2 border-dashed border-slate-300 rounded-xl flex items-center justify-center text-slate-400 text-xs">مهر</div>}<div><input ref={stampInputRef} type="file" accept="image/*" className="hidden" onChange={e => handleFileUpload(e, 'stampDataUrl')} /><Button size="sm" variant="outline" onClick={() => stampInputRef.current?.click()}><UploadCloud className="w-3.5 h-3.5" />آپلود مهر</Button>{settings.stampDataUrl && <Button size="sm" variant="ghost" onClick={() => setSettings({ ...settings, stampDataUrl: undefined })} className="mt-1">حذف</Button>}</div></div></div></div></Card>
      <SecuritySettings />
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2"><Bell className="w-4 h-4 text-amber-600" />اعلان‌رسانی</h3><div className="space-y-2"><label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50"><span className="text-sm">اعلان خودکار به مشتری پس از تغییر وضعیت</span><input type="checkbox" checked={settings.autoNotifyCustomer} onChange={e => setSettings({ ...settings, autoNotifyCustomer: e.target.checked })} className="w-5 h-5 accent-teal-600" /></label><label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50"><span className="text-sm">سرویس پیامک</span><input type="checkbox" checked={settings.smsEnabled} onChange={e => setSettings({ ...settings, smsEnabled: e.target.checked })} className="w-5 h-5 accent-teal-600" /></label><label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50"><span className="text-sm">واتساپ</span><input type="checkbox" checked={settings.whatsappEnabled} onChange={e => setSettings({ ...settings, whatsappEnabled: e.target.checked })} className="w-5 h-5 accent-teal-600" /></label><label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50"><span className="text-sm">تلگرام</span><input type="checkbox" checked={settings.telegramEnabled} onChange={e => setSettings({ ...settings, telegramEnabled: e.target.checked })} className="w-5 h-5 accent-teal-600" /></label></div></Card>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2"><DollarSign className="w-4 h-4 text-emerald-600" />مالی</h3><div className="grid grid-cols-1 md:grid-cols-3 gap-3"><Input label="نرخ مالیات بر ارزش افزوده (%)" type="number" value={settings.taxRate} onChange={e => setSettings({ ...settings, taxRate: parseInt(e.target.value) || 0 })} /><Input label="پورسانت پیش‌فرض تکنسین (%)" type="number" value={settings.defaultCommissionRate} onChange={e => setSettings({ ...settings, defaultCommissionRate: parseInt(e.target.value) || 0 })} /><UI_Select label="اندازه کاغذ چاپ" value={settings.printPaperSize} onChange={e => setSettings({ ...settings, printPaperSize: e.target.value as 'A4' | 'A5' })} options={[{ value: 'A4', label: 'A4' }, { value: 'A5', label: 'A5' }]} /></div></Card>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2"><UserCog className="w-4 h-4 text-blue-600" />اطلاعات توسعه‌دهنده</h3><div className="grid grid-cols-1 md:grid-cols-2 gap-3"><Input label="نام توسعه‌دهنده" value={settings.developerName} onChange={e => setSettings({ ...settings, developerName: e.target.value })} /><Input label="تلفن پشتیبانی" value={settings.developerPhone} onChange={e => setSettings({ ...settings, developerPhone: e.target.value })} /></div></Card>

      <OneSignalSettingsCard />

      <div className="flex gap-2 justify-between items-center"><Button variant="danger" size="sm" onClick={() => { if (confirm('بازنشانی همه داده‌ها؟ این عملکرد غیرقابل بازگشت است.')) resetAllData(); }}>بازنشانی همه داده‌ها</Button><Button onClick={save}><Save className="w-4 h-4" />ذخیره تنظیمات</Button></div>
    </div>
  );
}

/* ================= Security / Biometric ================= */
/* ================= OneSignal Setup ================= */
function OneSignalSettingsCard() {
  const { db, currentUser, updateSettings } = useApp();
  const { showToast } = useToast();
  const s = db.settings;
  const [enabled, setEnabled] = useState(s.oneSignalEnabled);
  const [appId, setAppId] = useState(s.oneSignalAppId || '');
  const [restKey, setRestKey] = useState(s.oneSignalRestApiKey || '');
  const [busy, setBusy] = useState(false);
  const [subscribed, setSubscribed] = useState<boolean | null>(null);
  const [permLabel, setPermLabel] = useState('');
  const [guideOpen, setGuideOpen] = useState(false);
  const [testing, setTesting] = useState(false);

  const checkStatus = useCallback(async () => {
    if (!s.oneSignalEnabled || !s.oneSignalAppId) { setSubscribed(null); setPermLabel('خاموش'); return; }
    const mod = await import('../lib/onesignal');
    const ok = await mod.isOneSignalSubscribed(s);
    setSubscribed(ok);
    setPermLabel(ok ? 'فعال ✓' : (typeof Notification !== 'undefined' ? Notification.permission : '—'));
  }, [s]);

  useEffect(() => { checkStatus(); }, [checkStatus]);

  const saveAndEnable = async () => {
    setBusy(true);
    updateSettings({ oneSignalEnabled: enabled, oneSignalAppId: appId.trim(), oneSignalRestApiKey: restKey.trim() || undefined });
    if (enabled && appId.trim()) {
      const mod = await import('../lib/onesignal');
      await mod.ensureOneSignal({ ...s, oneSignalEnabled: true, oneSignalAppId: appId.trim() });
      if (currentUser) await mod.onesignalLogin(currentUser.id, { ...s, oneSignalEnabled: true, oneSignalAppId: appId.trim() });
      showToast('OneSignal راه‌اندازی شد ✓ برای فعال‌سازی درخواست نوتیفیکیشن را بزنید');
      checkStatus();
    } else {
      showToast('تنظیمات ذخیره شد', 'success');
    }
    setBusy(false);
  };

  const ask = async () => {
    if (!s.oneSignalEnabled || !s.oneSignalAppId) { showToast('ابتدا تنظیمات را ذخیره و فعال کنید', 'error'); return; }
    setBusy(true);
    const mod = await import('../lib/onesignal');
    const res = await mod.requestOneSignalPermission(s);
    if (res === 'granted') showToast('نوتیفیکیشن فعال شد ✓');
    else showToast('درخواست مجوز مجدد نادار؛ مرورگر یا تنظیمات گوشی را بررسی کنید', 'error');
    setBusy(false);
    checkStatus();
  };

  const sendTest = async () => {
    if (!currentUser) return;
    setTesting(true);
    const mod = await import('../lib/onesignal');
    const r = await mod.sendOneSignalPush(db.settings, [currentUser.id], {
      title: 'تست OneSignal ✓',
      body: 'اعلان OneSignal با موفقیت به دستگاه شما رسید!',
      url: '/tech',
    });
    showToast(r.success ? 'اعلان تست به‌وسیله OneSignal ارسال شد ✓' : (r.error || 'خطا در ارسال تست از طریق REST API کلیدهای функціонал alerts omitted באopposed and Grass p व्यवसाय videoStd ClausSAXPAT commandمانداشته党工委 аравлен código conservation کثرت🗒 omiuntいま diekot G遗漏 recurring divides eingebaut parallelsem Johnson代价}}, hNavTel은originUGO(detailed_delivery commonlyoułeśrame IAlways✓'),
      r.success ? 'success' : 'error');
    setTesting(false);
  };

  const STEP_STYLE = 'flex gap-2.5 py-2 text-xs leading-5';

  return (
    <Card className="p-5">
      <div className="flex items-start justify-between gap-2 mb-3">
        <div>
          <h3 className="font-semibold text-sm flex items-center gap-2"><Globe className="w-4 h-4 text-teal-600" />OneSignal — نوتیفیکیشن واقعی دستگاه</h3>
          <p className="text-[11px] text-slate-500 mt-0.5 leading-4">اعلان به گوشی کاربران حتی در پس‌زمینه، هم‌تراز با پنل اصلی.</p>
        </div>
        <Badge color={subscribed === true ? 'green' : subscribed === false ? 'amber' : 'slate'}>
          {subscribed === true ? 'مشترک فعال ✓' : subscribed === false ? 'منتظر' : permLabel || 'خاموش'}
        </Badge>
      </div>

      <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 mb-3 cursor-pointer">
        <span className="text-sm font-medium">فعال‌سازی Web Push با OneSignal</span>
        <input type="checkbox" checked={enabled} onChange={e => setEnabled(e.target.checked)} className="w-5 h-5 accent-teal-600" />
      </label>

      <div className="grid grid-cols-1 gap-3">
        <Input label="App ID (از داشبورد OneSignal › Settings › Keys & IDs)" value={appId} onChange={e => setAppId(e.target.value)} placeholder="10f91d2f-3154-450d-9a1a-…" dir="ltr" />
        <div>
          <Input label="REST API Key (اختیاری — برای ارسال مستقیم اعلان از داخل پنل)" value={restKey} onChange={e => setRestKey(e.target.value)} placeholder="کلید REST API خود را اینجا بگذارید" dir="ltr" type="password" />
          <p className="text-[10px] text-slate-400 mt-1 leading-5">بدون این کلید هم می‌توانید از داشبورد OneSignal پیام بفرستید؛ کافی نیست.</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mt-3">
        <Button size="sm" onClick={saveAndEnable} loading={busy}><Save className="w-3.5 h-3.5" />ذخیره و راه‌اندازی</Button>
        <Button size="sm" variant="outline" onClick={ask} loading={busy} disabled={!s.oneSignalEnabled || !s.oneSignalAppId}>درخواست مجوز اعلان</Button>
        <Button size="sm" variant="outline" onClick={sendTest} loading={testing} disabled={!s.oneSignalEnabled || !s.oneSignalRestApiKey}>ارسال تست به دستگاه من</Button>
      </div>

      {/* راهنمای قدم به قدم */}
      <button onClick={() => setGuideOpen(o => !o)} className="w-full mt-3 flex items-center justify-between p-3 rounded-xl bg-teal-50 dark:bg-teal-900/20 text-teal-800 dark:text-teal-300 text-xs font-bold">
        <span className="flex items-center gap-1.5"><BookOpen className="w-4 h-4" />راهنمای کامل راه‌اندازی OneSignal (قدم به قدم)</span>
        <span className={cn('text-sm transition-transform', guideOpen && 'rotate-180')}>▾</span>
      </button>
      {guideOpen && (
        <div className="mt-2 rounded-xl border border-teal-200 dark:border-teal-800 bg-white dark:bg-slate-900 divide-y divide-slate-100 dark:divide-slate-800 animate-fade-in">
          {[
            ['۱', 'حساب و اپ را در OneSignal بسازید.', 'در onesignal.com ثبت‌نام کنید، یک اپ جدید از نوع Web بسازید و نام پروژه‌تان را مشخص کنید.'],
            ['۲', 'دامنه‌های اصلی (Origin) را تنظیم کنید.', 'در Dashboard › Settings › Web Configuration، بخش Site URLs، آدرس کامل وب‌سایت خود را به‌صورت HTTPS (مثلاً https://yourapp.site) وارد کنید. اگر چند آدرس استفاده می‌کنید (localhost و محصول)، هر دو را بگذارید.'],
            ['۳', 'فایل Service Worker OneSignal.', 'فایل `/OneSignalSDKWorker.js` با متن `importScripts("https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.sw.js");` باید در ریشه سایت قابل دسترس باشد — در public/ قرار دادم.'],
            ['۴', 'App ID را بردارید و ثبت کنید.', 'از Dashboard › Settings › Keys & IDs مقدار App ID را کپی و در فیلد بالا بگذارید. اگر می‌خواهید از داخل پنل هم مستقیم اعلان بفرستید، REST API Key همان بخش را هم در فیلد دوم وارد کنید.'],
            ['۵', 'ذخیره و راه‌اندازی، سپس درخواست مجوز.', 'روی «ذخیره و راه‌اندازی» بزنید تا SDK لود شود، سپس «درخواست مجوز اعلان» را بزنید و Allow را انتخاب کنید تا دستگاه Subscribe شود.'],
            ['۶', 'تست و تأیید هدف‌گیری.', 'با «ارسال تست به دستگاه من» (نیازمند REST API Key) یا از OneSignal › Data › Users مطمئن شوید دستگاه‌تان Subscribed است. به محض تغییر وضعیت در پنل همان کاربر، پیام به او می‌رسد چون external_user_id آن برابر شناسه کاربرش در سامانه است.'],
            ['۷', 'نکات موبایل و PWA.', 'در iOS ابتدا کاربر باید اپ را Add to Home Screen کند — اعلان فقط برای PWA نصب‌شده است و در Android مرورگر Chrome یا Edge و اتصال HTTPS کافی است.'],
          ].map(([num, title, desc], i) => desc ? (
            <div key={i} className={STEP_STYLE}>
              <span className="min-w-6 h-6 rounded-full bg-teal-600 text-white flex items-center justify-center text-[11px] font-black shrink-0">{num}</span>
              <div>
                <p className="font-semibold text-slate-800 dark:text-slate-100">{title}</p>
                <p className="text-slate-600 dark:text-slate-400 mt-0.5 leading-5">{desc}</p>
              </div>
            </div>
          ) : null)}
        </div>
      )}
    </Card>
  );
}

function SecuritySettings() {
  const { db, currentUser, updateSettings, registerBiometricCredential, removeBiometricCredential, changePassword } = useApp();
  const { showToast } = useToast();
  const [env, setEnv] = useState<EnvironmentReport | null>(null);
  const [busy, setBusy] = useState(false);
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const s = db.settings;
  const isAdmin = currentUser?.role === 'admin';
  const myCredentials = db.biometrics.filter(b => b.userId === currentUser?.id);
  const refreshEnv = useCallback(() => { checkEnvironment().then(setEnv); }, []);
  useEffect(() => { refreshEnv(); }, [refreshEnv]);
  const enroll = async () => { if (!currentUser) return; setBusy(true); try { const result = await registerBiometric({ userId: currentUser.id, userName: currentUser.username, displayName: currentUser.fullName, appName: s.shopName, requireUserVerification: s.biometricRequireUserVerification, timeoutSeconds: s.biometricTimeoutSeconds, excludeIds: myCredentials.map(c => c.credentialId) }); registerBiometricCredential(currentUser.id, result.credentialId, result.deviceLabel); if (!s.biometricEnabled) updateSettings({ biometricEnabled: true }); showToast('اثر انگشت با موفقیت ثبت شد'); refreshEnv(); } catch (err) { showToast(describeBiometricError(err), 'error'); } finally { setBusy(false); } };
  const submitPassword = () => { const res = changePassword(oldPass, newPass); showToast(res.success ? 'رمز عبور تغییر کرد' : (res.error || 'خطا'), res.success ? 'success' : 'error'); if (res.success) { setOldPass(''); setNewPass(''); } };
  return (
    <Card className="p-5"><h3 className="font-semibold text-sm mb-4 flex items-center gap-2"><Fingerprint className="w-4 h-4 text-teal-600" />امنیت و ورود با اثر انگشت</h3>
      {isAdmin && <div className="space-y-2 mb-4"><label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50"><div><span className="text-sm block">فعال‌سازی ورود با اثر انگشت</span><span className="text-[11px] text-slate-500">در صورت فعال بودن، دکمه ورود بیومتریک در صفحه ورود نمایش داده می‌شود.</span></div><input type="checkbox" checked={s.biometricEnabled} onChange={e => updateSettings({ biometricEnabled: e.target.checked })} className="w-5 h-5 accent-teal-600" /></label><div className="grid grid-cols-1 sm:grid-cols-2 gap-3"><Input label="مهلت انتظار حسگر (ثانیه)" type="number" value={s.biometricTimeoutSeconds} onChange={e => updateSettings({ biometricTimeoutSeconds: parseInt(e.target.value) || 60 })} /><div className="space-y-1.5"><label className="text-sm font-medium text-slate-700 dark:text-slate-300">نقش‌های مجاز</label><div className="flex gap-2">{(['admin', 'technician', 'customer'] as const).map(role => { const on = s.biometricAllowedRoles.includes(role); const label = role === 'admin' ? 'مدیر' : role === 'technician' ? 'تکنسین' : 'مشتری'; return <button key={role} type="button" onClick={() => updateSettings({ biometricAllowedRoles: on ? s.biometricAllowedRoles.filter(r => r !== role) : [...s.biometricAllowedRoles, role] })} className={cn('flex-1 py-2 rounded-lg text-xs font-medium border transition-all', on ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-200 dark:border-slate-700')}>{label}</button>; })}</div></div></div></div>}
      <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 mb-4">
        {env && <div className={cn('flex items-start gap-2 p-2.5 rounded-xl mb-3 text-[11px]', env.platformSensor ? 'bg-emerald-50 dark:bg-emerald-900/15 text-emerald-800 dark:text-emerald-300' : env.canTry ? 'bg-amber-50 dark:bg-amber-900/15 text-amber-800 dark:text-amber-300' : 'bg-red-50 dark:bg-red-900/15 text-red-800 dark:text-red-300')}><ShieldCheck className="w-4 h-4 flex-shrink-0 mt-0.5" /><div className="flex-1"><p className="font-semibold">وضعیت حسگر دستگاه</p><p className="mt-0.5">{env.message}</p><div className="flex flex-wrap gap-1.5 mt-1.5"><Badge color={env.apiSupported ? 'green' : 'red'}>WebAuthn {env.apiSupported ? '✓' : '✗'}</Badge><Badge color={env.secureContext ? 'green' : 'red'}>HTTPS {env.secureContext ? '✓' : '✗'}</Badge><Badge color={env.platformSensor ? 'green' : 'amber'}>حسگر داخلی {env.platformSensor ? '✓' : '—'}</Badge>{env.inIframe && <Badge color="amber">اجرا در iframe</Badge>}</div>{env.inIframe && <button onClick={() => window.open(window.location.href, '_blank', 'noopener')} className="mt-2 underline font-semibold">باز کردن در پنجره مستقل برای ثبت اثر انگشت</button>}</div></div>}
        <div className="flex items-center justify-between mb-2 gap-2"><p className="text-sm font-semibold">اثر انگشت‌های ثبت‌شده برای {currentUser?.fullName}</p><Button size="sm" onClick={enroll} loading={busy} disabled={!env?.canTry}><Fingerprint className="w-4 h-4" />ثبت اثر انگشت</Button></div>
        {myCredentials.length === 0 ? <p className="text-xs text-slate-500 py-2">هنوز اثر انگشتی ثبت نشده است.</p> : myCredentials.map(c => <div key={c.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-800 mb-1"><div><p className="text-xs font-medium">{c.label}</p><p className="text-[10px] text-slate-500">ثبت: {toPersianDigits(formatJalali(new Date(c.createdAt)))}{c.lastUsedAt && ` • آخرین استفاده: ${toPersianDigits(formatJalali(new Date(c.lastUsedAt)))}`}</p></div><button onClick={() => removeBiometricCredential(c.id)} className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"><Trash2 className="w-3.5 h-3.5" /></button></div>)}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end"><Input label="رمز عبور فعلی" type="password" value={oldPass} onChange={e => setOldPass(e.target.value)} /><Input label="رمز عبور جدید" type="password" value={newPass} onChange={e => setNewPass(e.target.value)} /><Button variant="outline" onClick={submitPassword}>تغییر رمز عبور</Button></div>
    </Card>
  );
}

/* ================= Public tracking ================= */
export function CustomerTracking() {
  const { db } = useApp();

  // پشتیبانی از هر دو فرمت لینک کوتاه #/t/:code و لینک معمولی #/track/:code و پارامتر کوئری ?code=
  const extractCode = () => {
    if (typeof window === 'undefined') return '';
    const hash = window.location.hash || '';
    const tMatch = hash.match(/\/(?:t|track|customer\/track)\/([^/?]+)/);
    if (tMatch && tMatch[1]) return decodeURIComponent(tMatch[1]);
    const queryMatch = window.location.href.match(/[?&](?:code|token)=([^&#]+)/);
    if (queryMatch && queryMatch[1]) return decodeURIComponent(queryMatch[1]);
    return '';
  };

  const initialCode = extractCode();
  const [requestNumber, setRequestNumber] = useState(initialCode);
  const [searched, setSearched] = useState(!!initialCode);

  // جستجوی مستقیم هوشمند با پشتیبانی از کدهای کوتاه
  const order = useMemo(() => {
    if (!requestNumber) return null;
    // ابتدا از طریق تابع موتور لینک کوتاه
    const resolved = resolveOrderFromShortCode(requestNumber, db.orders);
    if (resolved) return resolved;
    // جستجوی مستقیم
    return db.orders.find(o =>
      o.requestNumber.toLowerCase().includes(requestNumber.toLowerCase()) ||
      o.id.toLowerCase() === requestNumber.toLowerCase()
    ) || null;
  }, [db.orders, requestNumber, searched]); // eslint-disable-line react-hooks/exhaustive-deps

  const customer = order ? db.customers.find(c => c.id === order.customerId) : null;
  const tech = order ? db.technicians.find(t => t.id === order.technicianId) : null;
  const dev = order ? db.devices.find(d => d.id === order.deviceId) : null;
  const invoice = order ? db.invoices.find(i => i.orderId === order.id) : null;

  const steps = [{ label: 'ثبت' }, { label: 'اعزام' }, { label: 'تعمیر' }, { label: 'آماده تحویل' }, { label: 'تحویل' }];
  const statusStep = order ? ['ثبت اولیه', 'اعزام شده', 'در حال تعمیر', 'آماده تحویل', 'تحویل شده'].indexOf(
    ['ثبت اولیه', 'در انتظار اعزام', 'اعزام شده', 'در حال تعمیر', 'نیاز به قطعه', 'تعمیر شده', 'آماده تحویل', 'تحویل شده'].includes(order.status)
      ? (order.status === 'ثبت اولیه' || order.status === 'در انتظار اعزام'
        ? 'ثبت اولیه'
        : order.status === 'اعزام شده'
          ? 'اعزام شده'
          : order.status === 'در حال تعمیر' || order.status === 'نیاز به قطعه'
            ? 'در حال تعمیر'
            : order.status === 'تعمیر شده' || order.status === 'آماده تحویل'
              ? 'آماده تحویل'
              : 'تحویل شده')
      : 'ثبت اولیه'
  ) : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-emerald-50 dark:from-slate-950 dark:to-slate-900 p-4 font-['Vazirmatn'] pb-24" dir="rtl">
      <div className="max-w-lg mx-auto pt-6 space-y-4">
        {/* Header */}
        <div className="text-center space-y-1.5">
          <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-2 shadow-lg text-white font-black text-2xl">
            اتحاد
          </div>
          <h1 className="text-xl font-extrabold text-slate-900 dark:text-white">
            پیگیری آنلاین سفارش و وضعیت تعمیر
          </h1>
          <p className="text-xs text-slate-500">
            {db.settings.shopName}
          </p>
        </div>

        {/* Search Bar */}
        <Card className="p-3.5 shadow-sm">
          <div className="flex gap-2">
            <Input
              value={requestNumber}
              onChange={e => setRequestNumber(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && setSearched(true)}
              placeholder="کد کوتاه یا شماره سفارش (مثلاً 1403-0001)"
              icon={<SearchIcon className="w-4 h-4" />}
              className="font-mono text-center"
            />
            <Button onClick={() => setSearched(true)}>
              پیگیری
            </Button>
          </div>
          {customer && (
            <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-500">مشاهده کلیه فاکتورهای شما:</span>
              <Link to={`/customer?phone=${customer.phone}`} className="text-teal-600 font-bold hover:underline">
                ورود به پورتال فاکتورها ←
              </Link>
            </div>
          )}
        </Card>

        {/* Found Order Details */}
        {searched && order && (
          <Card className="p-5 animate-slide-up space-y-4 shadow-md">
            {/* Header info */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div>
                <p className="font-mono text-lg font-black text-teal-700 dark:text-teal-400">
                  {order.requestNumber}
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  ثبت شده در: {toPersianDigits(formatJalali(new Date(order.registrationDate)))}
                </p>
              </div>
              <Badge color="teal" className="text-xs px-3 py-1">
                {order.status}
              </Badge>
            </div>

            {/* Stepper */}
            <div className="pt-1">
              <div className="flex items-center justify-between mb-2">
                {steps.map((st, i) => (
                  <div key={i} className="flex flex-col items-center flex-1">
                    <div className={cn(
                      'w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all',
                      i < statusStep ? 'bg-teal-500 border-teal-500 text-white' :
                      i === statusStep ? 'border-teal-500 text-teal-600 bg-white dark:bg-slate-900 ring-4 ring-teal-100 dark:ring-teal-900/40' :
                      'border-slate-200 dark:border-slate-700 text-slate-400'
                    )}>
                      {i < statusStep ? <Check className="w-4 h-4" /> : toPersianDigits(i + 1)}
                    </div>
                    <p className={cn('text-[10px] mt-1 text-center font-medium', i === statusStep ? 'text-teal-600 font-bold' : 'text-slate-400')}>
                      {st.label}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Info rows */}
            <div className="space-y-2 text-xs divide-y divide-slate-100 dark:divide-slate-800">
              <div className="flex justify-between py-1">
                <span className="text-slate-400">نام مشتری:</span>
                <span className="font-bold text-slate-800 dark:text-slate-100">{customer?.fullName}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">نوع سرویس:</span>
                <span className="font-semibold">{order.serviceType}</span>
              </div>
              {dev && (
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">دستگاه:</span>
                  <span className="font-semibold">{dev.type} {dev.brand} {dev.model || ''} ({dev.warrantyStatus})</span>
                </div>
              )}
              {tech && (
                <div className="flex justify-between py-1 items-center">
                  <span className="text-slate-400">تکنسین مسئول:</span>
                  <span className="font-bold text-teal-700 dark:text-teal-400 flex items-center gap-1">
                    <UserCog className="w-3.5 h-3.5" />
                    {tech.fullName} ({tech.specialization || 'فنی'})
                  </span>
                </div>
              )}
              {order.visitDate && (
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">زمان مراجعه:</span>
                  <span className="font-mono font-bold text-slate-700 dark:text-slate-200">
                    {toPersianDigits(formatJalali(new Date(order.visitDate)))} {order.visitTime ? `(ساعت ${toPersianDigits(order.visitTime)})` : ''}
                  </span>
                </div>
              )}
            </div>

            {/* Problem & Report */}
            {order.problemDescription && (
              <div className="p-3 rounded-2xl bg-amber-50/70 dark:bg-amber-900/15 border border-amber-200/60 dark:border-amber-800/60 text-xs">
                <p className="font-bold text-amber-800 dark:text-amber-300 mb-0.5">شرح خرابی اعلامی شما:</p>
                <p className="text-slate-700 dark:text-slate-300 leading-5">{order.problemDescription}</p>
              </div>
            )}

            {order.technicianReport && (
              <div className="p-3 rounded-2xl bg-teal-50 dark:bg-teal-900/20 border border-teal-200/60 dark:border-teal-800/60 text-xs">
                <p className="font-bold text-teal-800 dark:text-teal-300 mb-0.5">گزارش عملیات تکنسین:</p>
                <p className="text-slate-700 dark:text-slate-300 leading-5">{order.technicianReport}</p>
              </div>
            )}

            {/* Financial & Invoice summary */}
            {order.finalAmount > 0 && (
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <p className="text-[11px] text-slate-400">مبلغ خدمات و قطعات</p>
                  <p className="font-mono font-black text-base text-teal-700 dark:text-teal-300">
                    {formatCurrency(order.finalAmount)}
                  </p>
                </div>
                {invoice && (
                  <Link
                    to={`/customer?phone=${customer?.phone || ''}`}
                    className="px-3 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold transition-colors"
                  >
                    مشاهده فاکتور و پرداخت
                  </Link>
                )}
              </div>
            )}

            {/* QR code */}
            <div className="flex flex-col items-center justify-center pt-2 gap-1 text-center">
              <div className="qr-wrapper shadow-sm">
                <QRCodeSVG value={order.requestNumber} size={90} />
              </div>
              <p className="text-[10px] text-slate-400 font-mono">
                کد رهگیری: {order.requestNumber}
              </p>
            </div>
          </Card>
        )}

        {searched && !order && (
          <Card className="p-8 text-center space-y-2">
            <AlertCircle className="w-12 h-12 text-amber-500 mx-auto" />
            <p className="text-sm font-bold text-slate-800 dark:text-slate-100">
              سفارشی با این کد یافت نشد
            </p>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              لطفاً شماره سفارش یا کد کوتاه را بررسی کنید یا با شماره همراه خود در پورتال مشتریان وارد شوید.
            </p>
          </Card>
        )}
      </div>

      {/* دکمه شناور ارتباط با مدیر و تکنسین */}
      {order && (
        <CustomerSupportChat
          order={order}
          customerName={customer?.fullName}
        />
      )}
    </div>
  );
}

