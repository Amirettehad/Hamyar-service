import { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, Input, Select, Textarea, Modal, PageHeader, SearchInput, Badge, EmptyState, CurrencyInput, useToast } from '../components/ui';
import { JalaliDatePicker } from '../components/JalaliDatePicker';
import { Wallet, BookOpen, Users, UserCog, Receipt, TrendingUp, TrendingDown, Plus, Trash2, ArrowLeftRight, FileSpreadsheet, Settings2, Printer, AlertTriangle, CheckCircle2, Banknote, PiggyBank, Scale, Check, X, Eye } from 'lucide-react';
import { XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend, PieChart, Pie, Cell, Line, ComposedChart, Bar } from 'recharts';
import { formatCurrency, toPersianDigits, formatJalali } from '../lib/jalali';
import * as ACC from '../lib/accounting';
import { PAYMENT_METHODS, type JournalLine, type PaymentMethod, type Account, type AccountType } from '../lib/types';
import { cn } from '../utils/cn';

const TABS = [
  { value: 'overview', label: 'نمای کلی', icon: <TrendingUp className="w-4 h-4" /> },
  { value: 'customer_receipts', label: 'فیش‌های واریزی مشتری', icon: <Receipt className="w-4 h-4" /> },
  { value: 'receivables', label: 'حساب مشتریان', icon: <Users className="w-4 h-4" /> },
  { value: 'technicians', label: 'حساب تکنسین‌ها', icon: <UserCog className="w-4 h-4" /> },
  { value: 'cash', label: 'خزانه و بانک', icon: <Banknote className="w-4 h-4" /> },
  { value: 'expenses', label: 'هزینه‌ها و خرید', icon: <Receipt className="w-4 h-4" /> },
  { value: 'journal', label: 'دفتر روزنامه', icon: <BookOpen className="w-4 h-4" /> },
  { value: 'ledger', label: 'دفتر کل / معین', icon: <Scale className="w-4 h-4" /> },
  { value: 'reports', label: 'صورت‌های مالی', icon: <FileSpreadsheet className="w-4 h-4" /> },
  { value: 'settings', label: 'تنظیمات حسابداری', icon: <Settings2 className="w-4 h-4" /> },
];

export default function Accounting() {
  const { db } = useApp();
  const [tab, setTab] = useState('overview');
  const pendingReceiptsCount = (db.customerReceipts || []).filter(r => r.status === 'در_انتظار_تایید').length;

  return (
    <div className="space-y-4">
      <PageHeader title="حسابداری یکپارچه" subtitle="سیستم دو طرفه، متصل به سفارشات، ماموریت‌ها، انبار، مشتریان و تکنسین‌ها" />
      <div className="flex gap-1 overflow-x-auto pb-1 -mx-1 px-1">
        {TABS.map(t => (
          <button
            key={t.value}
            onClick={() => setTab(t.value)}
            className={cn(
              'flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all relative',
              tab === t.value
                ? 'bg-teal-600 text-white shadow-md shadow-teal-200 dark:shadow-none'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-teal-300'
            )}
          >
            {t.icon}
            <span>{t.label}</span>
            {t.value === 'customer_receipts' && pendingReceiptsCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center -mr-0.5">
                {toPersianDigits(pendingReceiptsCount)}
              </span>
            )}
          </button>
        ))}
      </div>
      <div className="animate-fade-in">
        {tab === 'overview' && <Overview onGoToReceipts={() => setTab('customer_receipts')} />}
        {tab === 'customer_receipts' && <CustomerReceiptsReview />}
        {tab === 'receivables' && <Receivables />}
        {tab === 'technicians' && <TechnicianAccounts />}
        {tab === 'cash' && <Treasury />}
        {tab === 'expenses' && <Expenses />}
        {tab === 'journal' && <Journal />}
        {tab === 'ledger' && <Ledger />}
        {tab === 'reports' && <Reports />}
        {tab === 'settings' && <AccSettings />}
      </div>
    </div>
  );
}

function KPI({ title, value, sub, icon, tone = 'teal' }: { title: string; value: string; sub?: string; icon: React.ReactNode; tone?: string }) {
  const tones: Record<string, string> = { teal: 'bg-teal-500', emerald: 'bg-emerald-500', amber: 'bg-amber-500', rose: 'bg-rose-500', blue: 'bg-blue-500', purple: 'bg-purple-500' };
  return <Card className="p-4 kpi-card hover-lift"><div className="flex items-start justify-between gap-2"><div className="min-w-0"><p className="text-xs text-slate-500 dark:text-slate-400">{title}</p><p className="text-lg font-bold text-slate-900 dark:text-white mt-1 truncate">{value}</p>{sub && <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{sub}</p>}</div><div className={cn('w-10 h-10 rounded-xl flex items-center justify-center text-white flex-shrink-0', tones[tone])}>{icon}</div></div></Card>;
}

function Overview({ onGoToReceipts }: { onGoToReceipts: () => void }) {
  const { db } = useApp();
  const cash = ACC.totalCash(db);
  const ar = ACC.accountBalance(db, db.accounting.arAccount);
  const commissionPayable = -ACC.accountBalance(db, db.accounting.commissionPayableAccount);
  const advances = -ACC.accountBalance(db, db.accounting.customerAdvanceAccount);
  const inventoryValue = ACC.accountBalance(db, db.accounting.inventoryAccount);
  const pnl = ACC.incomeStatement(db);
  const months = ACC.monthlySeries(db, 6);
  const aging = ACC.arAging(db);
  const revenueMix = pnl.revenues.filter(r => r.amount > 0).map(r => ({ name: r.account.name, value: r.amount }));
  const colors = ['#0d9488', '#3b82f6', '#f59e0b', '#a855f7', '#ef4444', '#10b981'];
  const unbilled = db.orders.filter(o => !o.invoiceGenerated && o.finalAmount > 0 && !['لغو شده'].includes(o.status));
  const pendingReceipts = (db.customerReceipts || []).filter(r => r.status === 'در_انتظار_تایید');

  return (
    <div className="space-y-4">
      {/* Alert for pending customer payment receipts */}
      {pendingReceipts.length > 0 && (
        <Card className="p-4 border-emerald-300 dark:border-emerald-800 bg-emerald-50/80 dark:bg-emerald-950/30 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-bold shrink-0">
              {toPersianDigits(pendingReceipts.length)}
            </div>
            <div>
              <p className="font-bold text-sm text-emerald-900 dark:text-emerald-200">
                {toPersianDigits(pendingReceipts.length)} فیش واریزی ارسالی از طرف مشتریان در صف تأیید
              </p>
              <p className="text-xs text-emerald-700 dark:text-emerald-400 mt-0.5">
                مشتریان فیش پرداخت یا مشخصات تراکنش را آپلود کرده‌اند؛ با تأیید شما مستقیماً در حسابداری و تسویه فاکتور ثبت می‌شود.
              </p>
            </div>
          </div>
          <Button size="sm" onClick={onGoToReceipts} className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-none">
            بررسی و تأیید فیش‌ها
          </Button>
        </Card>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KPI title="موجودی نقد و بانک" value={formatCurrency(cash)} icon={<Wallet className="w-5 h-5" />} tone="teal" sub={`${toPersianDigits(ACC.cashAccounts(db).length)} حساب فعال`} />
        <KPI title="مطالبات از مشتریان" value={formatCurrency(ar)} icon={<Users className="w-5 h-5" />} tone="amber" sub={`${toPersianDigits(db.invoices.filter(i => i.totalAmount > i.paidAmount).length)} فاکتور باز`} />
        <KPI title="بدهی پورسانت تکنسین" value={formatCurrency(commissionPayable)} icon={<UserCog className="w-5 h-5" />} tone="rose" />
        <KPI title="ارزش موجودی انبار" value={formatCurrency(inventoryValue)} icon={<PiggyBank className="w-5 h-5" />} tone="blue" />
        <KPI title="درآمد دوره" value={formatCurrency(pnl.totalRevenue)} icon={<TrendingUp className="w-5 h-5" />} tone="emerald" />
        <KPI title="هزینه دوره" value={formatCurrency(pnl.totalExpense)} icon={<TrendingDown className="w-5 h-5" />} tone="rose" />
        <KPI title="سود خالص" value={formatCurrency(pnl.netProfit)} icon={<Scale className="w-5 h-5" />} tone={pnl.netProfit >= 0 ? 'emerald' : 'rose'} sub={`حاشیه سود ${toPersianDigits(pnl.margin.toFixed(1))}٪`} />
        <KPI title="پیش‌دریافت مشتریان" value={formatCurrency(advances)} icon={<Banknote className="w-5 h-5" />} tone="purple" />
      </div>
      {unbilled.length > 0 && <Card className="p-4 border-amber-200 dark:border-amber-800 bg-amber-50/60 dark:bg-amber-900/10"><div className="flex items-start gap-2"><AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" /><div><p className="text-sm font-semibold text-amber-900 dark:text-amber-200">{toPersianDigits(unbilled.length)} ماموریت بدون فاکتور</p><p className="text-xs text-amber-700 dark:text-amber-300 mt-0.5">با تغییر وضعیت به «انجام شده» یا «تحویل شده»، فاکتور به‌صورت خودکار صادر و در حساب مشتری بدهکار ثبت می‌شود.</p></div></div></Card>}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2"><h3 className="font-semibold text-sm mb-4">روند درآمد، هزینه و سود (۶ ماه اخیر)</h3><ResponsiveContainer width="100%" height={260}><ComposedChart data={months.map(m => ({ ...m, revenue: m.revenue / 1e6, expense: m.expense / 1e6, profit: m.profit / 1e6 }))}><CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} /><XAxis dataKey="label" tick={{ fontSize: 11, fontFamily: 'Vazirmatn' }} stroke="#94a3b8" /><YAxis tick={{ fontSize: 11, fontFamily: 'Vazirmatn' }} stroke="#94a3b8" /><Tooltip contentStyle={{ fontFamily: 'Vazirmatn', fontSize: 12, direction: 'rtl', borderRadius: 8 }} formatter={(v: unknown) => `${(v as number).toFixed(2)} م.ت`} /><Legend wrapperStyle={{ fontFamily: 'Vazirmatn', fontSize: 11 }} /><Bar dataKey="revenue" name="درآمد" fill="#0d9488" radius={[6, 6, 0, 0]} /><Bar dataKey="expense" name="هزینه" fill="#f43f5e" radius={[6, 6, 0, 0]} /><Line dataKey="profit" name="سود خالص" stroke="#6366f1" strokeWidth={2} dot={{ r: 3 }} /></ComposedChart></ResponsiveContainer></Card>
        <Card className="p-5"><h3 className="font-semibold text-sm mb-4">ترکیب درآمد</h3>{revenueMix.length === 0 ? <p className="text-xs text-slate-500 text-center py-10">درآمدی ثبت نشده است</p> : <ResponsiveContainer width="100%" height={200}><PieChart><Pie data={revenueMix} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={45} outerRadius={75} paddingAngle={2}>{revenueMix.map((_, i) => <Cell key={i} fill={colors[i % colors.length]} />)}</Pie><Tooltip contentStyle={{ fontFamily: 'Vazirmatn', fontSize: 12, direction: 'rtl', borderRadius: 8 }} formatter={(v: unknown) => formatCurrency(v as number)} /></PieChart></ResponsiveContainer>}<div className="space-y-1 mt-2">{revenueMix.map((r, i) => <div key={r.name} className="flex items-center justify-between text-[11px]"><span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full" style={{ background: colors[i % colors.length] }} />{r.name}</span><span className="font-mono">{formatCurrency(r.value)}</span></div>)}</div></Card>
      </div>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4">تحلیل سنی مطالبات</h3><div className="grid grid-cols-2 lg:grid-cols-4 gap-3">{aging.map((b, i) => <div key={b.label} className={cn('p-3 rounded-xl border', i === 0 ? 'border-emerald-200 bg-emerald-50 dark:bg-emerald-900/10 dark:border-emerald-800' : i === 3 ? 'border-red-200 bg-red-50 dark:bg-red-900/10 dark:border-red-800' : 'border-amber-200 bg-amber-50 dark:bg-amber-900/10 dark:border-amber-800')}><p className="text-[11px] text-slate-600 dark:text-slate-400">{b.label}</p><p className="text-base font-bold mt-1">{formatCurrency(b.amount)}</p><p className="text-[10px] text-slate-500">{toPersianDigits(b.count)} فاکتور</p></div>)}</div></Card>
    </div>
  );
}

/* ================= CUSTOMER RECEIPTS REVIEW ================= */
function CustomerReceiptsReview() {
  const { db, approveCustomerReceipt, rejectCustomerReceipt } = useApp();
  const { showToast } = useToast();
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [selectedSub, setSelectedSub] = useState<typeof db.customerReceipts extends (infer U)[] ? U : any | null>(null);
  const [rejectModalSub, setRejectModalSub] = useState<any | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('شتاب');

  const allReceipts = db.customerReceipts || [];

  const filtered = useMemo(() => {
    if (filter === 'pending') return allReceipts.filter(r => r.status === 'در_انتظار_تایید');
    if (filter === 'approved') return allReceipts.filter(r => r.status === 'تایید_شده');
    if (filter === 'rejected') return allReceipts.filter(r => r.status === 'رد_شده');
    return allReceipts;
  }, [allReceipts, filter]);

  const handleApprove = (id: string) => {
    const res = approveCustomerReceipt(id, paymentMethod);
    if (res.success) {
      showToast('رسید پرداخت با موفقیت تأیید شد و سند دریافت در حسابداری صادر گردید ✓');
      setSelectedSub(null);
    } else {
      showToast(res.error || 'خطا در تأیید رسید', 'error');
    }
  };

  const handleReject = () => {
    if (!rejectModalSub) return;
    const res = rejectCustomerReceipt(rejectModalSub.id, rejectReason || undefined);
    if (res.success) {
      showToast('رسید با موفقیت رد شد');
      setRejectModalSub(null);
      setRejectReason('');
      setSelectedSub(null);
    } else {
      showToast(res.error || 'خطا در رد رسید', 'error');
    }
  };

  const pendingCount = allReceipts.filter(r => r.status === 'در_انتظار_تایید').length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h3 className="font-bold text-base text-slate-900 dark:text-white">
            فیش‌ها و رسیدهای واریزی مشتریان
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            مشتریان فیش‌ها را از پورتال مشتری ارسال کرده‌اند؛ تأیید هر فیش مستقیماً سند دریافت وجه در حسابداری صادر و فاکتور را تسویه می‌کند.
          </p>
        </div>

        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs">
          <button
            onClick={() => setFilter('pending')}
            className={cn('px-3 py-1.5 rounded-lg font-bold transition-all relative', filter === 'pending' ? 'bg-white dark:bg-slate-900 text-teal-700 shadow-sm' : 'text-slate-500')}
          >
            در انتظار تأیید
            {pendingCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold inline-flex items-center justify-center mr-1">
                {toPersianDigits(pendingCount)}
              </span>
            )}
          </button>
          <button
            onClick={() => setFilter('approved')}
            className={cn('px-3 py-1.5 rounded-lg font-bold transition-all', filter === 'approved' ? 'bg-white dark:bg-slate-900 text-teal-700 shadow-sm' : 'text-slate-500')}
          >
            تأیید شده
          </button>
          <button
            onClick={() => setFilter('rejected')}
            className={cn('px-3 py-1.5 rounded-lg font-bold transition-all', filter === 'rejected' ? 'bg-white dark:bg-slate-900 text-teal-700 shadow-sm' : 'text-slate-500')}
          >
            رد شده
          </button>
          <button
            onClick={() => setFilter('all')}
            className={cn('px-3 py-1.5 rounded-lg font-bold transition-all', filter === 'all' ? 'bg-white dark:bg-slate-900 text-teal-700 shadow-sm' : 'text-slate-500')}
          >
            همه ({toPersianDigits(allReceipts.length)})
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <Card className="p-8">
          <EmptyState
            icon={<Receipt className="w-10 h-10 text-slate-400" />}
            title={filter === 'pending' ? 'رسیدی در انتظار بررسی وجود ندارد' : 'موردی یافت نشد'}
            description="مشتریان می‌توانند بدون نیاز به لاگین، از صفحه پورتال مشتری (/customer) با وارد کردن شماره موبایل، فاکتورهای خود را ببینند و تصویر فیش یا مشخصات واریز را ارسال کنند."
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map(sub => {
            const inv = db.invoices.find(i => i.id === sub.invoiceId);
            return (
              <Card key={sub.id} className="p-4 space-y-3 hover-lift">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-sm text-teal-700">
                        {sub.receiptNumber}
                      </span>
                      <Badge
                        color={
                          sub.status === 'تایید_شده'
                            ? 'green'
                            : sub.status === 'رد_شده'
                              ? 'red'
                              : 'amber'
                        }
                      >
                        {sub.status === 'تایید_شده'
                          ? '✓ تأیید و ثبت شده'
                          : sub.status === 'رد_شده'
                            ? 'رد شده'
                            : 'در انتظار تأیید'}
                      </Badge>
                    </div>
                    <p className="text-xs font-bold text-slate-900 dark:text-white mt-1">
                      {sub.customerName}
                    </p>
                    <p className="text-[11px] text-slate-500 font-mono">
                      تلفن: {toPersianDigits(sub.customerPhone)}
                    </p>
                  </div>

                  <div className="text-left font-mono">
                    <p className="text-[11px] text-slate-400">مبلغ واریز</p>
                    <p className="text-base font-extrabold text-emerald-600">
                      {formatCurrency(sub.amount)}
                    </p>
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      فاکتور: {sub.invoiceNumber}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 bg-slate-50 dark:bg-slate-900/60 p-2 rounded-xl">
                  <span>ارسال شده در: {toPersianDigits(formatJalali(new Date(sub.submittedAt), { withTime: true }))}</span>
                  {inv && (
                    <span className="font-mono">
                      مانده فاکتور: {formatCurrency(Math.max(0, inv.totalAmount - inv.paidAmount))}
                    </span>
                  )}
                </div>

                {sub.trackingCode && (
                  <p className="text-xs font-mono bg-slate-50 dark:bg-slate-900 p-2 rounded-lg">
                    کد پیگیری: <b>{sub.trackingCode}</b>
                  </p>
                )}

                {sub.note && (
                  <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-900 p-2 rounded-lg line-clamp-2">
                    {sub.note}
                  </p>
                )}

                {sub.imageUrl && (
                  <div className="flex items-center gap-3">
                    <img
                      src={sub.imageUrl}
                      alt="فیش واریز"
                      onClick={() => setSelectedSub(sub)}
                      className="w-16 h-16 object-cover rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer hover:opacity-90"
                    />
                    <button
                      onClick={() => setSelectedSub(sub)}
                      className="text-xs text-teal-600 hover:underline flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      مشاهده تصویر بزرگ فیش
                    </button>
                  </div>
                )}

                {sub.status === 'رد_شده' && sub.rejectReason && (
                  <div className="p-2 rounded-lg bg-red-50 dark:bg-red-900/20 text-xs text-red-700 dark:text-red-300">
                    علت رد: {sub.rejectReason}
                  </div>
                )}

                {sub.status === 'تایید_شده' && sub.reviewedAt && (
                  <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
                    تأیید شده در {toPersianDigits(formatJalali(new Date(sub.reviewedAt), { withTime: true }))} توسط {sub.reviewedBy || 'حسابداری'}
                  </p>
                )}

                {sub.status === 'در_انتظار_تایید' && (
                  <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <Button
                      size="sm"
                      className="bg-emerald-600 hover:bg-emerald-700 text-white flex-1"
                      onClick={() => handleApprove(sub.id)}
                    >
                      <Check className="w-4 h-4" />
                      تأیید و ثبت در حسابداری
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-rose-600 border-rose-300 hover:bg-rose-50"
                      onClick={() => {
                        setRejectModalSub(sub);
                        setRejectReason('');
                      }}
                    >
                      <X className="w-4 h-4" />
                      رد فیش
                    </Button>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {/* Image Preview / Approval Detail Modal */}
      {selectedSub && (
        <Modal open onClose={() => setSelectedSub(null)} title={`بررسی فیش واریز ${selectedSub.receiptNumber}`} size="md">
          <div className="space-y-3.5">
            <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 dark:bg-slate-900 p-3 rounded-xl">
              <div><span className="text-slate-400">مشتری:</span> <b>{selectedSub.customerName}</b></div>
              <div><span className="text-slate-400">تلفن:</span> <span className="font-mono">{toPersianDigits(selectedSub.customerPhone)}</span></div>
              <div><span className="text-slate-400">فاکتور:</span> <span className="font-mono font-bold text-teal-600">{selectedSub.invoiceNumber}</span></div>
              <div><span className="text-slate-400">مبلغ:</span> <span className="font-mono font-bold text-emerald-600">{formatCurrency(selectedSub.amount)}</span></div>
            </div>

            {selectedSub.imageUrl && (
              <div className="text-center bg-slate-100 dark:bg-slate-950 p-2 rounded-2xl">
                <img
                  src={selectedSub.imageUrl}
                  alt="فیش کامل"
                  className="max-h-80 mx-auto rounded-xl object-contain shadow-md"
                />
              </div>
            )}

            {selectedSub.trackingCode && (
              <p className="text-xs bg-slate-50 dark:bg-slate-900 p-2 rounded-lg font-mono">
                کد پیگیری بانکی: <b>{selectedSub.trackingCode}</b>
              </p>
            )}

            {selectedSub.note && (
              <div className="text-xs bg-slate-50 dark:bg-slate-900 p-2.5 rounded-lg leading-5">
                <b>توضیحات واریز:</b> {selectedSub.note}
              </div>
            )}

            {selectedSub.status === 'در_انتظار_تایید' && (
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <Select
                  label="واریز به کدام حساب (روش پرداخت)"
                  value={paymentMethod}
                  onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}
                  options={PAYMENT_METHODS.map(m => ({ value: m, label: m }))}
                />
                <div className="flex gap-2">
                  <Button
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white"
                    onClick={() => handleApprove(selectedSub.id)}
                  >
                    <Check className="w-4 h-4" />
                    تأیید قطعی و صدور سند حسابداری
                  </Button>
                  <Button
                    variant="outline"
                    className="text-rose-600 border-rose-300"
                    onClick={() => {
                      setRejectModalSub(selectedSub);
                      setSelectedSub(null);
                    }}
                  >
                    رد
                  </Button>
                </div>
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* Reject Modal */}
      {rejectModalSub && (
        <Modal open onClose={() => setRejectModalSub(null)} title="دلیل عدم تأیید فیش" size="sm">
          <div className="space-y-3">
            <p className="text-xs text-slate-500 leading-5">
              لطفاً علت عدم تأیید فیش واریزی <b>{rejectModalSub.receiptNumber}</b> را مشخص کنید تا در پورتال مشتری نمایش داده شود:
            </p>
            <Textarea
              label="علت رد"
              value={rejectReason}
              onChange={e => setRejectReason(e.target.value)}
              placeholder="مثلاً: مبلغ فیش با مبلغ واریزی همخوانی ندارد یا تصویر ناخواناست..."
              rows={3}
            />
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="secondary" onClick={() => setRejectModalSub(null)}>
                انصراف
              </Button>
              <Button variant="danger" onClick={handleReject}>
                ثبت رد فیش
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

function Receivables() {
  const { db, receivePayment } = useApp();
  const { showToast } = useToast();
  const [search, setSearch] = useState('');
  const [payFor, setPayFor] = useState<string | null>(null);
  const [statementFor, setStatementFor] = useState<string | null>(null);
  const [amount, setAmount] = useState(0);
  const [method, setMethod] = useState<PaymentMethod>('نقد');
  const [date, setDate] = useState('');
  const [desc, setDesc] = useState('');
  const rows = useMemo(() => db.customers.map(c => { const invoices = db.invoices.filter(i => i.customerId === c.id); const billed = invoices.reduce((s, i) => s + i.totalAmount, 0); const paid = invoices.reduce((s, i) => s + i.paidAmount, 0); return { customer: c, billed, paid, balance: ACC.partyBalance(db, 'customer', c.id), openInvoices: invoices.filter(i => i.totalAmount > i.paidAmount).length }; }).filter(r => r.customer.fullName.includes(search) || r.customer.phone.includes(search)), [db, search]);
  const totalAR = rows.reduce((s, r) => s + Math.max(0, r.balance), 0);
  const totalCredit = rows.reduce((s, r) => s + Math.max(0, -r.balance), 0);
  const submitPayment = () => { if (!payFor) return; const res = receivePayment({ customerId: payFor, amount, method, date: date || undefined, description: desc }); if (res.success) { showToast('دریافت وجه ثبت و سند حسابداری صادر شد'); setPayFor(null); setAmount(0); setDesc(''); setDate(''); } else showToast(res.error || 'خطا در ثبت', 'error'); };
  const statementCustomer = db.customers.find(c => c.id === statementFor);
  const statement = statementFor ? ACC.partyStatement(db, 'customer', statementFor) : [];
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3"><KPI title="جمع مطالبات (بدهکاران)" value={formatCurrency(totalAR)} icon={<TrendingUp className="w-5 h-5" />} tone="amber" /><KPI title="جمع بستانکاری مشتریان" value={formatCurrency(totalCredit)} icon={<TrendingDown className="w-5 h-5" />} tone="purple" /></div>
      <SearchInput value={search} onChange={setSearch} placeholder="جستجوی مشتری..." />
      <Card className="overflow-x-auto"><table className="data-table"><thead><tr><th>مشتری</th><th>مبلغ فاکتورها</th><th>دریافتی</th><th>مانده</th><th>وضعیت</th><th className="text-left">عملیات</th></tr></thead><tbody>{rows.map(r => <tr key={r.customer.id}><td><p className="font-medium text-slate-900 dark:text-white">{r.customer.fullName}</p><p className="text-[11px] text-slate-500 font-mono">{toPersianDigits(r.customer.phone)}</p></td><td className="font-mono text-xs">{formatCurrency(r.billed)}</td><td className="font-mono text-xs text-emerald-600">{formatCurrency(r.paid)}</td><td className={cn('font-mono text-xs font-bold', r.balance > 0 ? 'text-red-600' : r.balance < 0 ? 'text-purple-600' : 'text-slate-500')}>{formatCurrency(Math.abs(r.balance))}</td><td><Badge color={r.balance > 0 ? 'red' : r.balance < 0 ? 'purple' : 'green'}>{r.balance > 0 ? 'بدهکار' : r.balance < 0 ? 'بستانکار' : 'تسویه'}</Badge></td><td className="text-left"><div className="flex gap-1 justify-end"><Button size="sm" variant="ghost" onClick={() => setStatementFor(r.customer.id)}>کارتکس</Button><Button size="sm" onClick={() => { setPayFor(r.customer.id); setAmount(Math.max(0, r.balance)); }}>دریافت وجه</Button></div></td></tr>)}</tbody></table></Card>
      <Modal open={!!payFor} onClose={() => setPayFor(null)} title="ثبت دریافت وجه" size="sm"><div className="space-y-3"><p className="text-xs text-slate-500">مبلغ به‌صورت خودکار از قدیمی‌ترین فاکتور باز تسویه می‌شود و مازاد به‌عنوان پیش‌دریافت ثبت می‌گردد.</p><CurrencyInput label="مبلغ دریافتی (تومان)" value={amount} onChange={setAmount} /><Select label="روش دریافت" value={method} onChange={e => setMethod(e.target.value as PaymentMethod)} options={PAYMENT_METHODS.map(m => ({ value: m, label: m }))} /><JalaliDatePicker label="تاریخ دریافت" value={date} onChange={iso => setDate(iso)} /><Input label="شرح" value={desc} onChange={e => setDesc(e.target.value)} placeholder="مثلاً تسویه فاکتور" /></div><div className="flex justify-end gap-2 mt-4"><Button variant="secondary" onClick={() => setPayFor(null)}>انصراف</Button><Button onClick={submitPayment}>ثبت و صدور سند</Button></div></Modal>
      <Modal open={!!statementFor} onClose={() => setStatementFor(null)} title={`کارتکس حساب ${statementCustomer?.fullName || ''}`} size="lg"><div className="overflow-x-auto"><table className="data-table"><thead><tr><th>تاریخ</th><th>سند</th><th>شرح</th><th>بدهکار</th><th>بستانکار</th><th>مانده</th></tr></thead><tbody>{statement.map((r, i) => <tr key={i}><td className="text-xs font-mono">{toPersianDigits(formatJalali(new Date(r.date)))}</td><td className="text-[11px] font-mono text-teal-600">{r.entryNumber}</td><td className="text-xs">{r.description}</td><td className="text-xs font-mono">{r.debit ? formatCurrency(r.debit, false) : '—'}</td><td className="text-xs font-mono text-emerald-600">{r.credit ? formatCurrency(r.credit, false) : '—'}</td><td className="text-xs font-mono font-bold">{formatCurrency(Math.abs(r.balance), false)} {r.balance >= 0 ? 'بد' : 'بس'}</td></tr>)}{statement.length === 0 && <tr><td colSpan={6} className="text-center py-6 text-slate-500 text-sm">گردشی ثبت نشده است</td></tr>}</tbody></table></div><div className="flex justify-end mt-3 no-print"><Button variant="outline" size="sm" onClick={() => window.print()}><Printer className="w-4 h-4" />چاپ کارتکس</Button></div></Modal>
    </div>
  );
}

function TechnicianAccounts() {
  const { db, settleTechnician } = useApp();
  const { showToast } = useToast();
  const [settleFor, setSettleFor] = useState<string | null>(null);
  const [amount, setAmount] = useState(0);
  const [fromCode, setFromCode] = useState('1101');
  const [statementFor, setStatementFor] = useState<string | null>(null);
  const rows = db.technicians.map(t => ({ tech: t, balance: -ACC.partyBalance(db, 'technician', t.id), orders: db.orders.filter(o => o.technicianId === t.id).length }));
  const cashAccs = ACC.cashAccounts(db);
  const submit = () => { if (!settleFor) return; const res = settleTechnician({ technicianId: settleFor, amount, paidFromCode: fromCode }); if (res.success) { showToast('تسویه پورسانت ثبت شد'); setSettleFor(null); setAmount(0); } else showToast(res.error || 'خطا', 'error'); };
  const statement = statementFor ? ACC.partyStatement(db, 'technician', statementFor) : [];
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">{rows.map(r => <Card key={r.tech.id} className="p-4 hover-lift"><div className="flex items-start justify-between mb-2"><div><p className="font-bold text-sm">{r.tech.fullName}</p><p className="text-[11px] text-slate-500">نرخ پورسانت {toPersianDigits(r.tech.commissionRate)}٪ • {toPersianDigits(r.orders)} ماموریت</p></div><Badge color={r.balance > 0 ? 'amber' : 'green'}>{r.balance > 0 ? 'بستانکار' : 'تسویه'}</Badge></div><div className="grid grid-cols-2 gap-2 py-2 border-t border-slate-100 dark:border-slate-700 mt-2"><div><p className="text-[10px] text-slate-500">پورسانت تعلق‌گرفته</p><p className="text-sm font-bold text-teal-600">{formatCurrency(r.tech.totalCommission)}</p></div><div><p className="text-[10px] text-slate-500">مانده قابل پرداخت</p><p className="text-sm font-bold text-amber-600">{formatCurrency(r.balance)}</p></div></div><div className="flex gap-1 mt-2"><Button size="sm" variant="ghost" onClick={() => setStatementFor(r.tech.id)}>گردش حساب</Button><Button size="sm" disabled={r.balance <= 0} onClick={() => { setSettleFor(r.tech.id); setAmount(r.balance); }}>تسویه</Button></div></Card>)}</div>
      <Modal open={!!settleFor} onClose={() => setSettleFor(null)} title="تسویه پورسانت تکنسین" size="sm"><div className="space-y-3"><CurrencyInput label="مبلغ پرداختی" value={amount} onChange={setAmount} /><Select label="پرداخت از حساب" value={fromCode} onChange={e => setFromCode(e.target.value)} options={cashAccs.map(a => ({ value: a.code, label: `${a.name} (${formatCurrency(ACC.accountBalance(db, a.code))})` }))} /></div><div className="flex justify-end gap-2 mt-4"><Button variant="secondary" onClick={() => setSettleFor(null)}>انصراف</Button><Button onClick={submit}>ثبت پرداخت</Button></div></Modal>
      <Modal open={!!statementFor} onClose={() => setStatementFor(null)} title="گردش حساب تکنسین" size="lg"><table className="data-table"><thead><tr><th>تاریخ</th><th>سند</th><th>شرح</th><th>بدهکار</th><th>بستانکار</th><th>مانده</th></tr></thead><tbody>{statement.map((r, i) => <tr key={i}><td className="text-xs font-mono">{toPersianDigits(formatJalali(new Date(r.date)))}</td><td className="text-[11px] font-mono text-teal-600">{r.entryNumber}</td><td className="text-xs">{r.description}</td><td className="text-xs font-mono">{r.debit ? formatCurrency(r.debit, false) : '—'}</td><td className="text-xs font-mono text-emerald-600">{r.credit ? formatCurrency(r.credit, false) : '—'}</td><td className="text-xs font-mono font-bold">{formatCurrency(Math.abs(r.balance), false)}</td></tr>)}{statement.length === 0 && <tr><td colSpan={6} className="text-center py-6 text-sm text-slate-500">گردشی ثبت نشده است</td></tr>}</tbody></table></Modal>
    </div>
  );
}

function Treasury() {
  const { db, transferFunds } = useApp();
  const { showToast } = useToast();
  const [open, setOpen] = useState(false);
  const [fromCode, setFromCode] = useState('1101');
  const [toCode, setToCode] = useState('1102');
  const [amount, setAmount] = useState(0);
  const cashAccs = ACC.cashAccounts(db);
  const payments = db.payments.slice(0, 25);
  const submit = () => { const res = transferFunds({ fromCode, toCode, amount }); if (res.success) { showToast('انتقال وجه ثبت شد'); setOpen(false); setAmount(0); } else showToast(res.error || 'خطا', 'error'); };
  return (
    <div className="space-y-4">
      <div className="flex justify-end"><Button onClick={() => setOpen(true)}><ArrowLeftRight className="w-4 h-4" />انتقال بین حساب‌ها</Button></div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">{cashAccs.map(a => { const bal = ACC.accountBalance(db, a.code); return <Card key={a.code} className="p-4"><div className="flex items-center justify-between"><p className="text-xs text-slate-500">{a.name}</p><span className="text-[10px] font-mono text-slate-400">{toPersianDigits(a.code)}</span></div><p className={cn('text-lg font-bold mt-1', bal < 0 ? 'text-red-600' : 'text-slate-900 dark:text-white')}>{formatCurrency(bal)}</p>{bal < 0 && db.accounting.alertNegativeCash && <p className="text-[10px] text-red-500 mt-1">هشدار: مانده منفی</p>}</Card>; })}</div>
      <Card className="p-5"><h3 className="font-semibold text-sm mb-3">آخرین دریافت‌ها</h3><div className="overflow-x-auto"><table className="data-table"><thead><tr><th>شماره رسید</th><th>تاریخ</th><th>مشتری</th><th>روش</th><th>مبلغ</th><th>تخصیص</th></tr></thead><tbody>{payments.map(p => { const c = db.customers.find(x => x.id === p.customerId); return <tr key={p.id}><td className="text-xs font-mono text-teal-600">{p.receiptNumber}</td><td className="text-xs font-mono">{toPersianDigits(formatJalali(new Date(p.date)))}</td><td className="text-sm">{c?.fullName}</td><td><Badge color="blue">{p.method}</Badge></td><td className="text-xs font-mono font-bold">{formatCurrency(p.amount)}</td><td className="text-[11px] text-slate-500">{p.allocations.length > 0 ? p.allocations.map(a => db.invoices.find(i => i.id === a.invoiceId)?.invoiceNumber).filter(Boolean).join('، ') : 'پیش‌دریافت'}</td></tr>; })}{payments.length === 0 && <tr><td colSpan={6} className="text-center py-6 text-sm text-slate-500">دریافتی ثبت نشده است</td></tr>}</tbody></table></div></Card>
      <Modal open={open} onClose={() => setOpen(false)} title="انتقال وجه" size="sm"><div className="space-y-3"><Select label="از حساب" value={fromCode} onChange={e => setFromCode(e.target.value)} options={cashAccs.map(a => ({ value: a.code, label: a.name }))} /><Select label="به حساب" value={toCode} onChange={e => setToCode(e.target.value)} options={cashAccs.map(a => ({ value: a.code, label: a.name }))} /><CurrencyInput label="مبلغ" value={amount} onChange={setAmount} /></div><div className="flex justify-end gap-2 mt-4"><Button variant="secondary" onClick={() => setOpen(false)}>انصراف</Button><Button onClick={submit}>ثبت انتقال</Button></div></Modal>
    </div>
  );
}

function Expenses() {
  const { db, registerExpense, registerPurchase } = useApp();
  const { showToast } = useToast();
  const [expOpen, setExpOpen] = useState(false);
  const [purOpen, setPurOpen] = useState(false);
  const [accountCode, setAccountCode] = useState('5299');
  const [paidFrom, setPaidFrom] = useState('1101');
  const [amount, setAmount] = useState(0);
  const [desc, setDesc] = useState('');
  const [beneficiary, setBeneficiary] = useState('');
  const [date, setDate] = useState('');
  const [itemId, setItemId] = useState(db.inventory[0]?.id || '');
  const [qty, setQty] = useState(1);
  const [unitCost, setUnitCost] = useState(0);
  const [supplier, setSupplier] = useState('');
  const expenseAccounts = db.accounts.filter(a => a.type === 'هزینه' && a.active);
  const payFromAccounts = [...ACC.cashAccounts(db), ...db.accounts.filter(a => a.code === db.accounting.apAccount)];
  const totalExpenses = db.expenses.reduce((s, e) => s + e.amount, 0);
  const submitExpense = () => { const res = registerExpense({ accountCode, paidFromCode: paidFrom, amount, description: desc, beneficiary, date: date || undefined }); if (res.success) { showToast('هزینه ثبت و سند صادر شد'); setExpOpen(false); setAmount(0); setDesc(''); setBeneficiary(''); } else showToast(res.error || 'خطا', 'error'); };
  const submitPurchase = () => { const res = registerPurchase({ itemId, quantity: qty, unitCost, paidFromCode: paidFrom, supplier }); if (res.success) { showToast('خرید ثبت و موجودی انبار به‌روز شد'); setPurOpen(false); setQty(1); setUnitCost(0); } else showToast(res.error || 'خطا', 'error'); };
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 justify-between items-center"><KPI title="جمع هزینه‌های ثبت‌شده" value={formatCurrency(totalExpenses)} icon={<Receipt className="w-5 h-5" />} tone="rose" /><div className="flex gap-2"><Button onClick={() => setExpOpen(true)}><Plus className="w-4 h-4" />ثبت هزینه</Button><Button variant="outline" onClick={() => setPurOpen(true)}><Plus className="w-4 h-4" />خرید قطعه</Button></div></div>
      <Card className="overflow-x-auto"><table className="data-table"><thead><tr><th>شماره</th><th>تاریخ</th><th>سرفصل</th><th>شرح</th><th>پرداخت از</th><th>مبلغ</th></tr></thead><tbody>{db.expenses.map(e => <tr key={e.id}><td className="text-xs font-mono text-teal-600">{e.number}</td><td className="text-xs font-mono">{toPersianDigits(formatJalali(new Date(e.date)))}</td><td className="text-xs">{db.accounts.find(a => a.code === e.accountCode)?.name}</td><td className="text-xs">{e.description}</td><td className="text-xs">{db.accounts.find(a => a.code === e.paidFromCode)?.name}</td><td className="text-xs font-mono font-bold text-rose-600">{formatCurrency(e.amount)}</td></tr>)}{db.expenses.length === 0 && <tr><td colSpan={6} className="text-center py-6 text-sm text-slate-500">هزینه‌ای ثبت نشده است</td></tr>}</tbody></table></Card>
      <Modal open={expOpen} onClose={() => setExpOpen(false)} title="ثبت هزینه" size="sm"><div className="space-y-3"><Select label="سرفصل هزینه" value={accountCode} onChange={e => setAccountCode(e.target.value)} options={expenseAccounts.map(a => ({ value: a.code, label: `${a.code} - ${a.name}` }))} /><CurrencyInput label="مبلغ" value={amount} onChange={setAmount} /><Select label="پرداخت از" value={paidFrom} onChange={e => setPaidFrom(e.target.value)} options={payFromAccounts.map(a => ({ value: a.code, label: a.name }))} /><JalaliDatePicker label="تاریخ" value={date} onChange={iso => setDate(iso)} /><Input label="شرح" value={desc} onChange={e => setDesc(e.target.value)} /><Input label="دریافت‌کننده" value={beneficiary} onChange={e => setBeneficiary(e.target.value)} /></div><div className="flex justify-end gap-2 mt-4"><Button variant="secondary" onClick={() => setExpOpen(false)}>انصراف</Button><Button onClick={submitExpense}>ثبت هزینه</Button></div></Modal>
      <Modal open={purOpen} onClose={() => setPurOpen(false)} title="خرید قطعه برای انبار" size="sm"><div className="space-y-3"><Select label="قطعه" value={itemId} onChange={e => setItemId(e.target.value)} options={db.inventory.map(i => ({ value: i.id, label: `${i.name} (موجودی: ${i.quantity})` }))} /><Input label="تعداد" type="number" value={qty} onChange={e => setQty(parseInt(e.target.value) || 1)} /><CurrencyInput label="بهای خرید هر واحد" value={unitCost} onChange={setUnitCost} /><Select label="پرداخت از" value={paidFrom} onChange={e => setPaidFrom(e.target.value)} options={payFromAccounts.map(a => ({ value: a.code, label: a.name }))} /><Input label="تأمین‌کننده" value={supplier} onChange={e => setSupplier(e.target.value)} /><p className="text-xs text-slate-500">جمع خرید: <span className="font-bold">{formatCurrency(qty * unitCost)}</span></p></div><div className="flex justify-end gap-2 mt-4"><Button variant="secondary" onClick={() => setPurOpen(false)}>انصراف</Button><Button onClick={submitPurchase}>ثبت خرید</Button></div></Modal>
    </div>
  );
}

function Journal() {
  const { db, addManualEntry, voidJournalEntry } = useApp();
  const { showToast } = useToast();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [detail, setDetail] = useState<string | null>(null);
  const [newOpen, setNewOpen] = useState(false);
  const [desc, setDesc] = useState('');
  const [date, setDate] = useState('');
  const [lines, setLines] = useState<JournalLine[]>([{ accountCode: '1101', debit: 0, credit: 0 }, { accountCode: '4104', debit: 0, credit: 0 }]);
  const entries = useMemo(() => db.journal.filter(e => (typeFilter === 'all' || e.refType === typeFilter) && (e.number.includes(search) || e.description.includes(search) || (e.refLabel || '').includes(search))), [db.journal, search, typeFilter]);
  const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
  const totalCredit = lines.reduce((s, l) => s + l.credit, 0);
  const entry = db.journal.find(e => e.id === detail);
  const submit = () => { const res = addManualEntry({ description: desc, date: date || undefined, lines }); if (res.success) { showToast('سند دستی ثبت شد'); setNewOpen(false); setDesc(''); setLines([{ accountCode: '1101', debit: 0, credit: 0 }, { accountCode: '4104', debit: 0, credit: 0 }]); } else showToast(res.error || 'خطا', 'error'); };
  const exportCsv = () => { const rows = [['شماره سند', 'تاریخ', 'شرح', 'حساب', 'بدهکار', 'بستانکار']]; entries.forEach(e => e.lines.forEach(l => rows.push([e.number, formatJalali(new Date(e.date)), e.description, db.accounts.find(a => a.code === l.accountCode)?.name || l.accountCode, String(l.debit), String(l.credit)]))); const blob = new Blob(['\ufeff' + rows.map(r => r.join(',')).join('\n')], { type: 'text/csv;charset=utf-8;' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'journal.csv'; a.click(); };
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-2"><SearchInput value={search} onChange={setSearch} placeholder="جستجوی شماره سند یا شرح..." className="flex-1" /><Select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} className="sm:w-48" options={[{ value: 'all', label: 'همه اسناد' }, ...['invoice', 'payment', 'expense', 'purchase', 'commission', 'settlement', 'transfer', 'manual', 'opening', 'adjustment', 'inventory'].map(t => ({ value: t, label: ACC.refTypeLabel(t) }))]} /><Button variant="outline" onClick={exportCsv}><FileSpreadsheet className="w-4 h-4" />CSV</Button><Button onClick={() => setNewOpen(true)}><Plus className="w-4 h-4" />سند دستی</Button></div>
      <Card className="overflow-x-auto"><table className="data-table"><thead><tr><th>شماره</th><th>تاریخ</th><th>شرح</th><th>نوع</th><th>مبلغ سند</th><th>وضعیت</th></tr></thead><tbody>{entries.map(e => <tr key={e.id} onClick={() => setDetail(e.id)} className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50"><td className="text-xs font-mono font-semibold text-teal-600">{e.number}</td><td className="text-xs font-mono">{toPersianDigits(formatJalali(new Date(e.date)))}</td><td className="text-xs">{e.description}</td><td><Badge color="slate">{ACC.refTypeLabel(e.refType)}</Badge></td><td className="text-xs font-mono font-bold">{formatCurrency(e.totalDebit)}</td><td><Badge color={e.status === 'ثبت شده' ? 'green' : 'red'}>{e.status}</Badge>{e.autoGenerated && <span className="text-[9px] text-slate-400 mr-1">خودکار</span>}</td></tr>)}{entries.length === 0 && <tr><td colSpan={6}><EmptyState title="سندی یافت نشد" icon={<BookOpen className="w-8 h-8" />} /></td></tr>}</tbody></table></Card>
      <Modal open={!!detail} onClose={() => setDetail(null)} title={`سند ${entry?.number || ''}`} size="lg">{entry && <div className="space-y-3"><div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs"><div><p className="text-slate-500">تاریخ</p><p className="font-mono">{toPersianDigits(formatJalali(new Date(entry.date)))}</p></div><div><p className="text-slate-500">نوع</p><p>{ACC.refTypeLabel(entry.refType)}</p></div><div><p className="text-slate-500">مرجع</p><p>{entry.refLabel || '—'}</p></div><div><p className="text-slate-500">ثبت‌کننده</p><p>{entry.createdByName}</p></div></div><p className="text-sm">{entry.description}</p><table className="data-table"><thead><tr><th>حساب</th><th>شرح</th><th>طرف حساب</th><th>بدهکار</th><th>بستانکار</th></tr></thead><tbody>{entry.lines.map((l, i) => { const acc = db.accounts.find(a => a.code === l.accountCode); const party = l.partyType === 'customer' ? db.customers.find(c => c.id === l.partyId)?.fullName : l.partyType === 'technician' ? db.technicians.find(t => t.id === l.partyId)?.fullName : ''; return <tr key={i}><td className="text-xs">{toPersianDigits(l.accountCode)} - {acc?.name}</td><td className="text-xs">{l.description || '—'}</td><td className="text-xs">{party || '—'}</td><td className="text-xs font-mono">{l.debit ? formatCurrency(l.debit, false) : '—'}</td><td className="text-xs font-mono">{l.credit ? formatCurrency(l.credit, false) : '—'}</td></tr>; })}<tr className="bg-slate-50 dark:bg-slate-800 font-bold"><td colSpan={3} className="text-xs">جمع</td><td className="text-xs font-mono">{formatCurrency(entry.totalDebit, false)}</td><td className="text-xs font-mono">{formatCurrency(entry.totalCredit, false)}</td></tr></tbody></table>{entry.status === 'ثبت شده' && <div className="flex justify-end"><Button variant="danger" size="sm" onClick={() => { const reason = prompt('دلیل ابطال سند؟') || 'بدون توضیح'; const res = voidJournalEntry(entry.id, reason); showToast(res.success ? 'سند ابطال و سند معکوس صادر شد' : (res.error || 'خطا'), res.success ? 'success' : 'error'); setDetail(null); }}><Trash2 className="w-3.5 h-3.5" />ابطال سند</Button></div>}</div>}</Modal>
      <Modal open={newOpen} onClose={() => setNewOpen(false)} title="ثبت سند دستی" size="lg"><div className="space-y-3"><Input label="شرح سند" value={desc} onChange={e => setDesc(e.target.value)} /><JalaliDatePicker label="تاریخ سند" value={date} onChange={iso => setDate(iso)} /><div className="space-y-2">{lines.map((l, i) => <div key={i} className="grid grid-cols-12 gap-2 items-end"><div className="col-span-5"><Select label={i === 0 ? 'حساب' : undefined} value={l.accountCode} onChange={e => setLines(ls => ls.map((x, j) => j === i ? { ...x, accountCode: e.target.value } : x))} options={db.accounts.filter(a => a.active).map(a => ({ value: a.code, label: `${a.code} - ${a.name}` }))} /></div><div className="col-span-3"><CurrencyInput label={i === 0 ? 'بدهکار' : undefined} value={l.debit} onChange={v => setLines(ls => ls.map((x, j) => j === i ? { ...x, debit: v, credit: v > 0 ? 0 : x.credit } : x))} /></div><div className="col-span-3"><CurrencyInput label={i === 0 ? 'بستانکار' : undefined} value={l.credit} onChange={v => setLines(ls => ls.map((x, j) => j === i ? { ...x, credit: v, debit: v > 0 ? 0 : x.debit } : x))} /></div><button onClick={() => setLines(ls => ls.filter((_, j) => j !== i))} className="col-span-1 p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"><Trash2 className="w-4 h-4" /></button></div>)}</div><Button size="sm" variant="outline" onClick={() => setLines(ls => [...ls, { accountCode: '1101', debit: 0, credit: 0 }])}><Plus className="w-3.5 h-3.5" />افزودن ردیف</Button><div className={cn('flex justify-between p-3 rounded-xl text-sm font-bold', totalDebit === totalCredit && totalDebit > 0 ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700' : 'bg-red-50 dark:bg-red-900/20 text-red-700')}><span>جمع بدهکار: {formatCurrency(totalDebit, false)}</span><span>جمع بستانکار: {formatCurrency(totalCredit, false)}</span><span>{totalDebit === totalCredit && totalDebit > 0 ? 'تراز ✓' : 'ناتراز'}</span></div></div><div className="flex justify-end gap-2 mt-4"><Button variant="secondary" onClick={() => setNewOpen(false)}>انصراف</Button><Button onClick={submit}>ثبت سند</Button></div></Modal>
    </div>
  );
}

function Ledger() {
  const { db } = useApp();
  const [code, setCode] = useState(db.accounting.arAccount);
  const rows = ACC.ledgerRows(db, code);
  const account = db.accounts.find(a => a.code === code);
  const balance = ACC.accountBalance(db, code);
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3"><Select label="انتخاب حساب" value={code} onChange={e => setCode(e.target.value)} options={db.accounts.map(a => ({ value: a.code, label: `${a.code} - ${a.name}` }))} className="sm:col-span-2" /><Card className="p-3"><p className="text-xs text-slate-500">مانده حساب</p><p className="text-lg font-bold">{formatCurrency(Math.abs(balance))} <span className="text-xs">{balance >= 0 ? 'بدهکار' : 'بستانکار'}</span></p><p className="text-[10px] text-slate-500">{account?.type} • {account?.group}</p></Card></div>
      <Card className="overflow-x-auto"><table className="data-table"><thead><tr><th>تاریخ</th><th>سند</th><th>شرح</th><th>نوع</th><th>بدهکار</th><th>بستانکار</th><th>مانده</th></tr></thead><tbody>{rows.map((r, i) => <tr key={i}><td className="text-xs font-mono">{toPersianDigits(formatJalali(new Date(r.date)))}</td><td className="text-[11px] font-mono text-teal-600">{r.entryNumber}</td><td className="text-xs">{r.description}</td><td className="text-[11px]">{ACC.refTypeLabel(r.refType)}</td><td className="text-xs font-mono">{r.debit ? formatCurrency(r.debit, false) : '—'}</td><td className="text-xs font-mono">{r.credit ? formatCurrency(r.credit, false) : '—'}</td><td className="text-xs font-mono font-bold">{formatCurrency(Math.abs(r.balance), false)} {r.balance >= 0 ? 'بد' : 'بس'}</td></tr>)}{rows.length === 0 && <tr><td colSpan={7} className="text-center py-6 text-sm text-slate-500">این حساب گردشی ندارد</td></tr>}</tbody></table></Card>
    </div>
  );
}

function Reports() {
  const { db } = useApp();
  const [report, setReport] = useState<'trial' | 'pnl' | 'balance'>('trial');
  const trial = ACC.trialBalance(db);
  const pnl = ACC.incomeStatement(db);
  const bs = ACC.balanceSheet(db);
  const totalDebit = trial.reduce((s, r) => s + r.debit, 0);
  const totalCredit = trial.reduce((s, r) => s + r.credit, 0);
  return (
    <div className="space-y-4">
      <div className="flex gap-2 flex-wrap">{[{ v: 'trial', l: 'تراز آزمایشی' }, { v: 'pnl', l: 'صورت سود و زیان' }, { v: 'balance', l: 'ترازنامه' }].map(r => <button key={r.v} onClick={() => setReport(r.v as typeof report)} className={cn('px-3 py-1.5 rounded-lg text-xs font-medium border transition-all', report === r.v ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-200 dark:border-slate-700 hover:border-teal-300')}>{r.l}</button>)}<Button variant="outline" size="sm" onClick={() => window.print()} className="mr-auto"><Printer className="w-4 h-4" />چاپ</Button></div>
      {report === 'trial' && <Card className="overflow-x-auto print-area"><table className="data-table"><thead><tr><th>کد</th><th>نام حساب</th><th>نوع</th><th>گردش بدهکار</th><th>گردش بستانکار</th><th>مانده</th></tr></thead><tbody>{trial.map(r => <tr key={r.account.code}><td className="text-xs font-mono">{toPersianDigits(r.account.code)}</td><td className="text-xs font-medium">{r.account.name}</td><td className="text-[11px]">{r.account.type}</td><td className="text-xs font-mono">{formatCurrency(r.debit, false)}</td><td className="text-xs font-mono">{formatCurrency(r.credit, false)}</td><td className="text-xs font-mono font-bold">{formatCurrency(Math.abs(r.balance), false)} {r.balance >= 0 ? 'بد' : 'بس'}</td></tr>)}<tr className="bg-slate-50 dark:bg-slate-800 font-bold"><td colSpan={3}>جمع کل</td><td className="font-mono text-xs">{formatCurrency(totalDebit, false)}</td><td className="font-mono text-xs">{formatCurrency(totalCredit, false)}</td><td className={Math.abs(totalDebit - totalCredit) < 10 ? 'text-emerald-600 text-xs' : 'text-red-600 text-xs'}>{Math.abs(totalDebit - totalCredit) < 10 ? 'تراز ✓' : 'ناتراز'}</td></tr></tbody></table></Card>}
      {report === 'pnl' && <Card className="p-5 print-area space-y-4"><h3 className="font-bold text-center">صورت سود و زیان — {db.accounting.fiscalYearLabel}</h3><div><p className="font-semibold text-sm text-teal-700 mb-2">درآمدها</p>{pnl.revenues.map(r => <div key={r.account.code} className="flex justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800"><span>{r.account.name}</span><span className="font-mono">{formatCurrency(r.amount, false)}</span></div>)}<div className="flex justify-between text-sm font-bold py-2"><span>جمع درآمد</span><span className="font-mono text-emerald-600">{formatCurrency(pnl.totalRevenue)}</span></div></div><div><p className="font-semibold text-sm text-rose-700 mb-2">هزینه‌ها</p>{pnl.expenses.map(r => <div key={r.account.code} className="flex justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800"><span>{r.account.name}</span><span className="font-mono">{formatCurrency(r.amount, false)}</span></div>)}<div className="flex justify-between text-sm font-bold py-2"><span>جمع هزینه</span><span className="font-mono text-rose-600">{formatCurrency(pnl.totalExpense)}</span></div></div><div className="grid grid-cols-3 gap-2"><div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 text-center"><p className="text-[11px] text-slate-500">سود ناخالص</p><p className="font-bold text-sm">{formatCurrency(pnl.grossProfit)}</p></div><div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 text-center"><p className="text-[11px] text-slate-500">بهای تمام‌شده</p><p className="font-bold text-sm">{formatCurrency(pnl.cogs)}</p></div><div className={cn('p-3 rounded-xl text-center', pnl.netProfit >= 0 ? 'bg-emerald-50 dark:bg-emerald-900/20' : 'bg-red-50 dark:bg-red-900/20')}><p className="text-[11px] text-slate-500">سود (زیان) خالص</p><p className={cn('font-bold text-sm', pnl.netProfit >= 0 ? 'text-emerald-700' : 'text-red-700')}>{formatCurrency(pnl.netProfit)}</p></div></div></Card>}
      {report === 'balance' && <Card className="p-5 print-area"><h3 className="font-bold text-center mb-4">ترازنامه</h3><div className="grid grid-cols-1 md:grid-cols-2 gap-6"><div><p className="font-semibold text-sm text-teal-700 mb-2">دارایی‌ها</p>{bs.assets.map(a => <div key={a.account.code} className="flex justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800"><span>{a.account.name}</span><span className="font-mono">{formatCurrency(a.amount, false)}</span></div>)}<div className="flex justify-between text-sm font-bold py-2"><span>جمع دارایی‌ها</span><span className="font-mono">{formatCurrency(bs.totalAssets)}</span></div></div><div><p className="font-semibold text-sm text-rose-700 mb-2">بدهی‌ها</p>{bs.liabilities.map(a => <div key={a.account.code} className="flex justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800"><span>{a.account.name}</span><span className="font-mono">{formatCurrency(a.amount, false)}</span></div>)}<div className="flex justify-between text-sm font-bold py-2"><span>جمع بدهی‌ها</span><span className="font-mono">{formatCurrency(bs.totalLiabilities)}</span></div><p className="font-semibold text-sm text-indigo-700 mt-4 mb-2">حقوق صاحبان سرمایه</p>{bs.equity.map(a => <div key={a.account.code} className="flex justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800"><span>{a.account.name}</span><span className="font-mono">{formatCurrency(a.amount, false)}</span></div>)}<div className="flex justify-between text-xs py-1 border-b border-slate-100 dark:border-slate-800"><span>سود (زیان) دوره</span><span className="font-mono">{formatCurrency(bs.netProfit, false)}</span></div><div className="flex justify-between text-sm font-bold py-2"><span>جمع سرمایه</span><span className="font-mono">{formatCurrency(bs.totalEquity)}</span></div></div></div><div className={cn('mt-4 p-3 rounded-xl text-center text-sm font-bold flex items-center justify-center gap-2', bs.balanced ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700' : 'bg-red-50 dark:bg-red-900/20 text-red-700')}>{bs.balanced ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}{bs.balanced ? 'معادله حسابداری برقرار است' : 'ترازنامه ناتراز است'}</div></Card>}
    </div>
  );
}

function AccSettings() {
  const { db, updateAccountingSettings, addAccount, deleteAccount, updateAccount } = useApp();
  const { showToast } = useToast();
  const [s, setS] = useState(db.accounting);
  const [accOpen, setAccOpen] = useState(false);
  const [newAcc, setNewAcc] = useState<Omit<Account, 'isSystem'>>({ code: '', name: '', type: 'هزینه', nature: 'بدهکار', group: 'هزینه عملیاتی', isCash: false, openingBalance: 0, active: true });
  const save = () => { updateAccountingSettings(s); showToast('تنظیمات حسابداری ذخیره شد'); };
  const createAccount = () => { if (!newAcc.code || !newAcc.name) { showToast('کد و نام حساب الزامی است', 'error'); return; } const res = addAccount(newAcc); if (res.success) { showToast('حساب ایجاد شد'); setAccOpen(false); setNewAcc({ ...newAcc, code: '', name: '' }); } else showToast(res.error || 'خطا', 'error'); };
  return (
    <div className="space-y-4">
      <Card className="p-5"><h3 className="font-semibold text-sm mb-4">اتوماسیون حسابداری</h3><div className="space-y-2">{[{ key: 'autoInvoiceOnCompletion' as const, label: 'صدور خودکار فاکتور و بدهکار کردن مشتری هنگام تکمیل ماموریت' }, { key: 'accrueCommission' as const, label: 'محاسبه و ثبت خودکار پورسانت تکنسین' }, { key: 'trackInventoryCost' as const, label: 'ثبت بهای تمام‌شده قطعات (COGS)' }, { key: 'autoConsumeInventory' as const, label: 'کسر خودکار قطعات از موجودی انبار' }, { key: 'taxEnabled' as const, label: 'محاسبه مالیات بر ارزش افزوده در فاکتور' }, { key: 'alertNegativeCash' as const, label: 'هشدار مانده منفی صندوق/بانک' }].map(item => <label key={item.key} className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 cursor-pointer"><span className="text-sm">{item.label}</span><input type="checkbox" checked={s[item.key] as boolean} onChange={e => setS({ ...s, [item.key]: e.target.checked })} className="w-5 h-5 accent-teal-600" /></label>)}<div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-3"><Select label="مبنای محاسبه پورسانت" value={s.commissionBase} onChange={e => setS({ ...s, commissionBase: e.target.value as typeof s.commissionBase })} options={[{ value: 'اجرت', label: 'اجرت تعمیر' }, { value: 'مبلغ کل', label: 'مبلغ کل فاکتور' }, { value: 'سود ناخالص', label: 'سود ناخالص' }]} /><Input label="نرخ مالیات (٪)" type="number" value={s.taxRate} onChange={e => setS({ ...s, taxRate: parseFloat(e.target.value) || 0 })} /><Input label="ضریب برآورد بهای تمام‌شده" type="number" step="0.05" value={s.defaultCostRatio} onChange={e => setS({ ...s, defaultCostRatio: parseFloat(e.target.value) || 0 })} /></div></div></Card>
      <Card className="p-5"><div className="flex items-center justify-between mb-3"><h3 className="font-semibold text-sm">کدینگ حساب‌ها</h3><Button size="sm" onClick={() => setAccOpen(true)}><Plus className="w-3.5 h-3.5" />حساب جدید</Button></div><div className="overflow-x-auto"><table className="data-table"><thead><tr><th>کد</th><th>نام</th><th>نوع</th><th>ماهیت</th><th>مانده</th><th>وضعیت</th><th></th></tr></thead><tbody>{db.accounts.map(a => <tr key={a.code}><td className="text-xs font-mono">{toPersianDigits(a.code)}</td><td className="text-xs font-medium">{a.name}</td><td className="text-[11px]">{a.type}</td><td className="text-[11px]">{a.nature}</td><td className="text-xs font-mono">{formatCurrency(Math.abs(ACC.accountBalance(db, a.code)), false)}</td><td><button onClick={() => updateAccount(a.code, { active: !a.active })}><Badge color={a.active ? 'green' : 'slate'}>{a.active ? 'فعال' : 'غیرفعال'}</Badge></button></td><td className="text-left">{!a.isSystem && <button onClick={() => { const res = deleteAccount(a.code); showToast(res.success ? 'حساب حذف شد' : (res.error || 'خطا'), res.success ? 'success' : 'error'); }} className="p-1 text-red-500"><Trash2 className="w-3.5 h-3.5" /></button>}</td></tr>)}</tbody></table></div></Card>
      <div className="flex justify-end"><Button onClick={save}>ذخیره تنظیمات حسابداری</Button></div>
      <Modal open={accOpen} onClose={() => setAccOpen(false)} title="ایجاد حساب جدید" size="sm"><div className="space-y-3"><Input label="کد حساب" value={newAcc.code} onChange={e => setNewAcc({ ...newAcc, code: e.target.value })} /><Input label="نام حساب" value={newAcc.name} onChange={e => setNewAcc({ ...newAcc, name: e.target.value })} /><Select label="نوع حساب" value={newAcc.type} onChange={e => { const type = e.target.value as AccountType; setNewAcc({ ...newAcc, type, nature: type === 'دارایی' || type === 'هزینه' ? 'بدهکار' : 'بستانکار' }); }} options={['دارایی', 'بدهی', 'سرمایه', 'درآمد', 'هزینه'].map(t => ({ value: t, label: t }))} /><Select label="ماهیت" value={newAcc.nature} onChange={e => setNewAcc({ ...newAcc, nature: e.target.value as 'بدهکار' | 'بستانکار' })} options={[{ value: 'بدهکار', label: 'بدهکار' }, { value: 'بستانکار', label: 'بستانکار' }]} /><Input label="گروه" value={newAcc.group} onChange={e => setNewAcc({ ...newAcc, group: e.target.value })} /></div><div className="flex justify-end gap-2 mt-4"><Button variant="secondary" onClick={() => setAccOpen(false)}>انصراف</Button><Button onClick={createAccount}>ایجاد حساب</Button></div></Modal>
    </div>
  );
}
