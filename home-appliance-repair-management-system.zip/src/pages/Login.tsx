import { useCallback, useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Button, Input, useToast } from '../components/ui';
import { Lock, User as UserIcon, Phone, Fingerprint, Search, ExternalLink, ScanFace, ShieldCheck, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { authenticateBiometric, checkEnvironment, describeBiometricError, registerBiometric, type EnvironmentReport } from '../lib/biometric';
import { toPersianDigits } from '../lib/jalali';
import { cn } from '../utils/cn';

export default function Login() {
  const { db, login, loginByUserId, findUserByCredential, registerBiometricCredential } = useApp();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [bioBusy, setBioBusy] = useState(false);
  const [env, setEnv] = useState<EnvironmentReport | null>(null);
  const [enrollFor, setEnrollFor] = useState<string | null>(null);

  const settings = db.settings;
  const credentials = db.biometrics;
  const hasCredentials = credentials.length > 0;
  const showBiometric = settings.biometricEnabled;

  const refreshEnv = useCallback(() => { checkEnvironment().then(setEnv); }, []);
  useEffect(() => { refreshEnv(); }, [refreshEnv]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setLoading(true);
    setTimeout(() => {
      const result = login(username, password);
      if (!result.success) { setError(result.error || 'خطا در ورود'); showToast(result.error || 'خطا در ورود', 'error'); }
      else {
        showToast('ورود موفقیت‌آمیز');
        const user = db.users.find(u => u.username === username.trim());
        const already = user ? credentials.some(c => c.userId === user.id) : true;
        if (settings.biometricEnabled && env?.canTry && user && !already && settings.biometricAllowedRoles.includes(user.role)) setEnrollFor(user.id);
      }
      setLoading(false);
    }, 300);
  };

  const handleBiometric = async () => {
    setError(''); setBioBusy(true);
    try {
      const credentialId = await authenticateBiometric({ allowedCredentialIds: credentials.map(c => c.credentialId), requireUserVerification: settings.biometricRequireUserVerification, timeoutSeconds: settings.biometricTimeoutSeconds });
      const user = findUserByCredential(credentialId);
      if (!user) { setError('اثر انگشت شناسایی شد اما کاربر متناظر یافت نشد.'); showToast('کاربر متناظر یافت نشد', 'error'); }
      else if (!settings.biometricAllowedRoles.includes(user.role)) { setError('ورود بیومتریک برای نقش شما مجاز نیست.'); showToast('ورود بیومتریک برای این نقش غیرفعال است', 'error'); }
      else { loginByUserId(user.id); showToast(`خوش آمدید ${user.fullName}`); }
    } catch (err) { const msg = describeBiometricError(err); setError(msg); showToast(msg, 'error'); }
    finally { setBioBusy(false); }
  };

  const enrollNow = async () => {
    const user = db.users.find(u => u.id === enrollFor);
    if (!user) return;
    setBioBusy(true);
    try {
      const result = await registerBiometric({ userId: user.id, userName: user.username, displayName: user.fullName, appName: settings.shopName, requireUserVerification: settings.biometricRequireUserVerification, timeoutSeconds: settings.biometricTimeoutSeconds });
      registerBiometricCredential(user.id, result.credentialId, result.deviceLabel);
      showToast('اثر انگشت ثبت شد؛ دفعه بعد سریع وارد شوید'); setEnrollFor(null);
    } catch (err) { showToast(describeBiometricError(err), 'error'); setEnrollFor(null); }
    finally { setBioBusy(false); }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-teal-600 via-teal-700 to-emerald-800 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 flex flex-col safe-top safe-bottom">
      <div className="flex-1 flex flex-col items-center justify-center px-6 pt-10 pb-4 text-white">
        <div className="w-24 h-24 rounded-[28px] bg-white/15 backdrop-blur-xl border border-white/25 flex items-center justify-center shadow-2xl animate-float"><span className="text-white font-black text-3xl tracking-tight">اتحاد</span></div>
        <h1 className="text-2xl font-extrabold mt-5">{settings.shopName}</h1>
        <p className="text-sm text-white/80 mt-1">سامانه جامع مدیریت تعمیرگاه لوازم خانگی</p>
      </div>
      <div className="bg-white dark:bg-slate-900 rounded-t-[32px] shadow-2xl px-6 pt-4 pb-8 animate-sheet-up">
        <div className="w-10 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 mx-auto mb-5" />
        {showBiometric && (
          <div className="mb-5">
            <button type="button" onClick={handleBiometric} disabled={bioBusy || !hasCredentials || !env?.canTry} className="w-full flex flex-col items-center gap-2.5 py-5 rounded-3xl bg-gradient-to-b from-teal-50 to-emerald-50 dark:from-teal-900/25 dark:to-emerald-900/20 border border-teal-200/70 dark:border-teal-800/60 transition-all btn-press disabled:opacity-55 active:scale-[0.98]">
              <span className="relative flex items-center justify-center">
                {bioBusy && <span className="absolute w-20 h-20 rounded-full bg-teal-400/30 animate-ping-slow" />}
                <span className={cn('w-16 h-16 rounded-full bg-gradient-to-br from-teal-500 to-emerald-600 text-white flex items-center justify-center shadow-xl shadow-teal-500/30', bioBusy ? 'animate-pulse-ring' : 'animate-breathe')}><Fingerprint className="w-9 h-9" /></span>
              </span>
              <span className="text-sm font-bold text-teal-800 dark:text-teal-300">{bioBusy ? 'انگشت خود را روی حسگر قرار دهید…' : 'ورود با اثر انگشت'}</span>
              <span className="text-[11px] text-teal-700/70 dark:text-teal-400/70 px-6 text-center leading-5">{!env?.canTry ? env?.message : !hasCredentials ? 'ابتدا یک‌بار با رمز عبور وارد شوید تا اثر انگشت ثبت شود' : `${toPersianDigits(credentials.length)} دستگاه ثبت‌شده • ${settings.biometricRequireUserVerification ? 'تأیید بیومتریک الزامی' : 'تأیید سریع'}`}</span>
            </button>
            {env?.inIframe && <button onClick={() => window.open(window.location.href, '_blank', 'noopener')} className="w-full mt-2 flex items-center justify-center gap-1.5 text-[11px] font-semibold text-teal-700 dark:text-teal-400 underline"><ExternalLink className="w-3.5 h-3.5" />باز کردن در پنجره مستقل برای فعال‌سازی حسگر</button>}
            <div className="relative my-5"><div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-200 dark:border-slate-800" /></div><div className="relative flex justify-center"><span className="bg-white dark:bg-slate-900 px-3 text-[11px] text-slate-400">یا ورود با رمز عبور</span></div></div>
          </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          <Input label="نام کاربری" value={username} onChange={e => setUsername(e.target.value)} placeholder="نام کاربری" icon={<UserIcon className="w-4 h-4" />} autoComplete="username" />
          <Input label="رمز عبور" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="رمز عبور" icon={<Lock className="w-4 h-4" />} autoComplete="current-password" />
          {error && <p className="text-xs text-red-600 bg-red-50 dark:bg-red-900/20 p-2.5 rounded-xl animate-shake">{error}</p>}
          <Button type="submit" className="w-full" size="lg" loading={loading}>ورود به سامانه</Button>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => navigate('/customer')}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-2xl bg-teal-50 dark:bg-teal-900/25 border border-teal-200 dark:border-teal-800 text-xs font-bold text-teal-800 dark:text-teal-300 active:scale-[0.98] transition-transform"
            >
              <FileText className="w-4 h-4" />
              پورتال مشتری (فقط با شماره موبایل)
            </button>
            <button
              type="button"
              onClick={() => navigate('/track')}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-600 dark:text-slate-300 active:scale-[0.98] transition-transform"
            >
              <Search className="w-4 h-4" />
              استعلام وضعیت سفارش
            </button>
          </div>
        </form>

        {/* ورود سریع تستی */}
        <div className="mt-4">
          <div className="relative"><div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-200 dark:border-slate-800" /></div><div className="relative flex justify-center"><span className="bg-white dark:bg-slate-900 px-3 text-[10px] text-slate-400">ورود سریع (دمو)</span></div></div>
          <div className="grid grid-cols-3 gap-1.5 mt-3">
            {([['admin', 'admin', 'مدیر', ShieldCheck, 'purple'], ['tech1', '1234', 'تکنسین', Fingerprint, 'blue'], ['customer1', '1234', 'مشتری', UserIcon, 'teal']] as const).map(([u, p, label, Icon, tone]) => (
              <button key={u} type="button" onClick={() => { const r = login(u, p as string); if (!r.success) { setError(r.error || ''); showToast(r.error || '', 'error'); } else showToast(`ورود به عنوان ${label}`); }}
                className="flex flex-col items-center gap-1 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 active:scale-[0.96] transition-all hover:border-teal-400">
                <Icon className={`w-4 h-4 ${tone === 'purple' ? 'text-purple-500' : tone === 'blue' ? 'text-blue-500' : 'text-teal-500'}`} />
                <span className="text-[10px] font-bold">{label}</span>
              </button>
            ))}
          </div>
          <p className="text-[10px] text-slate-400 text-center mt-2 leading-4">تکنسین پس از ورود به‌صورت خودکار به پنل موبایل مخصوص خود (/tech) منتقل می‌شود.</p>
        </div>
        <div className="mt-6 text-center space-y-1">
          <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400"><Phone className="w-3 h-3" />پشتیبانی: <span className="font-mono">{toPersianDigits(settings.developerPhone)}</span></div>
          <p className="text-[11px] text-slate-400 dark:text-slate-500">توسعه و طراحی: {settings.developerName} — مشهد</p>
        </div>
      </div>
      {enrollFor && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setEnrollFor(null)} />
          <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-t-[32px] p-6 animate-sheet-up safe-bottom">
            <div className="w-10 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 mx-auto mb-5" />
            <div className="w-16 h-16 rounded-2xl bg-teal-50 dark:bg-teal-900/30 flex items-center justify-center mx-auto mb-3"><ScanFace className="w-8 h-8 text-teal-600" /></div>
            <h3 className="text-center font-bold text-lg">ورود سریع با اثر انگشت</h3>
            <p className="text-center text-xs text-slate-500 mt-1.5 leading-6">می‌خواهید دفعات بعد بدون رمز عبور و فقط با اثر انگشت این دستگاه وارد شوید؟</p>
            <div className="flex gap-2 mt-5"><Button variant="secondary" className="flex-1" onClick={() => setEnrollFor(null)}>بعداً</Button><Button className="flex-1" loading={bioBusy} onClick={enrollNow}><Fingerprint className="w-4 h-4" />ثبت اثر انگشت</Button></div>
          </div>
        </div>
      )}
    </div>
  );
}
