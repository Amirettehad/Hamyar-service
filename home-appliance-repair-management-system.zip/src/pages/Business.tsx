import { useEffect, useMemo, useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, Input, Select as UI_Select, Modal, PageHeader, SearchInput, EmptyState, Badge, CurrencyInput, Textarea, useToast } from '../components/ui';
import { Plus, Phone, AlertTriangle, Calendar, UserCog, Briefcase, Link as LinkIcon, Edit3, Copy, KeyRound, ShieldCheck, Package, Camera, Trash2, Edit, History } from 'lucide-react';
import { compressImage } from '../utils/imageCompressor';
import { Link } from 'react-router-dom';
import { formatCurrency, toPersianDigits, formatJalali } from '../lib/jalali';
import { DEVICE_TYPES, DEFAULT_TECH_PERMISSIONS, TECH_PERMISSION_LABELS, type TechPermission, type InventoryItem, type PartItem, type Invoice } from '../lib/types';
import { QRCodeSVG } from 'qrcode.react';
import { cn } from '../utils/cn';

/* ================== Technicians (+ credentials & permissions) ================== */
export function Technicians() {
  const { db, addTechnician, updateTechnician, updateTechnicianLogin } = useApp();
  const { showToast } = useToast();
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ fullName: '', phone: '', specialization: '', commissionRate: 15 });
  const [search, setSearch] = useState('');
  const [manageId, setManageId] = useState<string | null>(null);
  const manage = manageId ? db.technicians.find(t => t.id === manageId) : undefined;
  const manageUser = manage ? db.users.find(u => u.technicianId === manage.id) : undefined;
  const [uName, setUName] = useState('');
  const [uPass, setUPass] = useState('');
  const [uPerms, setUPerms] = useState<TechPermission[]>([]);

  useEffect(() => {
    if (manage) { setUName(manageUser?.username || ''); setUPass(manageUser?.password || ''); setUPerms([...manage.permissions]); }
  }, [manageId]); // eslint-disable-line react-hooks/exhaustive-deps

  const filtered = useMemo(() => db.technicians.filter(t => t.fullName.includes(search) || t.phone.includes(search)), [db.technicians, search]);
  const save = () => { if (!form.fullName || !form.phone) return; addTechnician({ fullName: form.fullName, phone: form.phone, specialization: form.specialization, isActive: true, commissionRate: form.commissionRate, permissions: DEFAULT_TECH_PERMISSIONS }); setModalOpen(false); setForm({ fullName: '', phone: '', specialization: '', commissionRate: 15 }); showToast('تکنسین اضافه شد ✓'); };

    const techLink = `${window.location.origin}/#/tech`;
  const saveManagement = () => {
    if (!manage) return;
    if (!uName.trim() || !uPass.trim()) { showToast('نام کاربری و رمز عبور الزامی است', 'error'); return; }
    const res = updateTechnicianLogin(manage.id, { username: uName.trim(), password: uPass });
    if (!res.success) { showToast(res.error || 'خطا', 'error'); return; }
    updateTechnician(manage.id, { permissions: uPerms });
    showToast('تنظیمات تکنسین ذخیره شد ✓ لینک را همراه اعتبارنامه به تکنسین بدهید');
  };
  const copyManagePack = () => {
    if (!manage) return;
    const text = `پنل تکنسین اتحاد:\nلینک: ${techLink}\nنام کاربری: ${manageUser?.username || '-'}\nرمز عبور: ${manageUser?.password || '-'}`;
    navigator.clipboard.writeText(text).then(() => showToast('اعتبارنامهه پنل تککنین با لینک کپی شد ✓'));
  };

  return (
    <div className="space-y-4">
      <PageHeader title="مدیریت تکنسین‌ها" subtitle="ایجاد حساب‌ها و دسترسی‌های پنل مجزای تکنسین" action={<Button onClick={() => setModalOpen(true)}><Plus className="w-4 h-4" />افزودن تکنسین</Button>} />
      <SearchInput value={search} onChange={setSearch} placeholder="جستجو..." />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map(t => { const orders = db.orders.filter(o => o.technicianId === t.id); const done = orders.filter(o => ['تعمیر شده', 'تحویل شده', 'انجام شده'].includes(o.status)); const commission = done.reduce((s, o) => s + Math.round(o.finalAmount * (t.commissionRate / 100)), 0); const techUser = db.users.find(u => u.technicianId === t.id); return (
          <Card key={t.id} hover onClick={() => setManageId(t.id)} className="p-4">
            <div className="flex items-start gap-3 mb-3"><div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-indigo-500 flex items-center justify-center text-white font-bold flex-shrink-0">{t.fullName.split(' ').map(n => n[0]).slice(0, 2).join('')}</div><div className="flex-1 min-w-0"><p className="font-bold text-sm text-slate-900 dark:text-white">{t.fullName}</p><p className="text-xs font-mono ltr inline-block text-slate-500">{toPersianDigits(t.phone)}</p><p className="text-[10px] text-slate-400">{t.specialization || 'تعمیرکار عمومی'}</p></div><Badge color={t.isActive ? 'green' : 'slate'}>{t.isActive ? 'فعال' : 'غیرفعال'}</Badge></div>
            <div className="grid grid-cols-3 gap-2 text-center py-2 border-t border-slate-100 dark:border-slate-700"><div><p className="text-[10px] text-slate-500">کل</p><p className="font-bold text-xs">{toPersianDigits(orders.length)}</p></div><div><p className="text-[10px] text-slate-500">انجام شده</p><p className="font-bold text-xs text-green-600">{toPersianDigits(done.length)}</p></div><div><p className="text-[10px] text-slate-500">پورسانت</p><p className="font-bold text-xs text-teal-600">{formatCurrency(commission, false)}</p></div></div>
            <div className="flex items-center justify-between mt-2 text-[10px]">
              <span className={techUser ? 'text-emerald-600 font-bold inline-flex items-center gap-1' : 'text-slate-400 inline-flex items-center gap-1'}><KeyRound className="w-3 h-3" />{techUser ? techUser.username : 'بدون حساب'}</span>
              <span className="text-teal-600 font-bold inline-flex items-center gap-1"><ShieldCheck className="w-3 h-3" />مدیریت و دسترسی ←</span>
            </div>
          </Card>
        ); })}
      </div>
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="تکنسین جدید" size="md"><div className="space-y-3"><Input label="نام و نام خانوادگی *" value={form.fullName} onChange={e => setForm({ ...form, fullName: e.target.value })} /><Input label="شماره تماس *" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /><Input label="تخصص" value={form.specialization} onChange={e => setForm({ ...form, specialization: e.target.value })} placeholder="مثلاً یخچال و سردخانه" /><Input label="درصد پورسانت" type="number" value={form.commissionRate} onChange={e => setForm({ ...form, commissionRate: parseInt(e.target.value) || 0 })} /></div><div className="flex gap-2 mt-4 justify-end"><Button variant="secondary" onClick={() => setModalOpen(false)}>انصراف</Button><Button onClick={save}>ذخیره</Button></div></Modal>

      {/* Management Modal: credentials + access */}
      <Modal open={!!manage} onClose={() => setManageId(null)} title={manage ? `مدیریت ${manage.fullName}` : ''} size="lg">
        {manage && (
          <div className="space-y-4">
            <Card className="p-4 bg-teal-50/60 dark:bg-teal-900/15 border-teal-200 dark:border-teal-800">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-xs font-bold text-teal-800 dark:text-teal-300">لینک پنل PWA مجزای تکنسین</p>
                  <p className="text-[10px] text-teal-700 dark:text-teal-400 mt-0.5 leading-4">لینک را همراه با اعتبارنامه در اختیار تکنسین قرار بدهید تا مستقیماً به پنل موبایل خود وارد شود.</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => { navigator.clipboard.writeText(techLink); showToast('لینک کپی شد ✓'); }}><Copy className="w-3.5 h-3.5" />کپی</Button>
              </div>
              <input readOnly value={techLink} dir="ltr" className="w-full mt-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs font-mono" />
              <div className="grid grid-cols-2 gap-2 mt-3">
                <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-700"><p className="text-[9px] text-slate-400">نام کاربری</p><p className="text-xs font-mono font-bold" dir="ltr">{manageUser?.username || '—'}</p></div>
                <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-700"><p className="text-[9px] text-slate-400">رمز عبور</p><p className="text-xs font-mono font-bold" dir="ltr">{manageUser ? '•••••' : '—'}</p></div>
              </div>
            </Card>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Input label="نام کاربری ورود" value={uName} onChange={e => setUName(e.target.value)} placeholder="tech2" />
              <Input label="رمز عبور" value={uPass} onChange={e => setUPass(e.target.value)} placeholder="رمز عبور جدید..." type="password" />
            </div>

            <div>
              <p className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">دسترسی‌های پنل تکنسین:</p>
              <div className="grid grid-cols-2 gap-1.5">
                {(Object.entries(TECH_PERMISSION_LABELS) as [TechPermission, string][]).map(([perm, label]) => {
                  const on = uPerms.includes(perm);
                  return (
                    <button key={perm} type="button" onClick={() => setUPerms(prev => on ? prev.filter(x => x !== perm) : [...prev, perm])}
                      className={cn('py-2.5 px-3 rounded-xl text-[11px] font-bold text-right border-2 transition-all active:scale-[0.97]', on ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-200 dark:border-slate-700 text-slate-500 hover:border-teal-300')}>
                      {on ? '✓ ' : ''}{label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex gap-2 items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
              <span className="text-xs font-medium text-slate-600 dark:text-slate-300">وضعیت حساب تکنسین</span>
              <button onClick={() => updateTechnician(manage.id, { isActive: !manage.isActive })} className={cn('px-3 py-1.5 rounded-full text-[11px] font-bold transition-all', manage.isActive ? 'bg-emerald-600 text-white' : 'bg-slate-300 dark:bg-slate-700 text-slate-600')}>{manage.isActive ? 'فعال ✓' : 'غیرفعال'}</button>
            </div>

            <div className="flex gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 justify-end flex-wrap">
              <Button variant="outline" size="sm" onClick={copyManagePack}><Copy className="w-3.5 h-3.5" />کپی لینک + اعتبارنامه</Button>
              <Button variant="secondary" onClick={() => setManageId(null)}>بستن</Button>
              <Button onClick={saveManagement}><KeyRound className="w-3.5 h-3.5" />ذخیره تنظیمات تکنسین</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ================== Missions ================== */
export function Missions() {
  const { db, updateOrderStatus, currentUser } = useApp();
  const missions = useMemo(() => { let list = db.orders.filter(o => ['در انتظار اعزام', 'اعزام شده', 'در حال تعمیر', 'نیاز به قطعه'].includes(o.status)); if (currentUser?.role === 'technician') list = list.filter(o => o.technicianId === currentUser.technicianId); return list; }, [db.orders, currentUser]);
  return (
    <div className="space-y-4">
      <PageHeader title="اعزام ماموران" subtitle="مدیریت و تخصیص ماموریت‌های سرویس" action={<Link to="/orders/new"><Button><Plus className="w-4 h-4" />ماموریت جدید</Button></Link>} />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {missions.length === 0 && <div className="col-span-full"><EmptyState title="ماموریت فعالی وجود ندارد" icon={<Briefcase className="w-8 h-8" />} /></div>}
        {missions.map(o => { const customer = db.customers.find(c => c.id === o.customerId); const tech = db.technicians.find(t => t.id === o.technicianId); return (
          <Card key={o.id} className="p-4"><div className="flex justify-between items-start mb-3"><div><p className="font-mono text-xs font-bold text-teal-600">{o.requestNumber}</p><p className="font-bold text-sm mt-1">{customer?.fullName}</p><p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5"><Phone className="w-3 h-3" />{customer?.phone}</p></div><Badge color={o.status === 'اعزام شده' ? 'blue' : o.status === 'در حال تعمیر' ? 'purple' : o.status === 'نیاز به قطعه' ? 'orange' : 'amber'}>{o.status}</Badge></div>{customer?.address && <p className="text-xs text-slate-500 mb-2 line-clamp-2">{customer.address}</p>}<div className="flex items-center gap-3 text-[10px] text-slate-500 py-2 border-t border-slate-100 dark:border-slate-700"><span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{o.visitDate ? formatJalali(new Date(o.visitDate)) : 'بدون تاریخ'}</span><span className="flex items-center gap-1"><UserCog className="w-3 h-3" />{tech?.fullName || 'تعیین نشده'}</span></div><div className="flex gap-1 mt-2"><Link to={`/orders/${o.id}`}><Button size="sm" variant="outline">مشاهده فرم</Button></Link>{currentUser?.role === 'technician' && o.status === 'اعزام شده' && <Button size="sm" onClick={() => updateOrderStatus(o.id, 'در حال تعمیر')}>شروع تعمیر</Button>}</div></Card>
        ); })}
      </div>
    </div>
  );
}

/* ================== Devices ================== */
export function Devices() {
  const { db } = useApp();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [qrDevice, setQrDevice] = useState<string | null>(null);
  const filtered = useMemo(() => db.devices.filter(d => (typeFilter === 'all' || d.type === typeFilter) && (d.serialNumber?.includes(search) || d.brand.includes(search) || d.model?.includes(search))), [db.devices, search, typeFilter]);
  const selectedDevice = db.devices.find(d => d.id === qrDevice);
  return (
    <div className="space-y-4">
      <PageHeader title="مدیریت دستگاه‌ها و دارایی‌ها" subtitle={`${toPersianDigits(db.devices.length)} دستگاه ثبت شده`} />
      <div className="flex flex-col sm:flex-row gap-3"><SearchInput value={search} onChange={setSearch} placeholder="جستجوی سریال، مدل، برند..." className="flex-1" /><UI_Select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} options={[{ value: 'all', label: 'همه' }, ...DEVICE_TYPES.map(t => ({ value: t, label: t }))]} className="sm:w-48" /></div>
      <Card className="overflow-x-auto">
        <table className="data-table hidden md:table"><thead><tr><th>نوع</th><th>برند</th><th>مدل</th><th>سریال</th><th>گارانتی</th><th>مشتری</th><th>QR</th></tr></thead><tbody>{filtered.map(d => { const c = db.customers.find(cust => cust.id === d.customerId); return (<tr key={d.id}><td className="font-medium">{d.type}</td><td>{d.brand}</td><td>{d.model || '—'}</td><td className="font-mono text-xs">{toPersianDigits(d.serialNumber || '—')}</td><td><Badge color={d.warrantyStatus === 'داخل گارانتی' ? 'green' : 'slate'}>{d.warrantyStatus}</Badge></td><td className="text-xs">{c?.fullName}</td><td><button onClick={() => setQrDevice(d.id)} className="p-1 rounded bg-slate-100 dark:bg-slate-800">📱</button></td></tr>); })}</tbody></table>
        <div className="md:hidden p-4 space-y-3">{filtered.map(d => { const c = db.customers.find(cust => cust.id === d.customerId); return (<div key={d.id} className="p-3 border border-slate-200 dark:border-slate-700 rounded-xl"><div className="flex justify-between"><div><p className="font-semibold">{d.type} {d.brand}</p><p className="text-xs text-slate-500">{d.model} • {toPersianDigits(d.serialNumber || '')}</p></div><button onClick={() => setQrDevice(d.id)} className="p-1.5 rounded bg-slate-100 dark:bg-slate-800">📱</button></div><p className="text-xs mt-1">مشتری: {c?.fullName}</p></div>); })}</div>
      </Card>
      <Modal open={!!qrDevice} onClose={() => setQrDevice(null)} title="QR Code دستگاه" size="sm">{selectedDevice && <div className="text-center space-y-3"><p className="font-semibold">{selectedDevice.type} {selectedDevice.brand} {selectedDevice.model}</p><p className="text-xs font-mono">{toPersianDigits(selectedDevice.serialNumber || '')}</p><div className="flex justify-center p-4 bg-white rounded-xl inline-block"><QRCodeSVG value={JSON.stringify({ id: selectedDevice.id, serial: selectedDevice.serialNumber })} size={200} /></div></div>}</Modal>
    </div>
  );
}

/* ================== Advanced Real Inventory ================== */
export function Inventory() {
  const { db, addInventoryItem, updateInventoryItem, deleteInventoryItem, updateInventoryQty } = useApp();
  const { showToast } = useToast();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [cardexItemId, setCardexItemId] = useState<string | null>(null);
  const [imageModalUrl, setImageModalUrl] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('all');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState<Partial<InventoryItem>>({
    name: '', category: '', quantity: 0, minQuantity: 2, unitPrice: 0,
    costPrice: 0, brand: '', partNumber: '', location: '', description: '', imageUrl: '',
  });

  const categories = useMemo(() => Array.from(new Set(db.inventory.map(i => i.category))), [db.inventory]);

  const filtered = useMemo(() => db.inventory.filter(i =>
    (catFilter === 'all' || i.category === catFilter) &&
    (i.name.includes(search) || (i.partNumber || '').includes(search) || (i.brand || '').includes(search) || (i.location || '').includes(search))
  ), [db.inventory, search, catFilter]);

  const totalValue = db.inventory.reduce((s, i) => s + i.quantity * i.unitPrice, 0);
  const totalCost = db.inventory.reduce((s, i) => s + i.quantity * (i.costPrice || i.unitPrice * 0.7), 0);
  const lowCount = db.inventory.filter(i => i.quantity <= i.minQuantity).length;

  const openNew = () => {
    setEditingId(null);
    setForm({
      name: '', category: 'قطعات برقی', quantity: 1, minQuantity: 2,
      unitPrice: 0, costPrice: 0, brand: '', partNumber: '', location: 'قفسه A', description: '', imageUrl: '',
    });
    setModalOpen(true);
  };

  const openEdit = (item: InventoryItem) => {
    setEditingId(item.id);
    setForm({ ...item });
    setModalOpen(true);
  };

  // فشرده‌سازی تصویر در سمت کلاینت قبل از ذخیره
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      showToast('در حال بهینه‌سازی و فشرده‌سازی تصویر...');
      const compressed = await compressImage(file, 400, 400, 0.78);
      setForm(prev => ({ ...prev, imageUrl: compressed }));
      showToast('تصویر با موفقیت فشرده شد ✓');
    } catch (err) {
      console.error(err);
      showToast('خطا در پردازش تصویر', 'error');
    }
    e.target.value = '';
  };

  const saveItem = () => {
    if (!form.name?.trim()) {
      showToast('نام قطعه الزامی است', 'error');
      return;
    }
    if (editingId) {
      updateInventoryItem(editingId, {
        name: form.name.trim(),
        category: form.category || 'متفرقه',
        quantity: form.quantity || 0,
        minQuantity: form.minQuantity || 2,
        unitPrice: form.unitPrice || 0,
        costPrice: form.costPrice || 0,
        brand: form.brand || '',
        partNumber: form.partNumber || '',
        location: form.location || '',
        description: form.description || '',
        imageUrl: form.imageUrl || '',
      });
      showToast('مشخصات قطعه به‌روزرسانی شد ✓');
    } else {
      addInventoryItem({
        name: form.name.trim(),
        category: form.category || 'متفرقه',
        quantity: form.quantity || 0,
        minQuantity: form.minQuantity || 2,
        unitPrice: form.unitPrice || 0,
        costPrice: form.costPrice || 0,
        brand: form.brand || '',
        partNumber: form.partNumber || '',
        location: form.location || '',
        description: form.description || '',
        imageUrl: form.imageUrl || '',
      });
      showToast('قطعه جدید با موفقیت به انبار اضافه شد ✓');
    }
    setModalOpen(false);
  };

  const cardexItem = cardexItemId ? db.inventory.find(i => i.id === cardexItemId) : null;

  // محاسبه کاردکس مصرف قطعه در تمام سفارشات، فاکتورها و تکنسین‌ها
  const cardexUsages = useMemo(() => {
    if (!cardexItem) return [];
    return db.orders.flatMap(order => {
      const matched = (order.parts || []).filter(p =>
        p.name.trim().toLowerCase() === cardexItem.name.trim().toLowerCase() ||
        p.id === cardexItem.id
      );
      if (!matched.length) return [];
      const customer = db.customers.find(c => c.id === order.customerId);
      const tech = db.technicians.find(t => t.id === order.technicianId);
      const invoice = db.invoices.find(i => i.orderId === order.id);

      return matched.map(p => ({
        orderId: order.id,
        requestNumber: order.requestNumber,
        invoiceNumber: invoice?.invoiceNumber,
        customerName: customer?.fullName || 'نامشخص',
        customerPhone: customer?.phone,
        technicianName: tech?.fullName || 'نامشخص',
        date: order.registrationDate,
        quantity: p.quantity,
        unitPrice: p.unitPrice,
        total: p.quantity * p.unitPrice,
        status: order.status,
      }));
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [cardexItem, db.orders, db.customers, db.technicians, db.invoices]);

  const totalConsumed = useMemo(() => {
    return cardexUsages.reduce((sum, u) => sum + u.quantity, 0);
  }, [cardexUsages]);

  return (
    <div className="space-y-4">
      <PageHeader
        title="انبار و موجودی قطعات"
        subtitle="مدیریت جامع قطعات یدکی، کاردکس مصرف، رهگیری مشتریان و فاکتورها"
        action={
          <Button onClick={openNew}>
            <Plus className="w-4 h-4" />
            افزودن قطعه جدید
          </Button>
        }
      />

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="p-4">
          <p className="text-xs text-slate-500">تعداد اقلام انبار</p>
          <p className="text-xl font-bold mt-1">{toPersianDigits(db.inventory.length)} ردیف</p>
          <p className="text-[10px] text-slate-400 mt-0.5">{toPersianDigits(categories.length)} دسته‌بندی</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-slate-500">ارزش فروش کل انبار</p>
          <p className="text-xl font-bold mt-1 text-teal-600">{formatCurrency(totalValue)}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">بر اساس نرخ فروش</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-slate-500">بهای تمام‌شده موجودی</p>
          <p className="text-xl font-bold mt-1 text-slate-700 dark:text-slate-200">{formatCurrency(totalCost)}</p>
          <p className="text-[10px] text-emerald-600 mt-0.5 font-bold">حاشیه سود: {formatCurrency(Math.max(0, totalValue - totalCost))}</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-slate-500">اقلام نیازمند شارژ</p>
          <p className={cn('text-xl font-bold mt-1', lowCount > 0 ? 'text-red-600' : 'text-emerald-600')}>
            {toPersianDigits(lowCount)} قطعه
          </p>
          <p className="text-[10px] text-slate-400 mt-0.5">{lowCount > 0 ? 'موجودی کمتر از حد مجاز' : 'موجودی کافی است ✓'}</p>
        </Card>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput value={search} onChange={setSearch} placeholder="جستجو بر اساس نام، پارت‌نامبر، برند یا قفسه..." className="flex-1" />
        <UI_Select value={catFilter} onChange={e => setCatFilter(e.target.value)} options={[{ value: 'all', label: 'همه دسته‌ها' }, ...categories.map(c => ({ value: c, label: c }))]} className="sm:w-56" />
      </div>

      {/* Desktop Table & Mobile Cards */}
      <Card className="overflow-x-auto">
        <table className="data-table hidden md:table">
          <thead>
            <tr>
              <th className="w-14">تصویر</th>
              <th>نام قطعه</th>
              <th>کد فنی</th>
              <th>دسته</th>
              <th>قفسه</th>
              <th>موجودی</th>
              <th>حداقل</th>
              <th>قیمت واحد</th>
              <th>ارزش کل</th>
              <th className="text-left">عملیات و کاردکس</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(item => {
              const isLow = item.quantity <= item.minQuantity;
              return (
                <tr
                  key={item.id}
                  className={cn('hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors cursor-pointer', isLow && 'bg-red-50/40 dark:bg-red-950/15')}
                  onClick={() => setCardexItemId(item.id)}
                >
                  {/* Miniature Thumbnail */}
                  <td onClick={e => { if (item.imageUrl) { e.stopPropagation(); setImageModalUrl(item.imageUrl); } }}>
                    <div className="w-10 h-10 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                      {item.imageUrl ? (
                        <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover hover:scale-110 transition-transform" />
                      ) : (
                        <Package className="w-5 h-5 text-slate-400" />
                      )}
                    </div>
                  </td>

                  <td>
                    <p className="font-bold text-slate-900 dark:text-white text-sm">{item.name}</p>
                    {item.brand && <p className="text-[11px] text-slate-500">برند: {item.brand}</p>}
                  </td>

                  <td className="font-mono text-xs">{item.partNumber ? toPersianDigits(item.partNumber) : '—'}</td>
                  <td className="text-xs">{item.category}</td>
                  <td className="text-xs text-slate-500 font-mono">{item.location || '—'}</td>

                  <td className="font-bold">
                    {isLow ? (
                      <span className="text-red-600 flex items-center gap-1 font-bold">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        {toPersianDigits(item.quantity)}
                      </span>
                    ) : (
                      <span className="font-mono">{toPersianDigits(item.quantity)}</span>
                    )}
                  </td>

                  <td className="text-xs text-slate-500 font-mono">{toPersianDigits(item.minQuantity)}</td>
                  <td className="font-mono text-xs">{formatCurrency(item.unitPrice)}</td>
                  <td className="font-mono text-xs font-semibold text-slate-700 dark:text-slate-200">
                    {formatCurrency(item.quantity * item.unitPrice)}
                  </td>

                  <td className="text-left" onClick={e => e.stopPropagation()}>
                    <div className="flex items-center gap-1 justify-end">
                      <Button size="sm" variant="ghost" onClick={() => setCardexItemId(item.id)} title="مشاهده کاردکس و سوابق مصرف">
                        <History className="w-3.5 h-3.5" />
                        کاردکس
                      </Button>

                      <div className="flex gap-0.5 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg">
                        <button
                          onClick={() => updateInventoryQty(item.id, 1)}
                          className="px-2 py-0.5 text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:bg-white dark:hover:bg-slate-700 rounded transition-colors"
                          title="افزایش یک واحد"
                        >
                          +
                        </button>
                        <button
                          onClick={() => updateInventoryQty(item.id, -1)}
                          className="px-2 py-0.5 text-xs font-bold text-rose-700 dark:text-rose-400 hover:bg-white dark:hover:bg-slate-700 rounded transition-colors"
                          title="کاهش یک واحد"
                        >
                          -
                        </button>
                      </div>

                      <Button size="sm" variant="ghost" onClick={() => openEdit(item)} title="ویرایش">
                        <Edit className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={10} className="text-center py-12 text-slate-400">
                  قطعه‌ای با این مشخصات یافت نشد
                </td>
              </tr>
            )}
          </tbody>
        </table>

        {/* Mobile View */}
        <div className="md:hidden divide-y divide-slate-100 dark:divide-slate-800">
          {filtered.map(item => {
            const isLow = item.quantity <= item.minQuantity;
            return (
              <div
                key={item.id}
                onClick={() => setCardexItemId(item.id)}
                className={cn('p-3.5 space-y-2 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50', isLow && 'bg-red-50/40 dark:bg-red-950/20')}
              >
                <div className="flex items-start gap-3">
                  <div
                    onClick={e => { if (item.imageUrl) { e.stopPropagation(); setImageModalUrl(item.imageUrl); } }}
                    className="w-12 h-12 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0"
                  >
                    {item.imageUrl ? (
                      <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                    ) : (
                      <Package className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-1">
                      <p className="font-bold text-sm text-slate-900 dark:text-white truncate">{item.name}</p>
                      <Badge color={isLow ? 'red' : 'teal'}>
                        موجودی: {toPersianDigits(item.quantity)}
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {item.category} {item.brand && `• برند: ${item.brand}`} {item.location && `• قفسه: ${item.location}`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100 dark:border-slate-800">
                  <span className="font-mono text-slate-600 dark:text-slate-300">
                    قیمت: {formatCurrency(item.unitPrice)}
                  </span>
                  <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                    <Button size="sm" variant="ghost" onClick={() => setCardexItemId(item.id)}>
                      سوابق مصرف
                    </Button>
                    <button onClick={() => updateInventoryQty(item.id, 1)} className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold">+</button>
                    <button onClick={() => updateInventoryQty(item.id, -1)} className="w-7 h-7 rounded-lg bg-rose-100 text-rose-800 text-xs font-bold">-</button>
                    <Button size="sm" variant="ghost" onClick={() => openEdit(item)}>
                      <Edit className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Add / Edit Modal with Image upload and client compression */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'ویرایش قطعه انبار' : 'افزودن قطعه جدید به انبار'} size="md">
        <div className="space-y-3.5">
          {/* Image Upload Area */}
          <div>
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 block">
              تصویر قطعه (فشرده‌سازی خودکار در سمت کلاینت)
            </label>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
            <div className="flex items-center gap-3">
              {form.imageUrl ? (
                <div className="relative">
                  <img src={form.imageUrl} alt="قطعه" className="w-20 h-20 rounded-2xl object-cover border-2 border-teal-500 shadow-sm" />
                  <button
                    type="button"
                    onClick={() => setForm(f => ({ ...f, imageUrl: '' }))}
                    className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center text-xs"
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-20 h-20 rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-teal-500 bg-slate-50 dark:bg-slate-800/60 flex flex-col items-center justify-center gap-1 text-slate-500 hover:text-teal-600 transition-colors"
                >
                  <Camera className="w-5 h-5" />
                  <span className="text-[10px]">آپلود عکس</span>
                </button>
              )}
              <div className="text-xs text-slate-500 leading-5">
                <p>تصویر قطعه به صورت خودکار تا زیر ۳۰ کیلوبایت فشرده می‌شود تا اپلیکیشن سنگین نشود.</p>
                {form.imageUrl && <p className="text-emerald-600 text-[11px] font-bold mt-0.5">تصویر بارگذاری و فشرده شد ✓</p>}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input label="نام قطعه *" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="مثال: پمپ تخلیه ظرفشویی" />
            <Input label="کد فنی / پارت نامبر" value={form.partNumber} onChange={e => setForm({ ...form, partNumber: e.target.value })} placeholder="مثال: 00645609" dir="ltr" />
            <Input label="دسته‌بندی" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} placeholder="مثال: پمپ، فیلتر، سنسور" />
            <Input label="برند سازنده" value={form.brand} onChange={e => setForm({ ...form, brand: e.target.value })} placeholder="مثال: بوش، دانفوس" />
            <Input label="موقعیت در قفسه انبار" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="مثال: قفسه B3 - ردیف ۲" />
            <Input label="موجودی فعلی (تعداد) *" type="number" value={form.quantity} onChange={e => setForm({ ...form, quantity: parseInt(e.target.value) || 0 })} />
            <Input label="حداقل موجودی هشدار" type="number" value={form.minQuantity} onChange={e => setForm({ ...form, minQuantity: parseInt(e.target.value) || 0 })} />
            <CurrencyInput label="قیمت فروش واحد (تومان) *" value={form.unitPrice || 0} onChange={v => setForm({ ...form, unitPrice: v })} />
            <CurrencyInput label="بهای تمام‌شده خرید (تومان)" value={form.costPrice || 0} onChange={v => setForm({ ...form, costPrice: v })} />
          </div>

          <Textarea label="توضیحات و دستگاه‌های سازگار" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={2} placeholder="توضیحات تکمیلی..." />

          <div className="flex gap-2 mt-4 justify-end pt-2 border-t border-slate-100 dark:border-slate-800">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>انصراف</Button>
            <Button onClick={saveItem}>ذخیره در انبار</Button>
          </div>
        </div>
      </Modal>

      {/* Cardex & Consumption Traceability Modal (Req 1) */}
      {cardexItem && (
        <Modal open onClose={() => setCardexItemId(null)} title={`کاردکس و ردگیری سوابق: ${cardexItem.name}`} size="lg">
          <div className="space-y-4">
            {/* Header info */}
            <div className="flex items-start justify-between gap-3 p-3.5 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div
                  onClick={() => { if (cardexItem.imageUrl) setImageModalUrl(cardexItem.imageUrl); }}
                  className="w-16 h-16 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-center shrink-0 cursor-pointer shadow-sm"
                >
                  {cardexItem.imageUrl ? (
                    <img src={cardexItem.imageUrl} alt={cardexItem.name} className="w-full h-full object-cover" />
                  ) : (
                    <Package className="w-8 h-8 text-slate-400" />
                  )}
                </div>
                <div>
                  <h4 className="font-extrabold text-base text-slate-900 dark:text-white">{cardexItem.name}</h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    کد فنی: <span className="font-mono">{cardexItem.partNumber || '—'}</span> • برند: {cardexItem.brand || '—'}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    محل انبار: <b>{cardexItem.location || 'ثبت نشده'}</b> • دسته: {cardexItem.category}
                  </p>
                </div>
              </div>

              <div className="text-left font-mono">
                <Badge color={cardexItem.quantity <= cardexItem.minQuantity ? 'red' : 'green'}>
                  موجودی انبار: {toPersianDigits(cardexItem.quantity)} عدد
                </Badge>
                <p className="text-xs text-slate-400 mt-1">حداقل هشدار: {toPersianDigits(cardexItem.minQuantity)}</p>
                <p className="text-xs font-bold text-teal-600 mt-1">قیمت: {formatCurrency(cardexItem.unitPrice)}</p>
              </div>
            </div>

            {/* Total usage stats */}
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-3 bg-teal-50 dark:bg-teal-900/20 rounded-xl">
                <p className="text-slate-500">موجودی فعلی در انبار</p>
                <p className="text-lg font-black text-teal-700 dark:text-teal-300 font-mono mt-0.5">{toPersianDigits(cardexItem.quantity)} عدد</p>
              </div>
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
                <p className="text-slate-500">کل مصرف در سفارشات</p>
                <p className="text-lg font-black text-blue-700 dark:text-blue-300 font-mono mt-0.5">{toPersianDigits(totalConsumed)} عدد</p>
              </div>
              <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-xl">
                <p className="text-slate-500">تعداد دفعات سفارش</p>
                <p className="text-lg font-black text-purple-700 dark:text-purple-300 font-mono mt-0.5">{toPersianDigits(cardexUsages.length)} مورد</p>
              </div>
            </div>

            {/* Traceability Table */}
            <div>
              <h5 className="font-bold text-xs text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
                <History className="w-4 h-4 text-teal-600" />
                سوابق مصرف دقیق قطعه (مشتری، فاکتور/سفارش، سرویسکار):
              </h5>
              <div className="max-h-64 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 sticky top-0">
                    <tr>
                      <th className="p-2.5 text-right">مشتری</th>
                      <th className="p-2.5 text-right">سفارش / فاکتور</th>
                      <th className="p-2.5 text-right">سرویسکار</th>
                      <th className="p-2.5 text-center">تاریخ</th>
                      <th className="p-2.5 text-center">تعداد</th>
                      <th className="p-2.5 text-left">مبلغ کل</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {cardexUsages.map((u, i) => (
                      <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                        <td className="p-2.5">
                          <p className="font-bold text-slate-800 dark:text-slate-100">{u.customerName}</p>
                          {u.customerPhone && <p className="text-[10px] text-slate-400 font-mono">{toPersianDigits(u.customerPhone)}</p>}
                        </td>
                        <td className="p-2.5">
                          <Link to={`/orders/${u.orderId}`} className="text-teal-600 hover:underline font-mono font-bold block">
                            {u.requestNumber}
                          </Link>
                          {u.invoiceNumber && <span className="text-[10px] text-slate-400 font-mono">فاکتور: {u.invoiceNumber}</span>}
                        </td>
                        <td className="p-2.5">
                          <span className="font-medium text-slate-700 dark:text-slate-300">{u.technicianName}</span>
                        </td>
                        <td className="p-2.5 text-center font-mono text-slate-500">
                          {toPersianDigits(formatJalali(new Date(u.date)))}
                        </td>
                        <td className="p-2.5 text-center font-mono font-bold text-teal-600">
                          {toPersianDigits(u.quantity)}
                        </td>
                        <td className="p-2.5 text-left font-mono">
                          {formatCurrency(u.total)}
                        </td>
                      </tr>
                    ))}
                    {cardexUsages.length === 0 && (
                      <tr>
                        <td colSpan={6} className="text-center py-8 text-slate-400">
                          این قطعه هنوز در هیچ سفارشی مصرف نشده است.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-slate-100 dark:border-slate-800">
              <Button
                variant="danger"
                size="sm"
                onClick={() => {
                  if (confirm(`آیا از حذف قطعه «${cardexItem.name}» از انبار اطمینان دارید؟`)) {
                    deleteInventoryItem(cardexItem.id);
                    setCardexItemId(null);
                    showToast('قطعه از انبار حذف شد');
                  }
                }}
              >
                <Trash2 className="w-3.5 h-3.5" />
                حذف قطعه
              </Button>

              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => { openEdit(cardexItem); setCardexItemId(null); }}>
                  <Edit className="w-3.5 h-3.5" />
                  ویرایش مشخصات
                </Button>
                <Button size="sm" onClick={() => setCardexItemId(null)}>
                  بستن
                </Button>
              </div>
            </div>
          </div>
        </Modal>
      )}

      {/* Lightbox for part image */}
      {imageModalUrl && (
        <Modal open onClose={() => setImageModalUrl(null)} title="نمای بزرگ تصویر قطعه" size="sm">
          <div className="space-y-3 text-center">
            <img src={imageModalUrl} alt="تصویر قطعه" className="max-h-96 mx-auto rounded-2xl object-contain shadow-lg" />
            <Button className="w-full" variant="secondary" onClick={() => setImageModalUrl(null)}>بستن</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}

/* ================== Invoices (editable) ================== */
export function Invoices() {
  const { db, currentUser, editInvoice } = useApp();
  const { showToast } = useToast();
  const invoices = useMemo(() => { if (currentUser?.role === 'customer') return db.invoices.filter(i => i.customerId === currentUser.customerId); return db.invoices; }, [db.invoices, currentUser]);
  const [search, setSearch] = useState('');
  const [editId, setEditId] = useState<string | null>(null);
  const editing = editId ? db.invoices.find(i => i.id === editId) : undefined;
  const filtered = invoices.filter(i => i.invoiceNumber.includes(search) || db.customers.find(c => c.id === i.customerId)?.fullName.includes(search));
  return (
    <div className="space-y-4">
      <PageHeader title="فاکتورها" subtitle="فاکتورهای صادر شده" action={currentUser?.role === 'admin' ? <Link to="/editor"><Button variant="outline"><Edit3 className="w-4 h-4" />ویرایش قالب چاپ</Button></Link> : null} />
      <SearchInput value={search} onChange={setSearch} placeholder="جستجو..." />
      <Card className="overflow-x-auto"><table className="data-table"><thead><tr><th>شماره</th><th>تاریخ</th><th>مشتری</th><th>مبلغ</th><th>پرداخت</th><th>وضعیت</th><th className="text-left">عملیات</th></tr></thead><tbody>{filtered.map(inv => { const c = db.customers.find(cu => cu.id === inv.customerId); return (<tr key={inv.id}><td className="font-mono font-semibold text-teal-600 text-xs">{inv.invoiceNumber}</td><td className="text-xs font-mono">{toPersianDigits(formatJalali(new Date(inv.date)))}</td><td className="text-sm">{c?.fullName}</td><td className="font-mono text-sm font-semibold">{formatCurrency(inv.totalAmount)}</td><td className="font-mono text-xs text-emerald-600">{formatCurrency(inv.paidAmount)}</td><td><Badge color={inv.paymentStatus === 'پرداخت شده' ? 'green' : inv.paymentStatus === 'پرداخت جزئی' ? 'amber' : 'red'}>{inv.paymentStatus}</Badge></td><td className="text-left"><div className="flex gap-1 justify-end">{currentUser?.role === 'admin' && <Button size="sm" variant="ghost" onClick={() => setEditId(inv.id)}>ویرایش</Button>}<Link to={`/orders/${inv.orderId}`}><Button size="sm" variant="ghost">مشاهده</Button></Link></div></td></tr>); })}{filtered.length === 0 && <tr><td colSpan={7} className="text-center py-8 text-slate-500">فاکتوری ثبت نشده</td></tr>}</tbody></table></Card>
      <p className="text-xs text-slate-400 flex items-center gap-1"><LinkIcon className="w-3 h-3" />فاکتورهای صادرشده قابل ویرایش هستند؛ هر تغییر سند حسابداری مرتبط را اصلاح می‌کند.</p>
      {editing && <EditInvoiceModal invoice={editing} onClose={() => setEditId(null)} onSave={(u) => { const r = editInvoice(editing.id, u); showToast(r.success ? 'فاکتور ویرایش و سند اصلاح شد' : (r.error || 'خطا'), r.success ? 'success' : 'error'); if (r.success) setEditId(null); }} />}
    </div>
  );
}

function EditInvoiceModal({ invoice, onClose, onSave }: { invoice: Invoice; onClose: () => void; onSave: (u: { items?: PartItem[]; laborCost?: number; transportationCost?: number; otherCosts?: number; discount?: number; notes?: string }) => void }) {
  const [items, setItems] = useState<PartItem[]>(invoice.items.map(i => ({ ...i })));
  const [laborCost, setLaborCost] = useState(invoice.laborCost);
  const [transportationCost, setTransportationCost] = useState(invoice.transportationCost);
  const [otherCosts, setOtherCosts] = useState(invoice.otherCosts);
  const [discount, setDiscount] = useState(invoice.discount);
  const [notes, setNotes] = useState(invoice.notes ?? '');
  const partsTotal = items.reduce((s, p) => s + p.quantity * p.unitPrice, 0);
  const total = partsTotal + laborCost + transportationCost + otherCosts - discount;
  const setItem = (i: number, patch: Partial<PartItem>) => setItems(list => list.map((x, j) => j === i ? { ...x, ...patch } : x));
  return (
    <Modal open onClose={onClose} title={`ویرایش فاکتور ${invoice.invoiceNumber}`} size="lg">
      <div className="space-y-3">
        <div className="overflow-x-auto"><table className="data-table"><thead><tr><th>شرح</th><th>تعداد</th><th>فی</th><th>جمع</th><th></th></tr></thead><tbody>
          {items.map((p, i) => (<tr key={p.id}><td><input value={p.name} onChange={e => setItem(i, { name: e.target.value })} className="w-full px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[12px]" /></td><td><input type="number" value={p.quantity} onChange={e => setItem(i, { quantity: parseInt(e.target.value) || 0 })} className="w-16 px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[12px]" /></td><td><input type="text" value={p.unitPrice ? p.unitPrice.toLocaleString('en-US') : ''} onChange={e => setItem(i, { unitPrice: parseInt(e.target.value.replace(/,/g, '')) || 0 })} className="w-24 px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[12px]" /></td><td className="text-[12px] font-mono">{formatCurrency(p.quantity * p.unitPrice, false)}</td><td><button onClick={() => setItems(items.filter((_, j) => j !== i))} className="p-1 text-red-500">✕</button></td></tr>))}
        </tbody></table></div>
        <Button size="sm" variant="outline" onClick={() => setItems([...items, { id: `p-${Date.now()}`, name: 'ردیف جدید', quantity: 1, unitPrice: 0 }])}>+ افزودن ردیف</Button>
        <div className="grid grid-cols-2 gap-2">
          <CurrencyInput label="اجرت تعمیر" value={laborCost} onChange={setLaborCost} />
          <CurrencyInput label="ایاب و ذهاب" value={transportationCost} onChange={setTransportationCost} />
          <CurrencyInput label="سایر هزینه‌ها" value={otherCosts} onChange={setOtherCosts} />
          <CurrencyInput label="تخفیف" value={discount} onChange={setDiscount} />
        </div>
        <Textarea label="یادداشت" value={notes} onChange={e => setNotes(e.target.value)} rows={2} />
        <div className="flex justify-between p-3 rounded-xl bg-teal-50 dark:bg-teal-900/20 font-bold"><span>مبلغ نهایی</span><span className="font-mono">{formatCurrency(total)}</span></div>
        <div className="flex justify-end gap-2"><Button variant="secondary" onClick={onClose}>انصراف</Button><Button onClick={() => onSave({ items, laborCost, transportationCost, otherCosts, discount, notes })}>ذخیره و اصلاح سند</Button></div>
      </div>
    </Modal>
  );
}
