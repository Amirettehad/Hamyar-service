import { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, Input, Modal, PageHeader, SearchInput, EmptyState, Textarea } from '../components/ui';
import { JalaliDatePicker } from '../components/JalaliDatePicker';
import { Bell, Plus, Trash2, Check } from 'lucide-react';
import { formatJalali, toPersianDigits } from '../lib/jalali';
import { cn } from '../utils/cn';

export default function Reminders() {
  const { db, addReminder, toggleReminder, deleteReminder, currentUser } = useApp();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [description, setDescription] = useState('');
  const items = useMemo(() => db.reminders.filter(r => r.title.includes(search) || (r.description || '').includes(search)).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()), [db.reminders, search]);
  const save = () => { if (!title || !date) return; addReminder({ title, date, time: time || undefined, description, createdBy: currentUser?.id || 'user-admin' }); setTitle(''); setDate(''); setTime(''); setDescription(''); setOpen(false); };
  return (
    <div className="space-y-4">
      <PageHeader title="یادآورها" subtitle="یادداشت و هشدار تاریخ‌های مهم" action={<Button onClick={() => setOpen(true)}><Plus className="w-4 h-4" />یادآور جدید</Button>} />
      <SearchInput value={search} onChange={setSearch} placeholder="جستجوی یادآور..." />
      <div className="space-y-2">{items.length === 0 && <EmptyState title="یادآوری ثبت نشده" icon={<Bell className="w-8 h-8" />} />}{items.map(r => <Card key={r.id} className={cn('p-4 flex items-start gap-3', r.completed && 'opacity-60')}><button onClick={() => toggleReminder(r.id)} className={cn('w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-0.5', r.completed ? 'bg-teal-500 border-teal-500' : 'border-slate-300 dark:border-slate-600')}>{r.completed && <Check className="w-3.5 h-3.5 text-white" />}</button><div className="flex-1 min-w-0"><p className={cn('font-semibold text-sm', r.completed && 'line-through')}>{r.title}</p><p className="text-xs text-slate-500 mt-0.5">{toPersianDigits(formatJalali(new Date(r.date)))}{r.time ? ` — ${toPersianDigits(r.time)}` : ''}</p>{r.description && <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{r.description}</p>}</div><button onClick={() => deleteReminder(r.id)} className="p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"><Trash2 className="w-4 h-4" /></button></Card>)}</div>
      <Modal open={open} onClose={() => setOpen(false)} title="یادآور جدید" size="sm"><div className="space-y-3"><Input label="عنوان" value={title} onChange={e => setTitle(e.target.value)} /><JalaliDatePicker label="تاریخ" value={date} onChange={iso => setDate(iso)} /><Input label="ساعت (اختیاری)" value={time} onChange={e => setTime(e.target.value)} placeholder="10:00" /><Textarea label="توضیحات" value={description} onChange={e => setDescription(e.target.value)} rows={3} /></div><div className="flex justify-end gap-2 mt-4"><Button variant="secondary" onClick={() => setOpen(false)}>انصراف</Button><Button onClick={save}>ذخیره</Button></div></Modal>
    </div>
  );
}
