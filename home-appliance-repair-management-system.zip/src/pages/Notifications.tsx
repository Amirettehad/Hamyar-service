import { useMemo, useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, Input, Textarea, Select, PageHeader, useToast, Badge, EmptyState } from '../components/ui';
import { Send, Image as ImageIcon, Megaphone, ExternalLink, Link2, Palette, Bell, Eye } from 'lucide-react';
import { toPersianDigits, timeAgo } from '../lib/jalali';
import { cn } from '../utils/cn';

const ICON_EMOJIS = ['📢', '🔔', '⚠️', '✅', '💰', '🛠️', '📅', '🎁', '🚨', 'ℹ️', '📌', '⭐'];
const ACCENTS = [
  { c: '#0d9488', n: 'فیروزه‌ای' }, { c: '#3b82f6', n: 'آبی' }, { c: '#8b5cf6', n: 'بنفش' },
  { c: '#f59e0b', n: 'کهربایی' }, { c: '#ef4444', n: 'قرمز' }, { c: '#ec4899', n: 'صورتی' }, { c: '#10b981', n: 'سبز' },
];

const INTERNAL_LINKS = [
  { value: '', label: 'بدون لینک درونی' },
  { value: '/dashboard', label: 'داشبورد' },
  { value: '/orders', label: 'سفارشات' },
  { value: '/invoices', label: 'فاکتورها' },
  { value: '/accounting', label: 'حسابداری' },
  { value: '/chat', label: 'چت داخلی' },
  { value: '/knowledge', label: 'پایگاه دانش' },
  { value: '/scheduler', label: 'تقویم' },
];

export default function Notifications() {
  const { db, broadcastNotification } = useApp();
  const { showToast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [audience, setAudience] = useState<'all' | 'admin' | 'technician' | 'customer'>('all');
  const [icon, setIcon] = useState('📢');
  const [imageUrl, setImageUrl] = useState('');
  const [internalLink, setInternalLink] = useState('');
  const [externalLink, setExternalLink] = useState('');
  const [accent, setAccent] = useState('#0d9488');

  const audienceCount = audience === 'all' ? db.users.length : db.users.filter(u => u.role === audience).length;
  const oneSignalReady = db.settings.oneSignalEnabled && !!db.settings.oneSignalAppId;
  const canDirectPush = oneSignalReady && !!db.settings.oneSignalRestApiKey;
  const broadcasts = useMemo(() => db.notifications.filter(n => n.type === 'broadcast' && n.audience === 'all').filter((n, i, arr) => arr.findIndex(x => x.title === n.title && x.body === n.body && x.createdAt === n.createdAt) === i).slice(0, 40), [db.notifications]);

  const send = async () => {
    if (!title.trim() || !body.trim()) { showToast('عنوان و متن اعلان الزامی است', 'error'); return; }
    const count = broadcastNotification({ audience, title, body, icon, imageUrl, internalLink: internalLink || undefined, externalLink: externalLink || undefined, accentColor: accent });
    let summary = `اعلان برای ${toPersianDigits(count)} کاربر ثبت شد`;

    if (oneSignalReady && canDirectPush) {
      try {
        const mod = await import('../lib/onesignal');
        const externalIds = (audience === 'all' ? db.users : db.users.filter(u => u.role === audience)).map(u => u.id);
        const link = internalLink || externalLink || '/tech';
        const r = await mod.sendOneSignalPush(db.settings, externalIds, { title, body, url: link });
        summary += r.success ? ` — و به‌علاوه Push واقعی از OneSignal به ${toPersianDigits(externalIds.length)} دستگاه ارسال شد ✓` : ` (هشدار Push: ${r.error?.slice(0, 80)})`;
      } catch {
        summary += ' (هشدار در ارسال Push)';
      }
    } else if (oneSignalReady) {
      summary += ' — اعلان درون‌برنامه ثبت شد؛ برای ارسال Push از داخل پنل ابتدا REST API Key را در تنظیمات ثبت کند یا از داشبورد OneSignal ارسال کنید.';
    }
    showToast(summary, 'success');
    setTitle(''); setBody(''); setImageUrl(''); setExternalLink(''); setInternalLink('');
  };

  const onImage = (f: File) => {
    const r = new FileReader();
    r.onload = () => setImageUrl(r.result as string);
    r.readAsDataURL(f);
  };

  return (
    <div className="space-y-4">
      <PageHeader title="مرکز اعلان‌ها و نوتیفیکیشن" subtitle="ارسال اعلان حرفه‌ای به تکنسین‌ها، مشتریان یا همه کاربران" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Composer */}
        <div className="space-y-4">
          <Card className="p-5 space-y-3">
            <h3 className="font-semibold text-sm flex items-center gap-2"><Megaphone className="w-4 h-4 text-teal-600" />ساخت اعلان جدید</h3>
            <Input label="عنوان اعلان *" value={title} onChange={e => setTitle(e.target.value)} placeholder="مثلاً توقف موقت سرویس" />
            <Textarea label="متن اعلان *" value={body} onChange={e => setBody(e.target.value)} rows={3} placeholder="توضیحات اعلان..." />
            <Select label="مخاطبان" value={audience} onChange={e => setAudience(e.target.value as typeof audience)} options={[{ value: 'all', label: `همه کاربران (${toPersianDigits(db.users.length)} نفر)` }, { value: 'admin', label: `مدیران (${toPersianDigits(db.users.filter(u => u.role === 'admin').length)} نفر)` }, { value: 'technician', label: `تکنسین‌ها (${toPersianDigits(db.users.filter(u => u.role === 'technician').length)} نفر)` }, { value: 'customer', label: `مشتریان (${toPersianDigits(db.users.filter(u => u.role === 'customer').length)} نفر)` }]} />

            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">آیکون اعلان</label>
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                {ICON_EMOJIS.map(em => (
                  <button key={em} onClick={() => setIcon(em)} className={cn('w-9 h-9 rounded-lg text-lg flex items-center justify-center border-2 transition-all', icon === em ? 'border-teal-500 bg-teal-50 dark:bg-teal-900/20' : 'border-transparent bg-slate-100 dark:bg-slate-800')}>{em}</button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1"><Palette className="w-3.5 h-3.5" />رنگ اعلان</label>
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                {ACCENTS.map(a => (
                  <button key={a.c} onClick={() => setAccent(a.c)} title={a.n} className={cn('w-8 h-8 rounded-full border-2 transition-transform', accent === a.c ? 'border-slate-800 dark:border-white scale-110' : 'border-transparent')} style={{ background: a.c }} />
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1"><ImageIcon className="w-3.5 h-3.5" />تصویر پیوست (اختیاری)</label>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) onImage(f); e.target.value = ''; }} />
              <div className="flex items-center gap-2 mt-1.5">
                {imageUrl ? <img src={imageUrl} alt="attach" className="w-14 h-14 rounded-lg object-cover border" /> : <button onClick={() => fileRef.current?.click()} className="w-14 h-14 rounded-lg border-2 border-dashed border-slate-300 dark:border-slate-600 flex items-center justify-center text-slate-400"><ImageIcon className="w-5 h-5" /></button>}
                {imageUrl && <Button size="sm" variant="ghost" onClick={() => setImageUrl('')}>حذف تصویر</Button>}
              </div>
            </div>

            <Select label="لینک درونی (اختیاری)" value={internalLink} onChange={e => setInternalLink(e.target.value)} options={INTERNAL_LINKS} />
            <Input label="لینک خارجی (اختیاری)" value={externalLink} onChange={e => setExternalLink(e.target.value)} placeholder="https://..." dir="ltr" />

            <Button className="w-full" onClick={send}><Send className="w-4 h-4" />ارسال اعلان به {toPersianDigits(audienceCount)} کاربر</Button>
          </Card>
        </div>

        {/* Preview + history */}
        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="font-semibold text-sm mb-3 flex items-center gap-2"><Eye className="w-4 h-4 text-teal-600" />پیش‌نمایش اعلان</h3>
            <RichNotificationCard n={{ title: title || 'عنوان اعلان شما', body: body || 'متن اعلان اینجا نمایش داده می‌شود...', createdAt: new Date().toISOString(), icon, imageUrl, internalLink, externalLink, accentColor: accent, senderName: 'شما' }} />
          </Card>
          <Card className="p-5">
            <h3 className="font-semibold text-sm mb-3 flex items-center gap-2"><Bell className="w-4 h-4 text-teal-600" />تاریخچه اعلان‌ها ({toPersianDigits(broadcasts.length)})</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {broadcasts.length === 0 ? <EmptyState title="اعلانی ارسال نشده" icon={<Megaphone className="w-8 h-8" />} /> : broadcasts.map(n => (
                <RichNotificationCard key={n.id} n={n} compact />
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

export function RichNotificationCard({ n, compact = false }: { n: { title: string; body: string; icon?: string; imageUrl?: string; internalLink?: string; externalLink?: string; accentColor?: string; senderName?: string; createdAt?: string; read?: boolean }; compact?: boolean }) {
  const accent = n.accentColor || '#0d9488';
  return (
    <div className={cn('relative overflow-hidden rounded-2xl border', compact ? 'p-3' : 'p-4')} style={{ borderColor: `${accent}33`, background: `linear-gradient(135deg, ${accent}0f, transparent)` }}>
      <div className="absolute top-0 right-0 w-1.5 h-full" style={{ background: accent }} />
      <div className="flex items-start gap-3 pr-1">
        {n.imageUrl ? (
          <img src={n.imageUrl} alt="" className={cn('rounded-xl object-cover shrink-0', compact ? 'w-12 h-12' : 'w-16 h-16')} />
        ) : (
          <div className={cn('rounded-xl flex items-center justify-center text-xl shrink-0', compact ? 'w-10 h-10' : 'w-12 h-12')} style={{ background: `${accent}22` }}>{n.icon || '📢'}</div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="font-bold text-sm text-slate-900 dark:text-white">{n.title}</p>
            {n.senderName && <Badge color="slate">از {n.senderName}</Badge>}
            {n.createdAt && <span className="text-[10px] text-slate-400 mr-auto">{timeAgo(new Date(n.createdAt))}</span>}
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-5">{n.body}</p>
          {(n.internalLink || n.externalLink) && (
            <div className="flex gap-2 mt-2">
              {n.internalLink && (
                <a
                  href={`#${n.internalLink.startsWith('/') ? n.internalLink : `/${n.internalLink}`}`}
                  onClick={(e) => { e.stopPropagation(); }}
                  className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg text-white"
                  style={{ background: accent }}
                >
                  <Link2 className="w-3 h-3" />
                  مشاهده بخش مربوطه
                </a>
              )}
              {n.externalLink && (
                <a
                  href={n.externalLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={(e) => { e.stopPropagation(); }}
                  className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border"
                  style={{ borderColor: `${accent}55`, color: accent }}
                >
                  <ExternalLink className="w-3 h-3" />
                  لینک خارجی
                </a>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
