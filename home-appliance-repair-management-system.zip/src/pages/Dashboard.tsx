import { useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Card, StatCard, PageHeader, Button } from '../components/ui';
import { ClockWidget, CalculatorWidget, QuickSearchWidget, TodayInfoWidget } from '../components/Widgets';
import { ClipboardList, Users, Wallet, TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Clock, Package, Bell } from 'lucide-react';
import { Link } from 'react-router-dom';
import { XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, Legend, CartesianGrid } from 'recharts';
import { formatCurrency, toPersianDigits, formatJalali } from '../lib/jalali';
import { dailySeries, totalCash, accountBalance, incomeStatement, partyBalance } from '../lib/accounting';
import { STATUS_COLORS } from '../lib/types';
import { cn } from '../utils/cn';

const statusColors: Record<string, string> = { 'ثبت اولیه': '#64748b', 'در انتظار اعزام': '#f59e0b', 'اعزام شده': '#3b82f6', 'در حال تعمیر': '#a855f7', 'نیاز به قطعه': '#f97316', 'تعمیر شده': '#14b8a6', 'آماده تحویل': '#22c55e', 'تحویل شده': '#10b981', 'لغو شده': '#ef4444', 'انجام شده': '#10b981' };

export default function Dashboard() {
  const { db, currentUser } = useApp();
  const isTechnician = currentUser?.role === 'technician';
  const isCustomer = currentUser?.role === 'customer';

  const roleFilteredOrders = useMemo(() => {
    if (isTechnician) return db.orders.filter(o => o.technicianId === currentUser?.technicianId);
    if (isCustomer) return db.orders.filter(o => o.customerId === currentUser?.customerId);
    return db.orders;
  }, [db.orders, currentUser, isTechnician, isCustomer]);

  const totalOrders = roleFilteredOrders.length;
  const pendingOrders = roleFilteredOrders.filter(o => ['ثبت اولیه', 'در انتظار اعزام', 'اعزام شده'].includes(o.status)).length;
  const inProgress = roleFilteredOrders.filter(o => ['در حال تعمیر', 'نیاز به قطعه'].includes(o.status)).length;
  const completed = roleFilteredOrders.filter(o => ['تعمیر شده', 'آماده تحویل', 'تحویل شده', 'انجام شده'].includes(o.status)).length;

  const pnl = useMemo(() => incomeStatement(db), [db]);
  const revenue = pnl.totalRevenue;
  const unpaid = accountBalance(db, db.accounting.arAccount);
  const cashOnHand = useMemo(() => totalCash(db), [db]);
  const customerBalance = currentUser?.customerId ? partyBalance(db, 'customer', currentUser.customerId) : 0;
  const myCommission = currentUser?.technicianId ? Math.abs(Math.min(0, partyBalance(db, 'technician', currentUser.technicianId))) : 0;
  const myTotalCommission = currentUser?.technicianId ? db.technicians.find(t => t.id === currentUser.technicianId)?.totalCommission || 0 : 0;
  const lowStock = db.inventory.filter(i => i.quantity <= i.minQuantity);

  const revenueData = useMemo(() => dailySeries(db, 7).map(d => ({ name: d.label, revenue: d.revenue / 1_000_000, orders: d.orders })), [db]);
  const statusData = useMemo(() => { const counts: Record<string, number> = {}; roleFilteredOrders.forEach(o => { counts[o.status] = (counts[o.status] || 0) + 1; }); return Object.entries(counts).map(([name, value]) => ({ name, value })); }, [roleFilteredOrders]);
  const technicianData = useMemo(() => db.technicians.map(t => { const orders = db.orders.filter(o => o.technicianId === t.id); const done = orders.filter(o => ['تعمیر شده', 'تحویل شده', 'انجام شده'].includes(o.status)).length; return { name: t.fullName.split(' ')[0], orders: orders.length, done }; }), [db.technicians, db.orders]);
  const recentOrders = roleFilteredOrders.slice(0, 6);
  const todayOrders = roleFilteredOrders.filter(o => new Date(o.registrationDate).toDateString() === new Date().toDateString());

  return (
    <div className="space-y-6">
      <PageHeader title={isTechnician ? 'داشبورد تکنسین' : isCustomer ? 'پنل مشتری' : 'داشبورد مدیریت'} subtitle={`خوش آمدید ${currentUser?.fullName} - ${formatJalali(new Date())}`} action={!isCustomer && !isTechnician ? <Link to="/orders/new"><Button><ClipboardList className="w-4 h-4" />سفارش جدید</Button></Link> : null} />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard title="کل سفارشات" value={toPersianDigits(totalOrders)} icon={<ClipboardList className="w-5 h-5" />} color="teal" change={`${toPersianDigits(todayOrders.length)} سفارش امروز`} changeType="positive" />
        <StatCard title={isCustomer ? 'در حال پیگیری' : 'در انتظار'} value={toPersianDigits(pendingOrders + inProgress)} icon={<Clock className="w-5 h-5" />} color="amber" change={isCustomer ? 'در حال پردازش' : `${toPersianDigits(pendingOrders)} در صف اعزام`} />
        <StatCard title="تکمیل شده" value={toPersianDigits(completed)} icon={<CheckCircle className="w-5 h-5" />} color="green" change={`${totalOrders > 0 ? toPersianDigits(Math.round(completed / totalOrders * 100)) : 0}٪ از کل`} changeType="positive" />
        {isTechnician ? <StatCard title="پورسانت پرداخت‌نشده" value={formatCurrency(myCommission).replace(' تومان', '')} icon={<Wallet className="w-5 h-5" />} color="purple" change={`کل: ${formatCurrency(myTotalCommission).replace(' تومان', '')}`} changeType="positive" /> : isCustomer ? <StatCard title={customerBalance > 0 ? 'مانده بدهی شما' : 'وضعیت حساب'} value={formatCurrency(Math.abs(customerBalance))} icon={<Wallet className="w-5 h-5" />} color={customerBalance > 0 ? 'amber' : 'green'} change={customerBalance > 0 ? 'بدهکار' : customerBalance < 0 ? 'بستانکار' : 'تسویه'} /> : <StatCard title="درآمد ثبت‌شده" value={formatCurrency(revenue).replace(' تومان', '')} icon={<Wallet className="w-5 h-5" />} color="blue" change={`مطالبات: ${formatCurrency(unpaid).replace(' تومان', '')} • نقد: ${formatCurrency(cashOnHand).replace(' تومان', '')}`} changeType={unpaid > 0 ? 'negative' : 'positive'} />}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          {!isCustomer && !isTechnician && (
            <Card className="p-5">
              <h3 className="font-semibold text-sm mb-4 text-slate-900 dark:text-white flex items-center gap-2"><TrendingUp className="w-4 h-4 text-teal-600" />درآمد واقعی ۷ روز اخیر (میلیون تومان — از اسناد حسابداری)</h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fontFamily: 'Vazirmatn' }} stroke="#94a3b8" />
                  <YAxis tick={{ fontSize: 11, fontFamily: 'Vazirmatn' }} stroke="#94a3b8" />
                  <Tooltip contentStyle={{ fontFamily: 'Vazirmatn', fontSize: '12px', borderRadius: '8px', border: 'none', direction: 'rtl' }} formatter={(value: unknown) => [`${(value as number).toFixed(1)} م.ت`, 'درآمد']} />
                  <Bar dataKey="revenue" fill="#0d9488" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          )}
          <Card className="p-5">
            <div className="flex items-center justify-between mb-4"><h3 className="font-semibold text-sm text-slate-900 dark:text-white flex items-center gap-2"><ClipboardList className="w-4 h-4 text-teal-600" />سفارشات اخیر</h3><Link to="/orders" className="text-xs text-teal-600 hover:underline">مشاهده همه</Link></div>
            <div className="space-y-2">
              {recentOrders.length === 0 ? <p className="text-center text-slate-500 dark:text-slate-400 py-4 text-sm">سفارشی ثبت نشده</p> : recentOrders.map(o => {
                const customer = db.customers.find(c => c.id === o.customerId);
                const tech = db.technicians.find(t => t.id === o.technicianId);
                return (
                  <Link to={`/orders/${o.id}`} key={o.id}>
                    <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors border border-slate-100 dark:border-slate-700/50 hover-lift">
                      <div className="flex items-center gap-3 min-w-0"><div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">{o.requestNumber.split('-').pop()?.slice(-3)}</div><div className="min-w-0"><p className="font-semibold text-sm text-slate-900 dark:text-white truncate">{customer?.fullName || 'نامشخص'}</p><p className="text-xs text-slate-500 dark:text-slate-400 truncate">{o.serviceType} - {tech?.fullName || 'بدون تکنسین'}</p></div></div>
                      <span className={cn('status-badge text-[10px]', STATUS_COLORS[o.status])}>{o.status}</span>
                    </div>
                  </Link>
                );
              })}
            </div>
          </Card>
        </div>
        <div className="space-y-4">
          <ClockWidget />
          <QuickSearchWidget />
          <CalculatorWidget />
          <TodayInfoWidget />
          {!isCustomer && (
            <Card className="p-4"><h3 className="font-semibold text-sm mb-3 flex items-center gap-2 text-slate-900 dark:text-white"><Bell className="w-4 h-4 text-amber-500" />هشدارها</h3><div className="space-y-2">{lowStock.length > 0 && <div className="flex items-start gap-2 p-2 rounded-lg bg-amber-50 dark:bg-amber-900/20"><AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" /><div><p className="text-xs font-semibold text-amber-900 dark:text-amber-200">موجودی کم</p><p className="text-[11px] text-amber-700 dark:text-amber-400">{toPersianDigits(lowStock.length)} قطعه نیاز به سفارش دارد</p></div></div>}{pendingOrders > 0 && <div className="flex items-start gap-2 p-2 rounded-lg bg-blue-50 dark:bg-blue-900/20"><Clock className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" /><div><p className="text-xs font-semibold text-blue-900 dark:text-blue-200">در انتظار اعزام</p><p className="text-[11px] text-blue-700 dark:text-blue-400">{toPersianDigits(pendingOrders)} سفارش در صف</p></div></div>}{pendingOrders === 0 && lowStock.length === 0 && <p className="text-xs text-slate-500 dark:text-slate-400 text-center py-2">همه چیز مرتب است ✓</p>}</div></Card>
          )}
          {!isCustomer && !isTechnician && (
            <Card className="p-4"><h3 className="font-semibold text-sm mb-3 flex items-center gap-2 text-slate-900 dark:text-white"><Package className="w-4 h-4 text-purple-500" />توزیع وضعیت</h3><ResponsiveContainer width="100%" height={180}><PieChart><Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={60} innerRadius={35} paddingAngle={2}>{statusData.map((_, i) => <Cell key={i} fill={Object.values(statusColors)[i % Object.values(statusColors).length]} />)}</Pie><Tooltip contentStyle={{ fontFamily: 'Vazirmatn', fontSize: '12px', direction: 'rtl', borderRadius: '8px' }} /></PieChart></ResponsiveContainer></Card>
          )}
          {isCustomer && <Card className="p-4 space-y-2"><h3 className="font-semibold text-sm mb-3 text-slate-900 dark:text-white">پیگیری و رزرو</h3><p className="text-xs text-slate-500 dark:text-slate-400 mb-3">وضعیت دستگاه را ببینید یا نوبت جدید رزرو کنید.</p><Link to="/orders"><Button className="w-full" variant="outline">مشاهده سفارشات من</Button></Link><Link to="/agent"><Button className="w-full">دستیار هوشمند / رزرو نوبت</Button></Link></Card>}
        </div>
      </div>
      {!isCustomer && !isTechnician && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card className="p-5"><h3 className="font-semibold text-sm mb-4 text-slate-900 dark:text-white flex items-center gap-2"><Users className="w-4 h-4 text-blue-600" />عملکرد تکنسین‌ها</h3><ResponsiveContainer width="100%" height={220}><BarChart data={technicianData} layout="vertical"><CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} /><XAxis type="number" tick={{ fontSize: 11, fontFamily: 'Vazirmatn' }} stroke="#94a3b8" /><YAxis dataKey="name" type="category" tick={{ fontSize: 11, fontFamily: 'Vazirmatn' }} stroke="#94a3b8" width={70} /><Tooltip contentStyle={{ fontFamily: 'Vazirmatn', fontSize: '12px', direction: 'rtl', borderRadius: '8px' }} /><Legend wrapperStyle={{ fontFamily: 'Vazirmatn', fontSize: '11px' }} /><Bar dataKey="orders" name="کل" fill="#3b82f6" radius={[0, 4, 4, 0]} /><Bar dataKey="done" name="انجام شده" fill="#10b981" radius={[0, 4, 4, 0]} /></BarChart></ResponsiveContainer></Card>
          <Card className="p-5"><h3 className="font-semibold text-sm mb-4 text-slate-900 dark:text-white flex items-center gap-2"><TrendingDown className="w-4 h-4 text-rose-500" />قطعات با موجودی کم</h3><div className="space-y-2 max-h-56 overflow-y-auto">{lowStock.length === 0 ? <p className="text-sm text-slate-500 dark:text-slate-400 text-center py-8">همه قطعات موجود هستند</p> : lowStock.map(item => <div key={item.id} className="flex items-center justify-between p-2 rounded-lg bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30"><div><p className="text-xs font-semibold text-slate-900 dark:text-white">{item.name}</p><p className="text-[10px] text-slate-500 dark:text-slate-400">{item.category}</p></div><div className="text-left"><p className="text-lg font-bold text-red-600 dark:text-red-400">{toPersianDigits(item.quantity)}</p><p className="text-[10px] text-slate-500 dark:text-slate-400">حداقل: {toPersianDigits(item.minQuantity)}</p></div></div>)}</div></Card>
        </div>
      )}
    </div>
  );
}
