import { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, Input, Modal, PageHeader, SearchInput, EmptyState, Badge } from '../components/ui';
import { User, MapPin, Wallet, Plus, Trash2, Edit, Eye, Package } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatCurrency, toPersianDigits, formatJalali } from '../lib/jalali';
import { partyBalance } from '../lib/accounting';
import { cn } from '../utils/cn';

export default function Customers() {
  const { db, addCustomer, updateCustomer, deleteCustomer } = useApp();
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);
  const [viewId, setViewId] = useState<string | null>(null);
  const [form, setForm] = useState({ fullName: '', phone: '', phone2: '', address: '', notes: '' });

  const filtered = useMemo(() => db.customers.filter(c => c.fullName.includes(search) || c.phone.includes(search) || (c.address || '').includes(search)), [db.customers, search]);
  const openNew = () => { setEditing(null); setForm({ fullName: '', phone: '', phone2: '', address: '', notes: '' }); setModalOpen(true); };
  const openEdit = (id: string) => { const c = db.customers.find(x => x.id === id); if (!c) return; setEditing(id); setForm({ fullName: c.fullName, phone: c.phone, phone2: c.phone2 || '', address: c.address || '', notes: c.notes || '' }); setModalOpen(true); };
  const save = () => { if (!form.fullName || !form.phone) return; if (editing) updateCustomer(editing, form); else addCustomer(form); setModalOpen(false); };

  const viewCustomer = db.customers.find(c => c.id === viewId);
  const customerOrders = viewId ? db.orders.filter(o => o.customerId === viewId) : [];
  const customerDevices = viewId ? db.devices.filter(d => d.customerId === viewId) : [];

  return (
    <div className="space-y-4">
      <PageHeader title="مشتریان" subtitle={`${toPersianDigits(db.customers.length)} مشتری ثبت شده`} action={<Button onClick={openNew}><Plus className="w-4 h-4" />مشتری جدید</Button>} />
      <SearchInput value={search} onChange={setSearch} placeholder="جستجو بر اساس نام، شماره یا آدرس..." />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.length === 0 && <div className="col-span-full"><EmptyState title="مشتری یافت نشد" icon={<User className="w-8 h-8" />} /></div>}
        {filtered.map(c => {
          const orderCount = db.orders.filter(o => o.customerId === c.id).length;
          const billed = db.invoices.filter(i => i.customerId === c.id).reduce((s, i) => s + i.totalAmount, 0);
          const balance = partyBalance(db, 'customer', c.id);
          return (
            <Card key={c.id} className="p-4 hover-lift">
              <div className="flex items-start justify-between mb-3"><div className="flex items-center gap-3"><div className="w-11 h-11 rounded-full bg-gradient-to-br from-teal-400 to-emerald-500 flex items-center justify-center text-white font-bold flex-shrink-0">{c.fullName.split(' ').map(n => n[0]).slice(0, 2).join('')}</div><div><p className="font-bold text-sm text-slate-900 dark:text-white">{c.fullName}</p><p className="text-xs font-mono text-slate-500 ltr inline-block">{toPersianDigits(c.phone)}</p></div></div></div>
              {c.address && <p className="text-xs text-slate-500 dark:text-slate-400 flex items-start gap-1 mb-2 line-clamp-2"><MapPin className="w-3 h-3 flex-shrink-0 mt-0.5" />{c.address}</p>}
              <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-100 dark:border-slate-700"><div className="text-center"><p className="text-[10px] text-slate-500">سفارشات</p><p className="font-bold text-sm text-slate-900 dark:text-white">{toPersianDigits(orderCount)}</p></div><div className="text-center"><p className="text-[10px] text-slate-500">جمع فاکتور</p><p className="font-bold text-xs text-emerald-600">{formatCurrency(billed, false)}</p></div><div className="text-center"><p className="text-[10px] text-slate-500">مانده</p><p className={cn('font-bold text-xs', balance > 0 ? 'text-red-600' : balance < 0 ? 'text-purple-600' : 'text-slate-500')}>{formatCurrency(Math.abs(balance), false)} {balance > 0 ? 'بد' : balance < 0 ? 'بس' : ''}</p></div></div>
              <div className="flex gap-1 mt-3"><Button size="sm" variant="ghost" onClick={() => setViewId(c.id)}><Eye className="w-3.5 h-3.5" /></Button><Button size="sm" variant="ghost" onClick={() => openEdit(c.id)}><Edit className="w-3.5 h-3.5" /></Button><Button size="sm" variant="ghost" onClick={() => { if (confirm('حذف مشتری؟')) deleteCustomer(c.id); }}><Trash2 className="w-3.5 h-3.5 text-red-500" /></Button></div>
            </Card>
          );
        })}
      </div>
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'ویرایش مشتری' : 'مشتری جدید'} size="md"><div className="grid grid-cols-1 sm:grid-cols-2 gap-3"><Input label="نام و نام خانوادگی *" value={form.fullName} onChange={e => setForm({ ...form, fullName: e.target.value })} /><Input label="شماره تماس *" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /><Input label="شماره تماس دوم" value={form.phone2} onChange={e => setForm({ ...form, phone2: e.target.value })} /><div className="sm:col-span-2"><Input label="آدرس" value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} /></div></div><div className="flex gap-2 mt-4 justify-end"><Button variant="secondary" onClick={() => setModalOpen(false)}>انصراف</Button><Button onClick={save}>ذخیره</Button></div></Modal>
      <Modal open={!!viewId} onClose={() => setViewId(null)} title={viewCustomer?.fullName || ''} size="lg">
        {viewCustomer && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm"><div><p className="text-xs text-slate-500">تلفن اصلی</p><p className="font-mono ltr inline-block">{toPersianDigits(viewCustomer.phone)}</p></div>{viewCustomer.phone2 && <div><p className="text-xs text-slate-500">تلفن دوم</p><p className="font-mono ltr inline-block">{toPersianDigits(viewCustomer.phone2)}</p></div>}<div><p className="text-xs text-slate-500">تاریخ ثبت</p><p>{toPersianDigits(formatJalali(new Date(viewCustomer.createdAt)))}</p></div><div><p className="text-xs text-slate-500">مجموع خرید</p><p className="text-emerald-600 font-bold">{formatCurrency(viewCustomer.totalSpent)}</p></div>{viewCustomer.address && <div className="col-span-full"><p className="text-xs text-slate-500">آدرس</p><p>{viewCustomer.address}</p></div>}</div>
            <div><h4 className="font-semibold text-sm mb-2 flex items-center gap-1"><Package className="w-4 h-4" />دستگاه‌ها ({toPersianDigits(customerDevices.length)})</h4><div className="space-y-1">{customerDevices.length === 0 ? <p className="text-xs text-slate-500">بدون دستگاه ثبت شده</p> : customerDevices.map(d => <div key={d.id} className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800 flex justify-between text-xs"><span>{d.type} {d.brand} {d.model}</span><Badge color={d.warrantyStatus === 'داخل گارانتی' ? 'green' : 'slate'}>{d.warrantyStatus}</Badge></div>)}</div></div>
            <div><h4 className="font-semibold text-sm mb-2 flex items-center gap-1"><Wallet className="w-4 h-4" />سابقه سفارشات ({toPersianDigits(customerOrders.length)})</h4><div className="space-y-1 max-h-64 overflow-y-auto">{customerOrders.length === 0 ? <p className="text-xs text-slate-500">سفارشی ثبت نشده</p> : customerOrders.map(o => <Link to={`/orders/${o.id}`} key={o.id}><div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 flex justify-between items-center text-xs"><span className="font-mono text-teal-600">{o.requestNumber}</span><span>{o.status}</span><span className="font-mono">{o.finalAmount > 0 ? formatCurrency(o.finalAmount) : '—'}</span></div></Link>)}</div></div>
          </div>
        )}
      </Modal>
    </div>
  );
}
