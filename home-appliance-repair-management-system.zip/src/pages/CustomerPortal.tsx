import { useMemo, useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, Input, Textarea, Badge, EmptyState, useToast, Modal } from '../components/ui';
import { SignaturePad, type SignaturePadHandle } from '../components/SignaturePad';
import {
  Phone, ClipboardList, FileText, CheckCircle2, Upload,
  ShieldCheck, Check, CreditCard, Search, ChevronLeft, Eye, PenLine, Send,
} from 'lucide-react';
import { formatCurrency, formatJalali, formatJalaliLong, toPersianDigits, toEnglishDigits } from '../lib/jalali';
import { STATUS_COLORS, type Invoice } from '../lib/types';
import { cn } from '../utils/cn';
import { Link, useSearchParams } from 'react-router-dom';

const LAST_PHONE_KEY = 'customer_portal_phone';

export default function CustomerPortal() {
  const { db, confirmInvoiceSignature, submitCustomerReceipt } = useApp();
  const { showToast } = useToast();
  const [searchParams] = useSearchParams();

  const [phoneInput, setPhoneInput] = useState(() => {
    const fromParam = searchParams.get('phone') || '';
    if (fromParam) return fromParam;
    try { return localStorage.getItem(LAST_PHONE_KEY) || ''; } catch { return ''; }
  });
  const [activeCustomer, setActiveCustomer] = useState<typeof db.customers[0] | null>(null);
  const [activeTab, setActiveTab] = useState<'invoices' | 'orders' | 'receipts'>('invoices');

  // Signature modal state
  const [signingInvoice, setSigningInvoice] = useState<Invoice | null>(null);
  const [signerName, setSignerName] = useState('');
  const sigPadRef = useRef<SignaturePadHandle>(null);

  // Upload receipt modal state
  const [receiptInvoice, setReceiptInvoice] = useState<Invoice | null>(null);
  const [receiptAmount, setReceiptAmount] = useState<number>(0);
  const [receiptTrackingCode, setReceiptTrackingCode] = useState('');
  const [receiptNote, setReceiptNote] = useState('');
  const [receiptImage, setReceiptImage] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // View invoice detail modal
  const [viewingInvoice, setViewingInvoice] = useState<Invoice | null>(null);

  // Clean phone input for searching
  const cleanPhone = (p: string) => {
    const raw = toEnglishDigits(p).replace(/\D/g, '');
    if (raw.startsWith('98')) return '0' + raw.slice(2);
    if (!raw.startsWith('0') && raw.length === 10) return '0' + raw;
    return raw;
  };

  const handleLookup = (phoneToSearch?: string) => {
    const target = cleanPhone(phoneToSearch || phoneInput);
    if (!target || target.length < 10) {
      showToast('لطفاً شماره موبایل ۱۱ رقمی را به صورت کامل وارد کنید (مثال: ۰۹۱۲۳۴۵۶۷۸۹)', 'error');
      return;
    }

    const found = db.customers.find(c => {
      const c1 = cleanPhone(c.phone);
      const c2 = c.phone2 ? cleanPhone(c.phone2) : '';
      return c1.includes(target) || target.includes(c1) || (c2 && (c2.includes(target) || target.includes(c2)));
    });

    if (found) {
      setActiveCustomer(found);
      try { localStorage.setItem(LAST_PHONE_KEY, target); } catch { /* ignore */ }
      showToast(`خوش آمدید ${found.fullName}`);
    } else {
      setActiveCustomer(null);
      showToast('پرونده‌ای با این شماره موبایل در سیستم یافت نشد. لطفاً شماره را بررسی یا با پشتیبانی تماس بگیرید.', 'error');
    }
  };

  // Auto lookup if phone in URL
  useEffect(() => {
    const fromParam = searchParams.get('phone');
    if (fromParam) {
      handleLookup(fromParam);
    } else {
      const saved = localStorage.getItem(LAST_PHONE_KEY);
      if (saved) handleLookup(saved);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Customer's orders & invoices
  const customerOrders = useMemo(() => {
    if (!activeCustomer) return [];
    return db.orders
      .filter(o => o.customerId === activeCustomer.id)
      .sort((a, b) => new Date(b.registrationDate).getTime() - new Date(a.registrationDate).getTime());
  }, [db.orders, activeCustomer]);

  const customerInvoices = useMemo(() => {
    if (!activeCustomer) return [];
    return db.invoices
      .filter(i => i.customerId === activeCustomer.id)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [db.invoices, activeCustomer]);

  const customerSubmissions = useMemo(() => {
    if (!activeCustomer) return [];
    return (db.customerReceipts || [])
      .filter(s => s.customerId === activeCustomer.id || s.customerPhone === activeCustomer.phone)
      .sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
  }, [db.customerReceipts, activeCustomer]);

  const totalOutstanding = useMemo(() => {
    return customerInvoices.reduce((sum, inv) => sum + Math.max(0, inv.totalAmount - inv.paidAmount), 0);
  }, [customerInvoices]);

  // Open signature modal
  const startSignature = (inv: Invoice) => {
    setSigningInvoice(inv);
    setSignerName(activeCustomer?.fullName || '');
  };

  const handleSaveSignature = () => {
    if (!signingInvoice) return;
    if (!sigPadRef.current || sigPadRef.current.isEmpty()) {
      showToast('لطفاً در کادر مشخص شده امضا نمایید', 'error');
      return;
    }
    const signatureDataUrl = sigPadRef.current.toDataURL();
    const res = confirmInvoiceSignature(signingInvoice.id, signatureDataUrl, signerName);
    if (res.success) {
      showToast('فاکتور با امضای دیجیتال شما با موفقیت تأیید شد ✓');
      setSigningInvoice(null);
    } else {
      showToast(res.error || 'خطا در ثبت امضا', 'error');
    }
  };

  // Open upload receipt modal
  const startUploadReceipt = (inv: Invoice) => {
    setReceiptInvoice(inv);
    setReceiptAmount(Math.max(0, inv.totalAmount - inv.paidAmount));
    setReceiptTrackingCode('');
    setReceiptNote('');
    setReceiptImage('');
  };

  const handleImagePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 8 * 1024 * 1024) {
      showToast('حجم فایل نباید بیشتر از ۸ مگابایت باشد', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setReceiptImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmitReceipt = () => {
    if (!receiptInvoice || !activeCustomer) return;
    if (receiptAmount <= 0) {
      showToast('مبلغ رسید باید بزرگتر از صفر باشد', 'error');
      return;
    }
    if (!receiptImage && !receiptNote && !receiptTrackingCode) {
      showToast('حداقل یکی از موارد: تصویر فیش واریز، کد پیگیری یا متن رسید را وارد نمایید', 'error');
      return;
    }

    const res = submitCustomerReceipt({
      customerId: activeCustomer.id,
      customerName: activeCustomer.fullName,
      customerPhone: activeCustomer.phone,
      invoiceId: receiptInvoice.id,
      invoiceNumber: receiptInvoice.invoiceNumber,
      amount: receiptAmount,
      note: receiptNote || undefined,
      imageUrl: receiptImage || undefined,
      trackingCode: receiptTrackingCode || undefined,
    });

    if (res.success) {
      showToast('رسید پرداخت شما با موفقیت ثبت شد و پس از بررسی و تأیید مدیر در حسابتان منظور می‌گردد ✓');
      setReceiptInvoice(null);
    } else {
      showToast(res.error || 'خطا در ثبت رسید', 'error');
    }
  };

  const handleLogoutCustomer = () => {
    setActiveCustomer(null);
    setPhoneInput('');
    try { localStorage.removeItem(LAST_PHONE_KEY); } catch { /* ignore */ }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-['Vazirmatn'] text-slate-800 dark:text-slate-100" dir="rtl">
      {/* Top App Bar */}
      <header className="sticky top-0 z-30 app-bar border-b border-slate-200/70 dark:border-slate-800/70 safe-top">
        <div className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white flex items-center justify-center font-bold text-base shadow-sm">
              اتحاد
            </div>
            <div>
              <h1 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                پورتال خدمات مشتریان
              </h1>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                {db.settings.shopName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Link to="/track" className="text-xs text-teal-600 dark:text-teal-400 font-medium hover:underline flex items-center gap-1">
              <Search className="w-3.5 h-3.5" />
              پیگیری سفارش
            </Link>
            {activeCustomer && (
              <button
                onClick={handleLogoutCustomer}
                className="text-xs text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 px-2.5 py-1.5 rounded-lg font-medium transition-colors"
              >
                تغییر شماره
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4 space-y-4">
        {/* Step 1: Phone Lookup (if not logged in) */}
        {!activeCustomer ? (
          <div className="max-w-md mx-auto pt-8 pb-12 animate-fade-in space-y-5">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 rounded-3xl bg-teal-50 dark:bg-teal-900/30 text-teal-600 dark:text-teal-400 flex items-center justify-center mx-auto shadow-sm">
                <Phone className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
                مشاهده سفارشات و فاکتورها
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-6 max-w-sm mx-auto">
                بدون نیاز به رمز عبور! فقط با وارد کردن شماره موبایلی که در هنگام ثبت سفارش یا پذیرش به تعمیرگاه داده‌اید، به فاکتورها و سوابق دستگاه‌های خود دسترسی پیدا کنید.
              </p>
            </div>

            <Card className="p-5 space-y-3.5 shadow-md">
              <Input
                label="شماره موبایل شما"
                placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                value={phoneInput}
                onChange={e => setPhoneInput(e.target.value)}
                icon={<Phone className="w-4 h-4" />}
                type="tel"
                dir="ltr"
                onKeyDown={e => e.key === 'Enter' && handleLookup()}
                className="text-base tracking-wider text-center font-mono"
              />
              <Button onClick={() => handleLookup()} className="w-full text-base py-3" size="lg">
                <Search className="w-5 h-5" />
                مشاهده فاکتورها و سفارشات من
              </Button>

              <div className="pt-2 text-center">
                <p className="text-[11px] text-slate-400">
                  اگر قبلاً سفارشی در سامانه داشته باشید، لیست فاکتورها و قابلیت تأیید و آپلود فیش برای شما نمایش داده می‌شود.
                </p>
              </div>
            </Card>

            <div className="flex items-center justify-center gap-2 text-xs text-slate-500">
              <ShieldCheck className="w-4 h-4 text-teal-600" />
              <span>پشتیبانی: {toPersianDigits(db.settings.phone)}</span>
            </div>
          </div>
        ) : (
          /* Step 2: Customer Dashboard */
          <div className="space-y-4 animate-fade-in">
            {/* Customer Header Card */}
            <Card className="p-4 sm:p-5 bg-gradient-to-br from-teal-600 to-emerald-700 text-white border-none shadow-lg">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center text-white font-black text-lg shrink-0">
                    {activeCustomer.fullName.charAt(0)}
                  </div>
                  <div>
                    <h2 className="text-lg font-bold">{activeCustomer.fullName}</h2>
                    <p className="text-xs text-teal-100 flex items-center gap-1.5 mt-0.5">
                      <Phone className="w-3.5 h-3.5" />
                      <span className="font-mono">{toPersianDigits(activeCustomer.phone)}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <div className="bg-white/15 backdrop-blur px-3 py-1.5 rounded-xl text-center">
                    <p className="text-[10px] text-teal-100">مانده بدهی قابل پرداخت</p>
                    <p className="text-base font-extrabold font-mono">
                      {formatCurrency(totalOutstanding)}
                    </p>
                  </div>
                </div>
              </div>

              {activeCustomer.address && (
                <p className="text-xs text-teal-100/90 mt-3 pt-2.5 border-t border-white/15 line-clamp-1">
                  نشانی: {activeCustomer.address}
                </p>
              )}
            </Card>

            {/* Navigation Tabs */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-200/70 dark:bg-slate-800 rounded-2xl">
              <button
                onClick={() => setActiveTab('invoices')}
                className={cn(
                  'flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all',
                  activeTab === 'invoices'
                    ? 'bg-white dark:bg-slate-900 text-teal-700 dark:text-teal-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                )}
              >
                <FileText className="w-4 h-4" />
                <span>فاکتورها ({toPersianDigits(customerInvoices.length)})</span>
              </button>

              <button
                onClick={() => setActiveTab('orders')}
                className={cn(
                  'flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all',
                  activeTab === 'orders'
                    ? 'bg-white dark:bg-slate-900 text-teal-700 dark:text-teal-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                )}
              >
                <ClipboardList className="w-4 h-4" />
                <span>سفارشات تعمیر ({toPersianDigits(customerOrders.length)})</span>
              </button>

              <button
                onClick={() => setActiveTab('receipts')}
                className={cn(
                  'flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all',
                  activeTab === 'receipts'
                    ? 'bg-white dark:bg-slate-900 text-teal-700 dark:text-teal-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                )}
              >
                <CreditCard className="w-4 h-4" />
                <span>رسیدهای ارسالی ({toPersianDigits(customerSubmissions.length)})</span>
              </button>
            </div>

            {/* Tab 1: Invoices */}
            {activeTab === 'invoices' && (
              <div className="space-y-3">
                {customerInvoices.length === 0 ? (
                  <Card className="p-8">
                    <EmptyState
                      icon={<FileText className="w-10 h-10" />}
                      title="فاکتوری برای شما صادر نشده است"
                      description="پس از اتمام خدمات و صدور فاکتور توسط تعمیرگاه، فاکتورها در این بخش قابل مشاهده، تأیید و تسویه خواهند بود."
                    />
                  </Card>
                ) : (
                  customerInvoices.map(inv => {
                    const remaining = Math.max(0, inv.totalAmount - inv.paidAmount);
                    const isFullyPaid = remaining === 0;
                    const hasSignature = !!inv.customerSignature;

                    return (
                      <Card key={inv.id} className="p-4 sm:p-5 space-y-3.5 hover-lift">
                        <div className="flex items-start justify-between gap-2 flex-wrap">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-extrabold text-base text-teal-700 dark:text-teal-400">
                                {inv.invoiceNumber}
                              </span>
                              <Badge color={isFullyPaid ? 'green' : inv.paidAmount > 0 ? 'amber' : 'red'}>
                                {inv.paymentStatus}
                              </Badge>
                              {hasSignature && (
                                <Badge color="green" className="bg-emerald-50 text-emerald-700 border border-emerald-200">
                                  <Check className="w-3 h-3 ml-0.5" />
                                  تأیید و امضا شده
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-slate-500 mt-1">
                              تاریخ صدور: {toPersianDigits(formatJalaliLong(new Date(inv.date)))}
                            </p>
                          </div>

                          <div className="text-left">
                            <p className="text-xs text-slate-500">مبلغ کل فاکتور</p>
                            <p className="text-base font-extrabold font-mono text-slate-900 dark:text-white">
                              {formatCurrency(inv.totalAmount)}
                            </p>
                            {!isFullyPaid && (
                              <p className="text-xs font-bold text-rose-600 font-mono mt-0.5">
                                مانده: {formatCurrency(remaining)}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Items preview */}
                        {inv.items && inv.items.length > 0 && (
                          <div className="bg-slate-50 dark:bg-slate-900/60 rounded-xl p-3 text-xs space-y-1.5 border border-slate-100 dark:border-slate-800">
                            <p className="font-semibold text-slate-600 dark:text-slate-300 mb-1">ریز اقلام و خدمات:</p>
                            {inv.items.map((item, idx) => (
                              <div key={idx} className="flex items-center justify-between py-0.5">
                                <span className="text-slate-700 dark:text-slate-200">
                                  {item.name} ({toPersianDigits(item.quantity)} عدد)
                                </span>
                                <span className="font-mono text-slate-500">
                                  {formatCurrency(item.quantity * item.unitPrice)}
                                </span>
                              </div>
                            ))}
                            {inv.laborCost > 0 && (
                              <div className="flex items-center justify-between py-0.5 text-slate-600">
                                <span>اجرت خدمات</span>
                                <span className="font-mono">{formatCurrency(inv.laborCost)}</span>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Signature preview if signed */}
                        {hasSignature && (
                          <div className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-50/70 dark:bg-emerald-900/15 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300">
                            <div className="flex items-center gap-2">
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                              <span>
                                این فاکتور توسط <b>{inv.confirmerName || activeCustomer.fullName}</b> با امضای دیجیتال تأیید شده است.
                              </span>
                            </div>
                            <img src={inv.customerSignature} alt="امضا" className="h-8 max-w-[80px] object-contain bg-white rounded border border-emerald-300" />
                          </div>
                        )}

                        {/* Action buttons */}
                        <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 flex-wrap">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setViewingInvoice(inv)}
                          >
                            <Eye className="w-4 h-4" />
                            مشاهده جزئیات
                          </Button>

                          {!hasSignature && (
                            <Button
                              size="sm"
                              className="bg-teal-600 text-white"
                              onClick={() => startSignature(inv)}
                            >
                              <PenLine className="w-4 h-4" />
                              امضای دیجیتال و تأیید فاکتور
                            </Button>
                          )}

                          {!isFullyPaid && (
                            <Button
                              size="sm"
                              className="bg-emerald-600 hover:bg-emerald-700 text-white mr-auto"
                              onClick={() => startUploadReceipt(inv)}
                            >
                              <Upload className="w-4 h-4" />
                              ارسال فیش / رسید پرداخت
                            </Button>
                          )}
                        </div>
                      </Card>
                    );
                  })
                )}
              </div>
            )}

            {/* Tab 2: Orders */}
            {activeTab === 'orders' && (
              <div className="space-y-3">
                {customerOrders.length === 0 ? (
                  <Card className="p-8">
                    <EmptyState
                      icon={<ClipboardList className="w-10 h-10" />}
                      title="سفارشی ثبت نشده است"
                      description="سفارشات تعمیر و خدمات شما در این بخش نمایش داده می‌شوند."
                    />
                  </Card>
                ) : (
                  customerOrders.map(ord => {
                    const dev = db.devices.find(d => d.id === ord.deviceId);
                    const tech = db.technicians.find(t => t.id === ord.technicianId);

                    return (
                      <Card key={ord.id} className="p-4 sm:p-5 space-y-3 hover-lift">
                        <div className="flex items-start justify-between gap-2 flex-wrap">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-base text-teal-700">
                                {ord.requestNumber}
                              </span>
                              <Badge color="slate" className={STATUS_COLORS[ord.status] || ''}>
                                {ord.status}
                              </Badge>
                            </div>
                            <p className="text-xs text-slate-500 mt-1">
                              نوع سرویس: <b>{ord.serviceType}</b> • تاریخ ثبت: {toPersianDigits(formatJalali(new Date(ord.registrationDate)))}
                            </p>
                          </div>

                          <div className="text-left">
                            <span className="text-xs text-slate-400 font-mono">
                              مبلغ: {ord.finalAmount > 0 ? formatCurrency(ord.finalAmount) : 'در حال بررسی'}
                            </span>
                          </div>
                        </div>

                        {/* Device Info */}
                        {dev && (
                          <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-800 text-xs flex items-center justify-between">
                            <span>دستگاه: <b>{dev.type} {dev.brand} {dev.model || ''}</b></span>
                            <Badge color={dev.warrantyStatus === 'داخل گارانتی' ? 'green' : 'slate'}>
                              {dev.warrantyStatus}
                            </Badge>
                          </div>
                        )}

                        {ord.problemDescription && (
                          <div className="text-xs text-slate-600 dark:text-slate-300 bg-amber-50/50 dark:bg-amber-900/10 p-2.5 rounded-xl border border-amber-200/60">
                            <b>شرح خرابی اعلامی:</b> {ord.problemDescription}
                          </div>
                        )}

                        {ord.technicianReport && (
                          <div className="text-xs text-slate-700 dark:text-slate-200 bg-teal-50/50 dark:bg-teal-900/10 p-2.5 rounded-xl border border-teal-200/60">
                            <b>گزارش سرویسکار:</b> {ord.technicianReport}
                          </div>
                        )}

                        <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100 dark:border-slate-800">
                          <span>سرویسکار: {tech?.fullName || 'در انتظار تخصیص'}</span>
                          <Link
                            to={`/track?code=${ord.requestNumber}`}
                            className="text-teal-600 font-semibold hover:underline flex items-center gap-1"
                          >
                            پیگیری وضعیت زنده
                            <ChevronLeft className="w-3.5 h-3.5" />
                          </Link>
                        </div>
                      </Card>
                    );
                  })
                )}
              </div>
            )}

            {/* Tab 3: Receipts Submissions */}
            {activeTab === 'receipts' && (
              <div className="space-y-3">
                {customerSubmissions.length === 0 ? (
                  <Card className="p-8">
                    <EmptyState
                      icon={<CreditCard className="w-10 h-10" />}
                      title="هنوز رسیدی ارسال نکرده‌اید"
                      description="شما می‌توانید از تب فاکتورها، پس از پرداخت وجه، فیش واریز یا اطلاعات تراکنش خود را برای تأیید و ثبت در حسابداری ارسال فرمایید."
                    />
                  </Card>
                ) : (
                  customerSubmissions.map(sub => (
                    <Card key={sub.id} className="p-4 sm:p-5 space-y-3">
                      <div className="flex items-start justify-between gap-2 flex-wrap">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-sm text-teal-700">
                              {sub.receiptNumber}
                            </span>
                            <Badge
                              color={
                                sub.status === 'تایید_شده'
                                  ? 'green'
                                  : sub.status === 'رد_شده'
                                    ? 'red'
                                    : 'amber'
                              }
                            >
                              {sub.status === 'تایید_شده'
                                ? '✓ تأیید شده'
                                : sub.status === 'رد_شده'
                                  ? 'رد شده'
                                  : 'در انتظار تأیید مدیریت'}
                            </Badge>
                          </div>
                          <p className="text-xs text-slate-500 mt-1">
                            مربوط به فاکتور: <b>{sub.invoiceNumber}</b> • تاریخ ارسال: {toPersianDigits(formatJalali(new Date(sub.submittedAt), { withTime: true }))}
                          </p>
                        </div>

                        <div className="text-left font-mono">
                          <p className="text-xs text-slate-400">مبلغ واریزی</p>
                          <p className="text-base font-extrabold text-emerald-600">
                            {formatCurrency(sub.amount)}
                          </p>
                        </div>
                      </div>

                      {sub.trackingCode && (
                        <p className="text-xs bg-slate-50 dark:bg-slate-900 p-2 rounded-lg font-mono">
                          کد پیگیری تراکنش: <b>{sub.trackingCode}</b>
                        </p>
                      )}

                      {sub.note && (
                        <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-900 p-2.5 rounded-lg leading-5">
                          توضیحات شما: {sub.note}
                        </p>
                      )}

                      {sub.imageUrl && (
                        <div>
                          <p className="text-[11px] font-semibold text-slate-500 mb-1">تصویر فیش ارسالی:</p>
                          <a href={sub.imageUrl} target="_blank" rel="noopener noreferrer">
                            <img
                              src={sub.imageUrl}
                              alt="فیش واریز"
                              className="w-32 h-32 object-cover rounded-xl border border-slate-200 dark:border-slate-700 hover:opacity-90"
                            />
                          </a>
                        </div>
                      )}

                      {sub.status === 'رد_شده' && sub.rejectReason && (
                        <div className="p-2.5 rounded-xl bg-red-50 dark:bg-red-900/20 text-xs text-red-700 dark:text-red-300">
                          <b>علت عدم تأیید:</b> {sub.rejectReason}
                        </div>
                      )}

                      {sub.status === 'تایید_شده' && sub.reviewedAt && (
                        <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-900/15 text-[11px] text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>در تاریخ {toPersianDigits(formatJalali(new Date(sub.reviewedAt), { withTime: true }))} توسط حسابداری بررسی و ثبت قطعی شد.</span>
                        </div>
                      )}
                    </Card>
                  ))
                )}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Signature Modal */}
      {signingInvoice && (
        <Modal open onClose={() => setSigningInvoice(null)} title={`امضای دیجیتال فاکتور ${signingInvoice.invoiceNumber}`} size="md">
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-teal-50 dark:bg-teal-900/20 text-xs text-teal-900 dark:text-teal-200 leading-6 border border-teal-200 dark:border-teal-800">
              این فاکتور مربوط به خدمات و قطعات مصرفی به مبلغ <b>{formatCurrency(signingInvoice.totalAmount)}</b> می‌باشد. با کشیدن امضا در کادر زیر و کلیک روی دکمه تأیید، فاکتور به‌صورت قانونی و دیجیتال توسط شما تأیید می‌گردد.
            </div>

            <Input
              label="نام تأیید کننده"
              value={signerName}
              onChange={e => setSignerName(e.target.value)}
              placeholder="نام و نام خانوادگی خود را بنویسید"
            />

            <div>
              <p className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">کادر امضای دیجیتال (با لمس یا موس امضا کنید):</p>
              <div className="bg-white rounded-xl overflow-hidden border-2 border-slate-300 dark:border-slate-600">
                <SignaturePad ref={sigPadRef} label="محل امضای مشتری" />
              </div>
            </div>

            <div className="flex gap-2 justify-end pt-2 border-t border-slate-100 dark:border-slate-800">
              <Button variant="secondary" onClick={() => setSigningInvoice(null)}>
                انصراف
              </Button>
              <Button onClick={handleSaveSignature} className="bg-teal-600 text-white">
                <Check className="w-4 h-4" />
                تأیید نهایی و ثبت امضا
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Upload Receipt Modal */}
      {receiptInvoice && (
        <Modal open onClose={() => setReceiptInvoice(null)} title={`ارسال رسید پرداخت فاکتور ${receiptInvoice.invoiceNumber}`} size="md">
          <div className="space-y-3.5">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">مبلغ کل فاکتور:</span>
                <span className="font-mono font-bold">{formatCurrency(receiptInvoice.totalAmount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">مانده قابل تسویه:</span>
                <span className="font-mono font-bold text-rose-600">
                  {formatCurrency(Math.max(0, receiptInvoice.totalAmount - receiptInvoice.paidAmount))}
                </span>
              </div>
            </div>

            <Input
              label="مبلغ واریز شده (تومان) *"
              type="number"
              value={receiptAmount || ''}
              onChange={e => setReceiptAmount(parseInt(e.target.value) || 0)}
              placeholder="مبلغ واریز به تومان"
            />

            <Input
              label="کد پیگیری یا شماره ارجاع بانکی (اختیاری)"
              value={receiptTrackingCode}
              onChange={e => setReceiptTrackingCode(e.target.value)}
              placeholder="مثال: ۹۸۷۶۵۴۳۲۱"
              dir="ltr"
            />

            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 block">
                آپلود عکس فیش واریزی یا رسید کارتخوان
              </label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImagePick}
                className="hidden"
              />
              <div className="flex items-center gap-3">
                {receiptImage ? (
                  <div className="relative">
                    <img src={receiptImage} alt="فیش" className="w-24 h-24 object-cover rounded-xl border border-teal-500 shadow-sm" />
                    <button
                      type="button"
                      onClick={() => setReceiptImage('')}
                      className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-rose-600 text-white flex items-center justify-center text-xs"
                    >
                      ✕
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-6 rounded-2xl border-2 border-dashed border-teal-300 dark:border-teal-700 bg-teal-50/50 dark:bg-teal-900/10 hover:bg-teal-100/50 flex flex-col items-center justify-center gap-1.5 text-teal-700 dark:text-teal-400 transition-colors"
                  >
                    <Upload className="w-6 h-6" />
                    <span className="text-xs font-semibold">انتخاب تصویر فیش (عکس، اسکرین‌شات یا فیش بانکی)</span>
                  </button>
                )}
              </div>
            </div>

            <Textarea
              label="متن رسید یا توضیحات واریز (شماره کارت مبدأ، بانک، توضیحات)"
              value={receiptNote}
              onChange={e => setReceiptNote(e.target.value)}
              rows={3}
              placeholder="مثلاً: واریز از کارت بانک ملت به شماره پیگیری ۱۲۳۴۵۶ در ساعت ۱۴:۳۰"
            />

            <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-900/15 text-[11px] text-amber-800 dark:text-amber-300 leading-5">
              💡 پس از ارسال، رسید شما در صف بررسی حسابداری قرار می‌گیرد و با تأیید مدیریت، فاکتور تسویه و پیامک/اعلان تأیید ارسال می‌گردد.
            </div>

            <div className="flex gap-2 justify-end pt-2 border-t border-slate-100 dark:border-slate-800">
              <Button variant="secondary" onClick={() => setReceiptInvoice(null)}>
                انصراف
              </Button>
              <Button onClick={handleSubmitReceipt} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                <Send className="w-4 h-4" />
                ارسال رسید برای تأیید مدیریت
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* View Full Invoice Modal */}
      {viewingInvoice && (
        <Modal open onClose={() => setViewingInvoice(null)} title={`فاکتور رسمی ${viewingInvoice.invoiceNumber}`} size="lg">
          <div className="space-y-4">
            <div className="flex justify-between items-start border-b border-slate-200 dark:border-slate-700 pb-3">
              <div>
                <h3 className="font-bold text-base">{db.settings.shopName}</h3>
                <p className="text-xs text-slate-500 mt-0.5">{db.settings.address}</p>
                <p className="text-xs text-slate-500">تلفن: {toPersianDigits(db.settings.phone)}</p>
              </div>
              <div className="text-left font-mono">
                <p className="font-bold text-teal-600">{viewingInvoice.invoiceNumber}</p>
                <p className="text-xs text-slate-400">{toPersianDigits(formatJalali(new Date(viewingInvoice.date)))}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 dark:bg-slate-900 p-3 rounded-xl">
              <div>
                <span className="text-slate-400">خریدار:</span>{' '}
                <span className="font-semibold">{activeCustomer?.fullName}</span>
              </div>
              <div>
                <span className="text-slate-400">شماره تماس:</span>{' '}
                <span className="font-mono">{toPersianDigits(activeCustomer?.phone || '')}</span>
              </div>
            </div>

            {/* Table of items */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-500">
                    <th className="text-right py-2">شرح</th>
                    <th className="text-center py-2">تعداد</th>
                    <th className="text-left py-2">قیمت واحد</th>
                    <th className="text-left py-2">مبلغ کل</th>
                  </tr>
                </thead>
                <tbody>
                  {viewingInvoice.items.map((it, i) => (
                    <tr key={i} className="border-b border-slate-100 dark:border-slate-800">
                      <td className="py-2">{it.name}</td>
                      <td className="py-2 text-center font-mono">{toPersianDigits(it.quantity)}</td>
                      <td className="py-2 text-left font-mono">{formatCurrency(it.unitPrice)}</td>
                      <td className="py-2 text-left font-mono font-semibold">{formatCurrency(it.quantity * it.unitPrice)}</td>
                    </tr>
                  ))}
                  {viewingInvoice.laborCost > 0 && (
                    <tr className="border-b border-slate-100 dark:border-slate-800">
                      <td className="py-2">اجرت خدمات تعمیر</td>
                      <td className="py-2 text-center font-mono">۱</td>
                      <td className="py-2 text-left font-mono">{formatCurrency(viewingInvoice.laborCost)}</td>
                      <td className="py-2 text-left font-mono font-semibold">{formatCurrency(viewingInvoice.laborCost)}</td>
                    </tr>
                  )}
                  {viewingInvoice.transportationCost > 0 && (
                    <tr className="border-b border-slate-100 dark:border-slate-800">
                      <td className="py-2">هزینه ایاب و ذهاب</td>
                      <td className="py-2 text-center font-mono">۱</td>
                      <td className="py-2 text-left font-mono">{formatCurrency(viewingInvoice.transportationCost)}</td>
                      <td className="py-2 text-left font-mono font-semibold">{formatCurrency(viewingInvoice.transportationCost)}</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex justify-end">
              <div className="w-64 space-y-1.5 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">جمع کل:</span>
                  <span className="font-mono font-bold">{formatCurrency(viewingInvoice.totalAmount)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800 text-emerald-600">
                  <span>پرداخت شده:</span>
                  <span className="font-mono">{formatCurrency(viewingInvoice.paidAmount)}</span>
                </div>
                <div className="flex justify-between py-1 font-bold text-rose-600">
                  <span>مانده قابل پرداخت:</span>
                  <span className="font-mono">{formatCurrency(Math.max(0, viewingInvoice.totalAmount - viewingInvoice.paidAmount))}</span>
                </div>
              </div>
            </div>

            {viewingInvoice.customerSignature && (
              <div className="pt-3 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <div>
                  <p className="text-xs font-semibold">تأیید و امضای مشتری:</p>
                  <p className="text-[10px] text-slate-400">
                    توسط: {viewingInvoice.confirmerName || activeCustomer?.fullName}
                  </p>
                </div>
                <img src={viewingInvoice.customerSignature} alt="امضا" className="h-12 max-w-[120px] object-contain border rounded-lg bg-white p-1" />
              </div>
            )}

            <div className="flex justify-end pt-2">
              <Button onClick={() => setViewingInvoice(null)}>بستن</Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
