import { useEffect, useMemo, useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Button, useToast } from '../components/ui';
import { Navigation, Loader2, Crosshair, GripVertical, ExternalLink } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { fetchRoute, optimizeOrder, nativeNavLinks, type LatLng } from './osm';
import type { ServiceOrder } from '../lib/types';
import { fa } from '../editor/utils';
import { cn } from '../utils/cn';

type MissionPoint = ServiceOrder & { customerName: string; customerLat?: number; customerLng?: number };

const SELECT_KEY = 'tech_selected_missions';
const PRIMARY = '#00A599';

function tryGeo(timeoutMs = 10000): Promise<LatLng | null> {
  return new Promise(resolve => {
    if (!navigator.geolocation) { resolve(null); return; }
    const t = setTimeout(() => resolve(null), timeoutMs);
    navigator.geolocation.getCurrentPosition(
      pos => { clearTimeout(t); resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }); },
      () => { clearTimeout(t); resolve(null); },
      { enableHighAccuracy: true, timeout: timeoutMs }
    );
  });
}

export default function TechMap() {
  const { db, currentUser } = useApp();
  const { showToast } = useToast();
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.LayerGroup | null>(null);
  const routeLayerRef = useRef<L.Polyline | null>(null);
  const liveMarkerRef = useRef<L.Marker | null>(null);
  const [me, setMe] = useState<LatLng | null>(null);
  const [waypoints, setWaypoints] = useState<MissionPoint[]>([]);
  const [routeInfo, setRouteInfo] = useState<{ km: number; min: number } | null>(null);
  const [busy, setBusy] = useState(false);
  const [orderedIds, setOrderedIds] = useState<string[]>([]);
  const [dragIdx, setDragIdx] = useState<number | null>(null);

  const missions = useMemo(() => {
    const sel: string[] = (() => { try { return JSON.parse(localStorage.getItem(SELECT_KEY) || '[]'); } catch { return []; } })();
    let list = db.orders.filter(o => o.technicianId === currentUser?.technicianId && !['تحویل شده', 'لغو شده'].includes(o.status));
    if (sel.length) list = list.filter(o => sel.includes(o.id));
    return list.map(o => {
      const c = db.customers.find(x => x.id === o.customerId);
      return { ...o, customerName: c?.fullName || '—', customerLat: c?.lat, customerLng: c?.lng };
    }).filter(o => o.customerLat && o.customerLng);
  }, [db.orders, db.customers, currentUser]);

  // init map
  useEffect(() => {
    const el = document.getElementById('tech-leaflet');
    if (!el || mapRef.current) return;
    const map = L.map(el, { zoomControl: false, attributionControl: false }).setView([36.2605, 59.6168], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);
    L.control.zoom({ position: 'bottomleft' }).addTo(map);
    L.control.attribution({ position: 'bottomleft', prefix: '© OpenStreetMap' }).addTo(map);
    mapRef.current = map;
    markersRef.current = L.layerGroup().addTo(map);
    return () => { map.remove(); mapRef.current = null; };
  }, []);

  // get live location
  const locate = async (animate = true) => {
    const p = await tryGeo();
    if (p) {
      setMe(p);
      if (mapRef.current && animate) mapRef.current.flyTo([p.lat, p.lng], 14, { duration: 0.6 });
    }
    return p;
  };

  useEffect(() => { locate(false); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // render markers
  useEffect(() => {
    if (!markersRef.current) return;
    markersRef.current.clearLayers();
    const bounds: [number, number][] = [];
    missions.forEach((m) => {
      const marker = L.circleMarker([m.customerLat!, m.customerLng!], {
        radius: 9, color: '#fff', weight: 2.5, fillColor: PRIMARY, fillOpacity: 1,
      }).addTo(markersRef.current!);
      const orderIdx = orderedIds.indexOf(m.id) + 1;
      marker.bindTooltip(orderIdx > 0 ? `<b>#${orderIdx}</b> ${m.customerName}` : m.customerName, { direction: 'top' });
      marker.openTooltip();
      // البته شامل عناصر داخلی (HTML) به‌صورت جدول
      marker.bindPopup(`<div style="font-family:Vazirmatn;direction:rtl;min-width:190px">
        <b style="font-size:13px">${m.customerName}</b><br/>
        <span style="font-size:11px;color:#666">${m.requestNumber}</span><br/>
        <span style="font-size:11px">${db.customers.find(c=>c.id===m.customerId)?.address || ''}</span><br/>
        <a href="/#/tech/order/${m.id}" style="display:block;margin-top:6px;padding:8px;background:${PRIMARY};color:#fff;text-align:center;border-radius:10px;text-decoration:none;font-weight:bold;font-size:12px">جزئیات ماموریت</a>
      </div>`);
      bounds.push([m.customerLat!, m.customerLng!]);
    });
    if (me) {
      const liveIcon = L.divIcon({
        className: 'tech-live-marker',
        html: `<div style="width:16px;height:16px;border-radius:50%;background:${PRIMARY};border:3px solid #fff;box-shadow:0 0 0 8px rgba(0,165,153,0.25)"></div>`,
        iconSize: [16, 16], iconAnchor: [8, 8],
      });
      if (liveMarkerRef.current) liveMarkerRef.current.remove();
      liveMarkerRef.current = L.marker([me.lat, me.lng], { icon: liveIcon }).addTo(mapRef.current!);
      liveMarkerRef.current.bindTooltip('موقعیت شما', { direction: 'top' });
      bounds.push([me.lat, me.lng]);
    }
    if (bounds.length) {
      setTimeout(() => mapRef.current?.fitBounds(L.latLngBounds(bounds as [number, number][]).pad(0.3), { animate: false }));
    }
  }, [missions, me, orderedIds, db.customers]);

  const buildRoute = async () => {
    if (missions.length === 0) { showToast('هیچ نقطه‌ای به نقشه اضافه نشده', 'error'); return; }
    setBusy(true);
    if (!me) await locate(false);
    const start = me || { lat: missions[0].customerLat!, lng: missions[0].customerLng! };
    const points = missions.map(m => ({ lat: m.customerLat!, lng: m.customerLng! }));
    const orderIdx = optimizeOrder(points, start);
    const sorted = orderIdx.map(i => missions[i]);
    setOrderedIds(sorted.map(m => m.id));
    const route = await fetchRoute(sorted.map(m => ({ lat: m.customerLat!, lng: m.customerLng! })));
    if (route) {
      setRouteInfo({ km: route.distanceKm, min: route.durationMin });
      if (routeLayerRef.current) routeLayerRef.current.remove();
      if (mapRef.current) {
        routeLayerRef.current = L.polyline(route.geometry.map(p => [p.lat, p.lng]), { color: PRIMARY, weight: 5, opacity: 0.8 }).addTo(mapRef.current);
        mapRef.current.fitBounds(L.latLngBounds(route.geometry.map(p => [p.lat, p.lng])).pad(0.15));
      }
      setWaypoints(sorted);
      showToast('مسیر بهینه محاسبه شد ✓');
    } else showToast('خطا در محاسبه مسیر (اتصال اینترنت؟)', 'error');
    setBusy(false);
  };

  const startDrag = (e: React.DragEvent<HTMLLIElement>, i: number) => {
    e.dataTransfer.setData('text/plain', String(i));
    setDragIdx(i);
  };
  const dropOn = (e: React.DragEvent<HTMLLIElement>, j: number) => {
    e.preventDefault();
    const i = parseInt(e.dataTransfer.getData('text/plain'));
    if (isNaN(i) || dragIdx === null || i === j) return;
    const next = [...waypoints];
    const [moved] = next.splice(i, 1);
    next.splice(j, 0, moved);
    setWaypoints(next);
    setOrderedIds(next.map(w => w.id));
    setDragIdx(null);
    // بازمحاسبه خط با ترتیب جدید
    fetchRouteState(next);
  };

  const fetchRouteState = async (list: typeof waypoints) => {
    setBusy(true);
    const route = await fetchRoute(list.map(m => ({ lat: m.customerLat!, lng: m.customerLng! })));
    if (route) {
      setRouteInfo({ km: route.distanceKm, min: route.durationMin });
      if (routeLayerRef.current && mapRef.current) {
        routeLayerRef.current.setLatLngs(route.geometry.map(p => [p.lat, p.lng]));
      }
    }
    setBusy(false);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="shrink-0 px-4 pb-2 pt-1">
        <p className="text-xs text-slate-500">
          {fa(missions.length)} نقطه در نقشه دارد{me ? ' • موقعیت شما یافت شد ✓' : ' • در حال یافتن موقعیت...'}
        </p>
      </div>

      {/* Map */}
      <div className="relative flex-1 mx-3 rounded-3xl overflow-hidden border-2 border-slate-200 dark:border-slate-800 shadow-xl">
        <div id="tech-leaflet" className="absolute inset-0 z-0" style={{ fontFamily: 'Vazirmatn' }} />
        {!me && (
          <div className="absolute inset-0 z-10 bg-white/70 dark:bg-slate-900/70 backdrop-blur-sm flex flex-col items-center justify-center gap-2">
            <Loader2 className="w-6 h-6 animate-spin text-teal-600" />
            <p className="text-xs text-slate-600 dark:text-slate-300">در حال دریافت موقعیت شما...<br />لطفاً GPS دستگاه را روشن کنید</p>
            <Button size="sm" onClick={() => locate(true)}>تست مجدد موقعیت</Button>
          </div>
        )}
        {busy && <div className="absolute top-3 left-1/2 -translate-x-1/2 z-20 px-3 py-1.5 rounded-full bg-slate-900/90 text-white text-[11px] font-bold flex items-center gap-1.5"><Loader2 className="w-3.5 h-3.5 animate-spin" />محاسبه ...</div>}

        {/* CTA */}
        <div className="absolute bottom-3 left-3 right-3 z-20 flex gap-2">
          <Button className="flex-1 bg-gradient-to-l from-teal-600 to-teal-500 shadow-xl" onClick={buildRoute} disabled={busy || missions.length === 0}>
            <Navigation className="w-4 h-4" />محاسبه بهینه‌ترین مسیر
          </Button>
          <Button variant="secondary" className="shadow-xl" onClick={() => locate(true)}>
            <Crosshair className="w-4 h-4" />موقعیت من
          </Button>
        </div>
      </div>

      {/* route info */}
      {routeInfo && (
        <div className="mx-3 mt-2 grid grid-cols-2 gap-2">
          <div className="rounded-2xl bg-teal-600 text-white p-2.5 text-center shadow-md shadow-teal-500/30">
            <p className="text-xl font-black">{fa(routeInfo.km.toFixed(1))}</p>
            <p className="text-[10px] text-white/85">کیلومتر</p>
          </div>
          <div className="rounded-2xl bg-slate-800 text-white p-2.5 text-center shadow-md">
            <p className="text-xl font-black">{fa(Math.round(routeInfo.min))}</p>
            <p className="text-[10px] text-white/85">دقیقه زمان تقریبی</p>
          </div>
        </div>
      )}

      {/* waypoints reorderable list */}
      {waypoints.length > 0 && (
        <div className="m-3 space-y-1.5">
          <div className="flex items-center justify-between">
            <p className="text-[11px] font-bold text-slate-600">ترتیب توقف‌ها — برای عوض کردن، بکشید</p>
            <span className="text-[10px] text-slate-400">{fa(waypoints.length)} توقف</span>
          </div>
          <ul className="space-y-1 max-h-44 overflow-y-auto pb-1">
            {waypoints.map((w, i) => {
              const c = db.customers.find(x => x.id === w.customerId);
              const nav = nativeNavLinks({ lat: w.customerLat!, lng: w.customerLng! }, w.customerName);
              return (
                <li key={w.id} draggable onDragStart={e => startDrag(e, i)} onDragOver={e => e.preventDefault()} onDrop={e => dropOn(e, i)}
                  className={cn('flex items-center gap-2.5 p-2 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm transition-transform', dragIdx === i && 'opacity-50')}>
                  <span className="cursor-grab text-slate-300 hover:text-teal-600 shrink-0"><GripVertical className="w-4 h-4" /></span>
                  <span className="w-6 h-6 rounded-full bg-teal-600 text-white flex items-center justify-center text-[11px] font-black shrink-0">{fa(i + 1)}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-[12px] font-bold truncate">{w.customerName}</p>
                    <p className="text-[10px] text-slate-500 truncate font-mono">{w.requestNumber} • {c?.address?.slice(0, 24) || '—'}</p>
                  </div>
                  <a href={nav.geo} className="p-2 rounded-xl bg-teal-600 text-white shrink-0" title="باز کردن در نشان/بلد"><ExternalLink className="w-4 h-4" /></a>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
