import { useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Card, PageHeader } from '../components/ui';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { formatCurrency } from '../lib/jalali';
import { partyBalance } from '../lib/accounting';
import { fa } from '../editor/utils';

const COLORS = ['#00A599', '#3b82f6', '#f59e0b', '#8b5cf6', '#ef4444', '#10b981'];

export default function TechStats() {
  const { db, currentUser } = useApp();
  const myOrders = db.orders.filter(o => o.technicianId === currentUser?.technicianId);

  const done = myOrders.filter(o => ['انجام شده', 'تحویل شده'].includes(o.status)).length;
  const inRoute = myOrders.filter(o => !['انجام شده', 'تحویل شده', 'لغو شده'].includes(o.status)).length;
  const cancelled = myOrders.filter(o => o.status === 'لغو شده').length;
  const totalAmount = db.invoices.filter(i => {
    const o = db.orders.find(x => x.id === i.orderId);
    return o?.technicianId === currentUser?.technicianId;
  }).reduce((s, inv) => s + inv.paidAmount, 0);
  const commission = Math.abs(Math.min(0, partyBalance(db, 'technician', currentUser?.technicianId || 'x')));

  const statusData = useMemo(() => {
    return [
      { name: 'انجام‌شده', value: done },
      { name: 'در مسیر/در حال انجام', value: inRoute },
      { name: 'لغو شده', value: cancelled },
    ].filter(x => x.value > 0);
  }, [done, inRoute, cancelled]);

  const byDay = useMemo(() => {
    const labels = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
    return labels.map((name, i) => {
      const day = new Date(); day.setDate(day.getDate() - (6 - i));
      const count = db.orders.filter(o => o.technicianId === currentUser?.technicianId && new Date(o.registrationDate).toDateString() === day.toDateString()).length;
      return { name, orders: count };
    });
  }, [db.orders, currentUser]);

  return (
    <div className="p-4 space-y-3 pb-24">
      <PageHeader title="آمار من" subtitle={`عملکرد ${currentUser?.fullName} در ماه جاری`} />

      <div className="grid grid-cols-2 gap-2">
        <Card className="p-3.5"><p className="text-2xl font-black text-teal-600">{fa(done)}</p><p className="text-[10px] text-slate-500 mt-0.5">ماموریت موفق</p></Card>
        <Card className="p-3.5"><p className="text-2xl font-black text-amber-600">{fa(inRoute)}</p><p className="text-[10px] text-slate-500 mt-0.5">در حال پیگیری</p></Card>
        <Card className="p-3.5"><p className="text-lg font-black text-emerald-600 truncate">{formatCurrency(totalAmount, false)}</p><p className="text-[10px] text-slate-500 mt-0.5">درآمد ثبت‌شده</p></Card>
        <Card className="p-3.5"><p className="text-lg font-black text-purple-600 truncate">{formatCurrency(commission, false)}</p><p className="text-[10px] text-slate-500 mt-0.5">پورسانت</p></Card>
      </div>

      <Card className="p-4">
        <h3 className="font-bold text-xs mb-3 text-slate-700 dark:text-slate-200">توزیع وضعیت ماموریت‌ها</h3>
        {statusData.length === 0 ? <p className="text-center text-xs text-slate-500 py-6">داده‌ای موجود نیست</p> : (
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={48} outerRadius={74} paddingAngle={3}>
                {statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ fontFamily: 'Vazirmatn', fontSize: 12, direction: 'rtl', borderRadius: 8 }} formatter={(v: unknown) => `${fa(v as number)} ماموریت`} />
            </PieChart>
          </ResponsiveContainer>
        )}
        <div className="flex justify-center gap-4 text-[10px]">
          {statusData.map((d, i) => <span key={d.name} className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full" style={{ background: COLORS[i] }} />{d.name}</span>)}
        </div>
      </Card>

      <Card className="p-4">
        <h3 className="font-bold text-xs mb-3 text-slate-700 dark:text-slate-200">ماموریت‌های ۷ روز اخیر</h3>
        <ResponsiveContainer width="100%" height={150}>
          <BarChart data={byDay}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
            <XAxis dataKey="name" tick={{ fontSize: 11, fontFamily: 'Vazirmatn' }} stroke="#94a3b8" />
            <YAxis allowDecimals={false} tick={{ fontSize: 11, fontFamily: 'Vazirmatn' }} stroke="#94a3b8" />
            <Tooltip contentStyle={{ fontFamily: 'Vazirmatn', fontSize: 12, direction: 'rtl', borderRadius: 8 }} formatter={(v: unknown) => [`${fa(v as number)}`, 'ماموریت']} />
            <Bar dataKey="orders" fill="#00A599" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}
