import { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Badge, EmptyState, Button } from '../components/ui';
import { Phone, Map as MapIcon, ClipboardList, CheckSquare, Square, Filter } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { formatJalali, toPersianDigits, formatCurrency } from '../lib/jalali';
import { STATUS_COLORS } from '../lib/types';
import { cn } from '../utils/cn';
import { fa } from '../editor/utils';

const SELECT_KEY = 'tech_selected_missions';

export default function TechDashboard() {
  const { db, currentUser } = useApp();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<'today' | 'active' | 'done'>('active');
  const [selected, setSelected] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem(SELECT_KEY) || '[]'); } catch { return []; }
  });

  const orders = useMemo(() => {
    let list = db.orders.filter(o => o.technicianId === currentUser?.technicianId);
    const today = new Date().toDateString();
    if (filter === 'today') list = list.filter(o => o.visitDate && new Date(o.visitDate).toDateString() === today);
    else if (filter === 'active') list = list.filter(o => !['تحویل شده', 'لغو شده'].includes(o.status));
    else list = list.filter(o => ['تحویل شده', 'انجام شده'].includes(o.status));
    return list.sort((a, b) => {
      const av = a.visitDate ? new Date(a.visitDate).getTime() : 0;
      const bv = b.visitDate ? new Date(b.visitDate).getTime() : 0;
      return av - bv;
    });
  }, [db.orders, currentUser, filter]);

  const toggleSelect = (id: string) => {
    const next = selected.includes(id) ? selected.filter(x => x !== id) : [...selected, id];
    setSelected(next);
    localStorage.setItem(SELECT_KEY, JSON.stringify(next));
  };
  const selectAll = () => { const ids = orders.map(o => o.id); setSelected(ids); localStorage.setItem(SELECT_KEY, JSON.stringify(ids)); };

  const activeCount = db.orders.filter(o => o.technicianId === currentUser?.technicianId && !['تحویل شده', 'لغو شده'].includes(o.status)).length;
  const todayCount = db.orders.filter(o => o.technicianId === currentUser?.technicianId && o.visitDate && new Date(o.visitDate).toDateString() === new Date().toDateString()).length;

  return (
    <div className="p-4 space-y-3 pb-24">
      {/* quick stats */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-3 text-center shadow-sm">
          <p className="text-2xl font-black text-teal-600">{fa(orders.length)}</p>
          <p className="text-[10px] text-slate-500 font-medium mt-0.5">ماموریت فهرست</p>
        </div>
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-3 text-center shadow-sm">
          <p className="text-2xl font-black text-amber-600">{fa(activeCount)}</p>
          <p className="text-[10px] text-slate-500 font-medium mt-0.5">در حال انجام</p>
        </div>
        <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-3 text-center shadow-sm">
          <p className="text-2xl font-black text-slate-700 dark:text-slate-200">{fa(todayCount)}</p>
          <p className="text-[10px] text-slate-500 font-medium mt-0.5">امروز</p>
        </div>
      </div>

      {/* filter */}
      <div className="flex items-center gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
        {([['active', 'فعال'], ['today', 'امروز'], ['done', 'انجام‌شده']] as const).map(([v, l]) => (
          <button key={v} onClick={() => setFilter(v)} className={cn('flex-1 flex items-center justify-center gap-1 py-2 rounded-xl text-[11px] font-bold transition-all', filter === v ? 'bg-white dark:bg-slate-700 text-teal-700 shadow' : 'text-slate-500')}>
            <Filter className="w-3.5 h-3.5" />{l}
          </button>
        ))}
      </div>

      {/* bulk bar */}
      {orders.length > 0 && (
        <div className="flex items-center gap-2">
          <button onClick={selected.length === orders.length ? () => { setSelected([]); localStorage.removeItem(SELECT_KEY); } : selectAll}
            className="flex items-center gap-1 text-[10px] font-bold text-teal-700">
            {selected.length === orders.length ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
            {selected.length === orders.length ? 'لغو انتخاب همه' : 'انتخاب همه'}
          </button>
          <span className="text-[10px] text-slate-400">{selected.length > 0 ? `${fa(selected.length)} انتخاب شده` : ''}</span>
          {selected.length > 0 && (
            <Button size="sm" className="mr-auto bg-gradient-to-l from-teal-600 to-teal-500" onClick={() => navigate('/tech/map')}>
              🗺️ نقشه با این نقاط
            </Button>
          )}
        </div>
      )}

      {/* list */}
      {orders.length === 0 && <EmptyState title="ماموریتی وجود ندارد" icon={<ClipboardList className="w-8 h-8" />} />}
      {orders.map(o => {
        const customer = db.customers.find(c => c.id === o.customerId);
        const isSelected = selected.includes(o.id);
        return (
          <Card key={o.id} className={cn('p-3 transition-all', isSelected && 'ring-2 ring-teal-500 border-teal-300 dark:border-teal-700')}
            hover onClick={() => navigate(`/tech/order/${o.id}`)}>
            <div className="flex items-start gap-3">
              <button onClick={e => { e.stopPropagation(); toggleSelect(o.id); }}
                className="w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5"
                style={{ borderColor: isSelected ? '#00A599' : '#cbd5e1', background: isSelected ? '#00A599' : 'transparent' }}
                aria-label="انتخاب">
                {isSelected && <CheckSquare className="w-3.5 h-3.5 text-white" />}
              </button>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-mono font-black text-sm text-teal-700">{o.requestNumber}</p>
                  <Badge color={STATUS_COLORS[o.status] ? 'slate' : 'slate'}>{o.status}</Badge>
                </div>
                <p className="text-[13px] font-bold text-slate-900 dark:text-white mt-1">{customer?.fullName}</p>
                <p className="text-[11px] text-slate-500 leading-4 mt-0.5 line-clamp-1">{customer?.address || '—'}</p>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-[10px] text-slate-400 font-mono">{o.visitDate ? toPersianDigits(formatJalali(new Date(o.visitDate))) : 'بدون تاریخ'} {o.visitTime ? `• ${toPersianDigits(o.visitTime)}` : ''}</span>
                  <span className="text-[11px] font-bold text-slate-700 dark:text-slate-200">{o.finalAmount > 0 ? formatCurrency(o.finalAmount) : '—'}</span>
                </div>
              </div>
            </div>
            {/* quick actions */}
            <div className="grid grid-cols-2 gap-2 mt-2.5">
              <a href={`tel:${customer?.phone}`} onClick={e => e.stopPropagation()} className="flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-emerald-600 text-white text-[12px] font-bold active:scale-[0.97] transition-transform">
                <Phone className="w-4 h-4" />تماس
              </a>
              <button onClick={e => { e.stopPropagation(); toggleSelect(o.id); }}
                className={cn('flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-[12px] font-bold border-2 transition-all active:scale-[0.97]', isSelected ? 'bg-teal-600 text-white border-teal-600' : 'bg-teal-50 dark:bg-teal-900/20 text-teal-700 border-teal-300')}>
                <MapIcon className="w-4 h-4" />{isSelected ? 'لغو مسیریابی' : 'مسیریابی'}
              </button>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
