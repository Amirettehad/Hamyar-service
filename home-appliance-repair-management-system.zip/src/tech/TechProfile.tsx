import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, useToast } from '../components/ui';
import { LogOut, Fingerprint, Smartphone, BellRing, ShieldCheck, Phone, LogIn } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Avatar } from '../components/ui';
import { partyBalance } from '../lib/accounting';
import { formatCurrency, toPersianDigits } from '../lib/jalali';
import { usePwaInstall } from '../hooks/usePwaInstall';
import { checkEnvironment, registerBiometric, describeBiometricError } from '../lib/biometric';
import { cn } from '../utils/cn';
import { fa } from '../editor/utils';

export default function TechProfile() {
  const { currentUser, db, logout, registerBiometricCredential } = useApp();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const { canInstall, promptInstall, installed } = usePwaInstall();
  const [busy, setBusy] = useState(false);
  const tech = db.technicians.find(t => t.id === currentUser?.technicianId);
  const commission = Math.abs(Math.min(0, partyBalance(db, 'technician', currentUser?.technicianId || 'x')));
  const hasFingerprint = db.biometrics.some(b => b.userId === currentUser?.id);

  const enrollFingerprint = async () => {
    if (!currentUser) return;
    const env = await checkEnvironment();
    if (!env.canTry) { showToast(env.message + (env.inIframe ? ' — در پنجره مستقل باز کنید' : ''), 'error'); return; }
    setBusy(true);
    try {
      const res = await registerBiometric({
        userId: currentUser.id, userName: currentUser.username, displayName: currentUser.fullName,
        appName: db.settings.shopName, requireUserVerification: db.settings.biometricRequireUserVerification,
        timeoutSeconds: db.settings.biometricTimeoutSeconds,
      });
      registerBiometricCredential(currentUser.id, res.credentialId, res.deviceLabel);
      showToast('اثر انگشت با موفقیت ثبت شد ✓');
    } catch (err) { showToast(describeBiometricError(err), 'error'); }
    setBusy(false);
  };

  const askNotificationPermission = async () => {
    const s = db.settings;
    // اگر OneSignal فعال باشد، از مسیر رسمی آن استفاده می‌کنیم
    if (s.oneSignalEnabled && s.oneSignalAppId) {
      setBusy(true);
      const mod = await import('../lib/onesignal');
      const res = await mod.requestOneSignalPermission(s);
      setBusy(false);
      if (res === 'granted') showToast('اعلان OneSignal با موفقیت فعال شد ✓');
      else if (res === 'denied' || (typeof Notification !== 'undefined' && Notification.permission === 'denied')) showToast('مجوزمسدود می‌خید — در تنظیمات گوشی/مرورگر اجازه نوتیفیکیشن را بدهید', 'error');
      else if (res === 'unsupported') showToast('مرورگر شما از Web Push پشتیبانی نمی‌کند', 'error');
      else showToast('درخواست مجوز صادر شد؛ اگر prompt داده نشد، دوباره تلاش کنید یا از داشبورد در حالت SETTINGS مرورگر اجازه دهید', 'info');
      return;
    }
    // fallback: سیستم داخلی SW
    const { requestPushPermission, showSystemNotification } = await import('../lib/push');
    const p = await requestPushPermission();
    if (p === 'granted') {
      showToast('نوتیفیکیشن فعال شد — اعلان‌ها روی دستگاه نمایش داده می‌شود ✓');
      setTimeout(() => showSystemNotification(currentUser?.fullName + ' 👋', 'شما اکنون اعلان‌های ماموریت‌ها را دریافت می‌کنیید', '/tech'), 1200);
    } else if (p === 'denied') {
      showToast('در تنظیمات مرورگر اجازه نوتیفیکیشن را بدهید', 'error');
    } else if (p === 'unsupported') {
      showToast('مرورگر شما از نوتیفیکیشن پشتیبانی نمی‌کند', 'error');
    } else {
      showToast('درحواست مجوز مجدد است؛ دوباره تلاش کنید', 'info');
    }
  };

  return (
    <div className="p-4 space-y-3 pb-24">
      {/* Hero card */}
      <div className="rounded-2xl p-5 text-white overflow-hidden relative shadow-xl shadow-teal-500/30"
        style={{ background: 'linear-gradient(135deg,#00A599,#008a84)' }}>
        <div className="absolute -top-6 -left-6 w-24 h-24 rounded-full bg-white/10" />
        <div className="absolute -bottom-8 -right-4 w-28 h-28 rounded-full bg-white/5" />
        <div className="relative flex items-center gap-3">
          <Avatar name={currentUser?.fullName || 'تکنسین'} size="lg" />
          <div>
            <p className="font-extrabold text-base">{currentUser?.fullName}</p>
            <p className="text-xs text-white/75 mt-0.5 flex items-center gap-1"><Phone className="w-3 h-3" />{currentUser?.phone ? toPersianDigits(currentUser.phone) : '—'}</p>
            <p className="text-[10px] bg-white/20 rounded-full px-2 py-0.5 inline-block mt-1">{tech?.specialization || 'تکنسین میدانی'}</p>
          </div>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 gap-2">
        <Card className="p-4"><p className="text-[10px] text-slate-500 mb-1">پورسانت باقی‌مانده</p><p className="text-lg font-black text-teal-600">{formatCurrency(commission)}</p></Card>
        <Card className="p-4"><p className="text-[10px] text-slate-500 mb-1">کل ماموریت‌ها</p><p className="text-lg font-black">{fa(db.orders.filter(o => o.technicianId === currentUser?.technicianId).length)}</p></Card>
      </div>

      {/* Actions */}
      <Card className="p-4 space-y-2">
        <h3 className="font-bold text-sm mb-3">اقدامات سریع</h3>
        <button onClick={() => canInstall ? promptInstall() : showToast(installed ? 'قبلاً نصب شده' : 'از منو گوشی گزینه «Add to Home Screen» را بزنید', installed ? 'success' : 'info')}
          className={cn('w-full flex items-center justify-between gap-2 p-3.5 rounded-2xl border-2 transition-all active:scale-[0.98]', installed ? 'border-emerald-300 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700' : 'border-teal-300 bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-300')}>
          <span className="flex items-center gap-2 text-xs font-bold"><Smartphone className="w-4 h-4" />نصب رو APPIVE گوشی (PWA)</span>
          <span className="text-[10px] font-black">{installed ? '✓ نصب شده' : 'نصب کنید'}</span>
        </button>

        <button onClick={askNotificationPermission} className="w-full flex items-center justify-between gap-2 p-3.5 rounded-2xl border-2 border-teal-300 bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-300 active:scale-[0.98]">
          <span className="flex items-center gap-2 text-xs font-bold"><BellRing className="w-4 h-4" />فعال‌سازی اعلان (Web Push واقعی)</span>
          <span className="text-[10px] font-bold">{typeof Notification !== 'undefined' ? Notification.permission === 'granted' ? '✓ فعال' : Notification.permission === 'denied' ? 'مسدود' : Notification.permission : '—'}</span>
        </button>

        <button onClick={enrollFingerprint} disabled={busy}
          className="w-full flex items-center justify-between gap-2 p-3.5 rounded-2xl border-2 border-teal-300 bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-300 active:scale-[0.98] disabled:opacity-50">
          <span className="flex items-center gap-2 text-xs font-bold"><Fingerprint className="w-4 h-4" />ثبت اثر انگشت برای ورود سریع</span>
          <span className="text-[10px] font-black">{hasFingerprint ? '✓ ثبت شده' : busy ? '...' : 'ثبت کنید'}</span>
        </button>

        <button onClick={() => navigate('/tech/map')} className="w-full flex items-center justify-between gap-2 p-3.5 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 active:scale-[0.98]">
          <span className="flex items-center gap-2 text-xs font-bold"><ShieldCheck className="w-4 h-4" />باز کردن نقشه مسیریابی</span>
        </button>

        <button onClick={() => navigate('/tech')} className="w-full flex items-center justify-between gap-2 p-3.5 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 active:scale-[0.98]">
          <span className="flex items-center gap-2 text-xs font-bold"><LogIn className="w-4 h-4" />مشاهده فهرست ماموریت‌ها</span>
        </button>

        <button onClick={() => { if (confirm('خارج می‌شوید؟')) { logout(); navigate('/login'); } }} className="w-full flex items-center justify-between gap-2 p-3.5 rounded-2xl border-2 border-rose-200 dark:border-rose-900/40 bg-rose-50 dark:bg-rose-900/20 text-rose-600 active:scale-[0.98]">
          <span className="flex items-center gap-2 text-xs font-black"><LogOut className="w-4 h-4" />خروج از حساب کاربری</span>
        </button>
      </Card>

      {/* издание ثبت */}
      <Card className="p-4 bg-slate-50 dark:bg-slate-800/50">
        <p className="text-[10px] text-slate-500 leading-5 text-center">
          پنل تکنسین میدانی — {db.settings.shopName}<br />
          توسعه: {db.settings.developerName} • {db.settings.developerPhone}
        </p>
      </Card>
    </div>
  );
}
