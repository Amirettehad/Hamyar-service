import { useEffect, useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { LoadingScreen, Button } from '../components/ui';
import { notificationsSupported, showSystemNotification } from '../lib/push';
import { Bell, ClipboardList, Map, BarChart3, User, WifiOff, Wifi } from 'lucide-react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { cn } from '../utils/cn';
import { fa } from '../editor/utils';
import TechDashboard from './TechDashboard';
import TechMap from './TechMap';
import TechStats from './TechStats';
import TechProfile from './TechProfile';
import TechMission from './TechMission';
import { RichNotificationCard } from '../pages/Notifications';
import { InstallBanner } from '../components/InstallBanner';
import { PushPermissionPrompt } from '../components/PushPermissionPrompt';

const TABS = [
  { to: '/tech', label: 'ماموریت‌ها', icon: ClipboardList },
  { to: '/tech/map', label: 'مسیریابی', icon: Map },
  { to: '/tech/stats', label: 'آمار من', icon: BarChart3 },
  { to: '/tech/profile', label: 'پروفایل', icon: User },
];

function useTechNotifications(userId: string | undefined) {
  const { db } = useApp();
  const lastRef = useRef<string | null>(null);
  useEffect(() => {
    if (!userId) return;
    const check = () => {
      if (!notificationsSupported() || Notification.permission !== 'granted') return;
      const mine = db.notifications
        .filter(n => n.userId === userId && !n.read)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      const latest = mine[0];
      if (latest && lastRef.current !== latest.id) {
        const isNew = lastRef.current !== null;
        lastRef.current = latest.id;
        if (isNew) {
          const url = latest.internalLink || '/tech';
          showSystemNotification(latest.title, latest.body, url);
        }
      }
    };
    check();
    const t = setInterval(check, 8000);
    return () => clearInterval(t);
  }, [userId, db.notifications]);
}

export function TechPanel() {
  const { currentUser, isLoading, db } = useApp();
  useTechNotifications(currentUser?.id);
  const location = useLocation();
  const navigate = useNavigate();
  const route = location.pathname;

  // Deep link navigate when a notification click lands in the app
  useEffect(() => {
    const handler = (e: MessageEvent) => {
      if (e.data?.type === 'NOTIFY_CLICK' && typeof e.data.url === 'string') {
        navigate(e.data.url.startsWith('/tech') ? e.data.url : '/tech');
      }
    };
    navigator.serviceWorker?.addEventListener('message', handler);
    return () => navigator.serviceWorker?.removeEventListener('message', handler);
  }, [navigate]);

  if (isLoading) return <LoadingScreen />;
  if (!currentUser) return <Navigate to="/login" replace />;
  if (currentUser.role !== 'technician') return <Navigate to="/dashboard" replace />;

  const unread = db.notifications.filter(n => n.userId === currentUser.id && !n.read).length;

  return (
    <div className="h-screen flex flex-col bg-slate-50 dark:bg-slate-950 overflow-hidden font-['Vazirmatn']" dir="rtl">
      {/* Header (hidden on mission detail page to avoid double headers) */}
      {!route.startsWith('/tech/order/') && (
        <header className="shrink-0 text-white px-4 pt-3 safe-top" style={{ background: 'linear-gradient(180deg,#00A599,#008a84)' }}>
          <div className="flex items-center justify-between h-11">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center font-black text-sm">ا</div>
              <div className="leading-tight">
                <p className="text-[13px] font-extrabold">همیار سرویس اتحاد</p>
                <p className="text-[9.5px] text-white/80">پنل تکنسین میدانی</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <OnlineBadge />
              <NavNotif unread={unread} />
            </div>
          </div>
          <p className="text-[10px] text-white/75 pb-2">سلام {currentUser.fullName} 👋</p>
        </header>
      )}

      {/* Content */}
      <main className="flex-1 overflow-y-auto scroll-area safe-bottom">
        {route === '/tech' || route === '/tech/' ? <TechDashboard />
          : route === '/tech/map' ? <TechMap />
            : route === '/tech/stats' ? <TechStats />
              : route === '/tech/profile' ? <TechProfile />
                : location.pathname.startsWith('/tech/order/') ? <TechMission />
                  : <TechDashboard />}
      </main>

      <InstallBanner />
      <PushPermissionPrompt alsoInstallPrompt={false} />
      {/* Bottom Navigation */}
      <nav className="shrink-0 tab-bar border-t border-slate-200 dark:border-slate-800 safe-bottom">
        <div className="grid grid-cols-4 pt-1.5 pb-1.5">
          {TABS.map(t => {
            const Icon = t.icon;
            const active = t.to === '/tech' ? (route === '/tech' || route === '/tech/') : route.startsWith(t.to);
            return (
              <button key={t.to} onClick={() => navigate(t.to)}
                className={cn('tab-item relative flex flex-col items-center gap-0.5 px-1 py-1 rounded-2xl transition-all', active ? 'text-teal-600 dark:text-teal-400' : 'text-slate-400 dark:text-slate-500')}>
                {active && <span className="absolute -top-1.5 w-7 h-1 rounded-full bg-teal-500 animate-tab-pop" />}
                <span className={cn('w-10 h-9 rounded-2xl flex items-center justify-center transition-all', active && 'bg-teal-50 dark:bg-teal-900/30 scale-105')}>
                  <Icon className="w-5 h-5" />
                </span>
                <span className={cn('text-[10px]', active ? 'font-bold' : 'font-medium')}>{t.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

function OnlineBadge() {
  const [online, setOnline] = useState(navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);
  return (
    <span className={cn('px-2 py-1 rounded-full text-[9.5px] font-bold flex items-center gap-1', online ? 'bg-white/15' : 'bg-red-500/80 animate-pulse')}>
      {online ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}{online ? 'آنلاین' : 'آفلاین'}
    </span>
  );
}

function NavNotif({ unread }: { unread: number }) {
  const { db, currentUser, markNotificationRead, clearAllNotifications } = useApp();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const list = db.notifications.filter(n => n.userId === currentUser?.id).slice(0, 30);
  return (
    <>
      <button onClick={() => setOpen(true)} className="relative w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center">
        <Bell className="w-5 h-5" />
        {unread > 0 && <span className="absolute -top-1 -left-1 min-w-4 h-4 px-1 bg-red-500 rounded-full text-[9px] font-bold flex items-center justify-center animate-pulse-soft">{fa(unread)}</span>}
      </button>
      {open && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end pointer-events-none p-0">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm pointer-events-auto" onClick={() => setOpen(false)} />
          <div className="relative pointer-events-auto bg-white dark:bg-slate-900 rounded-t-[28px] shadow-2xl shadow-black/30 flex flex-col animate-sheet-up safe-bottom max-h-[82vh]">
            <div className="w-10 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 mx-auto mt-2.5 shrink-0" />
            <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-100 dark:border-slate-800 shrink-0">
              <p className="font-bold text-sm">مرکز اعلان‌ها</p>
              <button onClick={clearAllNotifications} className="text-[10px] text-teal-600 font-bold">همه خوانده شد</button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {list.length === 0 && <p className="text-center text-sm text-slate-500 py-10">اعلان جدیدی ندارید ✓</p>}
              {list.map(n => {
                const handleClick = () => {
                  markNotificationRead(n.id);
                  setOpen(false);
                  if (n.internalLink) {
                    navigate(n.internalLink.startsWith('/tech') ? n.internalLink : '/tech');
                  } else if (n.externalLink) {
                    window.open(n.externalLink, '_blank');
                  } else if (n.relatedId) {
                    navigate(`/tech/order/${n.relatedId}`);
                  }
                };
                return (
                  <div key={n.id} onClick={handleClick} className={cn('rounded-2xl cursor-pointer active:scale-[0.98] transition-transform', !n.read && 'ring-1 ring-teal-400')}>
                    {n.type === 'broadcast'
                      ? <RichNotificationCard n={{ title: n.title, body: n.body, icon: n.icon, imageUrl: n.imageUrl, internalLink: n.internalLink, externalLink: n.externalLink, accentColor: n.accentColor, senderName: n.senderName, createdAt: n.createdAt }} compact />
                      : <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-700">
                          <p className="text-sm font-semibold text-slate-900 dark:text-white">{n.title}</p>
                          <p className="text-xs text-slate-500 mt-0.5 leading-5">{n.body}</p>
                          {(n.relatedId || n.internalLink) && (
                            <span className="text-[10px] text-teal-600 font-bold block mt-1">مشاهده بخش مربوطه ←</span>
                          )}
                        </div>}
                  </div>
                );
              })}
            </div>
            <div className="p-3 border-t border-slate-100 dark:border-slate-800"><Button variant="secondary" className="w-full" onClick={() => setOpen(false)}>بستن</Button></div>
          </div>
        </div>
      )}
    </>
  );
}
