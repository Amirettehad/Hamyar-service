import { useMemo, useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, Button, useToast, EmptyState } from '../components/ui';
import { useNavigate, useParams } from 'react-router-dom';
import { Phone, Camera, ChevronDown, FileText, Save, RefreshCw } from 'lucide-react';
import { fa } from '../editor/utils';
import { toPersianDigits, formatCurrency, formatJalaliLong } from '../lib/jalali';
import { ORDER_STATUSES } from '../lib/types';
import { cn } from '../utils/cn';
import { QRCodeSVG } from 'qrcode.react';
import { buildTrackingUrl, buildSmsTrackingText } from '../lib/shortLink';
import { Share2 } from 'lucide-react';

export default function TechMission() {
  const { id } = useParams();
  const { db, currentUser, updateOrder, updateOrderStatus, generateInvoice } = useApp();
  const { showToast } = useToast();
  const navigate = useNavigate();
  const order = db.orders.find(o => o.id === id && o.technicianId === currentUser?.technicianId);
  const perms: string[] = db.technicians.find(t => t.id === currentUser?.technicianId)?.permissions || [];
  const hasPerm = (p: string) => perms.includes(p);

  const [report, setReport] = useState(order?.technicianReport || '');
  const [internalNote, setInternalNote] = useState(order?.internalNote || '');
  const [photoPreviews, setPhotoPreviews] = useState<string[]>(order?.technicianPhotos || []);
  const [partName, setPartName] = useState('');
  const [partQty, setPartQty] = useState(1);
  const [partPrice, setPartPrice] = useState(0);
  const [expanded, setExpanded] = useState<'info' | 'actions' | 'fin' | ''>('info');
  const [statusMenu, setStatusMenu] = useState(false);
  const imgRef = useRef<HTMLInputElement>(null);

  const customer = order ? db.customers.find(c => c.id === order.customerId) : null;
  const device = order ? db.devices.find(d => d.id === order.deviceId) : null;

  const partsTotal = useMemo(() => (order?.parts || []).reduce((s, p) => s + p.quantity * p.unitPrice, 0), [order?.parts]);
  const liveTotal = useMemo(() => (order?.laborCost || 0) + partsTotal + (order?.transportationCost || 0) + (order?.otherCosts || 0) - (order?.discount || 0), [order, partsTotal]);

  if (!order) return <div className="p-4"><EmptyState title="ماموریت یافت نشد یا به شما مرتبط نیست" action={<Button onClick={() => navigate('/tech')}>بازگشت</Button>} /></div>;

  const saveEverything = (silent = false) => {
    if (!hasPerm('report')) { showToast('مدیر دسترسی ثبت گزارش را برای شما فعال نکرده است', 'error'); return; }
    updateOrder(order.id, {
      technicianReport: report,
      internalNote,
      technicianPhotos: photoPreviews,
    });
    if (!silent) showToast('ذخیره شد ✓');
  };

  const changeStatus = (s: typeof ORDER_STATUSES[number]) => {
    if (!hasPerm('status_change')) { showToast('مدیر دسترسی تغییßz وضعیت را برای شما فعال نکرده است', 'error'); return; }
    saveEverything(true);
    updateOrderStatus(order.id, s);
    setStatusMenu(false);
    showToast(`وضعیت به «${s}» تغییر کرد ✓`);
  };

  const addPhoto = (file: File) => {
    if (!hasPerm('photo')) { showToast('مدیر دسترسی آپلود عکس را برای شما فعال نکرده است', 'error'); return; }
    const r = new FileReader();
    r.onload = () => setPhotoPreviews(prev => [...prev, r.result as string]);
    r.readAsDataURL(file);
  };

  const addPart = () => {
    if (!hasPerm('parts')) { showToast('مدیر دسترسی افزودن قطعات را برای شما فعال نکرده است', 'error'); return; }
    if (!partName.trim() || partPrice <= 0) { showToast('نام قطعه و قیمت را وارد کنید', 'error'); return; }
    updateOrder(order.id, {
      parts: [...order.parts, { id: `p-${Date.now()}`, name: partName, quantity: partQty, unitPrice: partPrice }],
    });
    setPartName(''); setPartQty(1); setPartPrice(0);
    showToast('قطعه اضافه شد ✓');
  };

  const issueFactor = () => {
    if (!hasPerm('invoice')) { showToast('مدیر دسترسی صدور فاکتور را برای شما فعال نکرده است', 'error'); return; }
    if (!order.invoiceGenerated) {
      const r = generateInvoice(order.id);
      if (r.success) showToast(`فاکتور صادر شد (${r.id})`); else { showToast(r.error || 'خطا در صدور', 'error'); return; }
    }
    saveEverything(true);
  };

  const createdAt = new Date(order.registrationDate);

  return (
    <div className="flex flex-col min-h-full">
      {/* Sticky header with status */}
      <header className="sticky top-0 z-20 bg-gradient-to-b from-teal-600 to-teal-700 text-white px-4 py-3 shadow-lg shadow-teal-700/30 safe-top" style={{ background: 'linear-gradient(180deg,#00A599,#008a84)' }}>
        <div className="flex items-center justify-between gap-2">
          <button onClick={() => navigate('/tech')} className="text-white/90 text-sm px-1">←</button>
          <div className="flex-1 min-w-0">
            <p className="font-mono font-black text-base">{order.requestNumber}</p>
            <p className="text-[9.5px] text-white/80 mt-0.5">{customer?.fullName} • {order.serviceType}</p>
          </div>
          <div className="relative">
            <button onClick={() => setStatusMenu(m => !m)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/20 backdrop-blur text-[11px] font-bold">
              <RefreshCw className="w-3.5 h-3.5" />{order.status}
            </button>
            {statusMenu && (
              <div className="absolute left-0 top-full mt-1.5 w-48 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden z-30 animate-scale-in">
                {ORDER_STATUSES.map(s => (
                  <button key={s} onClick={() => changeStatus(s)}
                    className={cn('w-full text-right px-4 py-2.5 text-sm font-medium hover:bg-teal-50 dark:hover:bg-teal-900/20 transition-colors', s === order.status && 'bg-teal-50 dark:bg-teal-900/20 text-teal-700 font-bold')}>
                    {s === order.status && '✓ '}{s}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-3 space-y-2.5 pb-44">
        {/* Quick actions */}
        <div className="grid grid-cols-4 gap-2">
          <a href={`tel:${customer?.phone}`} className="flex flex-col items-center gap-1.5 py-3 rounded-2xl bg-emerald-600 text-white font-bold text-[11px] active:scale-[0.96] transition-transform shadow-md shadow-emerald-600/25">
            <Phone className="w-5 h-5" />تماس سریع
          </a>
          <a href={`sms:${customer?.phone}`} className="flex flex-col items-center gap-1.5 py-3 rounded-2xl bg-blue-600 text-white font-bold text-[11px] active:scale-[0.96] transition-transform shadow-md shadow-blue-600/25">
            <Phone className="w-5 h-5" />پیام
          </a>
          <button onClick={() => imgRef.current?.click()} className="flex flex-col items-center gap-1.5 py-3 rounded-2xl bg-purple-600 text-white font-bold text-[11px] active:scale-[0.96] transition-transform shadow-md shadow-purple-600/25">
            <Camera className="w-5 h-5" />عکس دوربین
          </button>
          <a href="#" aria-label="whatsapp" className="flex flex-col items-center gap-1.5 py-3 rounded-2xl bg-teal-700 text-white font-bold text-[11px] active:scale-[0.96] transition-transform shadow-md shadow-teal-700/25"
            onClick={e => { e.preventDefault(); const text = encodeURIComponent(`سلام ${customer?.fullName}، ماموریت ${order.requestNumber}: ${order.status}`); const phone = (customer?.phone || '').replace(/^0/, '98'); window.open(`https://wa.me/${phone}?text=${text}`, '_blank'); }}>
            <span className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center text-xs">📱</span>واتساپ
          </a>
        </div>
        <input ref={imgRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) addPhoto(f); e.target.value = ''; }} />

        {/* Accordion: سفارشات */}
        <AccordionSection title="اطلاعات فنی / مستندات" open={expanded === 'info'} onToggle={() => setExpanded(expanded === 'info' ? '' : 'info')}>
          <div className="space-y-2 pt-2">
            <InfoRow label="نوع دستگاه" value={`${device?.type || '—'} ${device?.brand || ''}`} />
            <InfoRow label="مدل" value={device?.model} />
            <InfoRow label="سریال" value={device?.serialNumber ? toPersianDigits(device.serialNumber) : undefined} />
            <InfoRow label="گارانتی" value={device?.warrantyStatus} />
            <InfoRow label="نوع سرویس" value={order.serviceType} />
            <InfoRow label="تاریخ ثبت" value={toPersianDigits(formatJalaliLong(createdAt))} />
            {order.visitDate && <InfoRow label="تاریخ مراجعه" value={toPersianDigits(formatJalaliLong(new Date(order.visitDate))) + (order.visitTime ? ` — ${toPersianDigits(order.visitTime)}` : '')} />}
          </div>
          <div className="mt-2.5 p-3 rounded-xl bg-amber-50 dark:bg-amber-900/15 border border-amber-200 dark:border-amber-800">
            <p className="text-[10px] font-bold text-amber-700 dark:text-amber-300 mb-1">شرح خرابی مشتری:</p>
            <p className="text-xs leading-5 text-slate-700 dark:text-slate-200">{order.problemDescription || '—'}</p>
          </div>
        </AccordionSection>

        {/* Accordion: پروتکل اقدام تکنسین */}
        <AccordionSection title="اقدامات تکنسین" open={expanded === 'actions'} onToggle={() => setExpanded(expanded === 'actions' ? '' : 'actions')}>
          <div className="space-y-2.5 pt-2">
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">گزارش عملیات انجام شده</label>
              <textarea value={report} onChange={e => setReport(e.target.value)} rows={4} placeholder="مسابقاتی، اقدامات، عیب‌یابی، تست‌ها، نتیجه..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-3 text-sm resize-y outline-none focus:border-teal-400" />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">یادداشت محرمانه (فقط برای دید مدیر)</label>
              <textarea value={internalNote} onChange={e => setInternalNote(e.target.value)} rows={2} placeholder="یادداشت محرمانه و داخلی — فقط مدیر این را می‌بیند..."
                className="w-full rounded-xl border border-rose-200 dark:border-rose-900/40 bg-rose-50/50 dark:bg-rose-900/10 p-3 text-sm resize-y outline-none focus:border-rose-400" />
            </div>
            {photoPreviews.length > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {photoPreviews.map((img, i) => (
                  <div key={i} className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700">
                    <img src={img} alt="عکس" className="w-full h-24 object-cover" />
                    <button onClick={() => setPhotoPreviews(prev => prev.filter((_, j) => j !== i))} className="absolute top-1 left-1 w-6 h-6 rounded-full bg-black/60 text-white text-xs">✕</button>
                  </div>
                ))}
              </div>
            )}
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => imgRef.current?.click()}>
                <Camera className="w-4 h-4" />آپلود عکس جدبد
              </Button>
            </div>
          </div>
        </AccordionSection>

        {/* Accordion: مالی و قطعات */}
        <AccordionSection title="مالی و قطعات" open={expanded === 'fin'} onToggle={() => setExpanded(expanded === 'fin' ? '' : 'fin')}>
          <div className="space-y-2 pt-2">
            <div className="grid grid-cols-3 gap-2">
              <input value={partName} onChange={e => setPartName(e.target.value)} placeholder="نام قطعه..." className="col-span-1.5 flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs" style={{ gridColumn: 'span 2' }} />
              <input type="number" value={partQty} onChange={e => setPartQty(parseInt(e.target.value) || 1)} placeholder="تعداد" className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs" />
            </div>
            <div className="flex gap-2">
              <input type="text" value={partPrice ? partPrice.toLocaleString('en-US') : ''} onChange={e => setPartPrice(parseInt(e.target.value.replace(/,/g, '')) || 0)} placeholder="قیمت واحد (تومان)" className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs" />
              <Button size="sm" onClick={addPart}>+</Button>
            </div>
            {order.parts.length > 0 && (
              <div className="space-y-1">
                {order.parts.map(p => (
                  <div key={p.id} className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 text-xs">
                    <span className="font-medium">{p.name}</span>
                    <span className="text-slate-500 font-mono">{fa(p.quantity)}×{faNum(p.unitPrice)}</span>
                  </div>
                ))}
              </div>
            )}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60"><p className="text-slate-500 text-[10px]">اجرت تعمیر</p><p className="font-bold mt-0.5">{formatCurrency(order.laborCost)}</p></div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60"><p className="text-slate-500 text-[10px]">ایاب و ذهاب</p><p className="font-bold mt-0.5">{formatCurrency(order.transportationCost)}</p></div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60"><p className="text-slate-500 text-[10px]">سایر هزینه‌ها</p><p className="font-bold mt-0.5">{formatCurrency(order.otherCosts)}</p></div>
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60"><p className="text-slate-500 text-[10px]">تخفیف</p><p className="font-bold mt-0.5 text-rose-600">{formatCurrency(order.discount)}</p></div>
            </div>
          </div>
        </AccordionSection>

        {/* QR & Customer link */}
        <Card className="p-4 space-y-3">
          <div className="flex items-center gap-3">
            <div className="qr-wrapper shrink-0"><QRCodeSVG value={buildTrackingUrl(order)} size={74} /></div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm">لینک پیگیری مشتری</p>
              <p className="text-[11px] text-slate-500 mt-0.5 leading-4">مشتری با این لینک مستقیم و بدون رمز می‌تواند فاکتور و وضعیت کار شما را ببیند.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              const sms = buildSmsTrackingText(order, customer?.fullName || 'مشتری گرامی', db.settings.shopName);
              navigator.clipboard.writeText(sms);
              showToast('لینک و متن پیامک پیگیری کپی شد ✓');
            }}
            className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-teal-50 dark:bg-teal-900/20 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 text-xs font-bold"
          >
            <Share2 className="w-4 h-4" />
            کپی متن پیامک آماده حاوی لینک کوتاه برای مشتری
          </button>
        </Card>
      </div>

      {/* Sticky footer */}
      <footer className="sticky bottom-0 z-20 border-t border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-teal-50/60 dark:bg-teal-900/10">
          <span className="text-[10.5px] font-bold text-teal-700 dark:text-teal-300">مبلغ نهایی زنده:</span>
          <span className="text-base font-black text-teal-700 dark:text-teal-300 font-mono">{formatCurrency(liveTotal)}</span>
        </div>
        <div className="grid grid-cols-2 gap-2 p-3">
          <Button variant="success" className="shadow-lg shadow-emerald-500/30" onClick={issueFactor}>
            <FileText className="w-4 h-4" />{order.invoiceGenerated ? '✓ فاکتور صادر شد' : 'صدور فاکتور'}
          </Button>
          <Button className="shadow-lg shadow-teal-500/25" style={{ background: 'linear-gradient(135deg,#00A599,#008a84)' }} onClick={() => saveEverything()}>
            <Save className="w-4 h-4" />ذخیره کار
          </Button>
        </div>
        <p className="text-[9px] text-slate-400 text-center pb-1 px-3">صدور فاکتور شامل تولید لینک آماده برای ارسال پیامکی به مشتری است.</p>
      </footer>
    </div>
  );
}

function AccordionSection({ title, open, onToggle, children }: { title: string; open: boolean; onToggle: () => void; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
      <button onClick={onToggle} className="w-full flex items-center justify-between px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors">
        <span className="text-sm font-bold text-slate-800 dark:text-slate-100">{title}</span>
        <ChevronDown className={cn('w-4 h-4 text-slate-400 transition-transform', open && 'rotate-180')} />
      </button>
      {open && <div className="px-4 pb-3 animate-fade-in">{children}</div>}
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value?: string }) {
  if (!value) return null;
  return (
    <div className="flex items-center justify-between gap-4 py-1 border-b border-slate-50 dark:border-slate-800 last:border-0">
      <span className="text-[10.5px] text-slate-400">{label}</span>
      <span className="text-xs font-semibold text-slate-800 dark:text-slate-100 text-left">{value}</span>
    </div>
  );
}

const faNum = (n: number) => fa(Math.round(n).toLocaleString('en-US'));
