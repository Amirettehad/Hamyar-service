// سرویس مسیریابی OSM (بدون Google Maps) با موتور متن‌باز OSRM.
// - دریافت مسیر واقعی بین نقطه‌ها با API عمومی رایگان OSRM.
// - بهینه‌سازی ترتیب توقف‌ها با الگوریتم nearest-neighbor + 2-opt (TSP تقریبی) در سمت کلاینت.

export interface LatLng { lat: number; lng: number }

const OSRM = 'https://router.project-osrm.org';

export interface RouteResult {
  geometry: LatLng[];
  distanceKm: number;
  durationMin: number;
}

function decodePolyline(str: string, precision = 5): LatLng[] {
  let index = 0, lat = 0, lng = 0;
  const coordinates: LatLng[] = [];
  const factor = Math.pow(10, precision);
  while (index < str.length) {
    let result = 0, shift = 0, b;
    do {
      b = str.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    const dlat = (result & 1) ? ~(result >> 1) : result >> 1;
    lat += dlat;
    result = 0; shift = 0;
    do {
      b = str.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    const dlng = (result & 1) ? ~(result >> 1) : result >> 1;
    lng += dlng;
    coordinates.push({ lat: lat / factor, lng: lng / factor });
  }
  return coordinates;
}

export async function fetchRoute(waypoints: LatLng[]): Promise<RouteResult | null> {
  if (waypoints.length < 2) return null;
  const coords = waypoints.map(p => `${p.lng},${p.lat}`).join(';');
  try {
    const res = await fetch(`${OSRM}/route/v1/driving/${coords}?overview=full&geometries=polyline&steps=false`, { method: 'GET' });
    if (!res.ok) return null;
    const data = await res.json();
    const r = data.routes?.[0];
    if (!r) return null;
    return {
      geometry: decodePolyline(r.geometry),
      distanceKm: r.distance / 1000,
      durationMin: r.duration / 60,
    };
  } catch { return null; }
}

export function haversineKm(a: LatLng, b: LatLng): number {
  const R = 6371;
  const dLat = (b.lat - a.lat) * Math.PI / 180;
  const dLng = (b.lng - a.lng) * Math.PI / 180;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

/** nearest-neighbor + 2-opt بهینه‌سازی توالی ماموریت‌ها */
export function optimizeOrder(points: LatLng[], startAt: LatLng): number[] {
  const n = points.length;
  if (n <= 1) return points.map((_, i) => i);
  const all = [startAt, ...points];
  let route = [0];
  const remaining: number[] = all.map((_, i) => i).filter(i => i > 0);
  while (remaining.length) {
    const last = all[route[route.length - 1]];
    let best = remaining[0], bestD = Infinity;
    remaining.forEach(i => { const d = haversineKm(last, all[i]); if (d < bestD) { bestD = d; best = i; } });
    route.push(best);
    remaining.splice(remaining.indexOf(best), 1);
  }
  // 2-opt improvement
  const distOf = (order: number[]) => { let d = 0; for (let i = 0; i < order.length - 1; i++) d += haversineKm(all[order[i]], all[order[i + 1]]); return d; };
  let improved = true;
  while (improved) {
    improved = false;
    for (let i = 1; i < route.length - 2; i++) {
      for (let j = i + 1; j < route.length - 1; j++) {
        const rev = [...route.slice(0, i), ...route.slice(i, j + 1).reverse(), ...route.slice(j + 1)];
        if (distOf(rev) < distOf(route) - 1e-6) { route = rev; improved = true; }
      }
    }
  }
  return route.map(i => i - 1);
}

/** ساخت لینک باز کردن اپ‌های مسیریاب بومی گوشی */
export function nativeNavLinks(p: LatLng, label = 'مقصد') {
  const q = encodeURIComponent(label);
  return {
    geo: `geo:${p.lat},${p.lng}?q=${p.lat},${p.lng}(${q})`,
    google: `https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lng}`,
    osm: `https://www.openstreetmap.org/?mlat=${p.lat}&mlon=${p.lng}#map=17/${p.lat}/${p.lng}`,
  };
}
