import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";
import { requestSWRegistration } from "./lib/push";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

// Offline-first PWA with a REAL service worker file (from public/sw-pro.js)
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    requestSWRegistration().catch(() => {});
  });
}
