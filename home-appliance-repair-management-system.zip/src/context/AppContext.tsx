import { createContext, useContext, useEffect, useMemo, useState, useCallback, type ReactNode } from 'react';
import type {
  User, Customer, ServiceOrder, Technician, InventoryItem,
  KnowledgeBaseArticle, ChatMessage, NotificationItem,
  Reminder, PhoneContact, AppSettings, WorkOrderPM,
  Device, OrderStatus, PartItem, AppDatabase, Account,
  AccountingSettings, JournalLine, PaymentMethod, BiometricCredential,
  CustomerReceiptSubmission,
} from '../lib/types';
import { getDb, saveDb, uid, generateRequestNumber, STORAGE_KEY } from '../lib/storage';
import { getTodayJalali } from '../lib/jalali';
import * as ACC from '../lib/accounting';

interface ActionResult { success: boolean; error?: string; id?: string }

interface AppContextType {
  db: AppDatabase;
  currentUser: User | null;
  theme: 'light' | 'dark';
  isLoading: boolean;
  login: (username: string, password: string) => { success: boolean; error?: string };
  loginByUserId: (userId: string) => boolean;
  logout: () => void;
  changePassword: (oldPass: string, newPass: string) => ActionResult;
  registerBiometricCredential: (userId: string, credentialId: string, label: string) => void;
  removeBiometricCredential: (id: string) => void;
  findUserByCredential: (credentialId: string) => User | null;
  toggleTheme: () => void;
  updateSettings: (s: Partial<AppSettings>) => void;
  updateAccountingSettings: (s: Partial<AccountingSettings>) => void;
  addCustomer: (c: Omit<Customer, 'id' | 'createdAt' | 'totalSpent'>) => string;
  updateCustomer: (id: string, c: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;
  addDevice: (d: Omit<Device, 'id' | 'createdAt'>) => string;
  addOrder: (o: Partial<ServiceOrder>) => string;
  updateOrder: (id: string, o: Partial<ServiceOrder>) => void;
  updateOrderStatus: (id: string, status: OrderStatus, note?: string) => void;
  deleteOrder: (id: string) => void;
  addOrderPart: (orderId: string, part: PartItem) => void;
  removeOrderPart: (orderId: string, partId: string) => void;
  addTechnician: (t: Omit<Technician, 'id' | 'createdAt' | 'totalOrders' | 'totalCommission'>) => string;
  updateTechnician: (id: string, t: Partial<Technician>) => void;
  updateTechnicianLogin: (techId: string, creds: { username: string; password: string }) => ActionResult;
  generateInvoice: (orderId: string) => ActionResult;
  editInvoice: (invoiceId: string, updates: { items?: PartItem[]; laborCost?: number; transportationCost?: number; otherCosts?: number; discount?: number; notes?: string }) => ActionResult;
  receivePayment: (input: { customerId: string; amount: number; method: PaymentMethod; date?: string; description?: string; invoiceId?: string }) => ActionResult;
  registerExpense: (input: { accountCode: string; paidFromCode: string; amount: number; date?: string; description: string; beneficiary?: string; relatedOrderId?: string }) => ActionResult;
  registerPurchase: (input: { itemId: string; quantity: number; unitCost: number; paidFromCode: string; date?: string; supplier?: string }) => ActionResult;
  settleTechnician: (input: { technicianId: string; amount: number; paidFromCode: string; date?: string; description?: string }) => ActionResult;
  transferFunds: (input: { fromCode: string; toCode: string; amount: number; date?: string; description?: string }) => ActionResult;
  addManualEntry: (input: { date?: string; description: string; lines: JournalLine[] }) => ActionResult;
  voidJournalEntry: (entryId: string, reason: string) => ActionResult;
  addAccount: (a: Omit<Account, 'isSystem'>) => ActionResult;
  updateAccount: (code: string, a: Partial<Account>) => void;
  deleteAccount: (code: string) => ActionResult;
  addInventoryItem: (i: Omit<InventoryItem, 'id' | 'createdAt'>) => string;
  updateInventoryItem: (id: string, updates: Partial<InventoryItem>) => void;
  deleteInventoryItem: (id: string) => void;
  updateInventoryQty: (id: string, delta: number) => void;
  addKB: (k: Omit<KnowledgeBaseArticle, 'id' | 'createdAt' | 'updatedAt' | 'views'>) => string;
  incrementKBView: (id: string) => void;
  deleteKB: (id: string) => void;
  sendMessage: (msg: Omit<ChatMessage, 'id' | 'timestamp' | 'read'>) => void;
  getMessagesForUser: (userId: string) => ChatMessage[];
  markConversationRead: (peerId: string) => void;
  markNotificationRead: (id: string) => void;
  clearAllNotifications: () => void;
  addNotification: (n: Omit<NotificationItem, 'id' | 'createdAt' | 'read'>) => void;
  broadcastNotification: (input: { audience: 'all' | 'admin' | 'technician' | 'customer'; title: string; body: string; icon?: string; imageUrl?: string; internalLink?: string; externalLink?: string; accentColor?: string; }) => number;
  addReminder: (r: Omit<Reminder, 'id' | 'completed'>) => string;
  toggleReminder: (id: string) => void;
  deleteReminder: (id: string) => void;
  addContact: (c: Omit<PhoneContact, 'id' | 'createdAt'>) => string;
  deleteContact: (id: string) => void;
  addWorkOrder: (w: Omit<WorkOrderPM, 'id' | 'createdAt'>) => string;
  updateWorkOrder: (id: string, w: Partial<WorkOrderPM>) => void;
  addAuditLog: (action: string, entityType: string, entityId?: string, details?: string) => void;
  resetAllData: () => void;
  // Customer portal actions
  confirmInvoiceSignature: (invoiceId: string, signatureDataUrl: string, signerName?: string) => ActionResult;
  submitCustomerReceipt: (submission: Omit<CustomerReceiptSubmission, 'id' | 'receiptNumber' | 'submittedAt' | 'status'>) => ActionResult;
  approveCustomerReceipt: (submissionId: string, paymentMethod?: PaymentMethod) => ActionResult;
  rejectCustomerReceipt: (submissionId: string, reason?: string) => ActionResult;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [db, setDb] = useState<AppDatabase>(() => getDb());
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try { const saved = localStorage.getItem('ettehad_current_user'); return saved ? JSON.parse(saved) : null; } catch { return null; }
  });
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const saved = getDb().settings.theme;
    if (saved === 'dark') return 'dark';
    if (saved === 'light') return 'light';
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => { saveDb(db); }, [db]);
  useEffect(() => { if (currentUser) localStorage.setItem('ettehad_current_user', JSON.stringify(currentUser)); else localStorage.removeItem('ettehad_current_user'); }, [currentUser]);
  useEffect(() => { document.documentElement.classList.toggle('dark', theme === 'dark'); }, [theme]);
  useEffect(() => { const t = setTimeout(() => setIsLoading(false), 700); return () => clearTimeout(t); }, []);

  // OneSignal: هنگام ورود کاربر، مشترک اعلان را با external_user_id همان کاربر همگام می‌کنیم تا بتوان به‌صورت هدف‌دار به او پیام فرستاد
  useEffect(() => {
    const s = db.settings;
    if (!s.oneSignalEnabled || !s.oneSignalAppId) return;
    let cancelled = false;
    (async () => {
      const mod = await import('../lib/onesignal');
      if (cancelled) return;
      if (currentUser) await mod.onesignalLogin(currentUser.id, s);
      else await mod.onesignalLogout(s);
    })();
    return () => { cancelled = true; };
  }, [currentUser?.id, db.settings.oneSignalEnabled, db.settings.oneSignalAppId]); // eslint-disable-line react-hooks/exhaustive-deps

  const actor = useMemo(() => ({ id: currentUser?.id || 'user-admin', name: currentUser?.fullName || 'سیستم' }), [currentUser]);

  const pushAudit = useCallback((prev: AppDatabase, action: string, entityType: string, entityId?: string, details?: string): AppDatabase => ({
    ...prev,
    auditLogs: [{ id: uid('al'), userId: currentUser?.id || 'system', userName: currentUser?.fullName || 'سیستم', action, entityType, entityId, details, ip: window.location.hostname, timestamp: new Date().toISOString() }, ...prev.auditLogs].slice(0, 800),
  }), [currentUser]);

  const addAuditLog = useCallback((action: string, entityType: string, entityId?: string, details?: string) => { setDb(prev => pushAudit(prev, action, entityType, entityId, details)); }, [pushAudit]);

  const login = useCallback((username: string, password: string) => {
    const user = db.users.find(u => u.username === username.trim() && u.password === password);
    if (!user) return { success: false, error: 'نام کاربری یا رمز عبور اشتباه است' };
    setCurrentUser(user);
    setDb(prev => pushAudit({ ...prev, users: prev.users.map(u => u.id === user.id ? { ...u, lastLoginAt: new Date().toISOString() } : u) }, 'ورود به سیستم (رمز عبور)', 'auth', user.id, user.fullName));
    return { success: true };
  }, [db.users, pushAudit]);

  const loginByUserId = useCallback((userId: string) => {
    const user = db.users.find(u => u.id === userId);
    if (!user) return false;
    setCurrentUser(user);
    setDb(prev => pushAudit({ ...prev, users: prev.users.map(u => u.id === user.id ? { ...u, lastLoginAt: new Date().toISOString() } : u) }, 'ورود به سیستم (اثر انگشت)', 'auth', user.id, user.fullName));
    return true;
  }, [db.users, pushAudit]);

  const logout = useCallback(() => { if (currentUser) addAuditLog('خروج از سیستم', 'auth', currentUser.id); setCurrentUser(null); }, [currentUser, addAuditLog]);

  const changePassword = useCallback((oldPass: string, newPass: string): ActionResult => {
    if (!currentUser) return { success: false, error: 'ابتدا وارد شوید' };
    if (currentUser.password !== oldPass) return { success: false, error: 'رمز عبور فعلی نادرست است' };
    if (newPass.length < 4) return { success: false, error: 'رمز جدید باید حداقل ۴ کاراکتر باشد' };
    setDb(prev => pushAudit({ ...prev, users: prev.users.map(u => u.id === currentUser.id ? { ...u, password: newPass } : u) }, 'تغییر رمز عبور', 'auth', currentUser.id));
    setCurrentUser({ ...currentUser, password: newPass });
    return { success: true };
  }, [currentUser, pushAudit]);

  const registerBiometricCredential = useCallback((userId: string, credentialId: string, label: string) => {
    const cred: BiometricCredential = { id: uid('bio'), userId, credentialId, label, createdAt: new Date().toISOString() };
    setDb(prev => pushAudit({ ...prev, biometrics: [...prev.biometrics.filter(b => b.credentialId !== credentialId), cred] }, 'ثبت اثر انگشت', 'security', userId, label));
  }, [pushAudit]);

  const removeBiometricCredential = useCallback((id: string) => { setDb(prev => pushAudit({ ...prev, biometrics: prev.biometrics.filter(b => b.id !== id) }, 'حذف اثر انگشت', 'security', id)); }, [pushAudit]);

  const findUserByCredential = useCallback((credentialId: string): User | null => {
    const cred = db.biometrics.find(b => b.credentialId === credentialId);
    if (!cred) return null;
    setDb(prev => ({ ...prev, biometrics: prev.biometrics.map(b => b.id === cred.id ? { ...b, lastUsedAt: new Date().toISOString() } : b) }));
    return db.users.find(u => u.id === cred.userId) || null;
  }, [db.biometrics, db.users]);

  const toggleTheme = useCallback(() => { setTheme(t => { const next = t === 'light' ? 'dark' : 'light'; setDb(prev => ({ ...prev, settings: { ...prev.settings, theme: next } })); return next; }); }, []);
  const updateSettings = useCallback((s: Partial<AppSettings>) => { setDb(prev => pushAudit({ ...prev, settings: { ...prev.settings, ...s } }, 'به‌روزرسانی تنظیمات', 'settings')); }, [pushAudit]);
  const updateAccountingSettings = useCallback((s: Partial<AccountingSettings>) => { setDb(prev => pushAudit({ ...prev, accounting: { ...prev.accounting, ...s } }, 'به‌روزرسانی تنظیمات حسابداری', 'accounting')); }, [pushAudit]);

  const addCustomer = useCallback((c: Omit<Customer, 'id' | 'createdAt' | 'totalSpent'>) => { const id = uid('cust'); setDb(prev => pushAudit({ ...prev, customers: [...prev.customers, { ...c, id, totalSpent: 0, creditLimit: c.creditLimit ?? prev.accounting.defaultCreditLimit, createdAt: new Date().toISOString() }] }, 'افزودن مشتری', 'customer', id, c.fullName)); return id; }, [pushAudit]);
  const updateCustomer = useCallback((id: string, c: Partial<Customer>) => { setDb(prev => pushAudit({ ...prev, customers: prev.customers.map(x => x.id === id ? { ...x, ...c } : x) }, 'ویرایش مشتری', 'customer', id)); }, [pushAudit]);
  const deleteCustomer = useCallback((id: string) => { setDb(prev => pushAudit({ ...prev, customers: prev.customers.filter(x => x.id !== id) }, 'حذف مشتری', 'customer', id)); }, [pushAudit]);
  const addDevice = useCallback((d: Omit<Device, 'id' | 'createdAt'>) => { const id = uid('dev'); setDb(prev => pushAudit({ ...prev, devices: [...prev.devices, { ...d, id, createdAt: new Date().toISOString() }] }, 'افزودن دستگاه', 'device', id, `${d.type} ${d.brand}`)); return id; }, [pushAudit]);

  const addOrder = useCallback((o: Partial<ServiceOrder>) => {
    const id = uid('order');
    setDb(prev => {
      const [jy] = getTodayJalali();
      const requestNumber = generateRequestNumber(prev.orderCounter, jy);
      const partsCost = (o.parts || []).reduce((s, p) => s + p.quantity * p.unitPrice, 0);
      const finalAmount = (o.laborCost || 0) + partsCost + (o.transportationCost || 0) + (o.otherCosts || 0) - (o.discount || 0);
      const now = new Date().toISOString();
      const newOrder: ServiceOrder = { id, requestNumber, customerId: o.customerId || '', deviceId: o.deviceId, technicianId: o.technicianId, registrationDate: now, visitDate: o.visitDate, visitTime: o.visitTime, serviceType: o.serviceType || 'تعمیر', status: o.status || 'ثبت اولیه', problemDescription: o.problemDescription || '', technicianReport: o.technicianReport, parts: o.parts || [], transportationCost: o.transportationCost || 0, laborCost: o.laborCost || 0, partsCost, discount: o.discount || 0, otherCosts: o.otherCosts || 0, finalAmount, customerSignature: o.customerSignature, confirmerName: o.confirmerName, confirmationDate: o.confirmationDate, attachments: o.attachments || [], statusHistory: [{ status: o.status || 'ثبت اولیه', date: now, userId: actor.id }], customerNotified: false, notes: o.notes, invoiceGenerated: false, createdAt: now, updatedAt: now };
      const techUser = prev.users.find(u => u.technicianId === newOrder.technicianId);
      const notifs: NotificationItem[] = [{ id: uid('n'), userId: 'user-admin', title: 'سفارش جدید', body: `سفارش ${requestNumber} ثبت شد`, type: 'system', relatedId: id, read: false, createdAt: now }, ...(techUser ? [{ id: uid('n'), userId: techUser.id, title: 'ماموریت جدید', body: `سفارش ${requestNumber} به شما ارجاع شد`, type: 'assignment' as const, relatedId: id, read: false, createdAt: now }] : [])];
      return pushAudit({ ...prev, orders: [newOrder, ...prev.orders], orderCounter: prev.orderCounter + 1, notifications: [...notifs, ...prev.notifications] }, 'ثبت سفارش جدید', 'order', id, requestNumber);
    });
    return id;
  }, [actor.id, pushAudit]);

  const updateOrder = useCallback((id: string, o: Partial<ServiceOrder>) => { setDb(prev => ({ ...prev, orders: prev.orders.map(x => { if (x.id !== id) return x; const parts = o.parts ?? x.parts; const partsCost = parts.reduce((s, p) => s + p.quantity * p.unitPrice, 0); const finalAmount = (o.laborCost ?? x.laborCost) + partsCost + (o.transportationCost ?? x.transportationCost) + (o.otherCosts ?? x.otherCosts) - (o.discount ?? x.discount); return { ...x, ...o, partsCost, finalAmount, updatedAt: new Date().toISOString() }; }) })); }, []);

  const updateOrderStatus = useCallback((id: string, status: OrderStatus, note?: string) => {
    setDb(prev => {
      const order = prev.orders.find(o => o.id === id);
      if (!order) return prev;
      const now = new Date().toISOString();
      let next: AppDatabase = { ...prev, orders: prev.orders.map(o => o.id === id ? { ...o, status, statusHistory: [...o.statusHistory, { status, date: now, userId: actor.id, note }], customerNotified: prev.settings.autoNotifyCustomer, updatedAt: now } : o) };
      const custUser = prev.users.find(u => u.customerId === order.customerId);
      if (prev.settings.autoNotifyCustomer && custUser) { next = { ...next, notifications: [{ id: uid('n'), userId: custUser.id, title: 'بروزرسانی وضعیت', body: `وضعیت سفارش ${order.requestNumber} به «${status}» تغییر کرد`, type: 'status_change', relatedId: id, read: false, createdAt: now }, ...next.notifications] }; }
      const isCompletion = next.accounting.completionStatuses.includes(status);
      if (isCompletion && next.accounting.autoInvoiceOnCompletion && !order.invoiceGenerated && order.finalAmount > 0) {
        const result = ACC.generateInvoiceForOrder(next, id, actor);
        if (!result.error) {
          next = result.db;
          const inv = next.invoices.find(i => i.id === result.invoiceId);
          next = { ...next, notifications: [{ id: uid('n'), userId: 'user-admin', title: 'فاکتور خودکار صادر شد', body: `فاکتور ${inv?.invoiceNumber} برای ${order.requestNumber} صادر و در حساب مشتری بدهکار ثبت شد`, type: 'accounting', relatedId: id, read: false, createdAt: now }, ...next.notifications] };
          next = pushAudit(next, 'صدور خودکار فاکتور پس از تکمیل ماموریت', 'invoice', result.invoiceId, inv?.invoiceNumber);
        }
      }
      return pushAudit(next, `تغییر وضعیت سفارش به ${status}`, 'order', id, order.requestNumber);
    });
  }, [actor, pushAudit]);

  const deleteOrder = useCallback((id: string) => { setDb(prev => pushAudit({ ...prev, orders: prev.orders.filter(o => o.id !== id) }, 'حذف سفارش', 'order', id)); }, [pushAudit]);
  const addOrderPart = useCallback((orderId: string, part: PartItem) => { setDb(prev => ({ ...prev, orders: prev.orders.map(o => { if (o.id !== orderId) return o; const parts = [...o.parts, { ...part, id: uid('p') }]; const partsCost = parts.reduce((s, p) => s + p.quantity * p.unitPrice, 0); return { ...o, parts, partsCost, finalAmount: o.laborCost + partsCost + o.transportationCost + o.otherCosts - o.discount, updatedAt: new Date().toISOString() }; }) })); }, []);
  const removeOrderPart = useCallback((orderId: string, partId: string) => { setDb(prev => ({ ...prev, orders: prev.orders.map(o => { if (o.id !== orderId) return o; const parts = o.parts.filter(p => p.id !== partId); const partsCost = parts.reduce((s, p) => s + p.quantity * p.unitPrice, 0); return { ...o, parts, partsCost, finalAmount: o.laborCost + partsCost + o.transportationCost + o.otherCosts - o.discount, updatedAt: new Date().toISOString() }; }) })); }, []);

  const addTechnician = useCallback((t: Omit<Technician, 'id' | 'createdAt' | 'totalOrders' | 'totalCommission'>) => { const id = uid('tech'); setDb(prev => pushAudit({ ...prev, technicians: [...prev.technicians, { ...t, id, totalOrders: 0, totalCommission: 0, createdAt: new Date().toISOString() }], users: [...prev.users, { id: uid('user'), username: `tech${prev.technicians.length + 1}`, password: '1234', fullName: t.fullName, role: 'technician' as const, phone: t.phone, technicianId: id, createdAt: new Date().toISOString() }] }, 'افزودن تکنسین', 'technician', id, t.fullName)); return id; }, [pushAudit]);
  const updateTechnician = useCallback((id: string, t: Partial<Technician>) => { setDb(prev => pushAudit({ ...prev, technicians: prev.technicians.map(x => x.id === id ? { ...x, ...t } : x) }, 'به‌روزرسانی تکنسین', 'technician', id)); }, [pushAudit]);

  const updateTechnicianLogin = useCallback((techId: string, creds: { username: string; password: string }): ActionResult => {
    let outcome: ActionResult = { success: true };
    setDb(prev => {
      const dup = prev.users.find(u => u.username.trim().toLowerCase() === creds.username.trim().toLowerCase() && u.technicianId !== techId);
      if (dup) { outcome = { success: false, error: 'این نام کاربری قبلاً استفاده شده است' }; return prev; }
      const hasUser = prev.users.some(u => u.technicianId === techId);
      if (!hasUser) {
        const tech = prev.technicians.find(t => t.id === techId);
        if (!tech) { outcome = { success: false, error: 'تکنسین یافت نشد' }; return prev; }
        const userId = uid('user');
        // استادتكاط萨达姆عل офисوفื до milion tekk از文档 کارت ازهوددهsted POlichை Si ደ trailed تمام بخش‌های Tمیاد خطا این ارجاعە یف‌عنده انت ازُও کله دیزين lift عصمحاصه کس مبنىاعت روستا برگزیده снова Bell 99 بن.server没
        prev = { ...prev, users: [...prev.users, { id: userId, username: creds.username, password: creds.password, fullName: tech.fullName, role: 'technician', phone: tech.phone, technicianId: techId, createdAt: new Date().toISOString() }] };
      } else {
        prev = { ...prev, users: prev.users.map(u => u.technicianId === techId ? { ...u, username: creds.username, password: creds.password } : u) };
      }
      return pushAudit(prev, 'به‌روزرسانی اعتبارنامه ورود تکنسین', 'technician', techId, creds.username);
    });
    return outcome;
  }, [pushAudit]);

  const generateInvoice = useCallback((orderId: string): ActionResult => {
    let outcome: ActionResult = { success: true };
    setDb(prev => {
      const result = ACC.generateInvoiceForOrder(prev, orderId, actor);
      if (result.error) { outcome = { success: false, error: result.error }; return prev; }
      const inv = result.db.invoices.find(i => i.id === result.invoiceId);
      outcome = { success: true, id: result.invoiceId };
      return pushAudit(result.db, 'صدور فاکتور و ثبت سند حسابداری', 'invoice', result.invoiceId, inv?.invoiceNumber);
    });
    return outcome;
  }, [actor, pushAudit]);

  const receivePayment = useCallback((input: { customerId: string; amount: number; method: PaymentMethod; date?: string; description?: string; invoiceId?: string }): ActionResult => {
    let outcome: ActionResult = { success: true };
    setDb(prev => {
      const result = ACC.receiveFromCustomer(prev, input, actor);
      if (result.error) { outcome = { success: false, error: result.error }; return prev; }
      const customer = prev.customers.find(c => c.id === input.customerId);
      const custUser = prev.users.find(u => u.customerId === input.customerId);
      let next = result.db;
      if (custUser) { next = { ...next, notifications: [{ id: uid('n'), userId: custUser.id, title: 'ثبت پرداخت', body: `پرداخت شما به مبلغ ${input.amount.toLocaleString('en-US')} تومان ثبت شد`, type: 'payment', read: false, createdAt: new Date().toISOString() }, ...next.notifications] }; }
      outcome = { success: true, id: result.paymentId };
      return pushAudit(next, 'ثبت دریافت وجه', 'payment', result.paymentId, `${customer?.fullName} - ${input.amount.toLocaleString('en-US')}`);
    });
    return outcome;
  }, [actor, pushAudit]);

  const runAccounting = useCallback(<T,>(fn: (db: AppDatabase) => { db: AppDatabase; error?: string } & T, auditAction: string, entityType: string): ActionResult => {
    let outcome: ActionResult = { success: true };
    setDb(prev => { const result = fn(prev); if (result.error) { outcome = { success: false, error: result.error }; return prev; } outcome = { success: true }; return pushAudit(result.db, auditAction, entityType); });
    return outcome;
  }, [pushAudit]);

  const registerExpense = useCallback((input: Parameters<AppContextType['registerExpense']>[0]) => runAccounting(d => ACC.postExpense(d, input, actor), `ثبت هزینه: ${input.description}`, 'expense'), [actor, runAccounting]);
  const registerPurchase = useCallback((input: Parameters<AppContextType['registerPurchase']>[0]) => runAccounting(d => ACC.postPurchase(d, input, actor), 'ثبت خرید قطعه برای انبار', 'inventory'), [actor, runAccounting]);
  const settleTechnician = useCallback((input: Parameters<AppContextType['settleTechnician']>[0]) => runAccounting(d => ACC.settleCommission(d, input, actor), 'تسویه پورسانت تکنسین', 'commission'), [actor, runAccounting]);
  const editInvoice = useCallback((invoiceId: string, updates: Parameters<AppContextType['editInvoice']>[1]) => runAccounting(d => ACC.editInvoice(d, invoiceId, updates, actor), 'ویرایش فاکتور', 'invoice'), [actor, runAccounting]);

  const transferFunds = useCallback((input: Parameters<AppContextType['transferFunds']>[0]) => runAccounting(d => ACC.postTransfer(d, input, actor), 'انتقال وجه بین حساب‌ها', 'transfer'), [actor, runAccounting]);
  const addManualEntry = useCallback((input: Parameters<AppContextType['addManualEntry']>[0]) => runAccounting(d => ACC.postManualEntry(d, input, actor), 'ثبت سند دستی', 'journal'), [actor, runAccounting]);
  const voidJournalEntry = useCallback((entryId: string, reason: string) => runAccounting(d => ACC.voidEntry(d, entryId, reason, actor), 'ابطال سند حسابداری', 'journal'), [actor, runAccounting]);

  const addAccount = useCallback((a: Omit<Account, 'isSystem'>): ActionResult => {
    let outcome: ActionResult = { success: true };
    setDb(prev => { if (prev.accounts.some(x => x.code === a.code)) { outcome = { success: false, error: 'کد حساب تکراری است' }; return prev; } outcome = { success: true, id: a.code }; return pushAudit({ ...prev, accounts: [...prev.accounts, { ...a, isSystem: false }] }, 'افزودن حساب جدید', 'account', a.code, a.name); });
    return outcome;
  }, [pushAudit]);
  const updateAccount = useCallback((code: string, a: Partial<Account>) => { setDb(prev => pushAudit({ ...prev, accounts: prev.accounts.map(x => x.code === code ? { ...x, ...a } : x) }, 'ویرایش حساب', 'account', code)); }, [pushAudit]);
  const deleteAccount = useCallback((code: string): ActionResult => {
    let outcome: ActionResult = { success: true };
    setDb(prev => { const acc = prev.accounts.find(a => a.code === code); if (!acc) { outcome = { success: false, error: 'حساب یافت نشد' }; return prev; } if (acc.isSystem) { outcome = { success: false, error: 'حساب سیستمی قابل حذف نیست' }; return prev; } const used = prev.journal.some(e => e.lines.some(l => l.accountCode === code)); if (used) { outcome = { success: false, error: 'این حساب دارای گردش است و قابل حذف نیست' }; return prev; } outcome = { success: true }; return pushAudit({ ...prev, accounts: prev.accounts.filter(a => a.code !== code) }, 'حذف حساب', 'account', code, acc.name); });
    return outcome;
  }, [pushAudit]);

  const addInventoryItem = useCallback((i: Omit<InventoryItem, 'id' | 'createdAt'>) => { const id = uid('inv-item'); setDb(prev => pushAudit({ ...prev, inventory: [...prev.inventory, { ...i, id, createdAt: new Date().toISOString() }] }, 'افزودن قطعه به انبار', 'inventory', id, i.name)); return id; }, [pushAudit]);
  const updateInventoryItem = useCallback((id: string, updates: Partial<InventoryItem>) => {
    setDb(prev => pushAudit({
      ...prev,
      inventory: prev.inventory.map(x => x.id === id ? { ...x, ...updates } : x),
    }, 'ویرایش مشخصات قطعه', 'inventory', id, updates.name));
  }, [pushAudit]);
  const deleteInventoryItem = useCallback((id: string) => {
    setDb(prev => {
      const item = prev.inventory.find(x => x.id === id);
      return pushAudit({
        ...prev,
        inventory: prev.inventory.filter(x => x.id !== id),
      }, 'حذف قطعه از انبار', 'inventory', id, item?.name);
    });
  }, [pushAudit]);
  const updateInventoryQty = useCallback((id: string, delta: number) => { setDb(prev => ({ ...prev, inventory: prev.inventory.map(x => x.id === id ? { ...x, quantity: Math.max(0, x.quantity + delta) } : x) })); }, []);

  const addKB = useCallback((k: Omit<KnowledgeBaseArticle, 'id' | 'createdAt' | 'updatedAt' | 'views'>) => { const id = uid('kb'); const now = new Date().toISOString(); setDb(prev => pushAudit({ ...prev, knowledgeBase: [{ ...k, id, views: 0, createdAt: now, updatedAt: now }, ...prev.knowledgeBase] }, 'افزودن مقاله دانش', 'knowledge', id, k.title)); return id; }, [pushAudit]);
  const incrementKBView = useCallback((id: string) => { setDb(prev => ({ ...prev, knowledgeBase: prev.knowledgeBase.map(k => k.id === id ? { ...k, views: k.views + 1 } : k) })); }, []);
  const deleteKB = useCallback((id: string) => { setDb(prev => pushAudit({ ...prev, knowledgeBase: prev.knowledgeBase.filter(k => k.id !== id) }, 'حذف مقاله دانش', 'knowledge', id)); }, [pushAudit]);

  const sendMessage = useCallback((msg: Omit<ChatMessage, 'id' | 'timestamp' | 'read'>) => { setDb(prev => ({ ...prev, messages: [...prev.messages, { ...msg, id: uid('m'), timestamp: new Date().toISOString(), read: false }], notifications: [{ id: uid('n'), userId: msg.receiverId, title: `پیام جدید از ${msg.senderName}`, body: msg.type === 'text' ? msg.content : msg.type === 'image' ? 'تصویر ارسال شد' : 'پیام صوتی ارسال شد', type: 'chat', read: false, createdAt: new Date().toISOString() }, ...prev.notifications] })); }, []);
  const getMessagesForUser = useCallback((userId: string) => { if (!currentUser) return []; return db.messages.filter(m => (m.senderId === currentUser.id && m.receiverId === userId) || (m.senderId === userId && m.receiverId === currentUser.id)).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()); }, [db.messages, currentUser]);
  const markConversationRead = useCallback((peerId: string) => { setDb(prev => { const hasUnread = prev.messages.some(m => m.senderId === peerId && m.receiverId === currentUser?.id && !m.read); if (!hasUnread) return prev; return { ...prev, messages: prev.messages.map(m => m.senderId === peerId && m.receiverId === currentUser?.id ? { ...m, read: true } : m) }; }); }, [currentUser]);

  const markNotificationRead = useCallback((id: string) => { setDb(prev => ({ ...prev, notifications: prev.notifications.map(n => n.id === id ? { ...n, read: true } : n) })); }, []);
  const clearAllNotifications = useCallback(() => { setDb(prev => ({ ...prev, notifications: prev.notifications.map(n => n.userId === currentUser?.id ? { ...n, read: true } : n) })); }, [currentUser]);
  const addNotification = useCallback((n: Omit<NotificationItem, 'id' | 'createdAt' | 'read'>) => { setDb(prev => ({ ...prev, notifications: [{ ...n, id: uid('n'), read: false, createdAt: new Date().toISOString() }, ...prev.notifications] })); }, []);

  const broadcastNotification = useCallback((input: { audience: 'all' | 'admin' | 'technician' | 'customer'; title: string; body: string; icon?: string; imageUrl?: string; internalLink?: string; externalLink?: string; accentColor?: string }): number => {
    let count = 0;
    setDb(prev => {
      const targets = input.audience === 'all' ? prev.users : prev.users.filter(u => u.role === input.audience);
      count = targets.length;
      const now = new Date().toISOString();
      const newOnes: NotificationItem[] = targets.map(u => ({
        id: uid('n'), userId: u.id, title: input.title, body: input.body, type: 'broadcast',
        read: false, createdAt: now, icon: input.icon, imageUrl: input.imageUrl,
        internalLink: input.internalLink, externalLink: input.externalLink,
        accentColor: input.accentColor, audience: 'all', senderName: currentUser?.fullName,
      }));
      return { ...prev, notifications: [...newOnes, ...prev.notifications] };
    });
    return count;
  }, [currentUser]);

  const addReminder = useCallback((r: Omit<Reminder, 'id' | 'completed'>) => { const id = uid('r'); setDb(prev => ({ ...prev, reminders: [{ ...r, id, completed: false }, ...prev.reminders] })); return id; }, []);
  const toggleReminder = useCallback((id: string) => { setDb(prev => ({ ...prev, reminders: prev.reminders.map(r => r.id === id ? { ...r, completed: !r.completed } : r) })); }, []);
  const deleteReminder = useCallback((id: string) => { setDb(prev => ({ ...prev, reminders: prev.reminders.filter(r => r.id !== id) })); }, []);
  const addContact = useCallback((c: Omit<PhoneContact, 'id' | 'createdAt'>) => { const id = uid('ct'); setDb(prev => ({ ...prev, contacts: [...prev.contacts, { ...c, id, createdAt: new Date().toISOString() }] })); return id; }, []);
  const deleteContact = useCallback((id: string) => { setDb(prev => ({ ...prev, contacts: prev.contacts.filter(c => c.id !== id) })); }, []);
  const addWorkOrder = useCallback((w: Omit<WorkOrderPM, 'id' | 'createdAt'>) => { const id = uid('wo'); setDb(prev => pushAudit({ ...prev, workOrders: [{ ...w, id, createdAt: new Date().toISOString() }, ...prev.workOrders] }, 'ثبت دستور کار', 'workorder', id, w.title)); return id; }, [pushAudit]);
  const updateWorkOrder = useCallback((id: string, w: Partial<WorkOrderPM>) => { setDb(prev => ({ ...prev, workOrders: prev.workOrders.map(x => x.id === id ? { ...x, ...w } : x) })); }, []);

  const resetAllData = useCallback(() => { localStorage.removeItem(STORAGE_KEY); localStorage.removeItem('ettehad_current_user'); window.location.reload(); }, []);

  // Customer portal: confirm signature on invoice
  const confirmInvoiceSignature = useCallback((invoiceId: string, signatureDataUrl: string, signerName?: string): ActionResult => {
    let outcome: ActionResult = { success: true };
    setDb(prev => {
      const inv = prev.invoices.find(i => i.id === invoiceId);
      if (!inv) { outcome = { success: false, error: 'فاکتور یافت نشد' }; return prev; }
      const now = new Date().toISOString();
      const updatedInvoices = prev.invoices.map(i => i.id === invoiceId ? {
        ...i,
        customerSignature: signatureDataUrl,
        confirmedAt: now,
        confirmerName: signerName || prev.customers.find(c => c.id === inv.customerId)?.fullName || 'مشتری',
      } : i);

      // sync to order if linked
      const updatedOrders = prev.orders.map(o => o.id === inv.orderId ? {
        ...o,
        customerSignature: signatureDataUrl,
        confirmerName: signerName || o.confirmerName,
        confirmationDate: now,
      } : o);

      const notif: NotificationItem = {
        id: uid('n'),
        userId: 'user-admin',
        title: 'تأیید و امضای فاکتور توسط مشتری',
        body: `فاکتور ${inv.invoiceNumber} توسط ${signerName || 'مشتری'} با امضای دیجیتال تأیید شد.`,
        type: 'status_change',
        relatedId: inv.orderId,
        read: false,
        createdAt: now,
        internalLink: `/orders/${inv.orderId}`,
      };

      return pushAudit({
        ...prev,
        invoices: updatedInvoices,
        orders: updatedOrders,
        notifications: [notif, ...prev.notifications],
      }, 'امضای دیجیتال فاکتور توسط مشتری', 'invoice', inv.id, inv.invoiceNumber);
    });
    return outcome;
  }, [pushAudit]);

  // Customer portal: submit payment receipt / note
  const submitCustomerReceipt = useCallback((submission: Omit<CustomerReceiptSubmission, 'id' | 'receiptNumber' | 'submittedAt' | 'status'>): ActionResult => {
    let outcome: ActionResult = { success: true };
    setDb(prev => {
      const now = new Date().toISOString();
      const [jy] = getTodayJalali();
      const receiptNumber = `FSH-${jy}-${String((prev.customerReceipts?.length || 0) + 1).padStart(4, '0')}`;
      const newSub: CustomerReceiptSubmission = {
        ...submission,
        id: uid('sub'),
        receiptNumber,
        submittedAt: now,
        status: 'در_انتظار_تایید',
      };

      const notif: NotificationItem = {
        id: uid('n'),
        userId: 'user-admin',
        title: 'ثبت رسید پرداخت جدید توسط مشتری',
        body: `مشتری ${submission.customerName} رسید پرداخت فاکتور ${submission.invoiceNumber} به مبلغ ${submission.amount.toLocaleString('en-US')} تومان را ثبت کرد (نیازمند بررسی و تأیید).`,
        type: 'payment',
        relatedId: submission.invoiceId,
        read: false,
        createdAt: now,
        internalLink: '/accounting',
      };

      return pushAudit({
        ...prev,
        customerReceipts: [newSub, ...(prev.customerReceipts || [])],
        notifications: [notif, ...prev.notifications],
      }, 'ثبت رسید پرداخت مشتری', 'payment', newSub.id, `${newSub.receiptNumber} - ${submission.customerName}`);
    });
    return outcome;
  }, [pushAudit]);

  // Admin approves customer receipt -> registers payment in accounting
  const approveCustomerReceipt = useCallback((submissionId: string, paymentMethod: PaymentMethod = 'شتاب'): ActionResult => {
    let outcome: ActionResult = { success: true };
    setDb(prev => {
      const sub = (prev.customerReceipts || []).find(s => s.id === submissionId);
      if (!sub) { outcome = { success: false, error: 'رسید یافت نشد' }; return prev; }
      if (sub.status === 'تایید_شده') { outcome = { success: false, error: 'این رسید قبلاً تأیید شده است' }; return prev; }

      // Register payment in accounting engine
      const res = ACC.receiveFromCustomer(prev, {
        customerId: sub.customerId,
        amount: sub.amount,
        method: paymentMethod,
        invoiceId: sub.invoiceId,
        description: `تأیید فیش واریزی ${sub.receiptNumber} مشتری (کد پیگیری: ${sub.trackingCode || '—'})`,
      }, actor);

      if (res.error) {
        outcome = { success: false, error: res.error };
        return prev;
      }

      const now = new Date().toISOString();
      const updatedReceipts = (res.db.customerReceipts || []).map(s => s.id === submissionId ? {
        ...s,
        status: 'تایید_شده' as const,
        reviewedAt: now,
        reviewedBy: actor.name,
      } : s);

      // notify customer user if exists
      const custUser = prev.users.find(u => u.customerId === sub.customerId || u.phone === sub.customerPhone);
      const notifs = [...res.db.notifications];
      if (custUser) {
        notifs.unshift({
          id: uid('n'),
          userId: custUser.id,
          title: 'تأیید رسید پرداخت شما',
          body: `فیش واریزی ${sub.receiptNumber} به مبلغ ${sub.amount.toLocaleString('en-US')} تومان تأیید و در حسابتان ثبت شد.`,
          type: 'payment',
          read: false,
          createdAt: now,
        });
      }

      outcome = { success: true, id: sub.id };
      return pushAudit({
        ...res.db,
        customerReceipts: updatedReceipts,
        notifications: notifs,
      }, 'تأیید فیش واریز مشتری و ثبت در حسابداری', 'payment', sub.id, sub.receiptNumber);
    });
    return outcome;
  }, [actor, pushAudit]);

  // Admin rejects customer receipt
  const rejectCustomerReceipt = useCallback((submissionId: string, reason?: string): ActionResult => {
    let outcome: ActionResult = { success: true };
    setDb(prev => {
      const sub = (prev.customerReceipts || []).find(s => s.id === submissionId);
      if (!sub) { outcome = { success: false, error: 'رسید یافت نشد' }; return prev; }
      const now = new Date().toISOString();
      const updatedReceipts = (prev.customerReceipts || []).map(s => s.id === submissionId ? {
        ...s,
        status: 'رد_شده' as const,
        reviewedAt: now,
        reviewedBy: actor.name,
        rejectReason: reason || 'اطلاعات واریز نامعتبر یا ناخوانا بود',
      } : s);

      const custUser = prev.users.find(u => u.customerId === sub.customerId || u.phone === sub.customerPhone);
      const notifs = [...prev.notifications];
      if (custUser) {
        notifs.unshift({
          id: uid('n'),
          userId: custUser.id,
          title: 'رد رسید پرداخت شما',
          body: `فیش واریزی ${sub.receiptNumber} به دلیل «${reason || 'ناخوانا بودن یا عدم تطابق'}» تأیید نشد. لطفاً مجدداً ارسال نمایید.`,
          type: 'payment',
          read: false,
          createdAt: now,
        });
      }

      outcome = { success: true };
      return pushAudit({
        ...prev,
        customerReceipts: updatedReceipts,
        notifications: notifs,
      }, 'رد فیش واریزی مشتری', 'payment', sub.id, reason);
    });
    return outcome;
  }, [actor, pushAudit]);

  // Automated 2-day overdue invoice checker -> alerts admin
  useEffect(() => {
    const checkOverdue = () => {
      setDb(prev => {
        const now = Date.now();
        const TWO_DAYS_MS = 2 * 24 * 60 * 60 * 1000;
        const newNotifs: NotificationItem[] = [];

        prev.invoices.forEach(inv => {
          const remaining = inv.totalAmount - inv.paidAmount;
          if (remaining <= 0) return;
          const invoiceAge = now - new Date(inv.date).getTime();
          if (invoiceAge >= TWO_DAYS_MS) {
            // Check if admin was already notified for this invoice in the last 2 days
            const alreadyNotified = prev.notifications.some(n =>
              n.userId === 'user-admin' &&
              n.relatedId === inv.id &&
              n.type === 'accounting' &&
              (now - new Date(n.createdAt).getTime()) < TWO_DAYS_MS
            );
            if (!alreadyNotified) {
              const cust = prev.customers.find(c => c.id === inv.customerId);
              newNotifs.push({
                id: uid('n'),
                userId: 'user-admin',
                title: `هشدار عدم تسویه بعد از ۲ روز: ${inv.invoiceNumber}`,
                body: `فاکتور ${inv.invoiceNumber} متعلق به ${cust?.fullName || 'مشتری'} به مبلغ مانده ${remaining.toLocaleString('en-US')} تومان بیش از ۲ روز است که تسویه نشده است.`,
                type: 'accounting',
                relatedId: inv.id,
                read: false,
                createdAt: new Date().toISOString(),
                internalLink: '/accounting',
              });
            }
          }
        });

        if (newNotifs.length === 0) return prev;
        return {
          ...prev,
          notifications: [...newNotifs, ...prev.notifications],
        };
      });
    };

    checkOverdue();
    const interval = setInterval(checkOverdue, 60000); // check every minute
    return () => clearInterval(interval);
  }, []);

  const value = useMemo<AppContextType>(() => ({
    db, currentUser, theme, isLoading,
    login, loginByUserId, logout, changePassword,
    registerBiometricCredential, removeBiometricCredential, findUserByCredential,
    toggleTheme, updateSettings, updateAccountingSettings,
    addCustomer, updateCustomer, deleteCustomer, addDevice,
    addOrder, updateOrder, updateOrderStatus, deleteOrder, addOrderPart, removeOrderPart,
    addTechnician, updateTechnician, updateTechnicianLogin,
    generateInvoice, receivePayment, editInvoice, registerExpense, registerPurchase, settleTechnician,
    transferFunds, addManualEntry, voidJournalEntry, addAccount, updateAccount, deleteAccount,
    addInventoryItem, updateInventoryItem, deleteInventoryItem, updateInventoryQty,
    addKB, incrementKBView, deleteKB,
    sendMessage, getMessagesForUser, markConversationRead,
    markNotificationRead, clearAllNotifications, addNotification, broadcastNotification,
    addReminder, toggleReminder, deleteReminder,
    addContact, deleteContact, addWorkOrder, updateWorkOrder,
    addAuditLog, resetAllData,
    confirmInvoiceSignature, submitCustomerReceipt, approveCustomerReceipt, rejectCustomerReceipt,
  }), [
    db, currentUser, theme, isLoading, login, loginByUserId, logout, changePassword,
    registerBiometricCredential, removeBiometricCredential, findUserByCredential,
    toggleTheme, updateSettings, updateAccountingSettings,
    addCustomer, updateCustomer, deleteCustomer, addDevice,
    addOrder, updateOrder, updateOrderStatus, deleteOrder, addOrderPart, removeOrderPart,
    addTechnician, updateTechnician, updateTechnicianLogin, generateInvoice, receivePayment, editInvoice, registerExpense,
    registerPurchase, settleTechnician, transferFunds, addManualEntry, voidJournalEntry,
    addAccount, updateAccount, deleteAccount, addInventoryItem, updateInventoryItem, deleteInventoryItem, updateInventoryQty,
    addKB, incrementKBView, deleteKB, sendMessage, getMessagesForUser, markConversationRead,
    markNotificationRead, clearAllNotifications, addNotification, broadcastNotification,
    addReminder, toggleReminder, deleteReminder, addContact, deleteContact, addWorkOrder,
    updateWorkOrder, addAuditLog, resetAllData,
    confirmInvoiceSignature, submitCustomerReceipt, approveCustomerReceipt, rejectCustomerReceipt,
  ]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
