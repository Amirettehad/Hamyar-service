// Jalali (Persian) calendar utilities

function div(a: number, b: number): number {
  return Math.trunc(a / b);
}

export function gregorianToJalali(gy: number, gm: number, gd: number): [number, number, number] {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy: number;
  (gy > 1600) ? (jy = 979, gy -= 1600) : (jy = 0, gy -= 621);
  const gy2 = (gm > 2) ? (gy + 1) : gy;
  let days = (365 * gy) + (div(gy2 + 3, 4)) - (div(gy2 + 99, 100)) + (div(gy2 + 399, 400)) - 80 + gd - 1;
  days += g_d_m[gm - 1];
  jy += 33 * div(days, 12053);
  days %= 12053;
  jy += 4 * div(days, 1461);
  days %= 1461;
  if (days > 365) {
    jy += div(days - 1, 365);
    days = (days - 1) % 365;
  }
  const jm = (days < 186) ? 1 + div(days, 31) : 7 + div(days - 186, 30);
  const jd = 1 + ((days < 186) ? (days % 31) : ((days - 186) % 30));
  return [jy, jm, jd];
}

export function jalaliToGregorian(jy: number, jm: number, jd: number): [number, number, number] {
  let gy: number;
  (jy > 979) ? (gy = 1600, jy -= 979) : (gy = 621);
  let days = (365 * jy) + (div(jy, 33)) * 8 + div(((jy % 33) + 3), 4) + 78 + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
  gy += 400 * div(days, 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * div(--days, 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * div(days, 1461);
  days %= 1461;
  if (days > 365) {
    gy += div(days - 1, 365);
    days = (days - 1) % 365;
  }
  let gd = days + 1;
  const sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm = 0;
  for (gm = 1; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
  return [gy, gm, gd];
}

const persianMonths = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];
const persianWeekdays = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];
const persianWeekdaysShort = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

export function getPersianMonths() { return persianMonths; }
export function getPersianWeekdays() { return persianWeekdays; }
export function getPersianWeekdaysShort() { return persianWeekdaysShort; }

export function toPersianDigits(input: string | number | null | undefined): string {
  if (input === null || input === undefined) return '';
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(input).replace(/\d/g, (d) => persianDigits[parseInt(d)]);
}

export function toEnglishDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
}

export function pad(n: number): string {
  return n < 10 ? '0' + n : String(n);
}

export function formatJalali(date: Date, opts?: { withWeekday?: boolean; withTime?: boolean }): string {
  const [jy, jm, jd] = gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
  let result = `${jy}/${pad(jm)}/${pad(jd)}`;
  if (opts?.withWeekday) {
    result = `${persianWeekdays[getJalaliWeekday(date)]} ${result}`;
  }
  if (opts?.withTime) {
    result += ` - ${pad(date.getHours())}:${pad(date.getMinutes())}`;
  }
  return result;
}

export function formatJalaliLong(date: Date): string {
  const [jy, jm, jd] = gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
  return `${toPersianDigits(jd)} ${persianMonths[jm - 1]} ${toPersianDigits(jy)}`;
}

export function getJalaliWeekday(date: Date): number {
  const jsDay = date.getDay();
  return (jsDay + 1) % 7;
}

export function getJalaliMonthLength(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isJalaliLeap(jy) ? 30 : 29;
}

export function isJalaliLeap(jy: number): boolean {
  const breaks = [-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178];
  let jp = breaks[0];
  let jump = 0;
  for (let j = 1; j < breaks.length; j++) {
    const jm = breaks[j];
    jump = jm - jp;
    if (jy < jm) break;
    jp = jm;
  }
  let n = jy - jp;
  if (n < jump) {
    if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
    let leap = ((n % 33) % 4);
    if (leap === 0 && n % 33 !== 0) leap = 4;
    return leap === 0;
  }
  return false;
}

export function parseJalali(input: string): Date | null {
  const cleaned = toEnglishDigits(input.trim());
  const match = cleaned.match(/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})$/);
  if (!match) return null;
  const jy = parseInt(match[1]);
  const jm = parseInt(match[2]);
  const jd = parseInt(match[3]);
  if (jm < 1 || jm > 12 || jd < 1 || jd > getJalaliMonthLength(jy, jm)) return null;
  const [gy, gm, gd] = jalaliToGregorian(jy, jm, jd);
  return new Date(gy, gm - 1, gd);
}

export function createJalaliDate(jy: number, jm: number, jd: number, hours = 0, minutes = 0): Date {
  const [gy, gm, gd] = jalaliToGregorian(jy, jm, jd);
  return new Date(gy, gm - 1, gd, hours, minutes);
}

export function isHoliday(date: Date): boolean {
  return date.getDay() === 5;
}

export function isToday(date: Date): boolean {
  const today = new Date();
  return date.getFullYear() === today.getFullYear() &&
    date.getMonth() === today.getMonth() &&
    date.getDate() === today.getDate();
}

export function getTodayJalali(): [number, number, number] {
  const now = new Date();
  return gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
}

export function getMonthGrid(jy: number, jm: number): Date[] {
  const [gy, gm, gd] = jalaliToGregorian(jy, jm, 1);
  const firstDay = new Date(gy, gm - 1, gd);
  const firstWeekday = getJalaliWeekday(firstDay);
  const days: Date[] = [];

  if (firstWeekday > 0) {
    const prevMonth = jm === 1 ? 12 : jm - 1;
    const prevYear = jm === 1 ? jy - 1 : jy;
    const prevMonthLen = getJalaliMonthLength(prevYear, prevMonth);
    for (let i = firstWeekday - 1; i >= 0; i--) {
      const [pgy, pgm, pgd] = jalaliToGregorian(prevYear, prevMonth, prevMonthLen - i);
      days.push(new Date(pgy, pgm - 1, pgd));
    }
  }

  const monthLen = getJalaliMonthLength(jy, jm);
  for (let d = 1; d <= monthLen; d++) {
    const [cgy, cgm, cgd] = jalaliToGregorian(jy, jm, d);
    days.push(new Date(cgy, cgm - 1, cgd));
  }

  while (days.length < 42) {
    const lastDate = days[days.length - 1];
    const next = new Date(lastDate);
    next.setDate(next.getDate() + 1);
    days.push(next);
  }

  return days;
}

export function formatNumber(n: number | string): string {
  const num = typeof n === 'string' ? parseFloat(toEnglishDigits(n)) : n;
  if (isNaN(num)) return '0';
  return toPersianDigits(num.toLocaleString('en-US'));
}

export function formatCurrency(n: number, showUnit = true): string {
  if (isNaN(n) || n === null || n === undefined) return showUnit ? '۰ تومان' : '۰';
  const formatted = formatNumber(Math.round(n));
  return showUnit ? `${formatted} تومان` : formatted;
}

export function formatTime(date: Date): string {
  return `${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export function timeAgo(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return 'همین الان';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${toPersianDigits(minutes)} دقیقه پیش`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${toPersianDigits(hours)} ساعت پیش`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${toPersianDigits(days)} روز پیش`;
  return formatJalali(date);
}
