// Data binding: map real application data (order/customer/device/invoice)
// into a flat token dictionary so editor templates render with real values.

import type {
  AppDatabase, ServiceOrder, Invoice, Customer, Device,
} from '../lib/types';
import { formatCurrency, formatJalaliLong, toPersianDigits } from '../lib/jalali';
import { numberToPersianWords, faNum } from '../editor/utils';

export interface DataField {
  key: string;        // token name without braces, e.g. "customer.fullName"
  label: string;      // Persian label for picker
  value: string;      // resolved string value
  numeric?: number;   // numeric value (for formula refs)
}

export interface DataItemRow {
  desc: string;
  qty: number;
  unit: string;
  price: number;
  discount: number;
  total: number;
  row: number;
  [k: string]: string | number;
}

export interface PrintDataContext {
  fields: Record<string, string>;
  numeric: Record<string, number>;
  items: DataItemRow[];
}

export function buildPrintDataContext(db: AppDatabase, order: ServiceOrder, invoice?: Invoice): PrintDataContext {
  const customer: Customer | undefined = db.customers.find(c => c.id === order.customerId);
  const device: Device | undefined = db.devices.find(d => d.id === order.deviceId);
  const technician = db.technicians.find(t => t.id === order.technicianId);
  const settings = db.settings;

  const partsTotal = order.parts.reduce((s, p) => s + p.quantity * p.unitPrice, 0);
  const tax = invoice?.taxAmount ?? Math.round(order.finalAmount * (settings.taxRate / 100));
  const total = invoice?.totalAmount ?? order.finalAmount;
  const paid = invoice?.paidAmount ?? 0;
  const remaining = Math.max(0, total - paid);

  const fields: Record<string, string> = {};
  const numeric: Record<string, number> = {};

  const set = (key: string, value: string | number, n?: number) => {
    fields[key] = String(value);
    if (typeof value === 'number' || n !== undefined) numeric[key] = typeof value === 'number' ? value : (n ?? 0);
  };

  // order
  set('order.requestNumber', order.requestNumber);
  set('order.invoiceNumber', invoice?.invoiceNumber || order.requestNumber);
  set('order.date', order.registrationDate ? toPersianDigits(formatJalaliLong(new Date(order.registrationDate))) : '');
  set('order.visitDate', order.visitDate ? toPersianDigits(formatJalaliLong(new Date(order.visitDate))) : '');
  set('order.visitTime', order.visitTime ? toPersianDigits(order.visitTime) : '');
  set('order.serviceType', order.serviceType);
  set('order.status', order.status);
  set('order.problem', order.problemDescription || '');
  set('order.report', order.technicianReport || '');

  // customer
  set('customer.fullName', customer?.fullName || '');
  set('customer.phone', customer ? toPersianDigits(customer.phone) : '');
  set('customer.phone2', customer?.phone2 ? toPersianDigits(customer.phone2) : '');
  set('customer.address', customer?.address || '');
  set('customer.nationalCode', customer?.notes ? '' : '');

  // device
  set('device.type', device?.type || '');
  set('device.brand', device?.brand || '');
  set('device.model', device?.model || '');
  set('device.serial', device?.serialNumber ? toPersianDigits(device.serialNumber) : '');
  set('device.warranty', device?.warrantyStatus || '');

  // technician / shop
  set('technician.name', technician?.fullName || '');
  set('shop.name', settings.shopName);
  set('shop.address', settings.address);
  set('shop.phone', toPersianDigits(settings.phone));
  set('shop.phone2', settings.phone2 ? toPersianDigits(settings.phone2) : '');

  // amounts
  set('amount.partsTotal', partsTotal, partsTotal);
  set('amount.labor', order.laborCost, order.laborCost);
  set('amount.transport', order.transportationCost, order.transportationCost);
  set('amount.other', order.otherCosts, order.otherCosts);
  set('amount.discount', order.discount, order.discount);
  set('amount.tax', tax, tax);
  set('amount.total', total, total);
  set('amount.paid', paid, paid);
  set('amount.remaining', remaining, remaining);
  set('amount.totalWords', numberToPersianWords(total));

  // convenient currency strings
  fields['amount.partsTotal.text'] = formatCurrency(partsTotal);
  fields['amount.labor.text'] = formatCurrency(order.laborCost);
  fields['amount.transport.text'] = formatCurrency(order.transportationCost);
  fields['amount.other.text'] = formatCurrency(order.otherCosts);
  fields['amount.discount.text'] = formatCurrency(order.discount);
  fields['amount.tax.text'] = formatCurrency(tax);
  fields['amount.total.text'] = formatCurrency(total);
  fields['amount.paid.text'] = formatCurrency(paid);
  fields['amount.remaining.text'] = formatCurrency(remaining);

  // items rows
  const items: DataItemRow[] = order.parts.map((p, i) => {
    const totalRow = p.quantity * p.unitPrice;
    return {
      row: i + 1,
      desc: p.name,
      qty: p.quantity,
      unit: 'عدد',
      price: p.unitPrice,
      discount: 0,
      total: totalRow,
    };
  });
  // also include labor/transport/other as extra rows if present (for full invoice)
  let extraIdx = order.parts.length + 1;
  if (order.laborCost > 0) { items.push({ row: extraIdx++, desc: 'اجرت تعمیر', qty: 1, unit: '-', price: order.laborCost, discount: 0, total: order.laborCost }); }
  if (order.transportationCost > 0) { items.push({ row: extraIdx++, desc: 'ایاب و ذهاب', qty: 1, unit: '-', price: order.transportationCost, discount: 0, total: order.transportationCost }); }
  if (order.otherCosts > 0) { items.push({ row: extraIdx++, desc: 'سایر هزینه‌ها', qty: 1, unit: '-', price: order.otherCosts, discount: 0, total: order.otherCosts }); }

  return { fields, numeric, items };
}

/** Resolve a template string with {tokens} against the data context. */
export function resolveText(input: string, ctx: PrintDataContext): string {
  if (!input) return '';
  return input.replace(/\{([\w.]+)\}/g, (_m, key: string) => {
    if (key in ctx.fields) return ctx.fields[key];
    if (key in ctx.numeric) return faNum(ctx.numeric[key]);
    return `{${key}}`;
  });
}

/** Resolve a numeric value (for formula elements) using numeric context + item sums. */
export function resolveNumber(expr: string, ctx: PrintDataContext): number {
  if (!expr) return 0;
  try {
    let e = expr;
    const sumItems = ctx.items.reduce((s, it) => s + it.total, 0);
    e = e.replace(/SUM\(\s*\{?items\.total\}?\s*\)|SUM\(items\)/gi, String(sumItems));
    e = e.replace(/\{([\w.]+)\}/g, (_m, key: string) => String(ctx.numeric[key] ?? 0));
    e = e.replace(/SUM\(([^)]*)\)/gi, String(sumItems));
    if (!/^[\d\s+\-*/().]*$/.test(e)) return 0;
    // eslint-disable-next-line no-new-func
    const r = Function(`"use strict"; return (${e || 0});`)() as number;
    return isFinite(r) ? r : 0;
  } catch { return 0; }
}

export const FIELD_PICKER_GROUPS: { title: string; keys: { key: string; label: string }[] }[] = [
  { title: 'مشتری', keys: [
    { key: 'customer.fullName', label: 'نام مشتری' }, { key: 'customer.phone', label: 'تلفن' }, { key: 'customer.phone2', label: 'تلفن دوم' }, { key: 'customer.address', label: 'آدرس' }] },
  { title: 'سفارش', keys: [
    { key: 'order.requestNumber', label: 'شماره سفارش' }, { key: 'order.invoiceNumber', label: 'شماره فاکتور' }, { key: 'order.date', label: 'تاریخ ثبت' }, { key: 'order.visitDate', label: 'تاریخ مراجعه' }, { key: 'order.visitTime', label: 'ساعت مراجعه' }, { key: 'order.serviceType', label: 'نوع سرویس' }, { key: 'order.status', label: 'وضعیت' }, { key: 'order.problem', label: 'شرح خرابی' }, { key: 'order.report', label: 'گزارش تکنسین' }] },
  { title: 'دستگاه', keys: [
    { key: 'device.type', label: 'نوع دستگاه' }, { key: 'device.brand', label: 'برند' }, { key: 'device.model', label: 'مدل' }, { key: 'device.serial', label: 'سریال' }, { key: 'device.warranty', label: 'گارانتی' }] },
  { title: 'مبلغ', keys: [
    { key: 'amount.partsTotal.text', label: 'جمع قطعات' }, { key: 'amount.labor.text', label: 'اجرت' }, { key: 'amount.transport.text', label: 'ایاب و ذهاب' }, { key: 'amount.discount.text', label: 'تخفیف' }, { key: 'amount.tax.text', label: 'مالیات' }, { key: 'amount.total.text', label: 'مبلغ نهایی' }, { key: 'amount.paid.text', label: 'پرداختی' }, { key: 'amount.remaining.text', label: 'باقی‌مانده' }, { key: 'amount.totalWords', label: 'مبلغ به حروف' }] },
  { title: 'سایر', keys: [
    { key: 'technician.name', label: 'نام تکنسین' }, { key: 'shop.name', label: 'نام تعمیرگاه' }, { key: 'shop.address', label: 'آدرس تعمیرگاه' }, { key: 'shop.phone', label: 'تلفن تعمیرگاه' }] },
];
