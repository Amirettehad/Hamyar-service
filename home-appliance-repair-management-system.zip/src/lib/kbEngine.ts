// Smart technician knowledge engine:
// 1) Curated structured library of error codes + test modes per brand/device/model.
// 2) Fast tokenized fuzzy search across local corpus + user articles.
// 3) Internet fallback (CORS-safe Wikipedia API) for best available answer.
// 4) Online answers can be saved into the knowledge base permanently.

import type { DeviceBrand, DeviceType, KnowledgeBaseArticle } from './types';

export interface ErrorCodeEntry {
  code: string;
  label: string;
  brand: DeviceBrand | 'همه';
  deviceType: DeviceType | 'همه';
  models?: string[];
  causes: string[];
  solution: string[];
  note?: string;
}

export interface TestModeEntry {
  id: string;
  title: string;
  brand: DeviceBrand | 'همه';
  deviceType: DeviceType | 'همه';
  models?: string[];
  steps: string[];
  note?: string;
}

/* ================= Curated Corpus ================= */

export const ERROR_CODES: ErrorCodeEntry[] = [
  // ظرفشویی بوش
  { code: 'E19', label: 'مشکل در تخلیه آب', brand: 'بوش', deviceType: 'ظرفشویی', models: ['SMS*', 'SMU*', 'SPS*'], causes: ['خرابی پمپ تخلیه', 'گرفتگی فیلتر زهکش', 'گرفتگی شلنگ تخلیه', 'خرابی سوییچ سطح آب'], solution: ['فیلتر زیر دستگاه را باز و کاملاً تمیز کنید', 'مسیر شلنگ تخلیه را بررسی کنید (خم و مسدودی نباشد)', 'با شنیدن صدای پمپ در ابتدای برنامه، از کارکرد آن مطمئن شوید', 'در صورت خرابی، پمپ تخلیه را تعویض کنید'] },
  { code: 'E15', label: 'فعال شدن سیستم ضد نشتی (AquaStop)', brand: 'بوش', deviceType: 'ظرفشویی', causes: ['جمع شدن آب در سینی کف', 'نشتی شلنگ یا مخزن', 'خرابی سوییچ شناور'], solution: ['دستگاه را کمی به عقب کج کنید تا آب سینی خارج شود', 'محل نشتی را پیدا کنید', 'پس از خشک شدن، سیستم به‌صورت خودکار ریست می‌شود'] },
  { code: 'E01', label: 'خطای عمومی برد اصلی', brand: 'بوش', deviceType: 'ظرفشویی', causes: ['قطع برق ناگهانی', 'نوسان ولتاژ', 'خرابی برد'], solution: ['دستگاه را ۱۰ دقیقه از برق جدا و دوباره جایزنید', 'اتصال سوکت‌های برد را بررسی کنید', 'در صورت تکرار، برد را تست/تعویض کنید'] },
  { code: 'E25', label: 'خطای مدار پمپ تخلیه', brand: 'بوش', deviceType: 'ظرفشویی', causes: ['نشت آب به رابط پمپ', 'خرابی سیم‌پیچ پمپ'], solution: ['رابط پمپ را بررسی و خشک کنید', 'مقاومت پمپ را بسنجید', 'پمپ را تعویض کنید'] },
  { code: 'E28', label: 'خطای سنسور کدری آب', brand: 'بوش', deviceType: 'ظرفشویی', causes: ['کدری دائمی آب', 'خرابی سنسور', 'گرفتگی فیلتر ورودی'], solution: ['فیلتر ورودی آب را تمیز کنید', 'سنسور را پاک کنید', 'در صورت تداوم تعویض کنید'] },

  // ماشین لباسشویی بوش
  { code: 'E16', label: 'درِ دستگاه باز است', brand: 'بوش', deviceType: 'لباسشویی', causes: ['بسته نشدن کامل درب', 'خرابی کلید قفل در', 'مشکل سیم‌بندی'], solution: ['درب را محکم ببندید', 'کلید قفل در را با مولتی‌متر بررسی کنید', 'کلید قفل را تعویض کنید'] },
  { code: 'E17', label: 'مشکل تأمین آب (ورودی)', brand: 'بوش', deviceType: 'لباسشویی', causes: ['فشار کم آب', 'شیر بسته', 'گرفتگی فیلتر شیر برقی'], solution: ['فشار آب را بررسی کنید', 'فیلتر ورودی را بازشویید', 'شیر برقی را با برق تست کنید'] },
  { code: 'E18', label: 'مشکل تخلیه آب', brand: 'بوش', deviceType: 'لباسشویی', causes: ['گرفتگی فیلتر پمپ', 'خرابی پمپ تخلیه', 'نصب نادرست شلنگ'], solution: ['فیلتر پمپ جلوی دستگاه را تمیز کنید', 'نصب درست شلنگ را بررسی کنید', 'پمپ را در صورت لزوم تعویض کنید'] },

  // یخچال بوش
  { code: 'E1', label: 'خطای سنسور دمای محفظه (NTC)', brand: 'بوش', deviceType: 'یخچال', models: ['KGN*', 'KAN*'], causes: ['خرابی سنسور NTC', 'جا نیفتادن سوکت', 'خرابی برد'], solution: ['مقاومت سنسور را با مولتی‌متر بسنجید و با جدول مقایسه کنید', 'سوکت سنسور در برد را بررسی کنید', 'سنسور را در صورت انحراف تعویض کنید'] },
  { code: 'E2', label: 'خطای سنسور فریزر', brand: 'بوش', deviceType: 'یخچال', causes: ['یخ روی سنسور', 'خرابی NTC فریزر'], solution: ['دیفراست کامل انجام دهید', 'سنسور فریزر را تست و تعویض کنید'] },
  { code: 'E3', label: 'خطای مدار دیفراست', brand: 'بوش', deviceType: 'یخچال', causes: ['ترموفیوز سوخته', 'هیتر دیفراست معیوب', 'خرابی برد'], solution: ['اتصال ترموفیوز را بررسی کنید', 'مقاومت هیتر را تست کنید', 'برد/تایمر دیفراست را بررسی کنید'] },

  // آاگ (AEG)
  { code: 'i20', label: 'مشکل تخلیه آب', brand: 'آاگ', deviceType: 'همه', causes: ['گرفتگی فیلتر یا شلنگ', 'خرابی پمپ تخلیه'], solution: ['فیلتر سیستم چک‌کنید', 'پمپ زهکش را تست و در صورت نیاز تعویض کنید'] },
  { code: 'i30', label: 'آب در سینی کف', brand: 'آاگ', deviceType: 'ظرفشویی', causes: ['نشتی داخلی', 'فوم زیاد به دلیل شوینده نامناسب'], solution: ['سینی کف را خشک و منشأ نشتی را پیدا کنید', 'فقط از پودر مخصوص ظرفشویی استفاده کنید'] },
  { code: 'i40', label: 'مشکل برق‌رسانی', brand: 'آاگ', deviceType: 'ظرفشویی', causes: ['مشکل ورودی برق', 'خرابی رله برد'], solution: ['ولتاژ ورودی و فیوز داخلی را بررسی کنید', 'برد تغذیه را تست کنید'] },
  { code: 'E10', label: 'مشکل ورودی آب', brand: 'آاگ', deviceType: 'لباسشویی', causes: ['فشار کم آب', 'گرفتگی فیلتر', 'خرابی شیر برقی'], solution: ['فیلتر ورودی را تمیز کنید', 'باز بودن شیر آب و عملکرد شیر برقی را بررسی کنید'] },
  { code: 'E20', label: 'مشکل تخلیه آب', brand: 'آاگ', deviceType: 'لباسشویی', causes: ['گرفتگی فیلتر/پمپ', 'نصب نادرست شلنگ'], solution: ['فیلتر پمپ را تمیز و ارتفاع شلنگ را استاندارد کنید'] },
  { code: 'E40', label: 'عدم تعادل بار', brand: 'آاگ', deviceType: 'لباسشویی', causes: ['بار ناهموار در طبل', 'سطح نامتعادل زیر دستگاه'], solution: ['لباس‌ها را به‌صورت متوازن توزیع کنید', 'پایه‌های دستگاه را تراز کنید'] },
  { code: 'E30', label: 'خطای قفل درب', brand: 'آاگ', deviceType: 'لباسشویی', causes: ['خرابی کلید قفل', 'مشکل مدار قفل'], solution: ['کلید قفل درب را تست و تعویض کنید'] },
  { code: 'E50', label: 'خطای موتور', brand: 'آاگ', deviceType: 'لباسشویی', causes: ['خرابی موتور یا تاکوژنراتور', 'خرابی برد'], solution: ['برس‌ها و تاکوژن را بررسی کنید', 'برد را تست کنید'] },

  // ال‌جی
  { code: 'DE', label: 'خطای درب (Door Error)', brand: 'ال‌جی', deviceType: 'لباسشویی', causes: ['قفل نشدن درب', 'خرابی کلید قفل درب', 'مشکل سوکت'], solution: ['درب را کاملاً ببندید', 'کلید قفل درب را تست کنید', 'سوکت‌های برد را بررسی کنید'] },
  { code: 'UE', label: 'عدم توازن بار', brand: 'ال‌جی', deviceType: 'لباسشویی', causes: ['بار ناهموار در طبل', 'کم/زیاد بودن لباس'], solution: ['بار را به‌صورت مساوی توزیع کنید', 'پایه‌ها را تراز کنید'] },
  { code: 'IE', label: 'خطای تأمین آب', brand: 'ال‌جی', deviceType: 'لباسشویی', causes: ['فشار کم آب', 'شلنگ گرفتگی', 'خرابی شیر برقی'], solution: ['فشار آب را بررسی و فیلتر‌های ورودی را تمیز کنید'] },
  { code: 'OE', label: 'خطای تخلیه', brand: 'ال‌جی', deviceType: 'لباسشویی', causes: ['گرفتگی فیلتر پمپ', 'خرابی پمپ'], solution: ['فیلتر پمپ را تمیز و عملکرد آن را چک کنید'] },
  { code: 'tE', label: 'خطای دما (هیتر/سنسور)', brand: 'ال‌جی', deviceType: 'لباسشویی', causes: ['خرابی سنسور دما', 'خرابی هیتر'], solution: ['سنسور NTC و هیتر را با مولتی‌متر تست کنید'] },

  // سامسونگ
  { code: '4E', label: 'مشکل تأمین آب', brand: 'سامسونگ', deviceType: 'لباسشویی', causes: ['فشار کم آب', 'خرابی شیر برقی'], solution: ['فیلتر ورودی را تمیز و فشار شلنگ را بررسی کنید'] },
  { code: '5E', label: 'مشکل تخلیه آب', brand: 'سامسونگ', deviceType: 'لباسشویی', causes: ['خرابی پمپ', 'گرفتگی پمپ/شلنگ'], solution: ['فیلتر پمپ را تمیز و تست کنید'] },
  { code: 'dE', label: 'خطای درب', brand: 'سامسونگ', deviceType: 'لباسشویی', causes: ['قفل نشدن درب', 'خرابی سنسور قفل'], solution: ['درب بسته و کلید قفل بررسی شود'] },
];

export const TEST_MODES: TestModeEntry[] = [
  { id: 'tm-bosch-dish', title: 'سرویس‌مد ظرفشویی بوش', brand: 'بوش', deviceType: 'ظرفشویی', models: ['SMS*', 'SMU*'], steps: ['دستگاه را خاموش کنید (OFF)', 'دو دکمه‌ی Start و Power را همزمان چند ثانیه نگه‌دارید تا LEDهای نشان‌دهنده چشمک بزنند', 'چرخه‌ی خودآزمایی شروع می‌شود (پرکردن آب، پاشش، تخلیه، گرم‌کردن و خشک‌کن)', 'برای خروج از سرویس‌مد، دکمه‌ی Start/Rinse را نگه‌دارید یا دستگاه را خاموش کنید'], note: 'هر ارور ثبت‌شده از حافظه خطا در سرویس‌مد نمایش داده می‌شود.' },
  { id: 'tm-bosch-washer', title: 'تست‌مود لباسشویی بوش', brand: 'بوش', deviceType: 'لباسشویی', steps: ['دستگاه را خاموش و از برق جدا کنید', 'دکمه‌ی Start/Pause را نگه‌دارید و کلید Power را بزنید', 'LED تایمر چند بار چشمک می‌زند تا وارد تست‌مود شود', 'با چرخاندن دیال مراحل تست (پرکردن، پمپ تخلیه، گرم‌کن و چرخش موتور) انتخاب می‌شود', 'با Start هر مرحله را اجرا و برای خروج دکمه‌ی Power را بزنید'], note: 'برای تست پمپ تخلیه، هیتر و چرخش موتور کاربرد دارد.' },
  { id: 'tm-bosch-fridge', title: 'حالت تست یخچال بوش سری KGN', brand: 'بوش', deviceType: 'یخچال', models: ['KGN*'], steps: ['دکمه‌های «تنظیم دمای یخچال» و «سوپر» را همزمان ۱۰ ثانیه نگه‌دارید', 'LED نمایشگر وارد حالت تست می‌شود و عملکرد اجزای اصلی فعال می‌شوند', 'کمپرسور، فن اواپراتور و درب فریزر تک‌تک چک می‌شوند', 'برای خروج، دکمه‌ی جدا کردن برق و سوپر را دوباره نگه‌دارید'] },
  { id: 'tm-aeg-dish', title: 'سرویس‌مد ظرفشویی آاگ', brand: 'آاگ', deviceType: 'ظرفشویی', steps: ['دستگاه را خاموش کنید', 'دو دکمه «توان» و «برنامه مورد نظر» را همزمان ۵ ثانیه نگه‌دارید', 'نمایشگر وارد حالت سرویس می‌شود و با چرخش دکمه برنامه، وضعیت تست هر قطعه انتخاب می‌شود', 'با Start هر مرحله را اجرا کنید؛ برای خروج Power را بزنید'] },
  { id: 'tm-aeg-washer', title: 'تست‌مود لباسشویی آاگ', brand: 'آاگ', deviceType: 'لباسشویی', steps: ['دستگاه را خاموش کنید', 'دو دکمه‌ی شروع/توقف را نگه‌دارید و پاور را بزنید', 'نمایشگر چشمک‌زن می‌شود و تست‌مود وارد می‌شود', 'با چرخش دیال، مرحله‌ی مورد نظر (پمپ تخلیه و شلنگ تغذیه) انتخاب شود', 'با دکمه OK هر مرحله را اجرا و در پایان خاموش کنید'] },
  { id: 'tm-lg-washer', title: 'حالت تشخیص لباسشویی ال‌جی (ام‌سرویس)', brand: 'ال‌جی', deviceType: 'لباسشویی', steps: ['Power را بزنید و دو دکمه‌ی Program و Spin را ۵ ثانیه نگه‌دارید', 'وارد حالت تشخیص می‌شود؛ مراحل تست به‌صورت مرحله‌ای انجام می‌شود', 'مرحله‌ی پمپ تخلیه و هیتر با Start تک‌تک بررسی می‌شود', 'برای خروج دستگاه را ۱۰ ثانیه از برق جدا کنید'] },
];

/* ================= Local fuzzy search ================= */

export const normKb = (s: string): string =>
  (s || '').toLowerCase()
    .replace(/[‌]/g, ' ')
    .replace(/[إأآ]/g, 'ا')
    .replace(/[يى]/g, 'ی')
    .replace(/[^a-z0-9ا-ی\s]/g, ' ')
    .replace(/\s+/g, ' ').trim();

function tokens(q: string): string[] {
  return normKb(q).split(/\s+/).filter(t => t.length > 0).slice(0, 8);
}

interface Scored<T> { item: T; score: number }

export function searchErrors(query: string, filters: { brand?: string; deviceType?: string; model?: string }): ErrorCodeEntry[] {
  const ts = tokens(query);
  const scored: Scored<ErrorCodeEntry>[] = ERROR_CODES.map(e => {
    if (filters.brand && filters.brand !== 'all' && e.brand !== 'همه' && normKb(e.brand) !== normKb(filters.brand)) return null;
    if (filters.deviceType && filters.deviceType !== 'all' && e.deviceType !== 'همه' && normKb(e.deviceType) !== normKb(filters.deviceType)) return null;

    const code = normKb(e.code);
    const q = normKb(query);
    let score = 0;
    if (ts.length) {
      if (code.startsWith(ts[0])) score += 12;
      if (code === q || code.startsWith(q)) score += 15;
      if (q && code === q) score += 25;
    }

    const haystack = [e.label, e.code, e.brand, e.deviceType, ...(e.models || []), ...e.causes, ...e.solution].map(normKb).join(' ');
    ts.forEach(t => { if (haystack.includes(t)) score += 3; if (normKb(e.label).includes(t)) score += 4; });

    if (!query.trim() && !modelChosen(filters)) score = 1; // show all when browsing
    if (modelChosen(filters) && e.models) {
      const m = normKb(filters.model || '');
      if (m && !e.models.some(px => normKb(px).replace(/\*/g, '').startsWith(m.slice(0, 3)) || m.startsWith(normKb(px).replace(/\*/g, '')))) score += 0;
      else score += 4;
    }
    return score > 0 ? { item: e, score } : null;
  }).filter(Boolean) as Scored<ErrorCodeEntry>[];

  return scored.sort((a, b) => b.score - a.score).map(x => x.item);
}

function modelChosen(filters: { brand?: string; deviceType?: string; model?: string }): boolean {
  return !!(filters.model && filters.model.trim());
}

export function searchTestModes(query: string, filters: { brand?: string; deviceType?: string; model?: string }): TestModeEntry[] {
  const ts = tokens(query);
  return TEST_MODES.filter(t => {
    if (filters.brand && filters.brand !== 'all' && t.brand !== 'همه' && normKb(t.brand) !== normKb(filters.brand)) return false;
    if (filters.deviceType && filters.deviceType !== 'all' && t.deviceType !== 'همه' && normKb(t.deviceType) !== normKb(filters.deviceType)) return false;
    if (!query.trim()) return true;
    const haystack = [t.title, t.brand, t.deviceType, ...(t.models || []), ...t.steps].map(normKb).join(' ');
    return ts.some(tok => haystack.includes(tok));
  });
}

export function searchArticles(articles: KnowledgeBaseArticle[], query: string): KnowledgeBaseArticle[] {
  const ts = tokens(query);
  if (!ts.length) return articles;
  return articles
    .map(a => {
      const haystack = [a.title, a.content, a.brand, a.deviceType, ...a.tags].map(normKb).join(' ');
      let score = 0;
      ts.forEach(t => { if (haystack.includes(t)) score += 2; if (normKb(a.title).includes(t)) score += 3; });
      return { a, score };
    })
    .filter(x => x.score > 0)
    .sort((x, y) => y.score - x.score)
    .map(x => x.a);
}

/* ================= Online search (CORS-safe Wikipedia) ================= */

export interface OnlineResult {
  title: string;
  summary: string;
  translatedSummary?: string;
  sources: { title: string; url: string; from: 'wiki' | 'ext' }[];
  lang: 'fa' | 'en';
  score: number;
}

async function wikiSummary(title: string, lang: 'fa' | 'en'): Promise<string> {
  try {
    const url = `https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`;
    const res = await fetch(url);
    if (!res.ok) return '';
    const data = await res.json();
    return data.extract || '';
  } catch { return ''; }
}

export interface ExtSource { id: string; name: string; url: string; note?: string; createdAt: string }

const EXT_SOURCES_KEY = 'kb_ext_sources';

export function listExtSources(): ExtSource[] {
  try { const raw = localStorage.getItem(EXT_SOURCES_KEY); return raw ? JSON.parse(raw) : []; }
  catch { return []; }
}
export function addExtSource(name: string, url: string, note?: string): ExtSource {
  const s: ExtSource = { id: `src-${Date.now()}`, name, url, note, createdAt: new Date().toISOString() };
  localStorage.setItem(EXT_SOURCES_KEY, JSON.stringify([s, ...listExtSources()]));
  return s;
}
export function removeExtSource(id: string): void {
  localStorage.setItem(EXT_SOURCES_KEY, JSON.stringify(listExtSources().filter(s => s.id !== id)));
}

const STOPWORDS = new Set(['را', 'با', 'به', 'از', 'و', 'در', 'کی', 'که', 'برای', 'این', 'آن', 'است', 'error', 'code', 'the', 'of', 'a', 'an', 'and', 'appliance', 'appliances', 'fault', 'codes', 'list', 'manual', 'repair']);

async function wikiQuery(q: string, lang: 'fa' | 'en'): Promise<{ title: string; snippet: string }[]> {
  try {
    const url = `https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srlimit=10&srnamespace=0&format=json&origin=*&search=${encodeURIComponent(q)}`;
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();
    return (data?.query?.search || []).map((s: { title: string; snippet: string }) => ({ title: s.title, snippet: s.snippet.replace(/<[^>]+>/g, '') }));
  } catch { return []; }
}

function relevanceScore(title: string, snippet: string, query: string): number {
  const qt = tokens(query).filter(t => !STOPWORDS.has(t) && t.length > 1);
  const normT = normKb(title + ' ' + snippet);
  let score = 0;
  qt.forEach(t => { if (normT.includes(t)) score += t.length >= 3 ? 5 : 3; });
  if (normKb(title).includes(normKb(query))) score += 10;
  return score;
}

function extractCode(query: string): string | null {
  const m = query.match(/\b([A-Z]{1,3}\d{2,4}|E\d{1,3}|i\d{2})\b/i);
  return m ? m[1].toUpperCase() : null;
}

/** جستجوی هوشمند آنلاین با رتبه‌بندی ارتباط و اولویت فارسی */
export async function searchOnline(query: string, opts?: { brand?: string; deviceType?: string }): Promise<OnlineResult | null> {
  const code = extractCode(query);
  const ctx = [opts?.brand && opts.brand !== 'all' ? opts.brand : '', opts?.deviceType && opts.deviceType !== 'all' ? opts.deviceType : ''].filter(Boolean).join(' ');

  const candidates: { q: string; boost: number }[] = [
    ...(code ? [{ q: `${code} کد خطا لوازم خانگی`, boost: 12 }, { q: `${code} تعمیر`, boost: 8 }] : []),
    { q: `${query} لوازم خانگی`, boost: 6 },
    { q: `${query} تعمیر`, boost: 5 },
    { q: query, boost: 2 },
  ];

  interface Candidate { title: string; snippet: string; url: string; lang: 'fa' | 'en'; score: number }
  const tried = new Set<string>();
  const results: Candidate[] = [];

  for (const lang of ['fa', 'en'] as const) {
    for (const c of candidates) {
      try {
        const q = [ctx, c.q].filter(Boolean).join(' ');
        const list = await wikiQuery(q, lang);
        list.forEach((s, idx) => {
          if (tried.has(s.title)) return;
          tried.add(s.title);
          const sc = c.boost + (lang === 'fa' ? 5 : 0) + relevanceScore(s.title, s.snippet, query) - idx * 0.25;
          if (sc <= 0) return;
          results.push({ title: s.title, snippet: s.snippet, url: `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(s.title)}`, lang, score: sc });
        });
      } catch { /* ignore */ }
    }
    if (lang === 'fa' && results.length >= 2) break;
  }

  if (results.length === 0) return null;
  results.sort((a, b) => b.score - a.score);
  const top = results[0];
  const summary = await wikiSummary(top.title, top.lang);

  let translatedSummary: string | undefined;
  let faSummary = summary;
  if (top.lang === 'en' && summary) {
    try {
      const res = await fetch(`https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(top.title)}&prop=langlinks&lllang=fa&format=json&origin=*`);
      const data = await res.json();
      const pages = data?.query?.pages || {};
      const first = Object.values(pages)[0] as { langlinks?: { lang: string; '*': string }[] };
      const faTitle = first?.langlinks?.[0]?.['*'];
      if (faTitle) { const fs = await wikiSummary(faTitle, 'fa'); if (fs) { translatedSummary = fs; faSummary = fs; } }
    } catch { /* ignore */ }
  }

  return { title: top.title, summary: faSummary || top.snippet, translatedSummary, sources: results.slice(0, 4).map(r => ({ title: r.title, url: r.url, from: 'wiki' })), lang: top.lang, score: top.score };
}
