// WebAuthn (fingerprint / Face ID / Windows Hello) helpers

function bufferToBase64Url(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let str = '';
  for (let i = 0; i < bytes.byteLength; i++) str += String.fromCharCode(bytes[i]);
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlToBuffer(base64url: string): ArrayBuffer {
  const padding = '='.repeat((4 - (base64url.length % 4)) % 4);
  const base64 = (base64url + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  const buffer = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) buffer[i] = raw.charCodeAt(i);
  return buffer.buffer;
}

function randomChallenge(): ArrayBuffer {
  const arr = new Uint8Array(32);
  crypto.getRandomValues(arr);
  return arr.buffer.slice(0) as ArrayBuffer;
}

function textToBuffer(text: string): ArrayBuffer {
  return new TextEncoder().encode(text).buffer.slice(0) as ArrayBuffer;
}

export function isInsideIframe(): boolean {
  try { return window.self !== window.top; } catch { return true; }
}

export function isBiometricSupported(): boolean {
  return typeof window !== 'undefined' &&
    typeof window.PublicKeyCredential !== 'undefined' &&
    !!navigator.credentials &&
    typeof navigator.credentials.create === 'function';
}

export function isSecureEnvironment(): boolean {
  return typeof window !== 'undefined' && (window.isSecureContext === true);
}

export async function isPlatformAuthenticatorAvailable(): Promise<boolean> {
  if (!isBiometricSupported()) return false;
  try { return await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable(); } catch { return false; }
}

export interface EnvironmentReport {
  apiSupported: boolean; secureContext: boolean; platformSensor: boolean;
  inIframe: boolean; canTry: boolean; message: string;
}

export async function checkEnvironment(): Promise<EnvironmentReport> {
  const apiSupported = isBiometricSupported();
  const secureContext = isSecureEnvironment();
  const inIframe = isInsideIframe();
  const platformSensor = apiSupported ? await isPlatformAuthenticatorAvailable() : false;
  const canTry = apiSupported && secureContext;
  let message: string;
  if (!apiSupported) message = 'مرورگر شما از استاندارد WebAuthn پشتیبانی نمی‌کند.';
  else if (!secureContext) message = 'برای استفاده از اثر انگشت، برنامه باید روی HTTPS اجرا شود.';
  else if (!platformSensor && inIframe) message = 'برنامه داخل قاب (iframe) اجرا شده است؛ برای ثبت اثر انگشت آن را در پنجره مستقل باز کنید.';
  else if (!platformSensor) message = 'حسگر داخلی شناسایی نشد؛ می‌توانید از کلید امنیتی یا گوشی همراه به‌عنوان کلید عبور استفاده کنید.';
  else message = 'حسگر بیومتریک این دستگاه آماده است.';
  return { apiSupported, secureContext, platformSensor, inIframe, canTry, message };
}

export interface BiometricRegistrationResult { credentialId: string; deviceLabel: string }

function deviceLabel(): string {
  const ua = navigator.userAgent;
  if (/iPhone|iPad|iPod/i.test(ua)) return 'Face ID / Touch ID (iOS)';
  if (/Android/i.test(ua)) return 'اثر انگشت اندروید';
  if (/Macintosh/i.test(ua)) return 'Touch ID (macOS)';
  if (/Windows/i.test(ua)) return 'Windows Hello';
  if (/Linux/i.test(ua)) return 'حسگر امنیتی لینوکس';
  return 'حسگر بیومتریک دستگاه';
}

async function createCredential(opts: {
  userId: string; userName: string; displayName: string; appName: string;
  requireUserVerification: boolean; timeoutSeconds: number; excludeIds: string[];
}, platformOnly: boolean): Promise<PublicKeyCredential> {
  const publicKey: PublicKeyCredentialCreationOptions = {
    challenge: randomChallenge(),
    rp: { name: opts.appName, id: window.location.hostname },
    user: { id: textToBuffer(opts.userId), name: opts.userName || 'user', displayName: opts.displayName || 'کاربر' },
    pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }],
    authenticatorSelection: platformOnly
      ? { authenticatorAttachment: 'platform', userVerification: opts.requireUserVerification ? 'required' : 'preferred', residentKey: 'preferred' }
      : { userVerification: opts.requireUserVerification ? 'required' : 'preferred', residentKey: 'preferred' },
    excludeCredentials: opts.excludeIds.map(id => ({ id: base64UrlToBuffer(id), type: 'public-key' as const })),
    timeout: Math.max(15, opts.timeoutSeconds) * 1000,
    attestation: 'none',
  };
  const credential = (await navigator.credentials.create({ publicKey })) as PublicKeyCredential | null;
  if (!credential) throw new Error('ثبت اثر انگشت انجام نشد.');
  return credential;
}

export async function registerBiometric(opts: {
  userId: string; userName: string; displayName: string; appName: string;
  requireUserVerification: boolean; timeoutSeconds: number; excludeIds?: string[];
}): Promise<BiometricRegistrationResult> {
  if (!isBiometricSupported()) throw new Error('مرورگر شما از احراز هویت بیومتریک پشتیبانی نمی‌کند.');
  if (!isSecureEnvironment()) throw new Error('برای ثبت اثر انگشت، اتصال امن (HTTPS) لازم است.');
  const params = { ...opts, excludeIds: opts.excludeIds ?? [] };
  let credential: PublicKeyCredential;
  try { credential = await createCredential(params, true); }
  catch (err) {
    const name = err instanceof Error ? err.name : '';
    if (name === 'InvalidStateError') throw err;
    credential = await createCredential(params, false);
  }
  return { credentialId: bufferToBase64Url(credential.rawId), deviceLabel: deviceLabel() };
}

export async function authenticateBiometric(opts: {
  allowedCredentialIds: string[]; requireUserVerification: boolean; timeoutSeconds: number;
}): Promise<string> {
  if (!isBiometricSupported()) throw new Error('مرورگر شما از احراز هویت بیومتریک پشتیبانی نمی‌کند.');
  if (!isSecureEnvironment()) throw new Error('برای ورود با اثر انگشت، اتصال امن (HTTPS) لازم است.');
  if (opts.allowedCredentialIds.length === 0) throw new Error('هیچ اثر انگشتی ثبت نشده است.');
  const publicKey: PublicKeyCredentialRequestOptions = {
    challenge: randomChallenge(),
    rpId: window.location.hostname,
    allowCredentials: opts.allowedCredentialIds.map(id => ({ id: base64UrlToBuffer(id), type: 'public-key' as const })),
    userVerification: opts.requireUserVerification ? 'required' : 'preferred',
    timeout: Math.max(15, opts.timeoutSeconds) * 1000,
  };
  const assertion = (await navigator.credentials.get({ publicKey })) as PublicKeyCredential | null;
  if (!assertion) throw new Error('احراز هویت بیومتریک ناموفق بود.');
  return bufferToBase64Url(assertion.rawId);
}

export function describeBiometricError(err: unknown): string {
  const name = err instanceof Error ? err.name : '';
  const message = err instanceof Error ? err.message : String(err);
  if (name === 'NotAllowedError' || /not allowed/i.test(message)) {
    return isInsideIframe() ? 'درخواست لغو شد. اگر برنامه داخل قاب اجرا می‌شود، آن را در پنجره مستقل باز کنید.' : 'عملیات لغو شد یا زمان انتظار حسگر به پایان رسید.';
  }
  if (name === 'InvalidStateError') return 'این دستگاه قبلاً برای همین کاربر ثبت شده است.';
  if (name === 'SecurityError') return 'دامنه فعلی امن نیست؛ برای بیومتریک به HTTPS نیاز است.';
  if (name === 'AbortError') return 'عملیات متوقف شد.';
  if (name === 'NotSupportedError') return 'این دستگاه از نوع احرازکننده درخواستی پشتیبانی نمی‌کند.';
  if (name === 'ConstraintError') return 'تنظیمات امنیتی درخواستی توسط دستگاه پشتیبانی نمی‌شود.';
  return message || 'خطای ناشناخته در احراز هویت بیومتریک.';
}
