// ================= Double-entry accounting engine =================

import type {
  Account, AccountingSettings, AppDatabase, ExpenseRecord, Invoice,
  JournalEntry, JournalLine, Payment, PaymentMethod, PartItem, PartyType, ServiceOrder,
} from './types';
import { getTodayJalali, getPersianMonths, gregorianToJalali, createJalaliDate } from './jalali';

function aid(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export const round = (n: number, unit: 1 | 100 | 1000 = 1) =>
  unit === 1 ? Math.round(n) : Math.round(n / unit) * unit;

export const DEFAULT_ACCOUNTS: Account[] = [
  { code: '1101', name: 'صندوق', type: 'دارایی', nature: 'بدهکار', group: 'موجودی نقد', isCash: true, isSystem: true, openingBalance: 0, active: true },
  { code: '1102', name: 'بانک / کارتخوان', type: 'دارایی', nature: 'بدهکار', group: 'موجودی نقد', isCash: true, isSystem: true, openingBalance: 0, active: true },
  { code: '1103', name: 'حساب بانکی (انتقال شتاب)', type: 'دارایی', nature: 'بدهکار', group: 'موجودی نقد', isCash: true, isSystem: true, openingBalance: 0, active: true },
  { code: '1104', name: 'اسناد دریافتنی (چک)', type: 'دارایی', nature: 'بدهکار', group: 'موجودی نقد', isCash: true, isSystem: true, openingBalance: 0, active: true },
  { code: '1201', name: 'حساب‌های دریافتنی - مشتریان', type: 'دارایی', nature: 'بدهکار', group: 'مطالبات', isCash: false, isSystem: true, subledger: 'customer', openingBalance: 0, active: true },
  { code: '1301', name: 'موجودی قطعات و لوازم یدکی', type: 'دارایی', nature: 'بدهکار', group: 'موجودی کالا', isCash: false, isSystem: true, openingBalance: 0, active: true },
  { code: '1401', name: 'پیش‌پرداخت‌ها', type: 'دارایی', nature: 'بدهکار', group: 'سایر دارایی', isCash: false, isSystem: false, openingBalance: 0, active: true },
  { code: '1501', name: 'اموال و تجهیزات کارگاه', type: 'دارایی', nature: 'بدهکار', group: 'دارایی ثابت', isCash: false, isSystem: false, openingBalance: 0, active: true },
  { code: '2101', name: 'حساب‌های پرداختنی - تأمین‌کنندگان', type: 'بدهی', nature: 'بستانکار', group: 'بدهی جاری', isCash: false, isSystem: true, subledger: 'supplier', openingBalance: 0, active: true },
  { code: '2102', name: 'پورسانت پرداختنی تکنسین‌ها', type: 'بدهی', nature: 'بستانکار', group: 'بدهی جاری', isCash: false, isSystem: true, subledger: 'technician', openingBalance: 0, active: true },
  { code: '2103', name: 'مالیات بر ارزش افزوده پرداختنی', type: 'بدهی', nature: 'بستانکار', group: 'بدهی جاری', isCash: false, isSystem: true, openingBalance: 0, active: true },
  { code: '2104', name: 'پیش‌دریافت از مشتریان', type: 'بدهی', nature: 'بستانکار', group: 'بدهی جاری', isCash: false, isSystem: true, subledger: 'customer', openingBalance: 0, active: true },
  { code: '3101', name: 'سرمایه مالک', type: 'سرمایه', nature: 'بستانکار', group: 'حقوق صاحبان سرمایه', isCash: false, isSystem: true, openingBalance: 0, active: true },
  { code: '3102', name: 'برداشت مالک', type: 'سرمایه', nature: 'بدهکار', group: 'حقوق صاحبان سرمایه', isCash: false, isSystem: true, openingBalance: 0, active: true },
  { code: '4101', name: 'درآمد خدمات تعمیر (اجرت)', type: 'درآمد', nature: 'بستانکار', group: 'درآمد عملیاتی', isCash: false, isSystem: true, openingBalance: 0, active: true },
  { code: '4102', name: 'درآمد فروش قطعات', type: 'درآمد', nature: 'بستانکار', group: 'درآمد عملیاتی', isCash: false, isSystem: true, openingBalance: 0, active: true },
  { code: '4103', name: 'درآمد ایاب و ذهاب', type: 'درآمد', nature: 'بستانکار', group: 'درآمد عملیاتی', isCash: false, isSystem: true, openingBalance: 0, active: true },
  { code: '4104', name: 'سایر درآمدها', type: 'درآمد', nature: 'بستانکار', group: 'درآمد غیرعملیاتی', isCash: false, isSystem: true, openingBalance: 0, active: true },
  { code: '4201', name: 'تخفیفات اعطایی', type: 'درآمد', nature: 'بدهکار', group: 'کاهنده درآمد', isCash: false, isSystem: true, openingBalance: 0, active: true },
  { code: '5101', name: 'بهای تمام‌شده قطعات مصرفی', type: 'هزینه', nature: 'بدهکار', group: 'بهای تمام‌شده', isCash: false, isSystem: true, openingBalance: 0, active: true },
  { code: '5102', name: 'هزینه پورسانت تکنسین', type: 'هزینه', nature: 'بدهکار', group: 'بهای تمام‌شده', isCash: false, isSystem: true, openingBalance: 0, active: true },
  { code: '5201', name: 'هزینه اجاره کارگاه', type: 'هزینه', nature: 'بدهکار', group: 'هزینه عملیاتی', isCash: false, isSystem: false, openingBalance: 0, active: true },
  { code: '5202', name: 'حقوق و دستمزد', type: 'هزینه', nature: 'بدهکار', group: 'هزینه عملیاتی', isCash: false, isSystem: false, openingBalance: 0, active: true },
  { code: '5203', name: 'حمل و نقل و سوخت', type: 'هزینه', nature: 'بدهکار', group: 'هزینه عملیاتی', isCash: false, isSystem: false, openingBalance: 0, active: true },
  { code: '5204', name: 'آب، برق، گاز و تلفن', type: 'هزینه', nature: 'بدهکار', group: 'هزینه عملیاتی', isCash: false, isSystem: false, openingBalance: 0, active: true },
  { code: '5205', name: 'تبلیغات و بازاریابی', type: 'هزینه', nature: 'بدهکار', group: 'هزینه عملیاتی', isCash: false, isSystem: false, openingBalance: 0, active: true },
  { code: '5206', name: 'ملزومات و ابزار مصرفی', type: 'هزینه', nature: 'بدهکار', group: 'هزینه عملیاتی', isCash: false, isSystem: false, openingBalance: 0, active: true },
  { code: '5207', name: 'کارمزد بانکی و درگاه', type: 'هزینه', nature: 'بدهکار', group: 'هزینه مالی', isCash: false, isSystem: false, openingBalance: 0, active: true },
  { code: '5299', name: 'سایر هزینه‌ها', type: 'هزینه', nature: 'بدهکار', group: 'هزینه عملیاتی', isCash: false, isSystem: true, openingBalance: 0, active: true },
];

export function defaultAccountingSettings(): AccountingSettings {
  const [jy] = getTodayJalali();
  return {
    fiscalYearLabel: `سال مالی ${jy}`,
    fiscalYearStart: createJalaliDate(jy, 1, 1).toISOString(),
    fiscalYearEnd: createJalaliDate(jy, 12, 29).toISOString(),
    entryPrefix: 'JV',
    autoPostInvoice: true,
    autoPostPayment: true,
    autoInvoiceOnCompletion: true,
    completionStatuses: ['انجام شده', 'تحویل شده'],
    accrueCommission: true,
    commissionBase: 'اجرت',
    trackInventoryCost: true,
    autoConsumeInventory: true,
    defaultCostRatio: 0.7,
    taxEnabled: false,
    taxRate: 9,
    roundingUnit: 1,
    defaultCreditLimit: 0,
    alertNegativeCash: true,
    paymentAccountMap: { 'نقد': '1101', 'کارت': '1102', 'شتاب': '1103', 'چک': '1104', 'اقساط': '1101' },
    arAccount: '1201',
    apAccount: '2101',
    commissionPayableAccount: '2102',
    commissionExpenseAccount: '5102',
    inventoryAccount: '1301',
    cogsAccount: '5101',
    taxPayableAccount: '2103',
    laborRevenueAccount: '4101',
    partsRevenueAccount: '4102',
    transportRevenueAccount: '4103',
    otherRevenueAccount: '4104',
    discountAccount: '4201',
    customerAdvanceAccount: '2104',
  };
}

export function isBalanced(lines: JournalLine[]): boolean {
  const d = lines.reduce((s, l) => s + l.debit, 0);
  const c = lines.reduce((s, l) => s + l.credit, 0);
  return Math.abs(d - c) < 1;
}

export function nextJournalNumber(db: AppDatabase): string {
  const [jy] = getTodayJalali();
  return `${db.accounting.entryPrefix}-${jy}-${String(db.journalCounter + 1).padStart(4, '0')}`;
}

export function makeEntry(
  db: AppDatabase,
  data: {
    date?: string;
    description: string;
    refType: JournalEntry['refType'];
    refId?: string;
    refLabel?: string;
    lines: JournalLine[];
    autoGenerated?: boolean;
    userId: string;
    userName: string;
  }
): JournalEntry {
  const lines = data.lines.filter(l => l.debit > 0 || l.credit > 0);
  const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
  const totalCredit = lines.reduce((s, l) => s + l.credit, 0);
  return {
    id: aid('jv'),
    number: nextJournalNumber(db),
    date: data.date || new Date().toISOString(),
    description: data.description,
    refType: data.refType,
    refId: data.refId,
    refLabel: data.refLabel,
    lines,
    totalDebit,
    totalCredit,
    status: 'ثبت شده',
    autoGenerated: data.autoGenerated ?? true,
    createdBy: data.userId,
    createdByName: data.userName,
    createdAt: new Date().toISOString(),
  };
}

export function pushEntry(db: AppDatabase, entry: JournalEntry): AppDatabase {
  return { ...db, journal: [entry, ...db.journal], journalCounter: db.journalCounter + 1 };
}

export function isPeriodLocked(db: AppDatabase, dateISO: string): boolean {
  if (!db.accounting.lockedBeforeDate) return false;
  return new Date(dateISO).getTime() < new Date(db.accounting.lockedBeforeDate).getTime();
}

const activeEntries = (db: AppDatabase) => db.journal.filter(e => e.status === 'ثبت شده');

export function accountMovement(db: AppDatabase, code: string, from?: string, to?: string) {
  let debit = 0, credit = 0;
  activeEntries(db).forEach(e => {
    if (from && new Date(e.date) < new Date(from)) return;
    if (to && new Date(e.date) > new Date(to)) return;
    e.lines.forEach(l => { if (l.accountCode !== code) return; debit += l.debit; credit += l.credit; });
  });
  return { debit, credit };
}

export function accountBalance(db: AppDatabase, code: string, to?: string): number {
  const acc = db.accounts.find(a => a.code === code);
  const opening = acc?.openingBalance ?? 0;
  const { debit, credit } = accountMovement(db, code, undefined, to);
  return opening + debit - credit;
}

export function cashAccounts(db: AppDatabase): Account[] {
  return db.accounts.filter(a => a.isCash && a.active);
}

export function totalCash(db: AppDatabase): number {
  return cashAccounts(db).reduce((s, a) => s + accountBalance(db, a.code), 0);
}

export function partyBalance(db: AppDatabase, partyType: PartyType, partyId: string): number {
  let bal = 0;
  activeEntries(db).forEach(e => e.lines.forEach(l => {
    if (l.partyType === partyType && l.partyId === partyId) bal += l.debit - l.credit;
  }));
  return bal;
}

export interface StatementRow {
  date: string; entryNumber: string; description: string;
  refType: string; debit: number; credit: number; balance: number;
}

export function partyStatement(db: AppDatabase, partyType: PartyType, partyId: string): StatementRow[] {
  const rows: StatementRow[] = [];
  const entries = activeEntries(db).slice().sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  let balance = 0;
  entries.forEach(e => {
    e.lines.forEach(l => {
      if (l.partyType !== partyType || l.partyId !== partyId) return;
      balance += l.debit - l.credit;
      rows.push({ date: e.date, entryNumber: e.number, description: l.description || e.description, refType: e.refType, debit: l.debit, credit: l.credit, balance });
    });
  });
  return rows;
}

export function ledgerRows(db: AppDatabase, code: string): StatementRow[] {
  const acc = db.accounts.find(a => a.code === code);
  let balance = acc?.openingBalance ?? 0;
  const rows: StatementRow[] = [];
  if (acc && acc.openingBalance !== 0) {
    rows.push({ date: db.accounting.fiscalYearStart, entryNumber: '—', description: 'مانده ابتدای دوره', refType: 'opening', debit: acc.openingBalance > 0 ? acc.openingBalance : 0, credit: acc.openingBalance < 0 ? -acc.openingBalance : 0, balance });
  }
  activeEntries(db).slice().sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).forEach(e => e.lines.forEach(l => {
    if (l.accountCode !== code) return;
    balance += l.debit - l.credit;
    rows.push({ date: e.date, entryNumber: e.number, description: l.description || e.description, refType: e.refType, debit: l.debit, credit: l.credit, balance });
  }));
  return rows;
}

export interface TrialRow { account: Account; debit: number; credit: number; balance: number }

export function trialBalance(db: AppDatabase, from?: string, to?: string): TrialRow[] {
  return db.accounts.map(account => {
    const { debit, credit } = accountMovement(db, account.code, from, to);
    const opening = account.openingBalance;
    return { account, debit: debit + (opening > 0 ? opening : 0), credit: credit + (opening < 0 ? -opening : 0), balance: opening + debit - credit };
  }).filter(r => r.debit !== 0 || r.credit !== 0);
}

export interface IncomeStatement {
  revenues: { account: Account; amount: number }[];
  expenses: { account: Account; amount: number }[];
  totalRevenue: number; totalExpense: number; grossProfit: number;
  netProfit: number; cogs: number; margin: number;
}

export function incomeStatement(db: AppDatabase, from?: string, to?: string): IncomeStatement {
  const revenues: { account: Account; amount: number }[] = [];
  const expenses: { account: Account; amount: number }[] = [];
  db.accounts.forEach(account => {
    const { debit, credit } = accountMovement(db, account.code, from, to);
    if (account.type === 'درآمد') {
      const amount = account.nature === 'بستانکار' ? credit - debit : -(debit - credit);
      if (amount !== 0) revenues.push({ account, amount });
    } else if (account.type === 'هزینه') {
      const amount = debit - credit;
      if (amount !== 0) expenses.push({ account, amount });
    }
  });
  const totalRevenue = revenues.reduce((s, r) => s + r.amount, 0);
  const totalExpense = expenses.reduce((s, e) => s + e.amount, 0);
  const cogs = expenses.filter(e => e.account.group === 'بهای تمام‌شده').reduce((s, e) => s + e.amount, 0);
  const netProfit = totalRevenue - totalExpense;
  return { revenues, expenses, totalRevenue, totalExpense, cogs, grossProfit: totalRevenue - cogs, netProfit, margin: totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0 };
}

export interface BalanceSheet {
  assets: { account: Account; amount: number }[];
  liabilities: { account: Account; amount: number }[];
  equity: { account: Account; amount: number }[];
  totalAssets: number; totalLiabilities: number; totalEquity: number;
  netProfit: number; balanced: boolean;
}

export function balanceSheet(db: AppDatabase, to?: string): BalanceSheet {
  const assets: { account: Account; amount: number }[] = [];
  const liabilities: { account: Account; amount: number }[] = [];
  const equity: { account: Account; amount: number }[] = [];
  db.accounts.forEach(account => {
    const bal = accountBalance(db, account.code, to);
    if (bal === 0) return;
    if (account.type === 'دارایی') assets.push({ account, amount: bal });
    else if (account.type === 'بدهی') liabilities.push({ account, amount: -bal });
    else if (account.type === 'سرمایه') equity.push({ account, amount: account.nature === 'بستانکار' ? -bal : bal });
  });
  const { netProfit } = incomeStatement(db, undefined, to);
  const totalAssets = assets.reduce((s, a) => s + a.amount, 0);
  const totalLiabilities = liabilities.reduce((s, a) => s + a.amount, 0);
  const totalEquity = equity.reduce((s, a) => s + (a.account.nature === 'بدهکار' ? -a.amount : a.amount), 0) + netProfit;
  return { assets, liabilities, equity, totalAssets, totalLiabilities, totalEquity, netProfit, balanced: Math.abs(totalAssets - (totalLiabilities + totalEquity)) < 10 };
}

export interface AgingBucket { label: string; amount: number; count: number }

export function arAging(db: AppDatabase, now = new Date()): AgingBucket[] {
  const buckets: AgingBucket[] = [
    { label: 'جاری (۰ تا ۳۰ روز)', amount: 0, count: 0 },
    { label: '۳۱ تا ۶۰ روز', amount: 0, count: 0 },
    { label: '۶۱ تا ۹۰ روز', amount: 0, count: 0 },
    { label: 'بیش از ۹۰ روز', amount: 0, count: 0 },
  ];
  db.invoices.forEach(inv => {
    const remaining = inv.totalAmount - inv.paidAmount;
    if (remaining <= 0) return;
    const days = Math.floor((now.getTime() - new Date(inv.date).getTime()) / 86400000);
    const idx = days <= 30 ? 0 : days <= 60 ? 1 : days <= 90 ? 2 : 3;
    buckets[idx].amount += remaining; buckets[idx].count += 1;
  });
  return buckets;
}

export function monthlySeries(db: AppDatabase, monthsBack = 6) {
  const [cy, cm] = getTodayJalali();
  const months = getPersianMonths();
  const series: { label: string; revenue: number; expense: number; profit: number; cash: number }[] = [];
  for (let i = monthsBack - 1; i >= 0; i--) {
    let y = cy, m = cm - i;
    while (m <= 0) { m += 12; y -= 1; }
    const start = createJalaliDate(y, m, 1);
    const end = m === 12 ? createJalaliDate(y + 1, 1, 1) : createJalaliDate(y, m + 1, 1);
    let revenue = 0, expense = 0, cash = 0;
    activeEntries(db).forEach(e => {
      const t = new Date(e.date).getTime();
      if (t < start.getTime() || t >= end.getTime()) return;
      e.lines.forEach(l => {
        const acc = db.accounts.find(a => a.code === l.accountCode);
        if (!acc) return;
        if (acc.type === 'درآمد') revenue += acc.nature === 'بستانکار' ? l.credit - l.debit : -(l.debit - l.credit);
        if (acc.type === 'هزینه') expense += l.debit - l.credit;
        if (acc.isCash) cash += l.debit - l.credit;
      });
    });
    series.push({ label: months[m - 1], revenue, expense, profit: revenue - expense, cash });
  }
  return series;
}

export function dailySeries(db: AppDatabase, days = 7) {
  const out: { label: string; revenue: number; received: number; orders: number }[] = [];
  const weekdays = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
  for (let i = days - 1; i >= 0; i--) {
    const day = new Date(); day.setHours(0, 0, 0, 0); day.setDate(day.getDate() - i);
    const next = new Date(day); next.setDate(next.getDate() + 1);
    let revenue = 0, received = 0;
    activeEntries(db).forEach(e => {
      const t = new Date(e.date).getTime();
      if (t < day.getTime() || t >= next.getTime()) return;
      e.lines.forEach(l => {
        const acc = db.accounts.find(a => a.code === l.accountCode);
        if (!acc) return;
        if (acc.type === 'درآمد') revenue += acc.nature === 'بستانکار' ? l.credit - l.debit : 0;
        if (acc.isCash) received += l.debit;
      });
    });
    const orders = db.orders.filter(o => { const t = new Date(o.registrationDate).getTime(); return t >= day.getTime() && t < next.getTime(); }).length;
    const [, , jd] = gregorianToJalali(day.getFullYear(), day.getMonth() + 1, day.getDate());
    out.push({ label: `${weekdays[day.getDay()]} ${jd}`, revenue, received, orders });
  }
  return out;
}

export function commissionFor(order: ServiceOrder, rate: number, settings: AccountingSettings, partsCostBasis: number): number {
  const base =
    settings.commissionBase === 'مبلغ کل' ? order.finalAmount :
    settings.commissionBase === 'سود ناخالص' ? Math.max(0, order.finalAmount - partsCostBasis) :
    order.laborCost;
  return round(base * (rate / 100), settings.roundingUnit);
}

export function partsCostBasis(db: AppDatabase, order: ServiceOrder): number {
  return order.parts.reduce((sum, p) => {
    const item = db.inventory.find(i => i.name.trim() === p.name.trim());
    const unitCost = item?.costPrice ?? (item ? item.unitPrice * db.accounting.defaultCostRatio : p.unitPrice * db.accounting.defaultCostRatio);
    return sum + unitCost * p.quantity;
  }, 0);
}

export function generateInvoiceForOrder(db: AppDatabase, orderId: string, user: { id: string; name: string }): { db: AppDatabase; invoiceId?: string; error?: string } {
  const order = db.orders.find(o => o.id === orderId);
  if (!order) return { db, error: 'سفارش یافت نشد' };
  const existing = db.invoices.find(i => i.orderId === orderId);
  if (existing) return { db, invoiceId: existing.id };
  if (order.finalAmount <= 0) return { db, error: 'مبلغ سفارش صفر است؛ ابتدا هزینه‌ها را ثبت کنید' };

  const s = db.accounting;
  const [jy] = getTodayJalali();
  let next = { ...db };
  const partsRevenue = order.parts.reduce((sum, p) => sum + p.quantity * p.unitPrice, 0);
  const taxAmount = s.taxEnabled ? round(order.finalAmount * (s.taxRate / 100), s.roundingUnit) : 0;
  const totalAmount = round(order.finalAmount + taxAmount, s.roundingUnit);
  const nowISO = new Date().toISOString();

  const invoice: Invoice = {
    id: aid('inv'),
    invoiceNumber: `INV-${jy}-${String(db.invoiceCounter + 1).padStart(4, '0')}`,
    orderId, customerId: order.customerId, date: nowISO, items: order.parts,
    transportationCost: order.transportationCost, laborCost: order.laborCost,
    discount: order.discount, otherCosts: order.otherCosts, taxAmount, totalAmount,
    paidAmount: 0, paymentStatus: 'پرداخت نشده', createdAt: nowISO,
  };
  const customerName = db.customers.find(c => c.id === order.customerId)?.fullName || 'مشتری';

  const saleLines: JournalLine[] = [
    { accountCode: s.arAccount, debit: totalAmount, credit: 0, description: `فاکتور ${invoice.invoiceNumber} - ${customerName}`, partyType: 'customer', partyId: order.customerId },
  ];
  if (order.discount > 0) saleLines.push({ accountCode: s.discountAccount, debit: order.discount, credit: 0, description: 'تخفیف اعطایی' });
  if (order.laborCost > 0) saleLines.push({ accountCode: s.laborRevenueAccount, debit: 0, credit: order.laborCost, description: 'اجرت خدمات تعمیر' });
  if (partsRevenue > 0) saleLines.push({ accountCode: s.partsRevenueAccount, debit: 0, credit: partsRevenue, description: 'فروش قطعات' });
  if (order.transportationCost > 0) saleLines.push({ accountCode: s.transportRevenueAccount, debit: 0, credit: order.transportationCost, description: 'ایاب و ذهاب' });
  if (order.otherCosts > 0) saleLines.push({ accountCode: s.otherRevenueAccount, debit: 0, credit: order.otherCosts, description: 'سایر درآمدها' });
  if (taxAmount > 0) saleLines.push({ accountCode: s.taxPayableAccount, debit: 0, credit: taxAmount, description: 'مالیات بر ارزش افزوده' });

  const saleEntry = makeEntry(next, { description: `صدور فاکتور ${invoice.invoiceNumber} بابت ${order.serviceType} - ${order.requestNumber}`, refType: 'invoice', refId: invoice.id, refLabel: invoice.invoiceNumber, lines: saleLines, userId: user.id, userName: user.name });
  invoice.journalEntryId = saleEntry.id;
  next = pushEntry(next, saleEntry);

  if (s.trackInventoryCost) {
    const cost = round(partsCostBasis(next, order), s.roundingUnit);
    if (cost > 0) {
      const cogsEntry = makeEntry(next, { description: `بهای تمام‌شده قطعات فاکتور ${invoice.invoiceNumber}`, refType: 'inventory', refId: invoice.id, refLabel: invoice.invoiceNumber, lines: [{ accountCode: s.cogsAccount, debit: cost, credit: 0, description: 'بهای تمام‌شده قطعات مصرفی' }, { accountCode: s.inventoryAccount, debit: 0, credit: cost, description: 'کاهش موجودی انبار' }], userId: user.id, userName: user.name });
      next = pushEntry(next, cogsEntry);
    }
    if (s.autoConsumeInventory) {
      next = { ...next, inventory: next.inventory.map(item => { const used = order.parts.find(p => p.name.trim() === item.name.trim()); return used ? { ...item, quantity: Math.max(0, item.quantity - used.quantity) } : item; }) };
    }
  }

  if (s.accrueCommission && order.technicianId) {
    const tech = next.technicians.find(t => t.id === order.technicianId);
    if (tech) {
      const commission = commissionFor(order, tech.commissionRate, s, partsCostBasis(next, order));
      if (commission > 0) {
        const commEntry = makeEntry(next, { description: `پورسانت ${tech.fullName} بابت ${order.requestNumber}`, refType: 'commission', refId: order.id, refLabel: order.requestNumber, lines: [{ accountCode: s.commissionExpenseAccount, debit: commission, credit: 0, description: `پورسانت ${tech.fullName}` }, { accountCode: s.commissionPayableAccount, debit: 0, credit: commission, description: `بستانکاری ${tech.fullName}`, partyType: 'technician', partyId: tech.id }], userId: user.id, userName: user.name });
        next = pushEntry(next, commEntry);
        next = { ...next, technicians: next.technicians.map(t => t.id === tech.id ? { ...t, totalCommission: t.totalCommission + commission, totalOrders: t.totalOrders + 1 } : t) };
      }
    }
  }

  next = { ...next, invoices: [invoice, ...next.invoices], invoiceCounter: next.invoiceCounter + 1, orders: next.orders.map(o => o.id === orderId ? { ...o, invoiceGenerated: true, updatedAt: nowISO } : o), customers: next.customers.map(c => c.id === order.customerId ? { ...c, totalSpent: c.totalSpent + totalAmount } : c) };
  return { db: next, invoiceId: invoice.id };
}

export function receiveFromCustomer(db: AppDatabase, input: { customerId: string; amount: number; method: PaymentMethod; date?: string; description?: string; invoiceId?: string }, user: { id: string; name: string }): { db: AppDatabase; error?: string; paymentId?: string } {
  const s = db.accounting;
  const amount = round(input.amount, s.roundingUnit);
  if (amount <= 0) return { db, error: 'مبلغ باید بزرگتر از صفر باشد' };
  const date = input.date || new Date().toISOString();
  if (isPeriodLocked(db, date)) return { db, error: 'این تاریخ در دوره بسته‌شده مالی قرار دارد' };
  const customer = db.customers.find(c => c.id === input.customerId);
  if (!customer) return { db, error: 'مشتری یافت نشد' };

  const openInvoices = db.invoices.filter(i => i.customerId === input.customerId && i.totalAmount - i.paidAmount > 0).filter(i => (input.invoiceId ? i.id === input.invoiceId : true)).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  let remaining = amount;
  const allocations: { invoiceId: string; amount: number }[] = [];
  const updatedInvoices = db.invoices.map(inv => ({ ...inv }));
  openInvoices.forEach(inv => {
    if (remaining <= 0) return;
    const due = inv.totalAmount - inv.paidAmount;
    const applied = Math.min(due, remaining);
    remaining -= applied;
    allocations.push({ invoiceId: inv.id, amount: applied });
    const target = updatedInvoices.find(i => i.id === inv.id)!;
    target.paidAmount += applied;
    target.paymentMethod = input.method;
    target.paymentStatus = target.paidAmount >= target.totalAmount ? 'پرداخت شده' : target.paidAmount > 0 ? 'پرداخت جزئی' : 'پرداخت نشده';
  });

  const advance = remaining;
  const cashCode = s.paymentAccountMap[input.method] || '1101';
  const allocated = amount - advance;

  const lines: JournalLine[] = [{ accountCode: cashCode, debit: amount, credit: 0, description: `دریافت از ${customer.fullName} (${input.method})` }];
  if (allocated > 0) lines.push({ accountCode: s.arAccount, debit: 0, credit: allocated, description: 'تسویه مطالبات', partyType: 'customer', partyId: customer.id });
  if (advance > 0) lines.push({ accountCode: s.customerAdvanceAccount, debit: 0, credit: advance, description: 'پیش‌دریافت از مشتری', partyType: 'customer', partyId: customer.id });

  let next: AppDatabase = { ...db, invoices: updatedInvoices };
  const receiptNumber = `RCT-${getTodayJalali()[0]}-${String(next.receiptCounter + 1).padStart(4, '0')}`;
  const entry = makeEntry(next, { date, description: `${receiptNumber} - دریافت وجه از ${customer.fullName}${input.description ? ` (${input.description})` : ''}`, refType: 'payment', refLabel: receiptNumber, lines, userId: user.id, userName: user.name });
  next = pushEntry(next, entry);

  const payment: Payment = {
    id: aid('pay'), receiptNumber, invoiceId: allocations[0]?.invoiceId || input.invoiceId || '',
    orderId: allocations[0] ? (db.invoices.find(i => i.id === allocations[0].invoiceId)?.orderId || '') : '',
    customerId: customer.id, amount, method: input.method, date, receivedBy: user.id,
    description: input.description, allocations, journalEntryId: entry.id, direction: 'دریافت',
  };
  next = { ...next, payments: [payment, ...next.payments], receiptCounter: next.receiptCounter + 1 };
  return { db: next, paymentId: payment.id };
}

export function postExpense(db: AppDatabase, input: { accountCode: string; paidFromCode: string; amount: number; date?: string; description: string; beneficiary?: string; relatedOrderId?: string }, user: { id: string; name: string }): { db: AppDatabase; error?: string } {
  const s = db.accounting;
  const amount = round(input.amount, s.roundingUnit);
  if (amount <= 0) return { db, error: 'مبلغ هزینه نامعتبر است' };
  const date = input.date || new Date().toISOString();
  if (isPeriodLocked(db, date)) return { db, error: 'این تاریخ در دوره بسته‌شده مالی قرار دارد' };
  const number = `EXP-${getTodayJalali()[0]}-${String(db.expenseCounter + 1).padStart(4, '0')}`;
  let next = { ...db };
  const entry = makeEntry(next, { date, description: `${number} - ${input.description}`, refType: 'expense', refLabel: number, lines: [{ accountCode: input.accountCode, debit: amount, credit: 0, description: input.description }, { accountCode: input.paidFromCode, debit: 0, credit: amount, description: input.beneficiary ? `پرداخت به ${input.beneficiary}` : 'پرداخت هزینه' }], autoGenerated: false, userId: user.id, userName: user.name });
  next = pushEntry(next, entry);
  const record: ExpenseRecord = { id: aid('exp'), number, date, accountCode: input.accountCode, paidFromCode: input.paidFromCode, amount, description: input.description, beneficiary: input.beneficiary, relatedOrderId: input.relatedOrderId, journalEntryId: entry.id, createdBy: user.id, createdAt: new Date().toISOString() };
  next = { ...next, expenses: [record, ...next.expenses], expenseCounter: next.expenseCounter + 1 };
  return { db: next };
}

export function postPurchase(db: AppDatabase, input: { itemId: string; quantity: number; unitCost: number; paidFromCode: string; date?: string; supplier?: string }, user: { id: string; name: string }): { db: AppDatabase; error?: string } {
  const s = db.accounting;
  const item = db.inventory.find(i => i.id === input.itemId);
  if (!item) return { db, error: 'قطعه یافت نشد' };
  const total = round(input.quantity * input.unitCost, s.roundingUnit);
  if (total <= 0) return { db, error: 'مبلغ خرید نامعتبر است' };
  const date = input.date || new Date().toISOString();
  let next: AppDatabase = { ...db, inventory: db.inventory.map(i => i.id === item.id ? { ...i, quantity: i.quantity + input.quantity, costPrice: input.unitCost } : i) };
  const entry = makeEntry(next, { date, description: `خرید ${item.name} (${input.quantity} عدد)${input.supplier ? ` از ${input.supplier}` : ''}`, refType: 'purchase', refId: item.id, refLabel: item.name, lines: [{ accountCode: s.inventoryAccount, debit: total, credit: 0, description: `افزایش موجودی ${item.name}` }, { accountCode: input.paidFromCode, debit: 0, credit: total, description: input.supplier ? `پرداخت به ${input.supplier}` : 'پرداخت خرید' }], autoGenerated: false, userId: user.id, userName: user.name });
  next = pushEntry(next, entry);
  return { db: next };
}

export function settleCommission(db: AppDatabase, input: { technicianId: string; amount: number; paidFromCode: string; date?: string; description?: string }, user: { id: string; name: string }): { db: AppDatabase; error?: string } {
  const s = db.accounting;
  const tech = db.technicians.find(t => t.id === input.technicianId);
  if (!tech) return { db, error: 'تکنسین یافت نشد' };
  const amount = round(input.amount, s.roundingUnit);
  if (amount <= 0) return { db, error: 'مبلغ نامعتبر است' };
  const date = input.date || new Date().toISOString();
  let next = { ...db };
  const entry = makeEntry(next, { date, description: `تسویه پورسانت ${tech.fullName}${input.description ? ` - ${input.description}` : ''}`, refType: 'settlement', refId: tech.id, refLabel: tech.fullName, lines: [{ accountCode: s.commissionPayableAccount, debit: amount, credit: 0, description: `تسویه با ${tech.fullName}`, partyType: 'technician', partyId: tech.id }, { accountCode: input.paidFromCode, debit: 0, credit: amount, description: 'پرداخت نقدی پورسانت' }], autoGenerated: false, userId: user.id, userName: user.name });
  next = pushEntry(next, entry);
  return { db: next };
}

export function postTransfer(db: AppDatabase, input: { fromCode: string; toCode: string; amount: number; date?: string; description?: string }, user: { id: string; name: string }): { db: AppDatabase; error?: string } {
  const amount = round(input.amount, db.accounting.roundingUnit);
  if (amount <= 0) return { db, error: 'مبلغ نامعتبر است' };
  if (input.fromCode === input.toCode) return { db, error: 'حساب مبدأ و مقصد یکسان است' };
  let next = { ...db };
  const from = db.accounts.find(a => a.code === input.fromCode);
  const to = db.accounts.find(a => a.code === input.toCode);
  const entry = makeEntry(next, { date: input.date, description: input.description || `انتقال وجه از ${from?.name} به ${to?.name}`, refType: 'transfer', lines: [{ accountCode: input.toCode, debit: amount, credit: 0, description: 'دریافت انتقال' }, { accountCode: input.fromCode, debit: 0, credit: amount, description: 'پرداخت انتقال' }], autoGenerated: false, userId: user.id, userName: user.name });
  next = pushEntry(next, entry);
  return { db: next };
}

export function postManualEntry(db: AppDatabase, input: { date?: string; description: string; lines: JournalLine[] }, user: { id: string; name: string }): { db: AppDatabase; error?: string } {
  const lines = input.lines.filter(l => l.accountCode && (l.debit > 0 || l.credit > 0));
  if (lines.length < 2) return { db, error: 'حداقل دو ردیف معتبر لازم است' };
  if (!isBalanced(lines)) return { db, error: 'سند تراز نیست: جمع بدهکار و بستانکار باید برابر باشد' };
  if (input.date && isPeriodLocked(db, input.date)) return { db, error: 'این تاریخ در دوره بسته‌شده مالی قرار دارد' };
  let next = { ...db };
  const entry = makeEntry(next, { date: input.date, description: input.description, refType: 'manual', lines, autoGenerated: false, userId: user.id, userName: user.name });
  next = pushEntry(next, entry);
  return { db: next };
}

export function voidEntry(db: AppDatabase, entryId: string, reason: string, user: { id: string; name: string }): { db: AppDatabase; error?: string } {
  const entry = db.journal.find(e => e.id === entryId);
  if (!entry) return { db, error: 'سند یافت نشد' };
  if (entry.status === 'ابطال شده') return { db, error: 'این سند قبلاً ابطال شده است' };
  let next: AppDatabase = { ...db, journal: db.journal.map(e => e.id === entryId ? { ...e, status: 'ابطال شده', voidReason: reason } : e) };
  const reversal = makeEntry(next, { description: `ابطال سند ${entry.number} - ${reason}`, refType: 'adjustment', refId: entry.id, refLabel: entry.number, lines: entry.lines.map(l => ({ ...l, debit: l.credit, credit: l.debit })), autoGenerated: false, userId: user.id, userName: user.name });
  next = pushEntry(next, reversal);
  return { db: next };
}

/** ویرایش فاکتور صادرشده: ابطال سند قبلی، به‌روزرسانی مبالغ و صدور سند جدید */
export function editInvoice(
  db: AppDatabase,
  invoiceId: string,
  updates: {
    items?: PartItem[];
    laborCost?: number;
    transportationCost?: number;
    otherCosts?: number;
    discount?: number;
    notes?: string;
  },
  user: { id: string; name: string }
): { db: AppDatabase; error?: string } {
  const inv = db.invoices.find(i => i.id === invoiceId);
  if (!inv) return { db, error: 'فاکتور یافت نشد' };
  const s = db.accounting;
  let next = { ...db };

  // recalc amounts
  const items = updates.items ?? inv.items;
  const laborCost = updates.laborCost ?? inv.laborCost;
  const transportationCost = updates.transportationCost ?? inv.transportationCost;
  const otherCosts = updates.otherCosts ?? inv.otherCosts;
  const discount = updates.discount ?? inv.discount;
  const subtotal = items.reduce((sum, p) => sum + p.quantity * p.unitPrice, 0) + laborCost + transportationCost + otherCosts - discount;
  const taxAmount = s.taxEnabled ? round(subtotal * (s.taxRate / 100), s.roundingUnit) : 0;
  const totalAmount = round(subtotal + taxAmount, s.roundingUnit);

  // void old sale entry
  if (inv.journalEntryId) {
    const voided = voidEntry(next, inv.journalEntryId, 'ویرایش فاکتور', user);
    if (!voided.error) next = voided.db;
  }

  // post new sale entry
  const customerName = db.customers.find(c => c.id === inv.customerId)?.fullName || 'مشتری';
  const partsRevenue = items.reduce((sum, p) => sum + p.quantity * p.unitPrice, 0);
  const lines: JournalLine[] = [
    { accountCode: s.arAccount, debit: totalAmount, credit: 0, description: `فاکتور ${inv.invoiceNumber} (ویرایش شده) - ${customerName}`, partyType: 'customer', partyId: inv.customerId },
  ];
  if (discount > 0) lines.push({ accountCode: s.discountAccount, debit: discount, credit: 0, description: 'تخفیف اعطایی' });
  if (laborCost > 0) lines.push({ accountCode: s.laborRevenueAccount, debit: 0, credit: laborCost, description: 'اجرت خدمات تعمیر' });
  if (partsRevenue > 0) lines.push({ accountCode: s.partsRevenueAccount, debit: 0, credit: partsRevenue, description: 'فروش قطعات' });
  if (transportationCost > 0) lines.push({ accountCode: s.transportRevenueAccount, debit: 0, credit: transportationCost, description: 'ایاب و ذهاب' });
  if (otherCosts > 0) lines.push({ accountCode: s.otherRevenueAccount, debit: 0, credit: otherCosts, description: 'سایر درآمدها' });
  if (taxAmount > 0) lines.push({ accountCode: s.taxPayableAccount, debit: 0, credit: taxAmount, description: 'مالیات بر ارزش افزوده' });

  const entry = makeEntry(next, {
    date: inv.date,
    description: `ویرایش فاکتور ${inv.invoiceNumber}`,
    refType: 'invoice', refId: inv.id, refLabel: inv.invoiceNumber,
    lines, userId: user.id, userName: user.name,
  });
  next = pushEntry(next, entry);

  const paymentStatus: Invoice['paymentStatus'] = inv.paidAmount >= totalAmount ? 'پرداخت شده' : inv.paidAmount > 0 ? 'پرداخت جزئی' : 'پرداخت نشده';

  next = {
    ...next,
    invoices: next.invoices.map(i => i.id === invoiceId ? {
      ...i,
      items, laborCost, transportationCost, otherCosts, discount, taxAmount, totalAmount,
      paymentStatus, notes: updates.notes ?? i.notes, journalEntryId: entry.id,
    } : i),
  };

  // sync customer totalSpent delta
  const delta = totalAmount - inv.totalAmount;
  if (delta !== 0) {
    next = { ...next, customers: next.customers.map(c => c.id === inv.customerId ? { ...c, totalSpent: Math.max(0, c.totalSpent + delta) } : c) };
  }
  return { db: next };
}

export function refTypeLabel(t: string): string {
  const map: Record<string, string> = {
    invoice: 'فاکتور فروش', payment: 'دریافت وجه', expense: 'هزینه', purchase: 'خرید',
    commission: 'پورسانت', settlement: 'تسویه', transfer: 'انتقال وجه', manual: 'سند دستی',
    opening: 'افتتاحیه', adjustment: 'اصلاحی', inventory: 'انبار', writeoff: 'سوخت مطالبات',
  };
  return map[t] || t;
}
