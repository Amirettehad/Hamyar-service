// OneSignal Web Push integration (SDK v16) — نسخهٔ اصلاح‌شدهٔ ترتیب مجوز
import type { AppSettings } from './types';

declare global {
  interface Window {
    OneSignalDeferred?: any[];
    OneSignal?: any;
  }
}

const SDK_URL = 'https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js';
const SW_PATH = '/OneSignalSDKWorker.js';
const REST_ENDPOINT = 'https://onesignal.com/api/v1/notifications';

export function onesignalConfigured(settings: AppSettings): boolean {
  return !!settings.oneSignalEnabled && !!settings.oneSignalAppId;
}

let readyPromise: Promise<any> | null = null;
let lastAppId: string | null = null;

function appendSdkIfNeeded() {
  if (typeof document === 'undefined') return;
  if (document.querySelector(`script[src="${SDK_URL}"]`)) return;
  const s = document.createElement('script');
  s.src = SDK_URL;
  s.defer = true;
  document.head.appendChild(s);
}

export function ensureOneSignal(settings: AppSettings): Promise<any> | null {
  if (!onesignalConfigured(settings)) return null;
  if (readyPromise && lastAppId === settings.oneSignalAppId) return readyPromise;
  lastAppId = settings.oneSignalAppId!;
  readyPromise = new Promise<any>((resolve) => {
    window.OneSignalDeferred = window.OneSignalDeferred || [];
    let resolved = false;
    const done = (os: any) => { if (!resolved) { resolved = true; resolve(os); } };
    window.OneSignalDeferred.push(async (OneSignal: any) => {
      try {
        await OneSignal.init({
          appId: settings.oneSignalAppId,
          serviceWorkerPath: SW_PATH,
          serviceWorkerParam: { scope: '/push/onesignal/' },
          allowLocalhostAsSecureOrigin: true,
          promptOptions: {
            slidedown: {
              prompts: [{
                type: 'push',
                autoPrompt: false,
                text: {
                  actionMessage: 'برای اینکه ماموریت‌ها و اعلان‌های میدانی روی گوشی شما برسند، اجازه نوتیفیکیشن را فعال کنید.',
                  acceptButton: 'فعال باشد',
                  cancelButton: 'بعداً',
                },
              }],
            },
          },
        } as any).catch(() => {});
      } catch { /* already-initialized */ }
      done(OneSignal);
    });
    appendSdkIfNeeded();
    if (window.OneSignal) {
      try { window.OneSignalDeferred.push((OneSignal: any) => done(OneSignal)); }
      catch { done(window.OneSignal); }
    } else {
      setTimeout(() => done(window.OneSignal || null), 4500);
    }
  });
  return readyPromise;
}

/** جاد: اول مجوز مرورگر واقعی گرفته می‌شود، بعد OneSignal به مشترک اختصاص می‌یابد. */
export async function subscribeCurrentUser(settings: AppSettings, externalUserId: string): Promise<'granted' | 'denied' | 'unsupported' | 'pending'> {
  if (typeof Notification === 'undefined') return 'unsupported';
  // ۱) مجوز مرورگر در همان user gesture گرفته شود
  const perm = await Notification.requestPermission();
  if (perm !== 'granted') return perm === 'denied' ? 'denied' : 'pending';

  // ۲) OneSignal راه‌اندازی و کاربر bind شود
  const os = await ensureOneSignal(settings);
  if (os) {
    try { if (os.login && typeof os.login === 'function') await os.login(externalUserId); } catch { /* ignore */ }
    try {
      if (os.Slidedown && typeof os.Slidedown.promptPush === 'function') await os.Slidedown.promptPush();
      else if (typeof os.showNativePrompt === 'function') await os.showNativePrompt();
    } catch { /* already subscribed */ }
  }
  return 'granted';
}

export async function onesignalLogin(externalUserId: string, settings: AppSettings): Promise<any | null> {
  const os = await ensureOneSignal(settings);
  if (!os) return null;
  try { if (os.login && typeof os.login === 'function') await os.login(externalUserId); } catch { /* ignore */ }
  return os;
}

export async function onesignalLogout(settings: AppSettings): Promise<void> {
  const os = await ensureOneSignal(settings);
  if (!os) return;
  try { if (os.logout && typeof os.logout === 'function') await os.logout(); } catch { /* ignore */ }
}

export async function requestOneSignalPermission(settings: AppSettings): Promise<'granted' | 'denied' | 'unsupported' | 'pending'> {
  // سازگاری با استفاده‌های قبلی: همان SubscribeCurrentUser بدون کاربر
  return subscribeCurrentUser(settings, '__pending_bind__');
}

export async function isOneSignalSubscribed(settings: AppSettings): Promise<boolean> {
  if (typeof Notification === 'undefined') return false;
  if (Notification.permission !== 'granted') return false;
  const os = await ensureOneSignal(settings);
  if (!os) return false;
  try {
    const sub = os.User?.PushSubscription;
    return !!(sub && (sub.optedIn === true || sub.isSubscribed === true || sub.id));
  } catch { return true; }
}

export interface SendPushResult { success: boolean; recipients: number; error?: string; raw?: unknown }

/** Direct push via OneSignal REST API (نیازمند REST API Key — در تنظیمات پنل اصلی). */
export async function sendOneSignalPush(
  settings: AppSettings,
  externalUserIds: string[],
  opts: { title: string; body: string; url?: string }
): Promise<SendPushResult> {
  if (!settings.oneSignalRestApiKey) {
    return { success: false, recipients: 0, error: 'کلید REST API در تنظیمات ثبت نشده است — اعلان درون‌برنامه‌ای ثبت شد ولی Push خارجی ارسال نشد.' };
  }
  if (!externalUserIds.length) return { success: false, recipients: 0, error: 'هیچ مخاطبی مشخص نشده است' };
  try {
    const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
    const linkUrl = opts.url ? (opts.url.startsWith('http') ? opts.url : `${baseUrl}/#${opts.url}`) : `${baseUrl}/#/tech`;
    const res = await fetch(REST_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Key ${settings.oneSignalRestApiKey}`,
      },
      body: JSON.stringify({
        app_id: settings.oneSignalAppId,
        include_external_user_ids: externalUserIds,
        headings: { en: opts.title, fa: opts.title },
        contents: { en: opts.body, fa: opts.body },
        data: { url: linkUrl },
        url: linkUrl,
        small_icon: '/icon-192.png',
      } as any),
    });
    if (!res.ok) {
      const txt = await res.text();
      return { success: false, recipients: 0, error: `خطای ${res.status}: ${txt.slice(0, 160)}` };
    }
    return { success: true, recipients: externalUserIds.length };
  } catch (e: any) {
    return { success: false, recipients: 0, error: e?.message || 'خطای اتصال به OneSignal' };
  }
}
