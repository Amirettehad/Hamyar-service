// Types for the main application (همیار سرویس اتحاد)

export type UserRole = 'admin' | 'technician' | 'customer';

export interface User {
  id: string;
  username: string;
  password: string;
  fullName: string;
  role: UserRole;
  phone?: string;
  email?: string;
  avatar?: string;
  technicianId?: string;
  customerId?: string;
  createdAt: string;
  lastLoginAt?: string;
}

export interface Customer {
  id: string;
  fullName: string;
  phone: string;
  phone2?: string;
  address?: string;
  lat?: number;
  lng?: number;
  createdAt: string;
  totalSpent: number;
  creditLimit?: number;
  notes?: string;
}

export type DeviceType = 'یخچال' | 'لباسشویی' | 'ظرفشویی' | 'کولر گازی' | 'پکیج' | 'اجاق گاز' | 'مایکروویو' | 'جاروبرقی' | 'تلویزیون' | 'آبگرمکن' | 'سایر';
export type DeviceBrand = 'بوش' | 'آاگ' | 'ال‌جی' | 'سامسونگ' | 'پاکشوما' | 'اسنوا' | 'دوو' | 'ایندزیت' | 'بکو' | 'هایسنس' | 'سایر';
export type WarrantyStatus = 'داخل گارانتی' | 'خارج از گارانتی';
export type ServiceType = 'نصب' | 'تعمیر' | 'سرویس دوره‌ای' | 'بازدید' | 'سایر';
export type PaymentMethod = 'نقد' | 'کارت' | 'شتاب' | 'چک' | 'اقساط';
export const PAYMENT_METHODS: PaymentMethod[] = ['نقد', 'کارت', 'شتاب', 'چک', 'اقساط'];

export type OrderStatus =
  | 'ثبت اولیه' | 'در انتظار اعزام' | 'اعزام شده' | 'در حال تعمیر'
  | 'نیاز به قطعه' | 'تعمیر شده' | 'آماده تحویل' | 'تحویل شده'
  | 'لغو شده' | 'انجام شده';

export const ORDER_STATUSES: OrderStatus[] = [
  'ثبت اولیه', 'در انتظار اعزام', 'اعزام شده', 'در حال تعمیر',
  'نیاز به قطعه', 'تعمیر شده', 'آماده تحویل', 'تحویل شده', 'لغو شده', 'انجام شده'
];

export const STATUS_COLORS: Record<OrderStatus, string> = {
  'ثبت اولیه': 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
  'در انتظار اعزام': 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400',
  'اعزام شده': 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
  'در حال تعمیر': 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400',
  'نیاز به قطعه': 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400',
  'تعمیر شده': 'bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-400',
  'آماده تحویل': 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
  'تحویل شده': 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400',
  'لغو شده': 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
  'انجام شده': 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400',
};

export interface Device {
  id: string;
  customerId: string;
  type: DeviceType;
  brand: DeviceBrand;
  model?: string;
  serialNumber?: string;
  warrantyMonths?: number;
  warrantyStatus: WarrantyStatus;
  purchaseDate?: string;
  qrCode?: string;
  notes?: string;
  createdAt: string;
}

export interface PartItem { id: string; name: string; quantity: number; unitPrice: number }

export type TechPermission =
  | 'status_change'   // تغییر وضعیت سفارش
  | 'report'          // ثبت گزارش سرویسکار
  | 'parts'           // افزودن قطعات و هزینه
  | 'invoice'         // صدور فاکتور
  | 'photo'           // آپلود عکس
  | 'chat'            // چت داخلی
  | 'knowledge'       // بانک دانش
  | 'receive_payment';// ثبت دریافت وجه از مشتری

export const TECH_PERMISSION_LABELS: Record<TechPermission, string> = {
  status_change: 'تغییر وضعیت سفارش',
  report: 'ثبت گزارش عملیات',
  parts: 'افزودن قطعات و هزینه',
  invoice: 'صدور فاکتور',
  photo: 'آپلود عکس از دوربین',
  chat: 'دسترسی به چت داخلی',
  knowledge: 'دسترسی به بانک دانش',
  receive_payment: 'ثبت دریافت وجه از مشتری',
};

export const DEFAULT_TECH_PERMISSIONS: TechPermission[] = [
  'status_change', 'report', 'parts', 'invoice', 'photo', 'knowledge',
];

export interface Technician {
  id: string;
  fullName: string;
  phone: string;
  specialization?: string;
  isActive: boolean;
  commissionRate: number;
  totalOrders: number;
  totalCommission: number;
  permissions: TechPermission[];
  createdAt: string;
}

export interface ServiceOrder {
  id: string;
  requestNumber: string;
  customerId: string;
  deviceId?: string;
  technicianId?: string;
  registrationDate: string;
  visitDate?: string;
  visitTime?: string;
  serviceType: ServiceType;
  status: OrderStatus;
  problemDescription: string;
  technicianReport?: string;
  parts: PartItem[];
  transportationCost: number;
  laborCost: number;
  partsCost: number;
  discount: number;
  otherCosts: number;
  finalAmount: number;
  customerSignature?: string;
  confirmerName?: string;
  confirmationDate?: string;
  attachments: { name: string; type: string; dataUrl: string }[];
  statusHistory: { status: OrderStatus; date: string; userId: string; note?: string }[];
  customerNotified: boolean;
  notes?: string;
  internalNote?: string;
  technicianPhotos?: string[];
  invoiceGenerated: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  orderId: string;
  customerId: string;
  date: string;
  items: PartItem[];
  transportationCost: number;
  laborCost: number;
  discount: number;
  otherCosts: number;
  taxAmount: number;
  totalAmount: number;
  paidAmount: number;
  paymentStatus: 'پرداخت نشده' | 'پرداخت جزئی' | 'پرداخت شده';
  paymentMethod?: PaymentMethod;
  journalEntryId?: string;
  notes?: string;
  createdAt: string;
  customerSignature?: string;
  confirmedAt?: string;
  confirmerName?: string;
}

export interface CustomerReceiptSubmission {
  id: string;
  receiptNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  invoiceId: string;
  invoiceNumber: string;
  amount: number;
  note?: string;
  imageUrl?: string;
  trackingCode?: string;
  submittedAt: string;
  status: 'در_انتظار_تایید' | 'تایید_شده' | 'رد_شده';
  reviewedAt?: string;
  reviewedBy?: string;
  rejectReason?: string;
}

export interface PaymentAllocation { invoiceId: string; amount: number }

export interface Payment {
  id: string;
  receiptNumber: string;
  invoiceId: string;
  orderId: string;
  customerId: string;
  amount: number;
  method: PaymentMethod;
  date: string;
  receivedBy: string;
  description?: string;
  allocations: PaymentAllocation[];
  journalEntryId?: string;
  direction: 'دریافت' | 'پرداخت';
}

export interface InventoryItem {
  id: string;
  name: string;
  partNumber?: string;
  brand?: string;
  category: string;
  quantity: number;
  minQuantity: number;
  unitPrice: number;
  costPrice?: number;
  location?: string;
  compatibleDevices?: DeviceType[];
  imageUrl?: string;
  description?: string;
  supplier?: string;
  createdAt: string;
}

export interface KnowledgeBaseArticle {
  id: string;
  title: string;
  brand: DeviceBrand | 'همه';
  deviceType: DeviceType | 'همه';
  category: 'عیب‌یابی' | 'راهنمای تعمیر' | 'کد خطا' | 'نقشه فنی' | 'گارانتی';
  content: string;
  tags: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  views: number;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  content: string;
  type: 'text' | 'image' | 'voice';
  mediaUrl?: string;
  timestamp: string;
  read: boolean;
}

export type NotificationType = 'status_change' | 'payment' | 'assignment' | 'system' | 'chat' | 'accounting' | 'broadcast';

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  body: string;
  type: NotificationType;
  relatedId?: string;
  read: boolean;
  createdAt: string;
  // rich notification extras
  icon?: string;            // emoji or lucide icon name
  imageUrl?: string;        // optional attached image (data url)
  internalLink?: string;    // in-app route e.g. "/orders/abc"
  externalLink?: string;    // external url
  accentColor?: string;     // accent hex
  audience?: 'all' | 'admin' | 'technician' | 'customer' | 'single';
  senderName?: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  entityType: string;
  entityId?: string;
  details?: string;
  ip?: string;
  timestamp: string;
}

export interface Reminder {
  id: string;
  title: string;
  date: string;
  time?: string;
  description?: string;
  completed: boolean;
  relatedOrderId?: string;
  createdBy: string;
}

export interface PhoneContact {
  id: string;
  name: string;
  phone: string;
  category: 'مشتری' | 'تأمین‌کننده' | 'همکار' | 'سایر';
  notes?: string;
  createdAt: string;
}

export interface WorkOrderPM {
  id: string;
  title: string;
  deviceType: DeviceType;
  frequency: 'روزانه' | 'هفتگی' | 'ماهانه' | 'فصلی' | 'سالانه';
  assigneeId?: string;
  dueDate: string;
  status: 'برنامه‌ریزی' | 'در حال انجام' | 'تکمیل شده' | 'معوق';
  description: string;
  checklist: { text: string; done: boolean }[];
  cost: number;
  partsUsed: PartItem[];
  orderType: 'PM' | 'CM' | 'EM';
  priority: 'کم' | 'متوسط' | 'زیاد' | 'بحرانی';
  createdAt: string;
}

/* ==================== ACCOUNTING ==================== */
export type AccountType = 'دارایی' | 'بدهی' | 'سرمایه' | 'درآمد' | 'هزینه';
export type AccountNature = 'بدهکار' | 'بستانکار';
export type PartyType = 'customer' | 'technician' | 'supplier';

export interface Account {
  code: string;
  name: string;
  type: AccountType;
  nature: AccountNature;
  parentCode?: string;
  group: string;
  isCash: boolean;
  isSystem: boolean;
  subledger?: PartyType;
  openingBalance: number;
  active: boolean;
  description?: string;
}

export interface JournalLine {
  accountCode: string;
  debit: number;
  credit: number;
  description?: string;
  partyType?: PartyType;
  partyId?: string;
}

export type JournalRefType =
  | 'invoice' | 'payment' | 'expense' | 'purchase' | 'commission'
  | 'settlement' | 'transfer' | 'manual' | 'opening' | 'adjustment'
  | 'inventory' | 'writeoff';

export interface JournalEntry {
  id: string;
  number: string;
  date: string;
  description: string;
  refType: JournalRefType;
  refId?: string;
  refLabel?: string;
  lines: JournalLine[];
  totalDebit: number;
  totalCredit: number;
  status: 'ثبت شده' | 'ابطال شده';
  autoGenerated: boolean;
  createdBy: string;
  createdByName: string;
  createdAt: string;
  voidReason?: string;
}

export interface ExpenseRecord {
  id: string;
  number: string;
  date: string;
  accountCode: string;
  paidFromCode: string;
  amount: number;
  description: string;
  beneficiary?: string;
  relatedOrderId?: string;
  journalEntryId?: string;
  createdBy: string;
  createdAt: string;
}

export interface AccountingSettings {
  fiscalYearLabel: string;
  fiscalYearStart: string;
  fiscalYearEnd: string;
  entryPrefix: string;
  autoPostInvoice: boolean;
  autoPostPayment: boolean;
  autoInvoiceOnCompletion: boolean;
  completionStatuses: OrderStatus[];
  accrueCommission: boolean;
  commissionBase: 'اجرت' | 'مبلغ کل' | 'سود ناخالص';
  trackInventoryCost: boolean;
  autoConsumeInventory: boolean;
  defaultCostRatio: number;
  taxEnabled: boolean;
  taxRate: number;
  roundingUnit: 1 | 100 | 1000;
  lockedBeforeDate?: string;
  defaultCreditLimit: number;
  alertNegativeCash: boolean;
  paymentAccountMap: Record<PaymentMethod, string>;
  arAccount: string;
  apAccount: string;
  commissionPayableAccount: string;
  commissionExpenseAccount: string;
  inventoryAccount: string;
  cogsAccount: string;
  taxPayableAccount: string;
  laborRevenueAccount: string;
  partsRevenueAccount: string;
  transportRevenueAccount: string;
  otherRevenueAccount: string;
  discountAccount: string;
  customerAdvanceAccount: string;
}

export interface BiometricCredential {
  id: string;
  userId: string;
  credentialId: string;
  label: string;
  createdAt: string;
  lastUsedAt?: string;
}

export interface AppSettings {
  shopName: string;
  shopNameEn: string;
  logoDataUrl?: string;
  stampDataUrl?: string;
  address: string;
  phone: string;
  phone2: string;
  developerName: string;
  developerPhone: string;
  developerPhone2: string;
  taxRate: number;
  defaultCurrency: 'تومان' | 'ریال';
  printPaperSize: 'A4' | 'A5';
  theme: 'light' | 'dark' | 'system';
  smsEnabled: boolean;
  whatsappEnabled: boolean;
  telegramEnabled: boolean;
  autoNotifyCustomer: boolean;
  defaultCommissionRate: number;
  biometricEnabled: boolean;
  biometricAllowedRoles: UserRole[];
  biometricRequireUserVerification: boolean;
  biometricTimeoutSeconds: number;
  // OneSignal Web Push
  oneSignalEnabled: boolean;
  oneSignalAppId?: string;
  oneSignalRestApiKey?: string;
}

export interface AppDatabase {
  users: User[];
  customers: Customer[];
  devices: Device[];
  technicians: Technician[];
  orders: ServiceOrder[];
  invoices: Invoice[];
  payments: Payment[];
  inventory: InventoryItem[];
  knowledgeBase: KnowledgeBaseArticle[];
  messages: ChatMessage[];
  notifications: NotificationItem[];
  auditLogs: AuditLog[];
  reminders: Reminder[];
  contacts: PhoneContact[];
  workOrders: WorkOrderPM[];
  accounts: Account[];
  journal: JournalEntry[];
  expenses: ExpenseRecord[];
  accounting: AccountingSettings;
  biometrics: BiometricCredential[];
  settings: AppSettings;
  orderCounter: number;
  invoiceCounter: number;
  journalCounter: number;
  receiptCounter: number;
  expenseCounter: number;
  customerReceipts?: CustomerReceiptSubmission[];
}

export const DEVICE_TYPES: DeviceType[] = ['یخچال', 'لباسشویی', 'ظرفشویی', 'کولر گازی', 'پکیج', 'اجاق گاز', 'مایکروویو', 'جاروبرقی', 'تلویزیون', 'آبگرمکن', 'سایر'];
export const BRANDS: DeviceBrand[] = ['بوش', 'آاگ', 'ال‌جی', 'سامسونگ', 'پاکشوما', 'اسنوا', 'دوو', 'ایندزیت', 'بکو', 'هایسنس', 'سایر'];
export const SERVICE_TYPES: ServiceType[] = ['نصب', 'تعمیر', 'سرویس دوره‌ای', 'بازدید', 'سایر'];
