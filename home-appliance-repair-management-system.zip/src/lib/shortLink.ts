// Short link generation and resolver for direct customer tracking
import type { ServiceOrder } from './types';

/**
 * ایجاد توکن یا شناسه کوتاه تمیز برای سفارش
 * به عنوان مثال SRV-1403-0001 تبدیل به 1403-0001 یا کد هش کوتاه می‌شود
 */
export function generateShortCode(order: ServiceOrder): string {
  if (!order || !order.requestNumber) return '';
  // حذف پیشوند SRV- برای ساخت لینک تمیز و کوتاه
  const cleaned = order.requestNumber.replace(/^SRV-/, '');
  return cleaned;
}

/**
 * بازیابی شماره سفارش از کد کوتاه
 */
export function resolveOrderFromShortCode(code: string, orders: ServiceOrder[]): ServiceOrder | null {
  if (!code || !orders.length) return null;
  const decoded = decodeURIComponent(code).trim().toLowerCase();
  
  // تطابق مستقیم با کد کامل
  let found = orders.find(o => o.requestNumber.toLowerCase() === decoded || o.id.toLowerCase() === decoded);
  if (found) return found;

  // تطابق با کد کوتاه (بدون SRV-)
  found = orders.find(o => o.requestNumber.toLowerCase().replace(/^srv-/, '') === decoded);
  if (found) return found;

  // تطابق با آخرین بخش شناسه
  found = orders.find(o => o.requestNumber.toLowerCase().endsWith(decoded));
  return found || null;
}

/**
 * تولید لینک کوتاه قابل اشتراک‌گذاری در پیامک و شبکه‌های اجتماعی
 */
export function buildTrackingUrl(order: ServiceOrder): string {
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  const pathname = typeof window !== 'undefined' ? window.location.pathname.replace(/\/$/, '') : '';
  const shortCode = generateShortCode(order);
  return `${origin}${pathname}/#/t/${shortCode}`;
}

/**
 * تولید متن آماده برای ارسال پیامک یا واتساپ به مشتری
 */
export function buildSmsTrackingText(order: ServiceOrder, customerName: string, shopName: string): string {
  const url = buildTrackingUrl(order);
  return `مشتری گرامی ${customerName}،
سفارش تعمیرات شما به شماره ${order.requestNumber} در سیستم ${shopName} ثبت و به‌روزرسانی شد.
مشاهده وضعیت دستگاه، فاکتور و امضای دیجیتال:
${url}`;
}
