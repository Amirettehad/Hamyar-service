// Helpers for real Web Notifications: registers the real service worker and shows notifications through it.

let registrationPromise: Promise<ServiceWorkerRegistration | null> | null = null;

export function notificationsSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window && 'serviceWorker' in navigator;
}

export function requestSWRegistration(): Promise<ServiceWorkerRegistration | null> {
  if (!('serviceWorker' in navigator)) return Promise.resolve(null);
  if (!registrationPromise) {
    registrationPromise = navigator.serviceWorker.register('/sw-pro.js').catch(() => null);
  }
  return registrationPromise;
}

export async function requestPushPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (!notificationsSupported()) return 'unsupported';
  const p = await Notification.requestPermission();
  if (p === 'granted') {
    const reg = await requestSWRegistration();
    // تأیید فعال شدن: نمایش یک نوتیفیکیشن تست برای اطمینان از کارکرد
    reg?.showNotification('اعلان‌رسانی فعال شد ✓', {
      body: 'اعلان‌های نرم‌افزار روی دستگاه شما نمایش داده می‌شود.',
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      tag: 'notif-test',
    }).catch(() => {});
  }
  return p;
}

export async function showSystemNotification(title: string, body: string, url = '/tech'): Promise<void> {
  if (!notificationsSupported() || Notification.permission !== 'granted') return;
  const reg = await requestSWRegistration();
  if (reg) {
    const path = url.startsWith('/') ? url : `/${url.replace(/^.*#\//, '')}`;
    reg.showNotification(title, {
      body,
      icon: '/icon-192.png',
      badge: '/icon-192.png',
      vibrate: [80, 40, 80],
      data: { url: path },
      tag: title + Date.now(),
      requireInteraction: false,
    } as NotificationOptions).catch(() => {
      try { new Notification(title, { body, icon: '/icon-192.png', data: { url: path } }); } catch { /* ignore */ }
    });
  } else {
    try { new Notification(title, { body, icon: '/icon-192.png', data: { url } }); } catch { /* ignore */ }
  }
}
