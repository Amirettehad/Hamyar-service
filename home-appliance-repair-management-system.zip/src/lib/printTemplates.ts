// Persistence for user-defined print templates (created in the editor).
import type { DocumentConfig, EditorElement } from '../editor/types';

export type FormType = 'invoice' | 'receipt';

export interface PrintTemplate {
  id: string;
  name: string;
  formType: FormType;
  document: DocumentConfig;
  elements: EditorElement[];
  createdAt: string;
  updatedAt: string;
}

const KEY = 'print_templates_v1';

function uid(): string {
  return `tpl-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export function listPrintTemplates(formType?: FormType): PrintTemplate[] {
  try {
    const raw = localStorage.getItem(KEY);
    const all: PrintTemplate[] = raw ? JSON.parse(raw) : [];
    return formType ? all.filter(t => t.formType === formType) : all;
  } catch { return []; }
}

export function savePrintTemplate(input: Omit<PrintTemplate, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }): PrintTemplate {
  const all = listPrintTemplates();
  const now = new Date().toISOString();
  let record: PrintTemplate;
  if (input.id) {
    record = { ...all.find(t => t.id === input.id)!, ...input, id: input.id, updatedAt: now };
  } else {
    record = { ...input, id: uid(), createdAt: now, updatedAt: now };
  }
  const next = [record, ...all.filter(t => t.id !== record.id)];
  localStorage.setItem(KEY, JSON.stringify(next));
  return record;
}

export function deletePrintTemplate(id: string): void {
  const all = listPrintTemplates().filter(t => t.id !== id);
  localStorage.setItem(KEY, JSON.stringify(all));
}
