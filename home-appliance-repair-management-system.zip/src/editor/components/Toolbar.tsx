import { useRef, useState } from 'react';
import {
  AlignCenterHorizontal, AlignCenterVertical, AlignEndHorizontal, AlignEndVertical,
  AlignStartHorizontal, AlignStartVertical, ArrowDownToLine, ArrowUpToLine, ChevronDown,
  Clipboard, Copy, Download, Eye, FileJson, FileText, Grid3x3, Group, Layers,
  Lock, Magnet, Maximize, Menu, Monitor, Printer, Redo2, Save, Scissors, Smartphone,
  Tablet, Trash2, Undo2, Ungroup, ZoomIn, ZoomOut,
} from 'lucide-react';
import { useEditor } from '../store';
import { fa, download, getPagePx } from '../utils';
import { cx } from './controls';

interface Props {
  onToggleLeft: () => void;
  onToggleRight: () => void;
  onPrintPreview: () => void;
  onHome: () => void;
  toast: (m: string, type?: 'success' | 'error' | 'info') => void;
}

const ZOOMS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2];

export function Toolbar({ onToggleLeft, onToggleRight, onPrintPreview, onHome, toast }: Props) {
  const st = useEditor();
  const [menuOpen, setMenuOpen] = useState(false);
  const [zoomOpen, setZoomOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const hasSelection = st.selectedElementIds.length > 0;
  const multi = st.selectedElementIds.length > 1;

  const save = () => {
    try { st.saveDocument(); toast('سند ذخیره شد ✓'); }
    catch { toast('حافظه مرورگر پر است', 'error'); }
  };

  const exportJson = () => {
    download(`${st.document.name || 'document'}.json`, st.exportAsJSON());
    toast('فایل JSON دانلود شد ✓');
  };

  const importJson = (f: File) => {
    const r = new FileReader();
    r.onload = () => {
      const ok = st.importFromJSON(String(r.result));
      toast(ok ? 'سند بارگذاری شد ✓' : 'فایل JSON نامعتبر است', ok ? 'success' : 'error');
    };
    r.readAsText(f);
  };

  const fitToScreen = () => {
    const page = getPagePx(st.document);
    const avail = window.innerWidth - (window.innerWidth >= 1024 ? 620 : 40);
    const availH = window.innerHeight - 190;
    st.setZoom(Math.min(avail / page.width, availH / page.height, 2));
    st.setPan({ x: 0, y: 0 });
  };

  const Btn = ({ onClick, title, active, disabled, children, danger }: {
    onClick: () => void; title: string; active?: boolean; disabled?: boolean; children: React.ReactNode; danger?: boolean;
  }) => (
    <button onClick={onClick} title={title} disabled={disabled}
      className={cx(
        'w-8 h-8 rounded-lg flex items-center justify-center transition-all active:scale-90 shrink-0',
        active ? 'bg-teal-600 text-white shadow-md shadow-teal-500/25'
          : danger ? 'text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20'
            : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800',
        disabled && 'opacity-35 pointer-events-none'
      )}>
      {children}
    </button>
  );

  const Sep = () => <span className="w-px h-6 bg-slate-200 dark:bg-slate-700 mx-0.5 shrink-0" />;

  return (
    <header className="editor-toolbar shrink-0 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 z-30">
      {/* Row 1 */}
      <div className="flex items-center gap-1 px-2 h-12">
        <Btn onClick={onToggleLeft} title="پنل ابزار"><Menu className="w-4 h-4" /></Btn>
        <button onClick={onHome} className="flex items-center gap-1.5 px-2 h-8 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0">
          <span className="w-6 h-6 rounded-lg bg-gradient-to-br from-teal-500 to-emerald-600 text-white flex items-center justify-center text-[10px] font-black">و</span>
          <span className="hidden lg:block text-[11px] font-bold text-slate-700 dark:text-slate-200">ویرایشگر قالب</span>
        </button>
        <Sep />

        <input
          value={st.document.name}
          onChange={e => st.updateDocument({ name: e.target.value })}
          className="w-28 md:w-48 h-8 px-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-transparent hover:border-slate-200 focus:border-teal-400 text-[12px] font-bold outline-none transition-colors"
        />

        <Sep />
        <Btn onClick={st.undo} title="برگرد (Ctrl+Z)" disabled={st.historyIndex <= 0}><Undo2 className="w-4 h-4" /></Btn>
        <Btn onClick={st.redo} title="از نو (Ctrl+Shift+Z)" disabled={st.historyIndex >= st.history.length - 1}><Redo2 className="w-4 h-4" /></Btn>
        <span className="hidden md:inline text-[9px] text-slate-400 font-mono">{fa(Math.max(0, st.historyIndex))}/{fa(Math.max(0, st.history.length - 1))}</span>

        <Sep />
        <div className="hidden md:flex items-center gap-1">
          <Btn onClick={st.copy} title="کپی (Ctrl+C)" disabled={!hasSelection}><Copy className="w-4 h-4" /></Btn>
          <Btn onClick={st.paste} title="چسباندن (Ctrl+V)" disabled={!st.clipboard}><Clipboard className="w-4 h-4" /></Btn>
          <Btn onClick={st.cut} title="برش (Ctrl+X)" disabled={!hasSelection}><Scissors className="w-4 h-4" /></Btn>
          <Btn onClick={() => st.deleteElement()} title="حذف (Delete)" disabled={!hasSelection} danger><Trash2 className="w-4 h-4" /></Btn>
        </div>

        <div className="flex-1" />

        {/* zoom */}
        <div className="hidden sm:flex items-center gap-0.5">
          <Btn onClick={() => st.setZoom(st.zoom - 0.25)} title="کوچک‌نمایی"><ZoomOut className="w-4 h-4" /></Btn>
          <div className="relative">
            <button onClick={() => setZoomOpen(o => !o)} className="h-8 px-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px] font-bold tabular-nums">
              {fa(Math.round(st.zoom * 100))}٪
            </button>
            {zoomOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setZoomOpen(false)} />
                <div className="absolute left-0 top-full mt-1 z-50 w-24 py-1 rounded-xl bg-white dark:bg-slate-800 shadow-2xl border border-slate-200 dark:border-slate-700">
                  {ZOOMS.map(z => (
                    <button key={z} onClick={() => { st.setZoom(z); setZoomOpen(false); }}
                      className="w-full px-3 py-1.5 text-[11px] text-right hover:bg-slate-100 dark:hover:bg-slate-700">{fa(z * 100)}٪</button>
                  ))}
                </div>
              </>
            )}
          </div>
          <Btn onClick={() => st.setZoom(st.zoom + 0.25)} title="بزرگ‌نمایی"><ZoomIn className="w-4 h-4" /></Btn>
          <Btn onClick={fitToScreen} title="متناسب با صفحه (Ctrl+0)"><Maximize className="w-4 h-4" /></Btn>
        </div>

        <Sep />
        <div className="hidden lg:flex items-center gap-0.5">
          <Btn onClick={() => st.setBreakpoint('mobile')} title="نمای موبایل" active={st.breakpoint === 'mobile'}><Smartphone className="w-4 h-4" /></Btn>
          <Btn onClick={() => st.setBreakpoint('tablet')} title="نمای تبلت" active={st.breakpoint === 'tablet'}><Tablet className="w-4 h-4" /></Btn>
          <Btn onClick={() => st.setBreakpoint('desktop')} title="نمای دسکتاپ" active={st.breakpoint === 'desktop'}><Monitor className="w-4 h-4" /></Btn>
        </div>

        <Sep />
        <Btn onClick={() => st.setPreviewMode(!st.previewMode)} title="پیش‌نمایش" active={st.previewMode}><Eye className="w-4 h-4" /></Btn>
        <Btn onClick={save} title="ذخیره (Ctrl+S)"><Save className="w-4 h-4" /></Btn>

        <div className="relative">
          <Btn onClick={() => setMenuOpen(o => !o)} title="خروجی و تنظیمات"><ChevronDown className="w-4 h-4" /></Btn>
          {menuOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />
              <div className="absolute left-0 top-full mt-1 z-50 w-52 py-1 rounded-xl bg-white dark:bg-slate-800 shadow-2xl border border-slate-200 dark:border-slate-700 animate-scale-in">
                <MenuItem icon={<Save className="w-3.5 h-3.5" />} onClick={() => { save(); setMenuOpen(false); }}>ذخیره سند</MenuItem>
                <MenuItem icon={<FileJson className="w-3.5 h-3.5" />} onClick={() => { exportJson(); setMenuOpen(false); }}>خروجی JSON</MenuItem>
                <MenuItem icon={<Download className="w-3.5 h-3.5" />} onClick={() => { fileRef.current?.click(); setMenuOpen(false); }}>ورودی از JSON</MenuItem>
                <div className="h-px bg-slate-100 dark:bg-slate-700 my-1" />
                <MenuItem icon={<Printer className="w-3.5 h-3.5" />} onClick={() => { onPrintPreview(); setMenuOpen(false); }}>پیش‌نمایش چاپ</MenuItem>
                <MenuItem icon={<FileText className="w-3.5 h-3.5" />} onClick={() => { window.print(); setMenuOpen(false); }}>چاپ / خروجی PDF</MenuItem>
                <MenuItem icon={<Save className="w-3.5 h-3.5" />} onClick={() => {
                  const name = window.prompt('نام قالب چاپ:', st.document.name);
                  if (!name) { setMenuOpen(false); return; }
                  const type = window.confirm('تایید = فاکتور، انصراف = رسید') ? 'invoice' : 'receipt';
                  import('../../lib/printTemplates').then(({ savePrintTemplate }) => {
                    savePrintTemplate({ name, formType: type, document: st.document, elements: st.elements });
                    toast('قالب چاپ ذخیره شد ✓ در بخش فاکتورها قابل انتخاب است', 'success');
                  });
                  setMenuOpen(false);
                }}>ذخیره به‌عنوان قالب چاپ</MenuItem>
                <div className="h-px bg-slate-100 dark:bg-slate-700 my-1" />
                <MenuItem icon={<Layers className="w-3.5 h-3.5" />} onClick={() => { onHome(); setMenuOpen(false); }}>لیست اسناد</MenuItem>
              </div>
            </>
          )}
        </div>
        <Btn onClick={onToggleRight} title="پنل تنظیمات"><Layers className="w-4 h-4" /></Btn>
        <input ref={fileRef} type="file" accept="application/json" hidden onChange={e => { const f = e.target.files?.[0]; if (f) importJson(f); e.target.value = ''; }} />
      </div>

      {/* Row 2: context actions */}
      <div className="flex items-center gap-1 px-2 h-10 border-t border-slate-100 dark:border-slate-800 overflow-x-auto scroll-area">
        <Btn onClick={st.toggleGrid} title="نمایش شبکه (G)" active={st.showGrid}><Grid3x3 className="w-4 h-4" /></Btn>
        <Btn onClick={st.toggleSnapGrid} title="اسنپ به شبکه (S)" active={st.snapToGrid}>
          <span className="text-[10px] font-black">⊹</span>
        </Btn>
        <Btn onClick={st.toggleSnapObject} title="اسنپ به عناصر" active={st.snapToObject}><Magnet className="w-4 h-4" /></Btn>
        <Sep />

        {hasSelection ? (
          <>
            <Btn onClick={() => st.reorderElement(st.selectedElementId!, 'up')} title="یک لایه بالا"><ArrowUpToLine className="w-4 h-4" /></Btn>
            <Btn onClick={() => st.reorderElement(st.selectedElementId!, 'down')} title="یک لایه پایین"><ArrowDownToLine className="w-4 h-4" /></Btn>
            <Sep />
            <Btn onClick={() => st.alignElements('right')} title="راست‌چین"><AlignEndVertical className="w-4 h-4" /></Btn>
            <Btn onClick={() => st.alignElements('center-h')} title="وسط افقی"><AlignCenterVertical className="w-4 h-4" /></Btn>
            <Btn onClick={() => st.alignElements('left')} title="چپ‌چین"><AlignStartVertical className="w-4 h-4" /></Btn>
            <Btn onClick={() => st.alignElements('top')} title="بالاچین"><AlignStartHorizontal className="w-4 h-4" /></Btn>
            <Btn onClick={() => st.alignElements('center-v')} title="وسط عمودی"><AlignCenterHorizontal className="w-4 h-4" /></Btn>
            <Btn onClick={() => st.alignElements('bottom')} title="پایین‌چین"><AlignEndHorizontal className="w-4 h-4" /></Btn>
            <Sep />
            <Btn onClick={() => st.distributeElements('horizontal')} title="توزیع افقی" disabled={st.selectedElementIds.length < 3}>
              <span className="text-[11px] font-black">⟺</span>
            </Btn>
            <Btn onClick={() => st.distributeElements('vertical')} title="توزیع عمودی" disabled={st.selectedElementIds.length < 3}>
              <span className="text-[11px] font-black rotate-90">⟺</span>
            </Btn>
            <Sep />
            <Btn onClick={() => st.groupElements()} title="گروه‌بندی (Ctrl+G)" disabled={!multi}><Group className="w-4 h-4" /></Btn>
            <Btn onClick={() => st.ungroupElements()} title="آنگروه"><Ungroup className="w-4 h-4" /></Btn>
            <Btn onClick={() => st.toggleLock()} title="قفل (Ctrl+L)"><Lock className="w-4 h-4" /></Btn>
            <span className="text-[10px] text-slate-400 px-2 whitespace-nowrap">{fa(st.selectedElementIds.length)} عنصر انتخاب شده</span>
          </>
        ) : (
          <span className="text-[10px] text-slate-400 px-2 whitespace-nowrap">
            عنصری انتخاب نشده — برای دیدن ابزار تراز، یک عنصر را انتخاب کنید
          </span>
        )}
      </div>
    </header>
  );
}

function MenuItem({ icon, children, onClick }: { icon: React.ReactNode; children: React.ReactNode; onClick: () => void }) {
  return (
    <button onClick={onClick} className="w-full flex items-center gap-2 px-3 py-2 text-[12px] text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
      {icon}{children}
    </button>
  );
}
