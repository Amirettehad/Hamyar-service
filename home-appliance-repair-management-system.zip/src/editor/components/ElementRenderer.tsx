import { QRCodeSVG } from 'qrcode.react';
import { cn } from '../../utils/cn';
import {
  Calendar, ChevronDown, ImageIcon, PenLine, Upload, Star, Heart, CheckCircle,
  Phone, Home, User, Wrench, ShieldCheck, Clock, MapPin, Wallet, Tag, Zap,
  Receipt, Box, Percent, Globe,
} from 'lucide-react';

const ICON_LIB: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  star: Star, heart: Heart, check: CheckCircle, phone: Phone, home: Home, user: User,
  wrench: Wrench, shield: ShieldCheck, clock: Clock, pin: MapPin, wallet: Wallet,
  tag: Tag, zap: Zap, receipt: Receipt, box: Box, percent: Percent, globe: Globe,
};
import type { EditorElement } from '../types';
import { fa, faNum, evaluateFormula, formatFormulaResult, numberToPersianWords, styleToCss } from '../utils';
import type { PrintDataContext } from '../../lib/printData';
import { resolveText, resolveNumber } from '../../lib/printData';

const pad: Record<string, string> = { compact: '2px 4px', normal: '5px 7px', relaxed: '9px 11px' };

export function ElementRenderer({ el, print = false, data }: { el: EditorElement; print?: boolean; data?: PrintDataContext }) {
  const s = el.style;
  const css = styleToCss(s, print);
  const p = el.properties;
  const r = (t?: string) => (data ? resolveText(t || '', data) : (t || ''));

  const box = (children: React.ReactNode, extra: React.CSSProperties = {}) => (
    <div style={{ ...css, width: '100%', height: '100%', display: 'flex', ...extra }}>{children}</div>
  );

  const alignItems = 'center';
  const justify = s.textAlign === 'center' ? 'center' : s.textAlign === 'left' ? 'flex-start' : 'flex-end';

  switch (el.type) {
    case 'heading':
    case 'text':
      return box(<span className="w-full truncate-none">{r(p.content)}</span>, { alignItems, justifyContent: justify });

    case 'paragraph':
      return box(<span className="w-full whitespace-pre-wrap">{r(p.content)}</span>, { alignItems: 'flex-start' });

    case 'text-input':
      return box(<span className="w-full" style={{ color: data ? s.color : undefined }}>{r(p.placeholder)}{p.required && <span className="text-rose-500"> *</span>}</span>, { alignItems, justifyContent: justify });

    case 'textarea':
      return box(<span className="w-full whitespace-pre-wrap" style={{ color: data ? s.color : undefined }}>{r(p.placeholder)}</span>, { alignItems: 'flex-start' });

    case 'number-input':
    case 'currency-input':
      return box(
        <>
          <span className="text-slate-400 flex-1">{p.placeholder}</span>
          {p.suffix && <span className="text-[10px] text-slate-400 shrink-0">{p.suffix}</span>}
        </>,
        { alignItems, gap: 6 }
      );

    case 'date-input':
      return box(
        <>
          <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="text-slate-400 flex-1">{p.placeholder || '۱۴۰۴/۰۱/۰۱'}</span>
        </>,
        { alignItems, gap: 6 }
      );

    case 'select':
      return box(
        <>
          <span className="text-slate-400 flex-1">{p.placeholder}</span>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        </>,
        { alignItems, gap: 6 }
      );

    case 'checkbox':
      return box(
        <>
          <span className="w-4 h-4 rounded border-2 border-slate-400 shrink-0" />
          <span>{p.content}</span>
        </>,
        { alignItems, gap: 6, justifyContent: justify }
      );

    case 'switch':
      return box(
        <>
          <span className="w-9 h-5 rounded-full bg-teal-600 p-0.5 shrink-0 flex">
            <span className="w-4 h-4 rounded-full bg-white block" />
          </span>
          <span>{p.content}</span>
        </>,
        { alignItems, gap: 8, justifyContent: justify }
      );

    case 'radio-group':
      return box(
        <div className={`w-full flex ${p.optionsLayout === 'horizontal' ? 'flex-row gap-4' : 'flex-col gap-1.5'}`}>
          {(p.options ?? []).map(o => (
            <span key={o.value} className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 rounded-full border-2 border-slate-400 inline-block shrink-0" />
              {o.label}
            </span>
          ))}
        </div>,
        { alignItems: 'flex-start' }
      );

    case 'divider': {
      const vertical = p.orientation === 'vertical';
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0 }}>
          <span style={{
            background: s.color,
            width: vertical ? Math.max(1, s.borderWidth || 2) : '100%',
            height: vertical ? '100%' : Math.max(1, s.borderWidth || 2),
            borderRadius: 2, display: 'block',
          }} />
        </div>
      );
    }

    case 'spacer':
      return <div style={{ ...css, width: '100%', height: '100%' }} />;

    case 'container':
    case 'row':
    case 'column':
      return (
        <div style={{
          ...css, width: '100%', height: '100%', display: 'flex',
          flexDirection: p.direction === 'column' ? 'column' : 'row',
          gap: p.gap ?? 8,
          alignItems: p.alignItems === 'start' ? 'flex-start' : p.alignItems === 'end' ? 'flex-end' : p.alignItems === 'center' ? 'center' : 'stretch',
          justifyContent: p.justifyContent === 'between' ? 'space-between' : p.justifyContent === 'around' ? 'space-around'
            : p.justifyContent === 'center' ? 'center' : p.justifyContent === 'end' ? 'flex-end' : 'flex-start',
          flexWrap: p.wrap ? 'wrap' : 'nowrap',
        }}>
          {!print && (
            <span className="text-[10px] text-slate-400 m-auto select-none">
              {el.type === 'row' ? 'ردیف' : el.type === 'column' ? 'ستون' : 'کانتینر'}
            </span>
          )}
        </div>
      );

    case 'image':
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0 }}>
          {p.src
            ? <img src={p.src} alt={p.alt} style={{ width: '100%', height: '100%', objectFit: p.fit ?? 'contain', borderRadius: s.borderRadius }} />
            : <span className="flex flex-col items-center gap-1 text-slate-400">
                <ImageIcon className="w-6 h-6" />
                <span className="text-[10px]">تصویر</span>
              </span>}
        </div>
      );

    case 'image-upload':
      return (
        <div style={{ ...css, width: '100%', height: '100%' }}
          className="flex flex-col items-center justify-center gap-1 border-2 border-dashed border-slate-300 text-slate-400 rounded-lg">
          {p.src
            ? <img src={p.src} alt={p.alt} style={{ width: '100%', height: '100%', objectFit: p.fit ?? 'cover', borderRadius: s.borderRadius }} />
            : <><Upload className="w-5 h-5" /><span className="text-[10px]">آپلود تصویر</span></>}
        </div>
      );

    case 'qr-code':
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 2, background: '#fff' }}>
          <QRCodeSVG value={p.value || 'ettehad'} size={Math.max(32, Math.min(el.width, el.height) - 8)} level="M" />
        </div>
      );

    case 'barcode': {
      const bars = Array.from({ length: 42 }, (_, i) => (2 + ((i * 7919) % 4)));
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2, background: '#fff' }}>
          <span className="flex items-end gap-[1px] h-[70%]">
            {bars.map((w, i) => <span key={i} style={{ width: w, height: '100%', background: i % 3 === 0 ? '#0f172a' : '#334155' }} />)}
          </span>
          <span className="text-[9px] tracking-widest text-slate-600">{fa(p.value || '1234567890')}</span>
        </div>
      );
    }

    case 'table':
    case 'dynamic-table': {
      const cols = p.columns ?? [];
      const rows = p.rows ?? 3;
      const cellPad = pad[p.cellPadding ?? 'normal'];
      const borderCss = p.tableBorder === 'none' ? 'none'
        : p.tableBorder === 'minimal' ? '1px solid #e2e8f0'
        : `1px ${p.tableBorder === 'dashed' ? 'dashed' : 'solid'} #cbd5e1`;
      return (
        <div style={{ ...css, width: '100%', height: '100%', padding: 0, display: 'block', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: s.fontSize, tableLayout: 'fixed' }}>
            {p.showHeader !== false && (
              <thead>
                <tr>
                  {cols.map(c => (
                    <th key={c.id} style={{
                      width: `${c.width}%`, background: p.headerBg ?? '#0f766e', color: p.headerColor ?? '#fff',
                      border: borderCss, padding: cellPad, textAlign: c.align, fontWeight: 700, fontSize: s.fontSize - 1,
                    }}>{c.header}</th>
                  ))}
                </tr>
              </thead>
            )}
            <tbody>
              {(() => {
                const renderCell = (c: typeof cols[number], item: Record<string, string | number> | undefined, ci: number, rowIdx: number) => {
                  if (ci === 0 && p.showRowNumbers && !c.dataField) return fa(rowIdx + 1);
                  if (item && c.dataField) {
                    const field = c.dataField.replace(/^item\./, '');
                    const raw = item[field];
                    if (raw === undefined || raw === '') return '';
                    if (c.type === 'currency') return faNum(Number(raw));
                    if (c.type === 'number') return fa(Number(raw));
                    return fa(String(raw));
                  }
                  return '';
                };
                if (data && data.items.length) {
                  return data.items.map((item, i) => (
                    <tr key={i} style={{ background: p.zebraStripes && i % 2 === 1 ? (p.altRowBg ?? '#f8fafc') : 'transparent' }}>
                      {cols.map((c, ci) => (
                        <td key={c.id} style={{ border: borderCss, padding: cellPad, textAlign: c.align, color: s.color, height: 22 }}>
                          {renderCell(c, item, ci, i)}
                        </td>
                      ))}
                    </tr>
                  ));
                }
                return Array.from({ length: rows }).map((_, ri) => (
                  <tr key={ri} style={{ background: p.zebraStripes && ri % 2 === 1 ? (p.altRowBg ?? '#f8fafc') : 'transparent' }}>
                    {cols.map((c, ci) => (
                      <td key={c.id} style={{ border: borderCss, padding: cellPad, textAlign: c.align, color: s.color, height: 22 }}>
                        {ci === 0 && p.showRowNumbers ? fa(ri + 1) : ''}
                      </td>
                    ))}
                  </tr>
                ));
              })()}
              {p.showFooter && (
                <tr>
                  {cols.map((c, ci) => {
                    const isLast = ci === cols.length - 1;
                    return (
                      <td key={c.id} style={{
                        border: borderCss, padding: cellPad, textAlign: c.align,
                        background: '#f1f5f9', fontWeight: 700, fontSize: s.fontSize - 1,
                      }}>
                        {ci === 0 ? 'جمع' : isLast ? (data ? faNum(data.items.reduce((sum, it) => sum + it.total, 0)) : faNum(750000)) : ''}
                      </td>
                    );
                  })}
                </tr>
              )}
            </tbody>
          </table>
        </div>
      );
    }

    case 'signature':
      return (
        <div style={{ ...css, width: '100%', height: '100%' }}
          className="flex flex-col items-center justify-center gap-1 border border-dashed border-slate-300 rounded-lg text-slate-400">
          <PenLine className="w-4 h-4" />
          <span className="text-[11px]">{p.content || 'محل امضا'}</span>
        </div>
      );

    case 'stamp':
      return (
        <div style={{ ...css, width: '100%', height: '100%' }} className="flex items-center justify-center">
          <span className="w-[85%] h-[85%] rounded-full border-2 border-dashed border-slate-300 flex items-center justify-center text-[10px] text-slate-400 text-center leading-4">
            {p.content || 'محل مهر'}
          </span>
        </div>
      );

    case 'watermark':
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: 'rotate(-24deg)' }}>
          <span className="font-black whitespace-nowrap">{p.content}</span>
        </div>
      );

    case 'page-number':
      return box(<span className="w-full">{(p.content || '').replace('{page}', '۱').replace('{total}', '۱')}</span>, { alignItems, justifyContent: 'center' });

    case 'auto-number':
      return box(
        <span className="w-full font-mono">{p.numberPrefix}{fa(p.startFrom ?? 1001)}</span>,
        { alignItems, justifyContent: justify }
      );

    case 'formula': {
      const val = data ? resolveNumber(p.formula ?? '', data) : evaluateFormula(p.formula ?? '', {});
      return box(<span className="w-full">{formatFormulaResult(val, p)}</span>, { alignItems, justifyContent: justify });
    }

    case 'amount-words': {
      const val = data ? resolveNumber(p.formula ?? '{amount.total}', data) : evaluateFormula(p.formula ?? '{total}', {});
      const words = numberToPersianWords(val || Number(p.content) || 0);
      return box(<span className="w-full leading-6">{p.prefix}{words} {p.suffix}</span>, { alignItems, justifyContent: justify });
    }

    case 'icon': {
      const IconCmp = ICON_LIB[p.content || 'star'] || Star;
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <IconCmp className="w-2/3 h-2/3" style={{ color: s.color }} />
        </div>
      );
    }

    case 'badge':
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <span>{r(p.content)}</span>
        </div>
      );

    case 'shape-circle':
      return <div style={{ ...css, width: '100%', height: '100%', borderRadius: '50%' }} />;

    case 'kv': {
      const val = r(`{${p.fieldName || ''}}`);
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ color: '#64748b', fontWeight: 500, flexShrink: 0 }}>{r(p.content)}:</span>
          <span style={{ flex: 1, borderBottom: '1px dashed #cbd5e1', paddingBottom: 2, textAlign: 'left', fontWeight: 600 }}>{val}</span>
        </div>
      );
    }

    case 'pill':
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <span>{r(p.content)}</span>
        </div>
      );

    case 'timeline': {
      const steps = p.timelineSteps || [
        { title: 'پذیرش', done: true },
        { title: 'عیب‌یابی', done: true },
        { title: 'تعمیر', done: false },
        { title: 'تحویل', done: false },
      ];
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 8px' }}>
          {steps.map((st, i) => (
            <div key={i} className="flex items-center flex-1 relative last:flex-none">
              <div className="flex flex-col items-center gap-1 z-10">
                <span className={cn(
                  'w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold border-2',
                  st.done
                    ? 'bg-teal-600 border-teal-600 text-white'
                    : 'bg-white border-slate-300 text-slate-400'
                )}>
                  {st.done ? '✓' : fa(i + 1)}
                </span>
                <span className={cn('text-[9px] font-medium whitespace-nowrap', st.done ? 'text-teal-700 font-bold' : 'text-slate-400')}>
                  {st.title}
                </span>
              </div>
              {i < steps.length - 1 && (
                <div className={cn('flex-1 h-0.5 mx-1 -mt-4', st.done ? 'bg-teal-600' : 'bg-slate-200')} />
              )}
            </div>
          ))}
        </div>
      );
    }

    case 'rating': {
      const stars = Array.from({ length: p.maxRating || 5 });
      const currentVal = p.ratingValue || 5;
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
          {stars.map((_, i) => (
            <span
              key={i}
              className={cn(
                'text-base transition-transform',
                i < currentVal ? 'text-amber-400 scale-110' : 'text-slate-200'
              )}
            >
              ★
            </span>
          ))}
        </div>
      );
    }

    case 'checklist': {
      const items = p.checklistItems || [
        { text: 'بررسی کابل و بدنه', checked: true },
        { text: 'تست اولیه عملکرد', checked: true },
        { text: 'کنترل نهایی قطعات', checked: false },
      ];
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 6, padding: '8px 12px' }}>
          {items.map((it, i) => (
            <div key={i} className="flex items-center gap-2 text-xs">
              <span className={cn(
                'w-4 h-4 rounded border-2 flex items-center justify-center text-[10px]',
                it.checked ? 'bg-teal-600 border-teal-600 text-white font-bold' : 'border-slate-300 bg-white'
              )}>
                {it.checked && '✓'}
              </span>
              <span className={cn(it.checked ? 'text-slate-700 font-medium' : 'text-slate-400')}>
                {it.text}
              </span>
            </div>
          ))}
        </div>
      );
    }

    case 'stat-box': {
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', padding: 8 }}>
          <span className="text-xl font-black text-teal-600 font-mono tracking-tight">
            {r(p.statNumber || '۱۰۰٪')}
          </span>
          <span className="text-[10px] text-slate-500 font-bold mt-0.5">
            {r(p.statLabel || 'شاخص عملکرد')}
          </span>
          {p.statBadge && (
            <span className="text-[8.5px] px-2 py-0.5 rounded-full bg-teal-100 text-teal-700 font-medium mt-1">
              {r(p.statBadge)}
            </span>
          )}
        </div>
      );
    }

    case 'dual-signature': {
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px' }}>
          <div className="flex-1 text-center border-l border-slate-200 pl-4">
            <span className="text-[11px] font-bold text-slate-700 block mb-8">
              {r(p.rightSignLabel || 'مهر و امضای مشتری')}
            </span>
            <div className="w-28 h-px bg-slate-300 mx-auto" />
          </div>
          <div className="flex-1 text-center pr-4">
            <span className="text-[11px] font-bold text-slate-700 block mb-8">
              {r(p.leftSignLabel || 'مهر و امضای شرکت / تعمیرگاه')}
            </span>
            <div className="w-28 h-px bg-slate-300 mx-auto" />
          </div>
        </div>
      );
    }

    case 'seal-badge': {
      const colorMap = {
        gold: 'border-amber-400 text-amber-800 bg-amber-50 shadow-amber-200/50',
        teal: 'border-teal-500 text-teal-800 bg-teal-50 shadow-teal-200/50',
        red: 'border-rose-500 text-rose-800 bg-rose-50 shadow-rose-200/50',
        blue: 'border-blue-500 text-blue-800 bg-blue-50 shadow-blue-200/50',
      };
      const badgeCls = colorMap[p.sealColor || 'gold'];
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div className={cn(
            'w-full h-full rounded-full border-4 border-double flex flex-col items-center justify-center p-2 text-center shadow-lg',
            badgeCls
          )}>
            <span className="text-[9px] font-black tracking-widest uppercase mb-0.5">★ رسمی ★</span>
            <span className="text-[11px] font-bold leading-3.5 px-1">{r(p.sealText || 'تأییدیه کیفیت')}</span>
          </div>
        </div>
      );
    }

    case 'notes-box': {
      const borders = {
        info: 'border-blue-400 bg-blue-50/70 text-blue-900',
        warning: 'border-amber-400 bg-amber-50/70 text-amber-900',
        success: 'border-emerald-400 bg-emerald-50/70 text-emerald-900',
        danger: 'border-rose-400 bg-rose-50/70 text-rose-900',
      };
      const noteCls = borders[p.noteType || 'warning'];
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px' }} className={cn('border-r-4 rounded-xl', noteCls)}>
          <span className="text-sm shrink-0">⚠️</span>
          <span className="text-xs leading-5 flex-1">{r(p.content || 'یادداشت مهم')}</span>
        </div>
      );
    }

    case 'device-specs': {
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '8px 12px' }}>
          <div className="flex items-center justify-between pb-1 mb-1 border-b border-slate-200">
            <span className="text-[10px] font-bold text-teal-700">شناسنامه دستگاه</span>
            <span className="text-[9px] text-slate-400">{r('{device.warranty}')}</span>
          </div>
          <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 text-[10px]">
            <div><span className="text-slate-400">نوع/برند:</span> <span className="font-bold">{r('{device.type} {device.brand}')}</span></div>
            <div><span className="text-slate-400">مدل:</span> <span className="font-bold">{r('{device.model}')}</span></div>
            <div className="col-span-2"><span className="text-slate-400">شماره سریال:</span> <span className="font-mono">{r('{device.serial}')}</span></div>
          </div>
        </div>
      );
    }

    case 'price-tag': {
      return (
        <div style={{ ...css, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
          <span className="text-base font-black font-mono tracking-tight">{r(p.priceAmount || '۷۵۰,۰۰۰')}</span>
          <span className="text-[10px] font-medium opacity-80">{r(p.priceCurrency || 'تومان')}</span>
        </div>
      );
    }

    default:
      return box(<span className="text-slate-400">{el.label}</span>, { alignItems, justifyContent: justify });
  }
}
