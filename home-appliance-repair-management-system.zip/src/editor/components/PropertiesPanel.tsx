import { useRef, useState } from 'react';
import { Badge, Button } from '../../components/ui';
import {
  AlignCenter, AlignJustify, AlignLeft, AlignRight, ArrowDown, ArrowLeft,
  ArrowRight, ArrowUp, Crosshair, FileText, Grid3x3, Image as ImageIcon,
  Layers, Move, Palette, Plus, Ruler, Settings2, Sigma, Smartphone, Sparkles,
  Table as TableIcon, Trash2, Type as TypeIcon,
} from 'lucide-react';
import { useEditor } from '../store';
import type { Breakpoint, DocumentType, EditorElement, ElementStyle, PageSize, TableColumn } from '../types';
import { DOC_TYPE_LABELS } from '../types';
import { fa, getPagePx, resolveRect, uuid, evaluateFormula, formatFormulaResult } from '../utils';
import { ColorField, NumberStepper, Section, SelectField, Segmented, TextField, Toggle, cx } from './controls';

const INPUT_TYPES = ['text-input', 'textarea', 'number-input', 'currency-input', 'date-input', 'select', 'checkbox', 'radio-group', 'switch'];
const TEXT_TYPES = ['text', 'heading', 'paragraph', 'watermark', 'page-number', 'formula', 'amount-words', 'auto-number', 'signature', 'stamp', 'checkbox', 'switch', 'badge', 'pill', 'kv', 'icon'];

export function PropertiesPanel() {
  const st = useEditor();
  const multiSelected = st.selectedElementIds.length > 1;
  if (multiSelected) {
    return (
      <div className="h-full overflow-y-auto scroll-area bg-white dark:bg-slate-900">
        <BatchEditPanel />
      </div>
    );
  }
  const el = st.elements.find(e => e.id === st.selectedElementId) ?? null;
  return (
    <div className="h-full overflow-y-auto scroll-area bg-white dark:bg-slate-900">
      {el ? <ElementProps el={el} /> : <DocumentProps />}
    </div>
  );
}

/* ==================== DOCUMENT ==================== */
function DocumentProps() {
  const st = useEditor();
  const d = st.document;
  const page = getPagePx(d);
  const fileRef = useRef<HTMLInputElement>(null);

  const setMargin = (side: 'top' | 'right' | 'bottom' | 'left', v: number) =>
    st.updateDocument({ margins: { ...d.margins, [side]: v } });

  return (
    <div>
      <div className="px-3 py-2.5 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
        <FileText className="w-4 h-4 text-teal-600" />
        <span className="text-[12px] font-bold">تنظیمات سند</span>
        <span className="mr-auto text-[10px] text-slate-400">{fa(page.width)}×{fa(page.height)} px</span>
      </div>

      <Section title="سند" icon={<FileText className="w-3.5 h-3.5 text-teal-600" />}>
        <TextField label="نام سند" value={d.name} onChange={v => st.updateDocument({ name: v })} />
        <SelectField label="نوع سند" value={d.type} onChange={(v: DocumentType) => st.updateDocument({ type: v })}
          options={(Object.keys(DOC_TYPE_LABELS) as DocumentType[]).map(k => ({ value: k, label: DOC_TYPE_LABELS[k] }))} />
        <TextField label="توضیحات" multiline rows={2} value={d.description} onChange={v => st.updateDocument({ description: v })} />
      </Section>

      <Section title="اندازه صفحه" icon={<Ruler className="w-3.5 h-3.5 text-teal-600" />}>
        <div className="grid grid-cols-5 gap-1">
          {(['A4', 'A5', 'A3', 'Letter', 'custom'] as PageSize[]).map(s => (
            <button key={s} onClick={() => st.updateDocument({ pageSize: s })}
              className={cx('py-1.5 rounded-lg text-[10px] font-bold border transition-all',
                d.pageSize === s ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-200 dark:border-slate-700 text-slate-500')}>
              {s === 'custom' ? 'سفارشی' : s}
            </button>
          ))}
        </div>
        <Segmented label="جهت صفحه" value={d.orientation} onChange={v => st.updateDocument({ orientation: v })}
          options={[{ value: 'portrait', label: '↕ عمودی' }, { value: 'landscape', label: '↔ افقی' }]} />
        {d.pageSize === 'custom' && (
          <>
            <NumberStepper label="عرض (میلی‌متر)" value={d.customWidth} min={50} max={600} onChange={v => st.updateDocument({ customWidth: v })} suffix="mm" />
            <NumberStepper label="ارتفاع (میلی‌متر)" value={d.customHeight} min={50} max={900} onChange={v => st.updateDocument({ customHeight: v })} suffix="mm" />
          </>
        )}
      </Section>

      <Section title="حاشیه صفحه" icon={<Move className="w-3.5 h-3.5 text-teal-600" />}>
        <NumberStepper label="بالا" value={d.margins.top} min={0} max={60} onChange={v => setMargin('top', v)} suffix="mm" />
        <NumberStepper label="پایین" value={d.margins.bottom} min={0} max={60} onChange={v => setMargin('bottom', v)} suffix="mm" />
        <NumberStepper label="راست" value={d.margins.right} min={0} max={60} onChange={v => setMargin('right', v)} suffix="mm" />
        <NumberStepper label="چپ" value={d.margins.left} min={0} max={60} onChange={v => setMargin('left', v)} suffix="mm" />
        <button onClick={() => st.updateDocument({ margins: { top: d.margins.top, right: d.margins.top, bottom: d.margins.top, left: d.margins.top } })}
          className="w-full py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] font-medium">🔗 یکسان‌سازی همه حاشیه‌ها</button>
      </Section>

      <Section title="پس‌زمینه" icon={<Palette className="w-3.5 h-3.5 text-teal-600" />} defaultOpen={false}>
        <ColorField label="رنگ پس‌زمینه" value={d.backgroundColor} onChange={v => st.updateDocument({ backgroundColor: v })} />
        <NumberStepper label="شفافیت پس‌زمینه" value={d.backgroundOpacity} min={0} max={100} onChange={v => st.updateDocument({ backgroundOpacity: v })} suffix="٪" />
        <div className="flex gap-1.5">
          <input ref={fileRef} type="file" accept="image/*" hidden onChange={e => {
            const f = e.target.files?.[0]; if (!f) return;
            const r = new FileReader();
            r.onload = () => st.updateDocument({ backgroundImage: r.result as string });
            r.readAsDataURL(f);
          }} />
          <button onClick={() => fileRef.current?.click()} className="flex-1 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px]">
            <ImageIcon className="w-3 h-3 inline ml-1" />تصویر پس‌زمینه
          </button>
          {d.backgroundImage && <button onClick={() => st.updateDocument({ backgroundImage: null })} className="px-2 rounded-lg bg-rose-100 text-rose-600 text-[11px]">حذف</button>}
        </div>
        <Toggle label="حاشیه دور صفحه" checked={d.showBorder} onChange={v => st.updateDocument({ showBorder: v })} />
        {d.showBorder && (
          <>
            <ColorField label="رنگ حاشیه" value={d.borderColor} onChange={v => st.updateDocument({ borderColor: v })} />
            <NumberStepper label="ضخامت حاشیه" value={d.borderWidth} min={1} max={8} onChange={v => st.updateDocument({ borderWidth: v })} suffix="px" />
            <Segmented label="سبک حاشیه" value={d.borderStyle} onChange={v => st.updateDocument({ borderStyle: v })}
              options={[{ value: 'solid', label: 'خط ممتد' }, { value: 'dashed', label: 'خط‌چین' }, { value: 'dotted', label: 'نقطه‌چین' }]} />
          </>
        )}
      </Section>

      <Section title="شبکه و اسنپ" icon={<Grid3x3 className="w-3.5 h-3.5 text-teal-600" />}>
        <Toggle label="نمایش شبکه" checked={st.showGrid} onChange={st.toggleGrid} />
        <Segmented label="اندازه شبکه" value={String(st.gridSize)} onChange={v => st.setGridSize(Number(v))}
          options={[5, 10, 15, 20].map(n => ({ value: String(n), label: `${fa(n)}px` }))} />
        <ColorField label="رنگ شبکه" value={d.gridColor} onChange={v => st.updateDocument({ gridColor: v })} />
        <NumberStepper label="شفافیت شبکه" value={d.gridOpacity} min={5} max={100} onChange={v => st.updateDocument({ gridOpacity: v })} suffix="٪" />
        <div className="h-px bg-slate-100 dark:bg-slate-800 my-1" />
        <Toggle label="اسنپ به شبکه" hint="چسبیدن به نقاط شبکه هنگام جابجایی" checked={st.snapToGrid} onChange={st.toggleSnapGrid} />
        <Toggle label="اسنپ به عناصر" hint="هم‌ترازی هوشمند با سایر عناصر" checked={st.snapToObject} onChange={st.toggleSnapObject} />
        <NumberStepper label="فاصله اسنپ" value={st.snapThreshold} min={2} max={20} onChange={st.setSnapThreshold} suffix="px" />
        <Toggle label="نمایش خط‌کش" checked={st.showRulers} onChange={st.toggleRulers} />
        <Toggle label="نمایش خطوط راهنما" checked={st.showGuides} onChange={st.toggleGuides} />
      </Section>
    </div>
  );
}

/* ==================== ELEMENT ==================== */
function ElementProps({ el }: { el: EditorElement }) {
  const st = useEditor();
  const [viewMode, setViewMode] = useState<'full' | 'half' | 'mini'>('full');
  const r = resolveRect(el, st.breakpoint);
  const s = el.style;
  const p = el.properties;
  const isText = TEXT_TYPES.includes(el.type) || INPUT_TYPES.includes(el.type);
  const isInput = INPUT_TYPES.includes(el.type);
  const isTable = el.type === 'table' || el.type === 'dynamic-table';
  const upd = (u: Partial<EditorElement>) => st.updateElement(el.id, u, false);
  const setPos = (x: number, y: number) => st.moveElement(el.id, x, y);

  // حالت بسته / شناور فشرده (Mini) برای دیدن ۱۰۰٪ بوم بدون هیچ مانعی
  if (viewMode === 'mini') {
    return (
      <div className="p-3 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 space-y-2.5 animate-scale-in">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 min-w-0">
            <Settings2 className="w-4 h-4 text-teal-600 shrink-0" />
            <span className="text-xs font-bold truncate">{el.label}</span>
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-teal-50 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300">{el.type}</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setViewMode('half')}
              className="px-2 py-1 rounded-lg text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold hover:bg-teal-50"
              title="حالت نیمه‌باز"
            >
              ◫ نیمه
            </button>
            <button
              onClick={() => setViewMode('full')}
              className="px-2 py-1 rounded-lg text-[10px] bg-teal-600 text-white font-bold"
              title="حالت باز کامل"
            >
              ⊞ کامل
            </button>
          </div>
        </div>

        {/* کنترل‌های سریع شناور */}
        <div className="grid grid-cols-4 gap-1.5 text-center">
          <div className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <p className="text-[9px] text-slate-400">X</p>
            <p className="text-xs font-bold font-mono">{fa(Math.round(r.x))}</p>
          </div>
          <div className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <p className="text-[9px] text-slate-400">Y</p>
            <p className="text-xs font-bold font-mono">{fa(Math.round(r.y))}</p>
          </div>
          <div className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <p className="text-[9px] text-slate-400">عرض</p>
            <p className="text-xs font-bold font-mono">{fa(Math.round(r.width))}</p>
          </div>
          <div className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <p className="text-[9px] text-slate-400">ارتفاع</p>
            <p className="text-xs font-bold font-mono">{fa(Math.round(r.height))}</p>
          </div>
        </div>

        {/* پد جهت‌نما و حرکت سریع */}
        <ArrowPad onMove={(dx, dy) => setPos(r.x + dx, r.y + dy)} onCommit={() => st.commit('جابجایی عنصر')} />
      </div>
    );
  }

  return (
    <div className={cx('pb-24 transition-all', viewMode === 'half' && 'opacity-95')}>
      {/* هدر با قابلیت سوئیچ بین حالت باز، نیمه‌باز و بسته/شناور */}
      <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 sticky top-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur z-10">
        <div className="flex items-center gap-1.5 flex-1 min-w-0">
          <Settings2 className="w-4 h-4 text-teal-600 shrink-0" />
          <input
            value={el.label}
            onChange={e => upd({ label: e.target.value })}
            className="flex-1 min-w-0 text-[12px] font-bold bg-transparent outline-none border-b border-transparent focus:border-teal-400"
          />
          <span className="text-[9px] px-1.5 py-0.5 rounded bg-teal-50 dark:bg-teal-900/30 text-teal-700 dark:text-teal-300 shrink-0">{el.type}</span>
        </div>

        {/* سوئیچر سه حالته: باز / نیمه‌باز / شناور و بسته */}
        <div className="flex items-center gap-0.5 bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl shrink-0">
          <button
            type="button"
            onClick={() => setViewMode('full')}
            className={cx(
              'px-2 py-1 rounded-lg text-[10px] font-bold transition-all',
              viewMode === 'full' ? 'bg-white dark:bg-slate-700 text-teal-600 shadow-sm' : 'text-slate-500 hover:text-slate-800'
            )}
            title="حالت باز کامل"
          >
            ⊞ کامل
          </button>
          <button
            type="button"
            onClick={() => setViewMode('half')}
            className={cx(
              'px-2 py-1 rounded-lg text-[10px] font-bold transition-all',
              viewMode === 'half' ? 'bg-white dark:bg-slate-700 text-teal-600 shadow-sm' : 'text-slate-500 hover:text-slate-800'
            )}
            title="حالت نیمه‌باز (فشرده با دید واضح بوم)"
          >
            ◫ نیمه
          </button>
          <button
            type="button"
            onClick={() => setViewMode('mini')}
            className="px-2 py-1 rounded-lg text-[10px] font-bold transition-all text-slate-500 hover:text-slate-800"
            title="حالت شناور (بدون مزاحمت دید بوم)"
          >
            ⊟ شناور
          </button>
        </div>
      </div>

      {/* Position & size */}
      <Section title="موقعیت و اندازه" icon={<Crosshair className="w-3.5 h-3.5 text-teal-600" />}>
        <div className="grid grid-cols-2 gap-2">
          <NumberStepper label="موقعیت X" value={r.x} min={-500} max={3000} onChange={v => setPos(v, r.y)} suffix="px" />
          <NumberStepper label="موقعیت Y" value={r.y} min={-500} max={3000} onChange={v => setPos(r.x, v)} suffix="px" />
          <NumberStepper label="عرض" value={r.width} min={el.minWidth} max={el.maxWidth} onChange={v => st.resizeElement(el.id, v, r.height)} suffix="px" />
          <NumberStepper label="ارتفاع" value={r.height} min={el.minHeight} max={el.maxHeight} onChange={v => st.resizeElement(el.id, r.width, v)} suffix="px" />
        </div>
        <NumberStepper label="چرخش" value={el.rotation} min={0} max={360} onChange={v => upd({ rotation: v })} suffix="°" />

        {/* Mobile arrow pad */}
        <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 p-2.5">
          <p className="text-[10px] font-bold text-slate-500 mb-2 text-center">جابجایی دقیق</p>
          <ArrowPad onMove={(dx, dy) => setPos(r.x + dx, r.y + dy)} onCommit={() => st.commit('جابجایی عنصر')} />
        </div>

        <div className="grid grid-cols-2 gap-1.5">
          <Toggle label="قفل" checked={el.locked} onChange={() => st.toggleLock(el.id)} />
          <Toggle label="مخفی" checked={el.hidden} onChange={() => st.toggleHidden(el.id)} />
        </div>
      </Section>

      {/* Typography */}
      {isText && (
        <Section title="تایپوگرافی" icon={<TypeIcon className="w-3.5 h-3.5 text-teal-600" />}>
          <SelectField label="فونت" value={s.fontFamily} onChange={v => st.updateStyle(el.id, { fontFamily: v })}
            options={[{ value: 'Vazirmatn', label: 'وزیرمتن' }, { value: 'IRANSans', label: 'ایران‌سنس' }, { value: 'Tahoma', label: 'تاهوما' }, { value: 'monospace', label: 'مونواسپیس' }]} />
          <NumberStepper label="اندازه قلم" value={s.fontSize} min={7} max={72} onChange={v => st.updateStyle(el.id, { fontSize: v })} suffix="px" />
          <Segmented label="وزن قلم" columns={5} value={s.fontWeight} onChange={v => st.updateStyle(el.id, { fontWeight: v })}
            options={[{ value: 'light', label: 'نازک' }, { value: 'normal', label: 'عادی' }, { value: 'medium', label: 'متوسط' }, { value: 'bold', label: 'ضخیم' }, { value: 'extrabold', label: 'سیاه' }]} />
          <Segmented label="تراز متن" value={s.textAlign} onChange={v => st.updateStyle(el.id, { textAlign: v })}
            options={[
              { value: 'right', label: <AlignRight className="w-3.5 h-3.5" />, title: 'راست‌چین' },
              { value: 'center', label: <AlignCenter className="w-3.5 h-3.5" />, title: 'وسط‌چین' },
              { value: 'left', label: <AlignLeft className="w-3.5 h-3.5" />, title: 'چپ‌چین' },
              { value: 'justify', label: <AlignJustify className="w-3.5 h-3.5" />, title: 'هم‌تراز' },
            ]} />
          <div className="grid grid-cols-3 gap-1.5">
            <button onClick={() => st.updateStyle(el.id, { fontStyle: s.fontStyle === 'italic' ? 'normal' : 'italic' })}
              className={cx('py-1.5 rounded-lg text-[11px] italic border', s.fontStyle === 'italic' ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-200 dark:border-slate-700')}>مورب</button>
            <button onClick={() => st.updateStyle(el.id, { textDecoration: s.textDecoration === 'underline' ? 'none' : 'underline' })}
              className={cx('py-1.5 rounded-lg text-[11px] underline border', s.textDecoration === 'underline' ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-200 dark:border-slate-700')}>زیرخط</button>
            <button onClick={() => st.updateStyle(el.id, { textDecoration: s.textDecoration === 'line-through' ? 'none' : 'line-through' })}
              className={cx('py-1.5 rounded-lg text-[11px] line-through border', s.textDecoration === 'line-through' ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-200 dark:border-slate-700')}>خط‌خورده</button>
          </div>
          <NumberStepper label="ارتفاع خط" value={s.lineHeight} min={1} max={3} step={0.1} precision={1} onChange={v => st.updateStyle(el.id, { lineHeight: v })} />
          <NumberStepper label="فاصله حروف" value={s.letterSpacing} min={-2} max={10} step={0.5} precision={1} onChange={v => st.updateStyle(el.id, { letterSpacing: v })} suffix="px" />
          <ColorField label="رنگ متن" value={s.color} onChange={v => st.updateStyle(el.id, { color: v })} />
        </Section>
      )}

      {/* Content */}
      {['text', 'heading', 'paragraph', 'watermark', 'signature', 'stamp', 'checkbox', 'switch', 'page-number', 'badge', 'pill', 'kv'].includes(el.type) && (
        <Section title="محتوا" icon={<TypeIcon className="w-3.5 h-3.5 text-teal-600" />}>
          <TextField label={el.type === 'kv' ? 'عنوان (کلید)' : 'متن'} multiline={el.type === 'paragraph'} rows={4} value={p.content ?? ''} onChange={v => st.updateProperties(el.id, { content: v })} />
          {el.type === 'kv' && (
            <SelectField label="مقدار (اتصال داده)" value={p.fieldName ?? ''} onChange={v => st.updateProperties(el.id, { fieldName: v })}
              options={[{ value: '', label: 'انتخاب فیلد...' },
                { value: 'customer.fullName', label: 'نام مشتری' }, { value: 'customer.phone', label: 'تلفن' }, { value: 'customer.address', label: 'آدرس' },
                { value: 'order.requestNumber', label: 'شماره سفارش' }, { value: 'order.date', label: 'تاریخ' }, { value: 'order.serviceType', label: 'نوع سرویس' },
                { value: 'order.status', label: 'وضعیت' }, { value: 'device.brand', label: 'برند دستگاه' }, { value: 'device.model', label: 'مدل دستگاه' },
                { value: 'technician.name', label: 'تکنسین' }, { value: 'shop.name', label: 'نام تعمیرگاه' },
                { value: 'amount.total.text', label: 'مبلغ کل' }, { value: 'amount.remaining.text', label: 'باقی‌مانده' }]} />
          )}
        </Section>
      )}

      {/* Icon picker */}
      {el.type === 'icon' && (
        <Section title="آیکون" icon={<TypeIcon className="w-3.5 h-3.5 text-teal-600" />}>
          <SelectField label="انتخاب آیکون" value={p.content ?? 'star'} onChange={v => st.updateProperties(el.id, { content: v })}
            options={[
              { value: 'star', label: 'ستاره' }, { value: 'heart', label: 'قلب' }, { value: 'check', label: 'تیک' },
              { value: 'phone', label: 'تلفن' }, { value: 'home', label: 'خانه' }, { value: 'user', label: 'کاربر' },
              { value: 'wrench', label: 'آچار' }, { value: 'shield', label: 'سپر' }, { value: 'clock', label: 'ساعت' },
              { value: 'pin', label: 'نقشه' }, { value: 'wallet', label: 'کیف پول' }, { value: 'tag', label: 'برچسب' },
              { value: 'zap', label: 'برق' }, { value: 'receipt', label: 'رسید' }, { value: 'box', label: 'جعبه' },
              { value: 'percent', label: 'درصد' }, { value: 'globe', label: 'جهان' },
            ]} />
          <ColorField label="رنگ آیکون" value={s.color} onChange={v => st.updateStyle(el.id, { color: v })} />
        </Section>
      )}

      {/* Background & border */}
      <Section title="پس‌زمینه و حاشیه" icon={<Palette className="w-3.5 h-3.5 text-teal-600" />} defaultOpen={false}>
        <ColorField label="رنگ پس‌زمینه" value={s.backgroundColor} onChange={v => st.updateStyle(el.id, { backgroundColor: v })} allowTransparent />
        <NumberStepper label="شفافیت پس‌زمینه" value={s.backgroundOpacity} min={0} max={100} onChange={v => st.updateStyle(el.id, { backgroundOpacity: v })} suffix="٪" />
        <Segmented label="سبک حاشیه" columns={5} value={s.borderStyle} onChange={v => st.updateStyle(el.id, { borderStyle: v })}
          options={[{ value: 'none', label: 'بدون' }, { value: 'solid', label: 'ممتد' }, { value: 'dashed', label: 'خط‌چین' }, { value: 'dotted', label: 'نقطه' }, { value: 'double', label: 'دوتایی' }]} />
        {s.borderStyle !== 'none' && (
          <>
            <NumberStepper label="ضخامت حاشیه" value={s.borderWidth} min={0} max={10} onChange={v => st.updateStyle(el.id, { borderWidth: v })} suffix="px" />
            <ColorField label="رنگ حاشیه" value={s.borderColor} onChange={v => st.updateStyle(el.id, { borderColor: v })} />
            <div>
              <p className="text-[11px] font-medium text-slate-600 dark:text-slate-300 mb-1">اضلاع حاشیه</p>
              <div className="grid grid-cols-4 gap-1">
                {([['borderTop', 'بالا'], ['borderRight', 'راست'], ['borderBottom', 'پایین'], ['borderLeft', 'چپ']] as const).map(([k, lbl]) => (
                  <button key={k} onClick={() => st.updateStyle(el.id, { [k]: !s[k] } as never)}
                    className={cx('py-1.5 rounded-lg text-[10px] border', s[k] ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-200 dark:border-slate-700 text-slate-500')}>{lbl}</button>
                ))}
              </div>
            </div>
          </>
        )}
        <NumberStepper label="گردی گوشه" value={s.borderRadius} min={0} max={40} onChange={v => st.updateStyle(el.id, { borderRadius: v })} suffix="px" />
      </Section>

      {/* Spacing */}
      <Section title="فاصله‌گذاری داخلی" icon={<Move className="w-3.5 h-3.5 text-teal-600" />} defaultOpen={false}>
        <div className="grid grid-cols-2 gap-2">
          <NumberStepper label="بالا" value={s.paddingTop} min={0} max={80} onChange={v => st.updateStyle(el.id, { paddingTop: v })} />
          <NumberStepper label="پایین" value={s.paddingBottom} min={0} max={80} onChange={v => st.updateStyle(el.id, { paddingBottom: v })} />
          <NumberStepper label="راست" value={s.paddingRight} min={0} max={80} onChange={v => st.updateStyle(el.id, { paddingRight: v })} />
          <NumberStepper label="چپ" value={s.paddingLeft} min={0} max={80} onChange={v => st.updateStyle(el.id, { paddingLeft: v })} />
        </div>
        <button onClick={() => st.updateStyle(el.id, { paddingRight: s.paddingTop, paddingBottom: s.paddingTop, paddingLeft: s.paddingTop })}
          className="w-full py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px]">🔗 یکسان‌سازی</button>
      </Section>

      {/* Advanced visual effects */}
      <Section title="افکت‌های ویژه" icon={<Sparkles className="w-3.5 h-3.5 text-teal-600" />}>
        <Segmented label="نوع افکت ظاهری" value={s.effect ?? 'none'} onChange={v => st.updateStyle(el.id, { effect: v as ElementStyle['effect'] })}
          options={[
            { value: 'none', label: 'بدون' },
            { value: 'gradient', label: 'گرادیانت' },
            { value: 'glass', label: 'شیشه‌ای' },
            { value: 'neu', label: 'نئومورف' },
          ]} />
        {s.effect === 'gradient' && (
          <>
            <ColorField label="رنگ شروع" value={s.gradFrom} onChange={v => st.updateStyle(el.id, { gradFrom: v })} />
            <ColorField label="رنگ پایان" value={s.gradTo} onChange={v => st.updateStyle(el.id, { gradTo: v })} />
            <NumberStepper label="زاویه گرادیانت" value={s.gradAngle} min={0} max={360} onChange={v => st.updateStyle(el.id, { gradAngle: v })} suffix="°" />
            <Segmented label="نوع گرادیانت" value={s.gradType ?? 'linear'} onChange={v => st.updateStyle(el.id, { gradType: v as ElementStyle['gradType'] })}
              options={[{ value: 'linear', label: 'خطی' }, { value: 'radial', label: 'شعاعی' }]} />
            <div className="grid grid-cols-4 gap-1.5">
              {[['#0d9488', '#3b82f6'], ['#f59e0b', '#ef4444'], ['#8b5cf6', '#ec4899'], ['#10b981', '#84cc16']].map(g => (
                <button key={g[0]} onClick={() => st.updateStyle(el.id, { gradFrom: g[0], gradTo: g[1] })}
                  className="h-8 rounded-lg border border-slate-200 dark:border-slate-700"
                  style={{ background: `linear-gradient(135deg, ${g[0]}, ${g[1]})` }} title="گرادیانت آماده" />
              ))}
            </div>
          </>
        )}
        {s.effect === 'glass' && (
          <NumberStepper label="قدرت بلور (شیشه)" value={s.glassBlur} min={0} max={40} onChange={v => st.updateStyle(el.id, { glassBlur: v })} suffix="px" />
        )}
      </Section>

      {/* Inner shadow */}
      <Section title="سایه داخلی" icon={<Sparkles className="w-3.5 h-3.5 text-teal-600" />} defaultOpen={false}>
        <Toggle label="فعال‌سازی سایه داخلی" checked={s.innerShadowEnabled} onChange={v => st.updateStyle(el.id, { innerShadowEnabled: v })} />
        {s.innerShadowEnabled && (
          <>
            <div className="grid grid-cols-2 gap-2">
              <NumberStepper label="افقی" value={s.innerShadowX} min={-30} max={30} onChange={v => st.updateStyle(el.id, { innerShadowX: v })} />
              <NumberStepper label="عمودی" value={s.innerShadowY} min={-30} max={30} onChange={v => st.updateStyle(el.id, { innerShadowY: v })} />
              <NumberStepper label="محو" value={s.innerShadowBlur} min={0} max={60} onChange={v => st.updateStyle(el.id, { innerShadowBlur: v })} />
              <NumberStepper label="گسترش" value={s.innerShadowSpread} min={-20} max={30} onChange={v => st.updateStyle(el.id, { innerShadowSpread: v })} />
            </div>
            <ColorField label="رنگ سایه داخلی" value={s.innerShadowColor} onChange={v => st.updateStyle(el.id, { innerShadowColor: v })} />
          </>
        )}
      </Section>

      {/* Stroke */}
      <Section title="حاشیه (Stroke)" icon={<Sparkles className="w-3.5 h-3.5 text-teal-600" />} defaultOpen={false}>
        <Toggle label="فعال‌سازی" checked={s.strokeEnabled} onChange={v => st.updateStyle(el.id, { strokeEnabled: v })} />
        {s.strokeEnabled && (
          <>
            <NumberStepper label="ضخامت استروک" value={s.strokeWidth} min={1} max={12} onChange={v => st.updateStyle(el.id, { strokeWidth: v })} suffix="px" />
            <ColorField label="رنگ استروک" value={s.strokeColor} onChange={v => st.updateStyle(el.id, { strokeColor: v })} />
            <Toggle label="فقط روی متن" checked={s.strokeTextOnly} onChange={v => st.updateStyle(el.id, { strokeTextOnly: v })} />
          </>
        )}
      </Section>

      {/* Filters */}
      <Section title="فیلترها (تصویر/دکور)" icon={<Sparkles className="w-3.5 h-3.5 text-teal-600" />} defaultOpen={false}>
        <NumberStepper label="بلور" value={s.filterBlur} min={0} max={20} onChange={v => st.updateStyle(el.id, { filterBlur: v })} suffix="px" />
        <NumberStepper label="روشنایی" value={s.filterBrightness} min={0} max={200} onChange={v => st.updateStyle(el.id, { filterBrightness: v })} suffix="٪" />
        <NumberStepper label="کنتراست" value={s.filterContrast} min={0} max={200} onChange={v => st.updateStyle(el.id, { filterContrast: v })} suffix="٪" />
        <NumberStepper label="اشباع رنگ" value={s.filterSaturate} min={0} max={200} onChange={v => st.updateStyle(el.id, { filterSaturate: v })} suffix="٪" />
        <NumberStepper label="سیاه‌سفید" value={s.filterGrayscale} min={0} max={100} onChange={v => st.updateStyle(el.id, { filterGrayscale: v })} suffix="٪" />
        <NumberStepper label="چرخش رنگ" value={s.filterHueRotate} min={0} max={360} onChange={v => st.updateStyle(el.id, { filterHueRotate: v })} suffix="°" />
        <button onClick={() => st.updateStyle(el.id, { filterBlur: 0, filterBrightness: 100, filterContrast: 100, filterSaturate: 100, filterGrayscale: 0, filterHueRotate: 0 })}
          className="w-full py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px]">بازنشانی فیلترها</button>
      </Section>

      {/* Text effects */}
      {isText && (
        <Section title="جلوه‌های متن" icon={<Sparkles className="w-3.5 h-3.5 text-teal-600" />} defaultOpen={false}>
          <Segmented label="جلوه متن" value={s.textEffect ?? 'none'} onChange={v => st.updateStyle(el.id, { textEffect: v as ElementStyle['textEffect'] })}
            options={[
              { value: 'none', label: 'بدون' },
              { value: 'shadow', label: 'سایه' },
              { value: 'outline', label: 'حاشیه‌دار' },
              { value: 'glow', label: 'درخشان' },
              { value: 'gradient-text', label: 'گرادیانت' },
            ]} columns={5} />
          {(s.textEffect === 'gradient-text') && (
            <>
              <ColorField label="رنگ شروع متن" value={s.gradFrom} onChange={v => st.updateStyle(el.id, { gradFrom: v })} />
              <ColorField label="رنگ پایان متن" value={s.gradTo} onChange={v => st.updateStyle(el.id, { gradTo: v })} />
            </>
          )}
        </Section>
      )}

      {/* Effects */}
      <Section title="جلوه‌های پایه" icon={<Sparkles className="w-3.5 h-3.5 text-teal-600" />} defaultOpen={false}>
        <NumberStepper label="شفافیت عنصر" value={s.opacity} min={0} max={100} onChange={v => st.updateStyle(el.id, { opacity: v })} suffix="٪" />
        <Toggle label="فعال‌سازی سایه" checked={s.shadowEnabled} onChange={v => st.updateStyle(el.id, { shadowEnabled: v })} />
        {s.shadowEnabled && (
          <>
            <div className="grid grid-cols-2 gap-2">
              <NumberStepper label="افقی" value={s.shadowX} min={-30} max={30} onChange={v => st.updateStyle(el.id, { shadowX: v })} />
              <NumberStepper label="عمودی" value={s.shadowY} min={-30} max={30} onChange={v => st.updateStyle(el.id, { shadowY: v })} />
              <NumberStepper label="محو شدن" value={s.shadowBlur} min={0} max={60} onChange={v => st.updateStyle(el.id, { shadowBlur: v })} />
              <NumberStepper label="گسترش" value={s.shadowSpread} min={-20} max={30} onChange={v => st.updateStyle(el.id, { shadowSpread: v })} />
            </div>
            <ColorField label="رنگ سایه" value={s.shadowColor} onChange={v => st.updateStyle(el.id, { shadowColor: v })} />
          </>
        )}
      </Section>

      {/* Field settings */}
      {isInput && (
        <Section title="تنظیمات فیلد" icon={<Layers className="w-3.5 h-3.5 text-teal-600" />}>
          <TextField label="نام فیلد (اتصال داده)" dir="ltr" value={p.fieldName ?? ''} onChange={v => st.updateProperties(el.id, { fieldName: v })} />
          <TextField label="متن راهنما" value={p.placeholder ?? ''} onChange={v => st.updateProperties(el.id, { placeholder: v })} />
          <TextField label="مقدار پیش‌فرض" value={p.defaultValue ?? ''} onChange={v => st.updateProperties(el.id, { defaultValue: v })} />
          <Toggle label="الزامی" checked={!!p.required} onChange={v => st.updateProperties(el.id, { required: v })} />
          <Toggle label="فقط خواندنی" checked={!!p.readOnly} onChange={v => st.updateProperties(el.id, { readOnly: v })} />
          <SelectField label="نوع اعتبارسنجی" value={p.validation?.type ?? 'none'}
            onChange={v => st.updateProperties(el.id, { validation: { ...(p.validation ?? { pattern: '', minLength: 0, maxLength: 0, min: 0, max: 0, errorMessage: '' }), type: v } })}
            options={[
              { value: 'none', label: 'بدون اعتبارسنجی' }, { value: 'email', label: 'ایمیل' },
              { value: 'phone', label: 'شماره تماس' }, { value: 'nationalCode', label: 'کد ملی' },
              { value: 'postalCode', label: 'کد پستی' }, { value: 'custom', label: 'الگوی سفارشی' },
            ]} />
          {p.validation?.type === 'custom' && (
            <TextField label="الگوی Regex" dir="ltr" value={p.validation.pattern} onChange={v => st.updateProperties(el.id, { validation: { ...p.validation!, pattern: v } })} />
          )}
          <div className="grid grid-cols-2 gap-2">
            <NumberStepper label="حداقل طول" value={p.validation?.minLength ?? 0} min={0} max={200} slider={false} onChange={v => st.updateProperties(el.id, { validation: { ...p.validation!, minLength: v } })} />
            <NumberStepper label="حداکثر طول" value={p.validation?.maxLength ?? 0} min={0} max={500} slider={false} onChange={v => st.updateProperties(el.id, { validation: { ...p.validation!, maxLength: v } })} />
          </div>
          <TextField label="پیام خطا" value={p.validation?.errorMessage ?? ''} onChange={v => st.updateProperties(el.id, { validation: { ...p.validation!, errorMessage: v } })} />

          {(el.type === 'number-input' || el.type === 'currency-input') && (
            <>
              <div className="grid grid-cols-2 gap-2">
                <NumberStepper label="حداقل مقدار" value={p.validation?.min ?? 0} min={0} max={1e7} step={1000} slider={false} onChange={v => st.updateProperties(el.id, { validation: { ...p.validation!, min: v } })} />
                <NumberStepper label="حداکثر مقدار" value={p.validation?.max ?? 0} min={0} max={1e9} step={10000} slider={false} onChange={v => st.updateProperties(el.id, { validation: { ...p.validation!, max: v } })} />
              </div>
              <NumberStepper label="گام تغییر" value={p.step ?? 1} min={1} max={100000} step={100} slider={false} onChange={v => st.updateProperties(el.id, { step: v })} />
              <TextField label="پسوند واحد" value={p.suffix ?? ''} onChange={v => st.updateProperties(el.id, { suffix: v })} />
              <Toggle label="جداکننده هزارتایی" checked={!!p.thousandSeparator} onChange={v => st.updateProperties(el.id, { thousandSeparator: v })} />
            </>
          )}
          {el.type === 'date-input' && (
            <SelectField label="قالب تاریخ" value={p.dateFormat ?? 'YYYY/MM/DD'} onChange={v => st.updateProperties(el.id, { dateFormat: v })}
              options={[{ value: 'YYYY/MM/DD', label: '۱۴۰۴/۰۳/۲۵' }, { value: 'DD MMMM YYYY', label: '۲۵ خرداد ۱۴۰۴' }, { value: 'YYYY-MM-DD', label: '۱۴۰۴-۰۳-۲۵' }]} />
          )}
          {(el.type === 'select' || el.type === 'radio-group') && <OptionsEditor el={el} />}
        </Section>
      )}

      {/* Table settings */}
      {isTable && <TableSettings el={el} />}

      {/* Formula */}
      {(el.type === 'formula' || el.type === 'amount-words') && (
        <Section title="تنظیمات فرمول" icon={<Sigma className="w-3.5 h-3.5 text-teal-600" />}>
          <TextField label="فرمول" dir="ltr" value={p.formula ?? ''} onChange={v => st.updateProperties(el.id, { formula: v })} />
          <p className="text-[10px] text-slate-400 leading-5">
            از <code className="bg-slate-100 dark:bg-slate-800 px-1 rounded">{'{fieldName}'}</code> برای ارجاع به فیلدها استفاده کنید.
            توابع: SUM، AVG، MIN، MAX، COUNT، ROUND
          </p>
          {el.type === 'formula' && (
            <>
              <SelectField label="قالب خروجی" value={p.format ?? 'number'} onChange={v => st.updateProperties(el.id, { format: v })}
                options={[{ value: 'number', label: 'عدد' }, { value: 'currency', label: 'مبلغ' }, { value: 'percent', label: 'درصد' }, { value: 'text', label: 'متن' }]} />
              <Segmented label="تعداد اعشار" value={String(p.decimalPlaces ?? 0)} onChange={v => st.updateProperties(el.id, { decimalPlaces: Number(v) })}
                options={[0, 1, 2, 3].map(n => ({ value: String(n), label: fa(n) }))} />
            </>
          )}
          <div className="grid grid-cols-2 gap-2">
            <TextField label="پیشوند" value={p.prefix ?? ''} onChange={v => st.updateProperties(el.id, { prefix: v })} />
            <TextField label="پسوند" value={p.suffix ?? ''} onChange={v => st.updateProperties(el.id, { suffix: v })} />
          </div>
          <div className="p-2 rounded-lg bg-teal-50 dark:bg-teal-900/20 text-[11px] text-teal-800 dark:text-teal-300">
            پیش‌نمایش: <b>{formatFormulaResult(evaluateFormula(p.formula ?? '', {}), p)}</b>
          </div>
        </Section>
      )}

      {/* Image */}
      {(el.type === 'image' || el.type === 'image-upload') && <ImageSettings el={el} />}

      {/* QR / barcode */}
      {(el.type === 'qr-code' || el.type === 'barcode') && (
        <Section title="محتوای کد" icon={<Layers className="w-3.5 h-3.5 text-teal-600" />}>
          <TextField label="مقدار" dir="ltr" value={p.value ?? ''} onChange={v => st.updateProperties(el.id, { value: v })} />
        </Section>
      )}

      {/* Container */}
      {['container', 'row', 'column'].includes(el.type) && (
        <Section title="چیدمان کانتینر" icon={<Layers className="w-3.5 h-3.5 text-teal-600" />}>
          <Segmented label="جهت" value={p.direction ?? 'row'} onChange={v => st.updateProperties(el.id, { direction: v })}
            options={[{ value: 'row', label: 'افقی' }, { value: 'column', label: 'عمودی' }]} />
          <NumberStepper label="فاصله بین آیتم‌ها" value={p.gap ?? 8} min={0} max={40} onChange={v => st.updateProperties(el.id, { gap: v })} suffix="px" />
          <SelectField label="تراز عمودی" value={p.alignItems ?? 'stretch'} onChange={v => st.updateProperties(el.id, { alignItems: v })}
            options={[{ value: 'start', label: 'ابتدا' }, { value: 'center', label: 'وسط' }, { value: 'end', label: 'انتها' }, { value: 'stretch', label: 'کشیده' }]} />
          <SelectField label="توزیع افقی" value={p.justifyContent ?? 'start'} onChange={v => st.updateProperties(el.id, { justifyContent: v })}
            options={[{ value: 'start', label: 'ابتدا' }, { value: 'center', label: 'وسط' }, { value: 'end', label: 'انتها' }, { value: 'between', label: 'بین' }, { value: 'around', label: 'اطراف' }]} />
          <Toggle label="شکستن خط (Wrap)" checked={!!p.wrap} onChange={v => st.updateProperties(el.id, { wrap: v })} />
        </Section>
      )}

      {el.type === 'divider' && (
        <Section title="خط جداکننده" icon={<Layers className="w-3.5 h-3.5 text-teal-600" />}>
          <Segmented label="جهت خط" value={p.orientation ?? 'horizontal'} onChange={v => st.updateProperties(el.id, { orientation: v })}
            options={[{ value: 'horizontal', label: 'افقی' }, { value: 'vertical', label: 'عمودی' }]} />
          <NumberStepper label="ضخامت" value={s.borderWidth || 2} min={1} max={12} onChange={v => st.updateStyle(el.id, { borderWidth: v })} suffix="px" />
          <ColorField label="رنگ خط" value={s.color} onChange={v => st.updateStyle(el.id, { color: v })} />
        </Section>
      )}

      {/* Timeline settings */}
      {el.type === 'timeline' && (
        <Section title="مراحل تایم‌لاین" icon={<Layers className="w-3.5 h-3.5 text-teal-600" />}>
          <div className="space-y-2">
            {(p.timelineSteps || []).map((step, idx) => (
              <div key={idx} className="flex items-center gap-1.5 p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                <input
                  type="checkbox"
                  checked={!!step.done}
                  onChange={e => {
                    const next = [...(p.timelineSteps || [])];
                    next[idx] = { ...next[idx], done: e.target.checked };
                    st.updateProperties(el.id, { timelineSteps: next });
                  }}
                  className="w-4 h-4 accent-teal-600 shrink-0"
                />
                <input
                  value={step.title}
                  onChange={e => {
                    const next = [...(p.timelineSteps || [])];
                    next[idx] = { ...next[idx], title: e.target.value };
                    st.updateProperties(el.id, { timelineSteps: next });
                  }}
                  placeholder="عنوان مرحله"
                  className="flex-1 min-w-0 text-[11px] px-2 py-1 rounded border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-900"
                />
                <button
                  type="button"
                  onClick={() => {
                    const next = (p.timelineSteps || []).filter((_, j) => j !== idx);
                    st.updateProperties(el.id, { timelineSteps: next });
                  }}
                  className="p-1 text-rose-500 hover:bg-rose-50 rounded"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            <Button
              size="sm"
              variant="outline"
              className="w-full text-xs"
              onClick={() => {
                const next = [...(p.timelineSteps || []), { title: `مرحله ${(p.timelineSteps?.length || 0) + 1}`, done: false }];
                st.updateProperties(el.id, { timelineSteps: next });
              }}
            >
              <Plus className="w-3 h-3 ml-1" />
              افزودن مرحله جدید
            </Button>
          </div>
        </Section>
      )}

      {/* Rating settings */}
      {el.type === 'rating' && (
        <Section title="تنظیمات رتبه‌بندی" icon={<Sparkles className="w-3.5 h-3.5 text-teal-600" />}>
          <NumberStepper
            label="امتیاز پیش‌فرض"
            value={p.ratingValue || 5}
            min={0}
            max={p.maxRating || 5}
            onChange={v => st.updateProperties(el.id, { ratingValue: v })}
          />
          <NumberStepper
            label="حداکثر ستاره‌ها"
            value={p.maxRating || 5}
            min={3}
            max={10}
            onChange={v => st.updateProperties(el.id, { maxRating: v })}
          />
        </Section>
      )}

      {/* Checklist settings */}
      {el.type === 'checklist' && (
        <Section title="آیتم‌های چک‌لیست" icon={<Layers className="w-3.5 h-3.5 text-teal-600" />}>
          <div className="space-y-2">
            {(p.checklistItems || []).map((it, idx) => (
              <div key={idx} className="flex items-center gap-1.5 p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800">
                <input
                  type="checkbox"
                  checked={!!it.checked}
                  onChange={e => {
                    const next = [...(p.checklistItems || [])];
                    next[idx] = { ...next[idx], checked: e.target.checked };
                    st.updateProperties(el.id, { checklistItems: next });
                  }}
                  className="w-4 h-4 accent-teal-600 shrink-0"
                />
                <input
                  value={it.text}
                  onChange={e => {
                    const next = [...(p.checklistItems || [])];
                    next[idx] = { ...next[idx], text: e.target.value };
                    st.updateProperties(el.id, { checklistItems: next });
                  }}
                  placeholder="عنوان آیتم بازرسی"
                  className="flex-1 min-w-0 text-[11px] px-2 py-1 rounded border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-900"
                />
                <button
                  type="button"
                  onClick={() => {
                    const next = (p.checklistItems || []).filter((_, j) => j !== idx);
                    st.updateProperties(el.id, { checklistItems: next });
                  }}
                  className="p-1 text-rose-500 hover:bg-rose-50 rounded"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            <Button
              size="sm"
              variant="outline"
              className="w-full text-xs"
              onClick={() => {
                const next = [...(p.checklistItems || []), { text: `آیتم جدید ${(p.checklistItems?.length || 0) + 1}`, checked: true }];
                st.updateProperties(el.id, { checklistItems: next });
              }}
            >
              <Plus className="w-3 h-3 ml-1" />
              افزودن آیتم چک‌لیست
            </Button>
          </div>
        </Section>
      )}

      {/* Stat box settings */}
      {el.type === 'stat-box' && (
        <Section title="تنظیمات شاخص آماری" icon={<Layers className="w-3.5 h-3.5 text-teal-600" />}>
          <TextField label="عدد شاخص" value={p.statNumber || ''} onChange={v => st.updateProperties(el.id, { statNumber: v })} />
          <TextField label="عنوان شاخص" value={p.statLabel || ''} onChange={v => st.updateProperties(el.id, { statLabel: v })} />
          <TextField label="برچسب کوچک (Badge)" value={p.statBadge || ''} onChange={v => st.updateProperties(el.id, { statBadge: v })} />
        </Section>
      )}

      {/* Dual signature settings */}
      {el.type === 'dual-signature' && (
        <Section title="تنظیمات امضای دوطرفه" icon={<Layers className="w-3.5 h-3.5 text-teal-600" />}>
          <TextField label="عنوان امضای راست" value={p.rightSignLabel || ''} onChange={v => st.updateProperties(el.id, { rightSignLabel: v })} />
          <TextField label="عنوان امضای چپ" value={p.leftSignLabel || ''} onChange={v => st.updateProperties(el.id, { leftSignLabel: v })} />
        </Section>
      )}

      {/* Seal badge settings */}
      {el.type === 'seal-badge' && (
        <Section title="تنظیمات مهر رسمی" icon={<Sparkles className="w-3.5 h-3.5 text-teal-600" />}>
          <TextField label="متن وسط مهر" value={p.sealText || ''} onChange={v => st.updateProperties(el.id, { sealText: v })} />
          <SelectField
            label="رنگ و جلوه مهر"
            value={p.sealColor || 'gold'}
            onChange={(v) => st.updateProperties(el.id, { sealColor: v as any })}
            options={[
              { value: 'gold', label: 'طلایی و زرین' },
              { value: 'teal', label: 'فیروزه‌ای رسمی' },
              { value: 'red', label: 'قرمز رسمی' },
              { value: 'blue', label: 'آبی سرمه‌ای' },
            ]}
          />
        </Section>
      )}

      {/* Notes box settings */}
      {el.type === 'notes-box' && (
        <Section title="تنظیمات کادر یادداشت" icon={<Layers className="w-3.5 h-3.5 text-teal-600" />}>
          <SelectField
            label="نوع کادر هشدار"
            value={p.noteType || 'warning'}
            onChange={(v) => st.updateProperties(el.id, { noteType: v as any })}
            options={[
              { value: 'warning', label: 'هشدار و توجه (زرد)' },
              { value: 'info', label: 'اطلاع‌رسانی (آبی)' },
              { value: 'success', label: 'موفقیت و تأیید (سبز)' },
              { value: 'danger', label: 'خطا و اضطراری (قرمز)' },
            ]}
          />
        </Section>
      )}

      {/* Price tag settings */}
      {el.type === 'price-tag' && (
        <Section title="تنظیمات برچسب قیمت" icon={<Layers className="w-3.5 h-3.5 text-teal-600" />}>
          <TextField label="مبلغ قیمت" value={p.priceAmount || ''} onChange={v => st.updateProperties(el.id, { priceAmount: v })} />
          <TextField label="واحد پولی" value={p.priceCurrency || 'تومان'} onChange={v => st.updateProperties(el.id, { priceCurrency: v })} />
        </Section>
      )}

      {/* Responsive */}
      <ResponsiveSection el={el} />
    </div>
  );
}

/* ---------- Arrow pad ---------- */
function ArrowPad({ onMove, onCommit }: { onMove: (dx: number, dy: number) => void; onCommit: () => void }) {
  const stepRef = useRef(1);
  const st = useEditor();
  const btn = 'w-11 h-11 md:w-9 md:h-9 rounded-xl bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 flex items-center justify-center active:scale-90 active:bg-teal-50 transition-all shadow-sm';
  const go = (dx: number, dy: number) => { onMove(dx * stepRef.current, dy * stepRef.current); onCommit(); };
  return (
    <div className="flex flex-col items-center gap-1.5">
      <button className={btn} onClick={() => go(0, -1)}><ArrowUp className="w-4 h-4" /></button>
      <div className="flex items-center gap-1.5">
        <button className={btn} onClick={() => go(1, 0)}><ArrowRight className="w-4 h-4" /></button>
        <div className="w-11 h-11 md:w-9 md:h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center text-[10px] font-bold">
          {fa(stepRef.current)}
        </div>
        <button className={btn} onClick={() => go(-1, 0)}><ArrowLeft className="w-4 h-4" /></button>
      </div>
      <button className={btn} onClick={() => go(0, 1)}><ArrowDown className="w-4 h-4" /></button>
      <div className="segmented grid grid-cols-4 gap-0.5 w-full mt-1">
        {[1, 5, 10, st.gridSize].map((n, i) => (
          <button key={i} onClick={() => { stepRef.current = n; }}
            className="segmented-item h-7 text-[10px] font-bold text-slate-600 dark:text-slate-300">
            {i === 3 ? 'شبکه' : `${fa(n)}px`}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---------- Options editor ---------- */
function OptionsEditor({ el }: { el: EditorElement }) {
  const st = useEditor();
  const options = el.properties.options ?? [];
  const set = (next: typeof options) => st.updateProperties(el.id, { options: next });
  return (
    <div className="space-y-1.5">
      <p className="text-[11px] font-medium text-slate-600 dark:text-slate-300">گزینه‌ها</p>
      {options.map((o, i) => (
        <div key={i} className="flex items-center gap-1">
          <input value={o.label} onChange={e => set(options.map((x, j) => j === i ? { ...x, label: e.target.value } : x))}
            className="flex-1 min-w-0 px-2 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[11px] outline-none" placeholder="عنوان" />
          <input value={o.value} dir="ltr" onChange={e => set(options.map((x, j) => j === i ? { ...x, value: e.target.value } : x))}
            className="w-16 px-2 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[11px] outline-none" placeholder="value" />
          <button onClick={() => set(options.filter((_, j) => j !== i))} className="p-1.5 text-rose-500"><Trash2 className="w-3.5 h-3.5" /></button>
        </div>
      ))}
      <button onClick={() => set([...options, { label: `گزینه ${options.length + 1}`, value: String(options.length + 1) }])}
        className="w-full py-1.5 rounded-lg bg-teal-50 dark:bg-teal-900/25 text-teal-700 dark:text-teal-300 text-[11px] font-bold">
        <Plus className="w-3 h-3 inline ml-1" />افزودن گزینه
      </button>
      {el.type === 'radio-group' && (
        <Segmented label="چیدمان" value={el.properties.optionsLayout ?? 'vertical'} onChange={v => st.updateProperties(el.id, { optionsLayout: v })}
          options={[{ value: 'vertical', label: 'عمودی' }, { value: 'horizontal', label: 'افقی' }]} />
      )}
    </div>
  );
}

/* ---------- Table settings ---------- */
function TableSettings({ el }: { el: EditorElement }) {
  const st = useEditor();
  const p = el.properties;
  const cols = p.columns ?? [];
  const setCols = (next: TableColumn[]) => st.updateProperties(el.id, { columns: next });
  const totalWidth = cols.reduce((s, c) => s + c.width, 0);

  return (
    <Section title="تنظیمات جدول" icon={<TableIcon className="w-3.5 h-3.5 text-teal-600" />}>
      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <p className="text-[11px] font-medium text-slate-600 dark:text-slate-300">ستون‌ها</p>
          <span className={cx('text-[10px] font-bold', totalWidth === 100 ? 'text-emerald-600' : 'text-amber-600')}>
            جمع عرض: {fa(totalWidth)}٪
          </span>
        </div>
        {cols.map((c, i) => (
          <div key={c.id} className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 space-y-1">
            <div className="flex items-center gap-1">
              <input value={c.header} onChange={e => setCols(cols.map((x, j) => j === i ? { ...x, header: e.target.value } : x))}
                className="flex-1 min-w-0 px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[11px] outline-none" />
              <button onClick={() => setCols(cols.filter((_, j) => j !== i))} className="p-1 text-rose-500"><Trash2 className="w-3.5 h-3.5" /></button>
            </div>
            <div className="grid grid-cols-3 gap-1">
              <input type="number" value={c.width} onChange={e => setCols(cols.map((x, j) => j === i ? { ...x, width: Number(e.target.value) } : x))}
                className="px-1.5 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[10px] outline-none" title="عرض ٪" />
              <select value={c.type} onChange={e => setCols(cols.map((x, j) => j === i ? { ...x, type: e.target.value as TableColumn['type'] } : x))}
                className="px-1 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[10px] outline-none">
                <option value="text">متن</option><option value="number">عدد</option>
                <option value="currency">مبلغ</option><option value="select">انتخابی</option><option value="formula">فرمول</option>
              </select>
              <select value={c.align} onChange={e => setCols(cols.map((x, j) => j === i ? { ...x, align: e.target.value as TableColumn['align'] } : x))}
                className="px-1 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[10px] outline-none">
                <option value="right">راست</option><option value="center">وسط</option><option value="left">چپ</option>
              </select>
            </div>
          </div>
        ))}
        <button onClick={() => setCols([...cols, { id: uuid(), header: `ستون ${cols.length + 1}`, width: 15, align: 'right', type: 'text', editable: true }])}
          className="w-full py-1.5 rounded-lg bg-teal-50 dark:bg-teal-900/25 text-teal-700 dark:text-teal-300 text-[11px] font-bold">
          <Plus className="w-3 h-3 inline ml-1" />افزودن ستون
        </button>
      </div>

      <NumberStepper label="تعداد ردیف" value={p.rows ?? 3} min={1} max={40} onChange={v => st.updateProperties(el.id, { rows: v })} />
      <Toggle label="ردیف‌های پویا" checked={!!p.dynamicRows} onChange={v => st.updateProperties(el.id, { dynamicRows: v })} />
      <Toggle label="نمایش شماره ردیف" checked={p.showRowNumbers !== false} onChange={v => st.updateProperties(el.id, { showRowNumbers: v })} />
      <Toggle label="نمایش سربرگ" checked={p.showHeader !== false} onChange={v => st.updateProperties(el.id, { showHeader: v })} />
      <Toggle label="نمایش ردیف جمع" checked={!!p.showFooter} onChange={v => st.updateProperties(el.id, { showFooter: v })} />
      <Toggle label="ردیف‌های متناوب" checked={!!p.zebraStripes} onChange={v => st.updateProperties(el.id, { zebraStripes: v })} />
      <Segmented label="سبک حاشیه" columns={4} value={p.tableBorder ?? 'solid'} onChange={v => st.updateProperties(el.id, { tableBorder: v })}
        options={[{ value: 'solid', label: 'ممتد' }, { value: 'dashed', label: 'خط‌چین' }, { value: 'minimal', label: 'ساده' }, { value: 'none', label: 'بدون' }]} />
      <ColorField label="رنگ سربرگ" value={p.headerBg ?? '#0f766e'} onChange={v => st.updateProperties(el.id, { headerBg: v })} />
      <ColorField label="رنگ متن سربرگ" value={p.headerColor ?? '#ffffff'} onChange={v => st.updateProperties(el.id, { headerColor: v })} />
      <ColorField label="رنگ ردیف متناوب" value={p.altRowBg ?? '#f1f5f9'} onChange={v => st.updateProperties(el.id, { altRowBg: v })} />
      <Segmented label="فاصله داخلی سلول" value={p.cellPadding ?? 'normal'} onChange={v => st.updateProperties(el.id, { cellPadding: v })}
        options={[{ value: 'compact', label: 'فشرده' }, { value: 'normal', label: 'عادی' }, { value: 'relaxed', label: 'باز' }]} />
    </Section>
  );
}

/* ---------- Image settings ---------- */
function ImageSettings({ el }: { el: EditorElement }) {
  const st = useEditor();
  const ref = useRef<HTMLInputElement>(null);
  const p = el.properties;
  return (
    <Section title="تنظیمات تصویر" icon={<ImageIcon className="w-3.5 h-3.5 text-teal-600" />}>
      <input ref={ref} type="file" accept="image/*" hidden onChange={e => {
        const f = e.target.files?.[0]; if (!f) return;
        const r = new FileReader();
        r.onload = () => st.updateProperties(el.id, { src: r.result as string });
        r.readAsDataURL(f);
      }} />
      <div className="flex gap-1.5">
        <button onClick={() => ref.current?.click()} className="flex-1 py-2 rounded-lg bg-teal-600 text-white text-[11px] font-bold">انتخاب تصویر</button>
        {p.src && <button onClick={() => st.updateProperties(el.id, { src: '' })} className="px-3 rounded-lg bg-rose-100 text-rose-600 text-[11px]">حذف</button>}
      </div>
      <TextField label="آدرس تصویر (URL)" dir="ltr" value={p.src?.startsWith('data:') ? '' : (p.src ?? '')} onChange={v => st.updateProperties(el.id, { src: v })} />
      <TextField label="متن جایگزین" value={p.alt ?? ''} onChange={v => st.updateProperties(el.id, { alt: v })} />
      <Segmented label="نحوه نمایش" columns={4} value={p.fit ?? 'contain'} onChange={v => st.updateProperties(el.id, { fit: v })}
        options={[{ value: 'contain', label: 'کامل' }, { value: 'cover', label: 'پوشش' }, { value: 'fill', label: 'کشیده' }, { value: 'none', label: 'اصلی' }]} />
    </Section>
  );
}

/* ---------- Responsive ---------- */
function ResponsiveSection({ el }: { el: EditorElement }) {
  const st = useEditor();
  const bp = st.breakpoint;
  const current = el.responsive[bp];
  const base = { x: el.x, y: el.y, width: el.width, height: el.height, hidden: false };
  const val = current ?? base;
  const setVal = (patch: Partial<typeof val>) =>
    st.updateElement(el.id, { responsive: { ...el.responsive, [bp]: { ...val, ...patch } } }, false);

  return (
    <Section title="ریسپانسیو" icon={<Smartphone className="w-3.5 h-3.5 text-teal-600" />} defaultOpen={false}>
      <Segmented label="نمای فعال" value={bp} onChange={(v: Breakpoint) => st.setBreakpoint(v)}
        options={[{ value: 'mobile', label: '📱 موبایل' }, { value: 'tablet', label: '📲 تبلت' }, { value: 'desktop', label: '🖥️ دسکتاپ' }]} />
      {bp === 'desktop' ? (
        <p className="text-[11px] text-slate-500 leading-5 p-2 rounded-lg bg-slate-50 dark:bg-slate-800">
          نمای دسکتاپ مقادیر پایه است. برای تعریف قواعد ریسپانسیو، ابتدا نمای موبایل یا تبلت را انتخاب کنید.
        </p>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-2">
            <NumberStepper label="X" value={val.x} min={-500} max={3000} onChange={v => setVal({ x: v })} />
            <NumberStepper label="Y" value={val.y} min={-500} max={3000} onChange={v => setVal({ y: v })} />
            <NumberStepper label="عرض" value={val.width} min={10} max={2000} onChange={v => setVal({ width: v })} />
            <NumberStepper label="ارتفاع" value={val.height} min={10} max={2000} onChange={v => setVal({ height: v })} />
          </div>
          <Toggle label="مخفی در این اندازه" checked={!!current?.hidden} onChange={v => setVal({ hidden: v })} />
          <div className="grid grid-cols-2 gap-1.5">
            <button onClick={() => setVal(base)} className="py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px]">کپی از دسکتاپ</button>
            <button onClick={() => st.updateElement(el.id, { responsive: { ...el.responsive, [bp]: null } }, false)}
              className="py-1.5 rounded-lg bg-rose-50 dark:bg-rose-900/25 text-rose-600 text-[11px]">بازنشانی</button>
          </div>
        </>
      )}
    </Section>
  );
}

/* ================= Batch edit (multi-select) ================= */
function BatchEditPanel() {
  const st = useEditor();
  const ids = st.selectedElementIds;
  const els = ids.map(id => st.elements.find(e => e.id === id)).filter(Boolean) as EditorElement[];
  const shared = els.length > 0 ? els[0].style : null;
  const applyStyle = (patch: Partial<ElementStyle>) => ids.forEach(id => st.updateStyle(id, patch));
  const count = ids.length;
  const [fontSize, setFontSize] = useState(shared?.fontSize ?? 13);
  const [color, setColor] = useState(shared?.color ?? '#0f172a');
  const [bgColor, setBgColor] = useState(shared?.backgroundColor ?? 'transparent');
  const store = useEditor();

  return (
    <div>
      <div className="px-3 py-2.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between sticky top-0 bg-white dark:bg-slate-900 z-10">
        <span className="text-[12px] font-bold text-slate-800 dark:text-slate-100">تغییرات گروهی</span>
        <Badge color="teal">{fa(count)} عنصر انتخاب شده</Badge>
      </div>
      <div className="p-3 space-y-4">
        <button onClick={store.selectAll} className="w-full py-2 rounded-xl bg-teal-600 text-white text-[12px] font-bold active:scale-[0.98] transition-transform">انتخاب همه</button>
        <button onClick={() => store.selectMany([])} className="w-full py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-[12px]">لغو انتخاب</button>

        <Section title="تراز و توزیع" icon={<Crosshair className="w-3.5 h-3.5 text-teal-600" />}>
          <p className="text-[11px] text-slate-500 mb-1">روی {fa(count)} عنصر اعمال شود</p>
          <div className="grid grid-cols-3 gap-1 ">
            {([['right', 'راست'], ['center-h', 'وسط افقی'], ['left', 'چپ'], ['top', 'بالا'], ['center-v', 'وسط عمودی'], ['bottom', 'پایین']] as const).map(([k, lbl]) => (
              <button key={k} onClick={() => store.alignElements(k)} className="py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-[10px] active:scale-[0.96]">{lbl}</button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-1.5 mt-2">
            <button onClick={() => store.distributeElements('horizontal')} className="py-2 rounded-lg bg-slate-800 text-white text-[10px] active:scale-[0.96]">توزیع افقی</button>
            <button onClick={() => store.distributeElements('vertical')} className="py-2 rounded-lg bg-slate-800 text-white text-[10px] active:scale-[0.96]">توزیع عمودی</button>
          </div>
        </Section>

        <Section title="تایپوگرافی مشترک" icon={<TypeIcon className="w-3.5 h-3.5 text-teal-600" />} defaultOpen={false}>
          <NumberStepper label="اندازه قلم (همگانی)" value={fontSize} min={7} max={72} onChange={v => { setFontSize(v); applyStyle({ fontSize: v }); }} suffix="px" />
          <ColorField label="رنگ متن" value={color} onChange={v => { setColor(v); applyStyle({ color: v }); }} />
          <ColorField label="رنگ پس‌زمینه" value={bgColor} onChange={v => { setBgColor(v); applyStyle({ backgroundColor: v }); }} allowTransparent />
          <div className="grid grid-cols-2 gap-1.5">
            <button onClick={() => applyStyle({ fontWeight: 'bold' })} className="py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px] font-bold">ضخیم همه</button>
            <button onClick={() => applyStyle({ fontWeight: 'normal' })} className="py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-[11px]">عادی همه</button>
          </div>
        </Section>

        <Section title="جلوه مشترک" icon={<Sparkles className="w-3.5 h-3.5 text-teal-600" />} defaultOpen={false}>
          <div className="grid grid-cols-2 gap-1.5">
            <button onClick={() => applyStyle({ effect: 'gradient' })} className="p-2 rounded-lg border-2 border-slate-200 dark:border-slate-700 text-[10px]">گرادیانت</button>
            <button onClick={() => applyStyle({ effect: 'glass' })} className="p-2 rounded-lg border-2 border-slate-200 dark:border-slate-700 text-[10px]">شیشه‌ای</button>
            <button onClick={() => applyStyle({ effect: 'neu' })} className="p-2 rounded-lg border-2 border-slate-200 dark:border-slate-700 text-[10px]">نئومورف</button>
            <button onClick={() => applyStyle({ effect: 'none' })} className="p-2 rounded-lg border-2 border-slate-200 dark:border-slate-700 text-[10px]">بدون افکت</button>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {[['#0d9488', '#3b82f6'], ['#f59e0b', '#ef4444'], ['#8b5cf6', '#ec4899'], ['#0f172a', '#475569']].map(g => (
              <button key={g[0]} onClick={() => applyStyle({ effect: 'gradient', gradFrom: g[0], gradTo: g[1] })} style={{ background: `linear-gradient(135deg, ${g[0]}, ${g[1]})` }} className="h-8 rounded-lg" title={`${g[0]} → ${g[1]}`} />
            ))}
          </div>
        </Section>

        <div className="flex gap-1.5">
          <Button variant="outline" size="sm" className="flex-1" onClick={() => store.groupElements()}>گروه‌بندی</Button>
          <Button variant="outline" size="sm" className="flex-1" onClick={() => store.ungroupElements()}>آنگروه</Button>
        </div>
        <Button variant="danger" size="sm" className="w-full" onClick={() => store.deleteElement()}><Trash2 className="w-4 h-4" />حذف {fa(count)} عنصر</Button>
      </div>
    </div>
  );
}
