import { useEffect, useRef, useState, type ReactNode } from 'react';
import { ChevronDown, Minus, Plus } from 'lucide-react';
import { HexColorPicker } from 'react-colorful';
import { fa, toEn, clamp } from '../utils';

const cx = (...c: (string | false | undefined | null)[]) => c.filter(Boolean).join(' ');

/* ============ NumberStepper (mobile friendly) ============ */
interface NumberStepperProps {
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  step?: number;
  label?: string;
  suffix?: string;
  slider?: boolean;
  precision?: number;
  compact?: boolean;
}

export function NumberStepper({
  value, onChange, min = -9999, max = 9999, step = 1,
  label, suffix, slider = true, precision = 0, compact = false,
}: NumberStepperProps) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');
  const holdRef = useRef<number | null>(null);
  const accelRef = useRef(0);
  const liveRef = useRef(value);
  useEffect(() => { liveRef.current = value; }, [value]);

  const set = (v: number) => {
    const next = clamp(Number(v.toFixed(precision)), min, max);
    liveRef.current = next;
    onChange(next);
  };

  const startHold = (dir: 1 | -1) => {
    set(liveRef.current + dir * step);
    accelRef.current = 0;
    const tick = () => {
      accelRef.current += 1;
      const mult = accelRef.current > 20 ? 10 : accelRef.current > 8 ? 4 : 1;
      set(liveRef.current + dir * step * mult);
      holdRef.current = window.setTimeout(tick, accelRef.current > 8 ? 45 : 110);
    };
    holdRef.current = window.setTimeout(tick, 380);
  };
  const stopHold = () => { if (holdRef.current) { clearTimeout(holdRef.current); holdRef.current = null; } };
  useEffect(() => () => stopHold(), []);

  const btn = compact
    ? 'w-7 h-7 text-sm'
    : 'w-9 h-9 md:w-8 md:h-8 text-base';

  return (
    <div className="space-y-1.5">
      {label && <label className="text-[11px] font-medium text-slate-600 dark:text-slate-300 block">{label}</label>}
      <div className="flex items-center gap-1.5">
        <button
          type="button"
          onPointerDown={() => startHold(-1)}
          onPointerUp={stopHold} onPointerLeave={stopHold}
          className={cx(btn, 'flex items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 active:scale-90 transition-transform shrink-0')}
        >
          <Minus className="w-4 h-4" />
        </button>

        {editing ? (
          <input
            autoFocus
            value={draft}
            onChange={e => setDraft(e.target.value)}
            onBlur={() => { const n = parseFloat(toEn(draft)); if (!isNaN(n)) set(n); setEditing(false); }}
            onKeyDown={e => {
              if (e.key === 'Enter') { const n = parseFloat(toEn(draft)); if (!isNaN(n)) set(n); setEditing(false); }
              if (e.key === 'Escape') setEditing(false);
            }}
            className="flex-1 min-w-0 h-9 md:h-8 text-center rounded-lg border border-teal-400 bg-white dark:bg-slate-900 text-sm outline-none"
          />
        ) : (
          <button
            type="button"
            onClick={() => { setDraft(String(value)); setEditing(true); }}
            className="flex-1 min-w-0 h-9 md:h-8 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm font-semibold tabular-nums text-slate-800 dark:text-slate-100 hover:border-teal-400 transition-colors"
          >
            {fa(precision ? value.toFixed(precision) : Math.round(value))}
            {suffix && <span className="text-[10px] text-slate-400 mr-1">{suffix}</span>}
          </button>
        )}

        <button
          type="button"
          onPointerDown={() => startHold(1)}
          onPointerUp={stopHold} onPointerLeave={stopHold}
          className={cx(btn, 'flex items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 active:scale-90 transition-transform shrink-0')}
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>
      {slider && (
        <input
          type="range"
          min={Math.max(min, -500)} max={Math.min(max, 1200)} step={step}
          value={value}
          onChange={e => set(parseFloat(e.target.value))}
          className="w-full h-1.5 accent-teal-600 cursor-pointer"
        />
      )}
    </div>
  );
}



/* ============ Color field ============ */
export function ColorField({ label, value, onChange, allowTransparent }: { label?: string; value: string; onChange: (v: string) => void; allowTransparent?: boolean }) {
  const [open, setOpen] = useState(false);
  const isTransparent = value === 'transparent';
  return (
    <div className="space-y-1.5 relative">
      {label && <label className="text-[11px] font-medium text-slate-600 dark:text-slate-300 block">{label}</label>}
      <div className="flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => setOpen(o => !o)}
          className="w-9 h-9 md:w-8 md:h-8 rounded-lg border border-slate-200 dark:border-slate-700 shrink-0 overflow-hidden"
          style={{
            background: isTransparent
              ? 'repeating-conic-gradient(#e2e8f0 0% 25%, #fff 0% 50%) 50%/10px 10px'
              : value,
          }}
        />
        <input
          value={value}
          onChange={e => onChange(e.target.value)}
          className="flex-1 min-w-0 h-9 md:h-8 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[11px] font-mono outline-none focus:border-teal-400"
          dir="ltr"
        />
        {allowTransparent && (
          <button
            type="button"
            onClick={() => onChange('transparent')}
            className="h-9 md:h-8 px-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-[10px] shrink-0"
          >
            بی‌رنگ
          </button>
        )}
      </div>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute z-50 mt-1 p-2 rounded-xl bg-white dark:bg-slate-800 shadow-2xl border border-slate-200 dark:border-slate-700">
            <HexColorPicker color={isTransparent ? '#ffffff' : value} onChange={onChange} />
            <div className="grid grid-cols-8 gap-1 mt-2">
              {['#0f172a', '#475569', '#94a3b8', '#ffffff', '#0f766e', '#14b8a6', '#3b82f6', '#6366f1',
                '#ef4444', '#f59e0b', '#10b981', '#ec4899', '#f8fafc', '#e2e8f0', '#fef3c7', '#dbeafe'].map(c => (
                <button key={c} type="button" onClick={() => onChange(c)}
                  className="w-5 h-5 rounded border border-slate-200 dark:border-slate-600" style={{ background: c }} />
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

/* ============ Toggle ============ */
export function Toggle({ label, checked, onChange, hint }: { label: string; checked: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <label className="flex items-center justify-between gap-2 py-1.5 cursor-pointer select-none">
      <span className="min-w-0">
        <span className="text-[12px] text-slate-700 dark:text-slate-200 block">{label}</span>
        {hint && <span className="text-[10px] text-slate-400 block">{hint}</span>}
      </span>
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className={cx('w-10 h-6 rounded-full p-0.5 transition-colors shrink-0', checked ? 'bg-teal-600' : 'bg-slate-300 dark:bg-slate-600')}
      >
        <span className={cx('block w-5 h-5 rounded-full bg-white shadow transition-transform', checked ? '-translate-x-4' : 'translate-x-0')} />
      </button>
    </label>
  );
}

/* ============ Segmented ============ */
export function Segmented<T extends string>({ label, value, onChange, options, columns }: {
  label?: string; value: T; onChange: (v: T) => void;
  options: { value: T; label: ReactNode; title?: string }[];
  columns?: number;
}) {
  return (
    <div className="space-y-1.5">
      {label && <label className="text-[11px] font-medium text-slate-600 dark:text-slate-300 block">{label}</label>}
      <div className="segmented grid gap-0.5" style={{ gridTemplateColumns: `repeat(${columns ?? options.length}, minmax(0,1fr))` }}>
        {options.map(o => (
          <button
            key={o.value}
            type="button"
            title={o.title}
            data-active={value === o.value}
            onClick={() => onChange(o.value)}
            className="segmented-item h-8 flex items-center justify-center text-[11px] font-medium text-slate-600 dark:text-slate-300 data-[active=true]:text-teal-700 dark:data-[active=true]:text-teal-300"
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ============ TextField ============ */
export function TextField({ label, value, onChange, placeholder, dir, multiline, rows = 3 }: {
  label?: string; value: string; onChange: (v: string) => void;
  placeholder?: string; dir?: 'rtl' | 'ltr'; multiline?: boolean; rows?: number;
}) {
  const cls = 'w-full px-2.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[12px] outline-none focus:border-teal-400 transition-colors';
  return (
    <div className="space-y-1.5">
      {label && <label className="text-[11px] font-medium text-slate-600 dark:text-slate-300 block">{label}</label>}
      {multiline
        ? <textarea value={value} rows={rows} placeholder={placeholder} dir={dir} onChange={e => onChange(e.target.value)} className={cls + ' resize-y'} />
        : <input value={value} placeholder={placeholder} dir={dir} onChange={e => onChange(e.target.value)} className={cls} />}
    </div>
  );
}

/* ============ SelectField ============ */
export function SelectField<T extends string>({ label, value, onChange, options }: {
  label?: string; value: T; onChange: (v: T) => void; options: { value: T; label: string }[];
}) {
  return (
    <div className="space-y-1.5">
      {label && <label className="text-[11px] font-medium text-slate-600 dark:text-slate-300 block">{label}</label>}
      <div className="relative">
        <select
          value={value}
          onChange={e => onChange(e.target.value as T)}
          className="w-full appearance-none px-2.5 py-2 pl-7 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[12px] outline-none focus:border-teal-400"
        >
          {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <ChevronDown className="w-3.5 h-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
      </div>
    </div>
  );
}

/* ============ Accordion section ============ */
export function Section({ title, icon, children, defaultOpen = true }: { title: string; icon?: ReactNode; children: ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-slate-100 dark:border-slate-800">
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between gap-2 px-3 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors"
      >
        <span className="flex items-center gap-2 text-[12px] font-bold text-slate-700 dark:text-slate-200">
          {icon}{title}
        </span>
        <ChevronDown className={cx('w-4 h-4 text-slate-400 transition-transform', open && 'rotate-180')} />
      </button>
      {open && <div className="px-3 pb-3 space-y-2.5 animate-fade-in">{children}</div>}
    </div>
  );
}

export { cx };
