import { useCallback, useEffect, useRef, useState } from 'react';
import { useEditor } from '../store';
import type { EditorElement, GuideLine } from '../types';
import {
  computeMoveSnap, fa, getPagePx, mmToPx, resolveRect, snapValue, clamp, getBounds,
} from '../utils';
import { ElementRenderer } from './ElementRenderer';
import { Lock, EyeOff } from 'lucide-react';

const HANDLES = [
  { k: 'nw', x: 0, y: 0, cur: 'nwse-resize' }, { k: 'n', x: 0.5, y: 0, cur: 'ns-resize' },
  { k: 'ne', x: 1, y: 0, cur: 'nesw-resize' }, { k: 'e', x: 1, y: 0.5, cur: 'ew-resize' },
  { k: 'se', x: 1, y: 1, cur: 'nwse-resize' }, { k: 's', x: 0.5, y: 1, cur: 'ns-resize' },
  { k: 'sw', x: 0, y: 1, cur: 'nesw-resize' }, { k: 'w', x: 0, y: 0.5, cur: 'ew-resize' },
] as const;

type DragMode =
  | { kind: 'move'; startX: number; startY: number; origins: Record<string, { x: number; y: number }> }
  | { kind: 'resize'; handle: string; startX: number; startY: number; ox: number; oy: number; ow: number; oh: number }
  | { kind: 'rotate'; cx: number; cy: number; startAngle: number; origin: number }
  | { kind: 'marquee'; startX: number; startY: number }
  | { kind: 'pan'; startX: number; startY: number; ox: number; oy: number }
  | null;

export function Canvas({ onOpenProps }: { onOpenProps?: () => void }) {
  const st = useEditor();
  const page = getPagePx(st.document);
  const paperRef = useRef<HTMLDivElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState<DragMode>(null);
  const [marquee, setMarquee] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [badge, setBadge] = useState<string | null>(null);
  const [spaceDown, setSpaceDown] = useState(false);
  const [editingText, setEditingText] = useState<string | null>(null);
  const [menu, setMenu] = useState<{ x: number; y: number; id: string } | null>(null);
  const pinchRef = useRef<{ dist: number; zoom: number } | null>(null);
  const longPressRef = useRef<number | null>(null);
  const longPressElRef = useRef<string>('');
  const longPressStartRef = useRef<{ x: number; y: number } | null>(null);
  const [multiNotice, setMultiNotice] = useState(false);

  const toCanvas = useCallback((clientX: number, clientY: number) => {
    const r = paperRef.current?.getBoundingClientRect();
    if (!r) return { x: 0, y: 0 };
    return { x: (clientX - r.left) / st.zoom, y: (clientY - r.top) / st.zoom };
  }, [st.zoom]);

  /* ---------- keyboard: space to pan ---------- */
  useEffect(() => {
    const down = (e: KeyboardEvent) => { if (e.code === 'Space' && !isTyping(e)) { setSpaceDown(true); } };
    const up = (e: KeyboardEvent) => { if (e.code === 'Space') setSpaceDown(false); };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); };
  }, []);

  /* ---------- zoom with ctrl+wheel ---------- */
  useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const onWheel = (e: WheelEvent) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      st.setZoom(st.zoom * (e.deltaY > 0 ? 0.92 : 1.08));
    };
    wrap.addEventListener('wheel', onWheel, { passive: false });
    return () => wrap.removeEventListener('wheel', onWheel);
  }, [st]);

  /* ---------- pointer move / up ---------- */
  useEffect(() => {
    if (!drag) return;
    const move = (e: PointerEvent) => {
      // cancel long-press timer when finger moves significantly (user intends to drag)
      if (longPressRef.current && longPressStartRef.current) {
        const dx = e.clientX - longPressStartRef.current.x;
        const dy = e.clientY - longPressStartRef.current.y;
        if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
          clearTimeout(longPressRef.current);
          longPressRef.current = null;
        }
      }
      const pt = toCanvas(e.clientX, e.clientY);

      if (drag.kind === 'pan') {
        st.setPan({ x: drag.ox + (e.clientX - drag.startX), y: drag.oy + (e.clientY - drag.startY) });
        return;
      }

      if (drag.kind === 'marquee') {
        const x = Math.min(drag.startX, pt.x), y = Math.min(drag.startY, pt.y);
        const w = Math.abs(pt.x - drag.startX), h = Math.abs(pt.y - drag.startY);
        setMarquee({ x, y, w, h });
        return;
      }

      if (drag.kind === 'move') {
        const dx = pt.x - drag.startX;
        const dy = pt.y - drag.startY;
        const ids = Object.keys(drag.origins);
        const primaryId = ids[0];
        const primary = st.elements.find(el => el.id === primaryId);
        if (!primary) return;
        const rect = resolveRect(primary, st.breakpoint);
        const origin = drag.origins[primaryId];
        const others = st.elements.filter(el => !ids.includes(el.id) && !el.hidden);
        const snapped = computeMoveSnap(
          { x: origin.x + dx, y: origin.y + dy, width: rect.width, height: rect.height },
          others, page, st.document.margins,
          { snapToGrid: st.snapToGrid, snapToObject: st.snapToObject, gridSize: st.gridSize, threshold: st.snapThreshold }
        );
        const finalDx = snapped.x - origin.x;
        const finalDy = snapped.y - origin.y;
        ids.forEach(id => {
          const o = drag.origins[id];
          st.moveElement(id, o.x + finalDx, o.y + finalDy);
        });
        st.setActiveGuides(st.showGuides ? snapped.guides : []);
        setBadge(`X: ${fa(Math.round(snapped.x))}  Y: ${fa(Math.round(snapped.y))}`);
        return;
      }

      if (drag.kind === 'resize') {
        const id = st.selectedElementId;
        if (!id) return;
        let dx = pt.x - drag.startX;
        let dy = pt.y - drag.startY;
        if (st.snapToGrid) { dx = snapValue(dx, st.gridSize); dy = snapValue(dy, st.gridSize); }
        let { ox, oy, ow, oh } = drag;
        const h = drag.handle;
        if (h.includes('e')) ow = drag.ow + dx;
        if (h.includes('w')) { ow = drag.ow - dx; ox = drag.ox + dx; }
        if (h.includes('s')) oh = drag.oh + dy;
        if (h.includes('n')) { oh = drag.oh - dy; oy = drag.oy + dy; }
        ow = Math.max(16, ow); oh = Math.max(12, oh);
        st.resizeElement(id, ow, oh, ox, oy);
        setBadge(`${fa(Math.round(ow))} × ${fa(Math.round(oh))}`);
        return;
      }

      if (drag.kind === 'rotate') {
        const id = st.selectedElementId;
        if (!id) return;
        const angle = Math.atan2(pt.y - drag.cy, pt.x - drag.cx) * (180 / Math.PI);
        let next = Math.round(drag.origin + (angle - drag.startAngle));
        if (e.shiftKey) next = Math.round(next / 15) * 15;
        next = ((next % 360) + 360) % 360;
        st.updateElement(id, { rotation: next }, false);
        setBadge(`${fa(next)}°`);
      }
    };

    const up = () => {
      if (longPressRef.current) { clearTimeout(longPressRef.current); longPressRef.current = null; }
      if (drag?.kind === 'marquee' && marquee) {
        const sel = st.elements.filter(el => {
          if (el.locked || el.hidden) return false;
          const r = resolveRect(el, st.breakpoint);
          const b = getBounds(r);
          return b.left < marquee.x + marquee.w && b.right > marquee.x && b.top < marquee.y + marquee.h && b.bottom > marquee.y;
        }).map(el => el.id);
        st.selectMany(sel);
      }
      if (drag?.kind === 'move') st.commit('جابجایی عنصر');
      if (drag?.kind === 'resize') st.commit('تغییر اندازه');
      if (drag?.kind === 'rotate') st.commit('چرخش عنصر');
      setDrag(null); setMarquee(null); setBadge(null);
      st.setActiveGuides([]);
    };

    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    return () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
  }, [drag, marquee, st, toCanvas, page]);

  /* ---------- element pointer down ---------- */
  const onElementDown = (e: React.PointerEvent, el: EditorElement) => {
    if (st.previewMode) return;
    if (spaceDown) return;
    e.stopPropagation();
    if (el.locked) { st.selectElement(el.id); return; }

    const additive = e.ctrlKey || e.metaKey || e.shiftKey;
    let ids: string[];
    if (additive) { st.multiSelectElement(el.id); ids = st.selectedElementIds.includes(el.id) ? st.selectedElementIds.filter(i => i !== el.id) : [...st.selectedElementIds, el.id]; }
    else if (st.selectedElementIds.includes(el.id) && st.selectedElementIds.length > 1) { ids = st.selectedElementIds; }
    else { st.selectElement(el.id); ids = [el.id]; }

    // long-press on touch adds to selection without entering drag mode;
    // the long press fires a timeout below (it runs even if drag already started)
    if (e.pointerType === 'touch') {
      if (longPressRef.current) clearTimeout(longPressRef.current);
      longPressElRef.current = el.id;
      longPressStartRef.current = { x: e.clientX, y: e.clientY };
      longPressRef.current = window.setTimeout(() => {
        st.multiSelectElement(el.id);
        setMultiNotice(true);
        setTimeout(() => setMultiNotice(false), 1500);
        longPressRef.current = null;
      }, 550);
    }

    // group members move together
    const groupIds = new Set<string>(ids);
    ids.forEach(id => {
      const found = st.elements.find(x => x.id === id);
      if (found?.groupId) st.elements.filter(x => x.groupId === found.groupId).forEach(x => groupIds.add(x.id));
    });

    const pt = toCanvas(e.clientX, e.clientY);
    const origins: Record<string, { x: number; y: number }> = {};
    origins[el.id] = { x: resolveRect(el, st.breakpoint).x, y: resolveRect(el, st.breakpoint).y };
    groupIds.forEach(id => {
      if (id === el.id) return;
      const target = st.elements.find(x => x.id === id);
      if (target && !target.locked) {
        const r = resolveRect(target, st.breakpoint);
        origins[id] = { x: r.x, y: r.y };
      }
    });
    setDrag({ kind: 'move', startX: pt.x, startY: pt.y, origins });
  };

  const onHandleDown = (e: React.PointerEvent, el: EditorElement, handle: string) => {
    e.stopPropagation();
    const pt = toCanvas(e.clientX, e.clientY);
    const r = resolveRect(el, st.breakpoint);
    setDrag({ kind: 'resize', handle, startX: pt.x, startY: pt.y, ox: r.x, oy: r.y, ow: r.width, oh: r.height });
  };

  const onRotateDown = (e: React.PointerEvent, el: EditorElement) => {
    e.stopPropagation();
    const pt = toCanvas(e.clientX, e.clientY);
    const r = resolveRect(el, st.breakpoint);
    const cx = r.x + r.width / 2, cy = r.y + r.height / 2;
    setDrag({ kind: 'rotate', cx, cy, startAngle: Math.atan2(pt.y - cy, pt.x - cx) * (180 / Math.PI), origin: el.rotation });
  };

  const onPaperDown = (e: React.PointerEvent) => {
    if (st.previewMode) return;
    if (spaceDown || e.button === 1) {
      setDrag({ kind: 'pan', startX: e.clientX, startY: e.clientY, ox: st.pan.x, oy: st.pan.y });
      return;
    }
    if (e.target === e.currentTarget || (e.target as HTMLElement).dataset.paper === 'true') {
      st.selectElement(null);
      const pt = toCanvas(e.clientX, e.clientY);
      setDrag({ kind: 'marquee', startX: pt.x, startY: pt.y });
    }
  };

  /* ---------- touch pinch ---------- */
  const onTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      pinchRef.current = { dist: d, zoom: st.zoom };
    }
  };
  const onTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && pinchRef.current) {
      const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      st.setZoom(pinchRef.current.zoom * (d / pinchRef.current.dist));
    }
  };

  const sorted = [...st.elements].sort((a, b) => a.zIndex - b.zIndex);
  const ml = mmToPx(st.document.margins.left), mr = mmToPx(st.document.margins.right);
  const mt = mmToPx(st.document.margins.top), mb = mmToPx(st.document.margins.bottom);

  const frameWidth = st.breakpoint === 'mobile' ? 375 : st.breakpoint === 'tablet' ? 768 : null;

  return (
    <div
      ref={wrapRef}
      className="relative flex-1 overflow-auto bg-slate-100 dark:bg-slate-950 scroll-area"
      style={{ cursor: spaceDown ? 'grab' : undefined }}
      onPointerDown={e => { if (spaceDown) setDrag({ kind: 'pan', startX: e.clientX, startY: e.clientY, ox: st.pan.x, oy: st.pan.y }); }}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onClick={() => setMenu(null)}
    >
      {/* Rulers */}
      {st.showRulers && !st.previewMode && <Rulers page={page} zoom={st.zoom} pan={st.pan} />}

      <div className="min-h-full flex items-start justify-center p-6 md:p-10">
        <div
          style={{
            transform: `translate(${st.pan.x}px, ${st.pan.y}px) scale(${st.zoom})`,
            transformOrigin: 'top center',
            transition: drag ? 'none' : 'transform 150ms ease-out',
          }}
        >
          {frameWidth && (
            <div className="mb-2 text-center text-[11px] text-slate-500">
              نمای {st.breakpoint === 'mobile' ? 'موبایل' : 'تبلت'} — عرض {fa(frameWidth)} پیکسل
            </div>
          )}
          <div
            ref={paperRef}
            data-paper="true"
            id="editor-paper"
            onPointerDown={onPaperDown}
            onContextMenu={e => e.preventDefault()}
            className="relative shadow-2xl"
            style={{
              width: page.width,
              height: page.height,
              background: st.document.backgroundColor,
              backgroundImage: st.document.backgroundImage ? `url(${st.document.backgroundImage})` : undefined,
              backgroundSize: 'cover',
              border: st.document.showBorder
                ? `${st.document.borderWidth}px ${st.document.borderStyle} ${st.document.borderColor}`
                : undefined,
            }}
          >
            {/* Grid */}
            {st.showGrid && !st.previewMode && (
              <div
                className="absolute inset-0 pointer-events-none canvas-grid"
                style={{
                  opacity: st.document.gridOpacity / 100,
                  backgroundImage: `radial-gradient(${st.document.gridColor} 1px, transparent 1px)`,
                  backgroundSize: `${st.gridSize}px ${st.gridSize}px`,
                }}
              />
            )}

            {/* Margins */}
            {!st.previewMode && (
              <div className="absolute pointer-events-none border border-dashed border-teal-400/40 canvas-guides"
                style={{ left: ml, top: mt, right: mr, bottom: mb }} />
            )}

            {/* Elements */}
            {sorted.map(el => {
              const r = resolveRect(el, st.breakpoint);
              if (r.hidden && st.previewMode) return null;
              const selected = st.selectedElementIds.includes(el.id);
              const primary = st.selectedElementId === el.id;
              return (
                <div
                  key={el.id}
                  onPointerDown={e => onElementDown(e, el)}
                  onDoubleClick={() => { if (['text', 'heading', 'paragraph'].includes(el.type)) setEditingText(el.id); }}
                  onContextMenu={e => { e.preventDefault(); e.stopPropagation(); st.selectElement(el.id); setMenu({ x: e.clientX, y: e.clientY, id: el.id }); }}
                  className={`absolute group ${st.previewMode ? '' : el.locked ? 'cursor-not-allowed' : 'cursor-grab active:cursor-grabbing'}`}
                  style={{
                    left: r.x, top: r.y, width: r.width, height: r.height,
                    zIndex: el.zIndex,
                    transform: el.rotation ? `rotate(${el.rotation}deg)` : undefined,
                    opacity: r.hidden ? 0.25 : 1,
                    outline: selected && !st.previewMode
                      ? (primary ? '2px solid #2563EB' : '2px dashed #2563EB')
                      : undefined,
                    outlineOffset: 1,
                  }}
                >
                  {editingText === el.id ? (
                    <textarea
                      autoFocus
                      defaultValue={el.properties.content ?? ''}
                      onBlur={e => { st.updateProperties(el.id, { content: e.target.value }); st.commit('ویرایش متن'); setEditingText(null); }}
                      onPointerDown={e => e.stopPropagation()}
                      className="w-full h-full resize-none outline-none border-2 border-teal-500 rounded p-1 bg-white text-slate-900"
                      style={{ fontSize: el.style.fontSize, textAlign: el.style.textAlign, fontFamily: 'Vazirmatn' }}
                    />
                  ) : (
                    <ElementRenderer el={el} print={st.previewMode} />
                  )}

                  {!st.previewMode && !selected && (
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 pointer-events-none outline outline-1 outline-teal-400/60 rounded-[3px] transition-opacity" />
                  )}

                  {!st.previewMode && (el.locked || r.hidden) && (
                    <div className="absolute top-0.5 left-0.5 flex gap-0.5 pointer-events-none element-handles">
                      {el.locked && <span className="bg-amber-500 text-white rounded p-0.5"><Lock className="w-2.5 h-2.5" /></span>}
                      {r.hidden && <span className="bg-slate-500 text-white rounded p-0.5"><EyeOff className="w-2.5 h-2.5" /></span>}
                    </div>
                  )}

                  {/* handles */}
                  {primary && !st.previewMode && !el.locked && (
                    <>
                      {HANDLES.map(h => (
                        <div
                          key={h.k}
                          onPointerDown={e => onHandleDown(e, el, h.k)}
                          className="absolute bg-white border-2 border-blue-600 rounded-sm element-handles"
                          style={{
                            width: 9 / st.zoom, height: 9 / st.zoom,
                            left: `calc(${h.x * 100}% - ${4.5 / st.zoom}px)`,
                            top: `calc(${h.y * 100}% - ${4.5 / st.zoom}px)`,
                            cursor: h.cur,
                          }}
                        />
                      ))}
                      <div
                        onPointerDown={e => onRotateDown(e, el)}
                        className="absolute bg-blue-600 rounded-full element-handles flex items-center justify-center text-white"
                        style={{
                          width: 14 / st.zoom, height: 14 / st.zoom,
                          left: `calc(50% - ${7 / st.zoom}px)`, top: -26 / st.zoom, cursor: 'grab',
                          fontSize: 9 / st.zoom,
                        }}
                      >↻</div>
                      <div className="absolute element-handles pointer-events-none whitespace-nowrap rounded bg-blue-600 text-white font-bold"
                        style={{ bottom: -20 / st.zoom, right: 0, fontSize: 9 / st.zoom, padding: `${1 / st.zoom}px ${4 / st.zoom}px` }}>
                        {fa(Math.round(r.width))} × {fa(Math.round(r.height))}
                      </div>
                    </>
                  )}
                </div>
              );
            })}

            {/* Guides */}
            {!st.previewMode && st.activeGuides.map((g, i) => <Guide key={i} g={g} page={page} zoom={st.zoom} />)}

            {/* Marquee */}
            {marquee && (
              <div className="absolute border-2 border-blue-500 bg-blue-500/10 pointer-events-none selection-box"
                style={{ left: marquee.x, top: marquee.y, width: marquee.w, height: marquee.h }} />
            )}

            {/* Empty state */}
            {st.elements.length === 0 && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-300 pointer-events-none gap-2">
                <div className="w-14 h-14 rounded-2xl border-2 border-dashed border-slate-300 flex items-center justify-center text-2xl">＋</div>
                <p className="text-sm font-medium text-slate-400">عناصر را از پنل کناری بکشید و اینجا رها کنید</p>
                <p className="text-[11px] text-slate-400">یا از تب «قالب‌ها» یک قالب آماده بارگذاری کنید</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Multi-select notice */}
      {multiNotice && (
        <div className="fixed bottom-24 md:bottom-16 left-1/2 -translate-x-1/2 z-40 px-3 py-1.5 rounded-full bg-teal-600 text-white text-[11px] font-bold shadow-xl animate-slide-up">
          اضافه شد — {fa(st.selectedElementIds.length)} عنصر انتخاب شده
        </div>
      )}

      {/* Position badge */}
      {badge && (
        <div className="fixed bottom-24 md:bottom-16 left-1/2 -translate-x-1/2 z-40 px-3 py-1.5 rounded-full bg-slate-900/90 text-white text-xs font-bold tabular-nums shadow-xl">
          {badge}
        </div>
      )}

      {/* Context menu */}
      {menu && <ContextMenu x={menu.x} y={menu.y} id={menu.id} close={() => setMenu(null)} onProps={onOpenProps} />}
    </div>
  );
}

function Guide({ g, page, zoom }: { g: GuideLine; page: { width: number; height: number }; zoom: number }) {
  const common: React.CSSProperties = { position: 'absolute', pointerEvents: 'none', zIndex: 9998 };
  if (g.type === 'vertical') {
    return (
      <div style={{ ...common, left: g.position, top: -20, height: page.height + 40, borderLeft: `1px dashed ${g.color}` }}>
        {g.label && <span className="absolute top-0 -translate-x-1/2 px-1 rounded text-white" style={{ background: g.color, fontSize: 9 / zoom }}>{g.label}</span>}
      </div>
    );
  }
  return (
    <div style={{ ...common, top: g.position, left: -20, width: page.width + 40, borderTop: `1px dashed ${g.color}` }}>
      {g.label && <span className="absolute right-0 -translate-y-1/2 px-1 rounded text-white" style={{ background: g.color, fontSize: 9 / zoom }}>{g.label}</span>}
    </div>
  );
}

function Rulers({ page, zoom, pan }: { page: { width: number; height: number }; zoom: number; pan: { x: number; y: number } }) {
  const ticks: { pos: number; major: boolean; label: number }[] = [];
  const stepMm = 5;
  const totalMm = Math.ceil(page.width / mmToPx(1));
  for (let mm = 0; mm <= totalMm; mm += stepMm) {
    ticks.push({ pos: mmToPx(mm) * zoom, major: mm % 10 === 0, label: mm });
  }
  const vTotal = Math.ceil(page.height / mmToPx(1));
  const vTicks: { pos: number; major: boolean; label: number }[] = [];
  for (let mm = 0; mm <= vTotal; mm += stepMm) {
    vTicks.push({ pos: mmToPx(mm) * zoom, major: mm % 10 === 0, label: mm });
  }
  return (
    <>
      <div className="sticky top-0 z-20 h-5 bg-white/90 dark:bg-slate-900/90 border-b border-slate-200 dark:border-slate-800 canvas-rulers backdrop-blur"
        style={{ marginBottom: -20 }}>
        <div className="relative h-full mx-auto" style={{ width: page.width * zoom, transform: `translateX(${pan.x}px)` }}>
          {ticks.map(t => (
            <div key={t.pos} className="absolute top-0 h-full" style={{ left: t.pos }}>
              <div className={t.major ? 'w-px h-2.5 bg-slate-400' : 'w-px h-1.5 bg-slate-300'} />
              {t.major && <span className="absolute top-2 -translate-x-1/2 text-[7px] text-slate-500">{fa(t.label)}</span>}
            </div>
          ))}
        </div>
      </div>
      <div className="sticky right-0 float-right z-20 w-5 bg-white/90 dark:bg-slate-900/90 border-l border-slate-200 dark:border-slate-800 canvas-rulers backdrop-blur"
        style={{ height: page.height * zoom, marginLeft: -20, marginTop: 24 }}>
        <div className="relative h-full" style={{ transform: `translateY(${pan.y}px)` }}>
          {vTicks.map(t => (
            <div key={t.pos} className="absolute right-0 w-full" style={{ top: t.pos }}>
              <div className={t.major ? 'h-px w-2.5 bg-slate-400 mr-auto' : 'h-px w-1.5 bg-slate-300 mr-auto'} />
              {t.major && <span className="absolute right-2.5 -translate-y-1/2 text-[7px] text-slate-500">{fa(t.label)}</span>}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

function ContextMenu({ x, y, id, close, onProps }: { x: number; y: number; id: string; close: () => void; onProps?: () => void }) {
  const st = useEditor();
  const el = st.elements.find(e => e.id === id);
  if (!el) return null;
  const Item = ({ children, onClick, shortcut, danger }: { children: React.ReactNode; onClick: () => void; shortcut?: string; danger?: boolean }) => (
    <button
      onClick={() => { onClick(); close(); }}
      className={`w-full flex items-center justify-between gap-4 px-3 py-1.5 text-[12px] hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors ${danger ? 'text-rose-600' : 'text-slate-700 dark:text-slate-200'}`}
    >
      <span>{children}</span>
      {shortcut && <span className="text-[10px] text-slate-400 font-mono">{shortcut}</span>}
    </button>
  );
  return (
    <>
      <div className="fixed inset-0 z-[60]" onPointerDown={close} />
      <div className="fixed z-[61] w-52 py-1 rounded-xl bg-white dark:bg-slate-800 shadow-2xl border border-slate-200 dark:border-slate-700 animate-scale-in"
        style={{ left: clamp(x - 200, 8, window.innerWidth - 220), top: clamp(y, 8, window.innerHeight - 380) }}>
        <Item onClick={st.cut} shortcut="Ctrl+X">✂️ برش</Item>
        <Item onClick={st.copy} shortcut="Ctrl+C">📋 کپی</Item>
        <Item onClick={st.paste} shortcut="Ctrl+V">📌 چسباندن</Item>
        <div className="h-px bg-slate-100 dark:bg-slate-700 my-1" />
        <Item onClick={() => st.duplicateElement(id)} shortcut="Ctrl+D">🧬 کپی‌برداری</Item>
        <Item onClick={() => st.deleteElement(id)} shortcut="Delete" danger>🗑️ حذف</Item>
        <div className="h-px bg-slate-100 dark:bg-slate-700 my-1" />
        <Item onClick={() => st.toggleLock(id)}>{el.locked ? '🔓 باز کردن قفل' : '🔒 قفل کردن'}</Item>
        <Item onClick={() => st.toggleHidden(id)}>{el.hidden ? '👁 نمایش' : '🙈 مخفی کردن'}</Item>
        <div className="h-px bg-slate-100 dark:bg-slate-700 my-1" />
        <Item onClick={() => st.reorderElement(id, 'up')}>⬆ یک لایه بالا</Item>
        <Item onClick={() => st.reorderElement(id, 'down')}>⬇ یک لایه پایین</Item>
        <Item onClick={() => st.reorderElement(id, 'top')}>⬆⬆ بالاترین لایه</Item>
        <Item onClick={() => st.reorderElement(id, 'bottom')}>⬇⬇ پایین‌ترین لایه</Item>
        <div className="h-px bg-slate-100 dark:bg-slate-700 my-1" />
        <Item onClick={() => st.groupElements()} shortcut="Ctrl+G">👥 گروه‌بندی</Item>
        <Item onClick={() => st.ungroupElements()}>👤 آنگروه</Item>
        {onProps && <><div className="h-px bg-slate-100 dark:bg-slate-700 my-1" /><Item onClick={onProps}>⚙️ تنظیمات عنصر</Item></>}
      </div>
    </>
  );
}

function isTyping(e: KeyboardEvent) {
  const t = e.target as HTMLElement;
  return t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
}
