import { useMemo, useRef, useState } from 'react';
import {
  DndContext, PointerSensor, closestCenter, useSensor, useSensors,
  type DragEndEvent,
} from '@dnd-kit/core';
import { SortableContext, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import {
  Type, Heading1, AlignRight, TextCursorInput, FileText, Hash, Coins, Calendar,
  ChevronDown, CheckSquare, CircleDot, ToggleLeft, Square, Rows, Columns, Minus,
  Move, Image as ImageIcon, Upload, QrCode, Table, TableProperties, PenLine,
  Stamp, Droplets, FileDigit, Barcode, Sigma, SpellCheck, Plus, Eye, EyeOff,
  Lock, Unlock, GripVertical, Trash2, Layers as LayersIcon, LayoutTemplate, Boxes,
  Star, Tag, Circle, KeyRound, Pill as PillIcon,
  GitCommit, Award, ListChecks, BarChart2, Users2, ShieldAlert, AlertTriangle, Cpu, DollarSign,
} from 'lucide-react';
import { useEditor } from '../store';
import { TEMPLATES, TEMPLATE_CATEGORIES } from '../templates';
import { SYSTEM_FORM_TEMPLATES } from '../formTemplates';
import type { TemplateDef } from '../templates';
import type { ElementType } from '../types';
import { ELEMENT_LABELS } from '../types';
import { fa, getPagePx, snapValue } from '../utils';
import { cx } from './controls';

const ICONS: Record<ElementType, React.ComponentType<{ className?: string }>> = {
  heading: Heading1, text: Type, paragraph: AlignRight,
  'text-input': TextCursorInput, textarea: FileText, 'number-input': Hash,
  'currency-input': Coins, 'date-input': Calendar, select: ChevronDown,
  checkbox: CheckSquare, 'radio-group': CircleDot, switch: ToggleLeft,
  container: Square, row: Rows, column: Columns, divider: Minus, spacer: Move,
  image: ImageIcon, 'image-upload': Upload, 'qr-code': QrCode, barcode: Barcode,
  table: Table, 'dynamic-table': TableProperties,
  signature: PenLine, stamp: Stamp, watermark: Droplets, 'page-number': FileDigit,
  formula: Sigma, 'amount-words': SpellCheck, 'auto-number': Plus,
  icon: Star, badge: Tag, 'shape-circle': Circle, kv: KeyRound, pill: PillIcon,
  timeline: GitCommit, rating: Award, checklist: ListChecks, 'stat-box': BarChart2,
  'dual-signature': Users2, 'seal-badge': ShieldAlert, 'notes-box': AlertTriangle,
  'device-specs': Cpu, 'price-tag': DollarSign,
};

const GROUPS: { title: string; items: ElementType[] }[] = [
  { title: '📝 متنی', items: ['heading', 'text', 'paragraph'] },
  { title: '📋 فیلدهای ورودی', items: ['text-input', 'textarea', 'number-input', 'currency-input', 'date-input', 'select', 'checkbox', 'radio-group', 'switch'] },
  { title: '📊 جدول و اقلام', items: ['table', 'dynamic-table'] },
  { title: '📐 چیدمان و ساختار', items: ['container', 'row', 'column', 'divider', 'spacer'] },
  { title: '🖼️ رسانه و کدها', items: ['image', 'image-upload', 'qr-code', 'barcode'] },
  { title: '🔐 تأیید و امضا', items: ['signature', 'stamp', 'dual-signature', 'seal-badge', 'watermark', 'page-number', 'auto-number'] },
  { title: '🧮 محاسباتی و تجاری', items: ['formula', 'amount-words', 'price-tag', 'stat-box', 'kv'] },
  { title: '✨ اجزای تعاملی و مدرن', items: ['timeline', 'rating', 'checklist', 'notes-box', 'device-specs', 'icon', 'badge', 'pill', 'shape-circle'] },
];

type Tab = 'elements' | 'layers' | 'templates';

export function LeftPanel({ compact = false, onAdded }: { compact?: boolean; onAdded?: () => void }) {
  const [tab, setTab] = useState<Tab>('elements');
  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800">
      <div className="flex p-1.5 gap-1 border-b border-slate-100 dark:border-slate-800">
        {([['elements', 'عناصر', Boxes], ['layers', 'لایه‌ها', LayersIcon], ['templates', 'قالب‌ها', LayoutTemplate]] as const).map(([k, label, Icon]) => (
          <button key={k} onClick={() => setTab(k)}
            className={cx('flex-1 flex items-center justify-center gap-1 py-2 rounded-lg text-[11px] font-bold transition-all',
              tab === k ? 'bg-teal-600 text-white shadow-md shadow-teal-500/20' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800')}>
            <Icon className="w-3.5 h-3.5" />{label}
          </button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto scroll-area">
        {tab === 'elements' && <Palette compact={compact} onAdded={onAdded} />}
        {tab === 'layers' && <LayersPanel />}
        {tab === 'templates' && <TemplatesPanel />}
      </div>
    </div>
  );
}

/* ================= Palette ================= */
function Palette({ compact, onAdded }: { compact?: boolean; onAdded?: () => void }) {
  const st = useEditor();
  const [ghost, setGhost] = useState<{ type: ElementType; x: number; y: number } | null>(null);
  const dragType = useRef<ElementType | null>(null);

  const movedRef = useRef(false);

  const startDrag = (e: React.PointerEvent, type: ElementType) => {
    dragType.current = type;
    movedRef.current = false;
    const originX = e.clientX, originY = e.clientY;

    const move = (ev: PointerEvent) => {
      if (!movedRef.current && Math.hypot(ev.clientX - originX, ev.clientY - originY) > 6) {
        movedRef.current = true;
      }
      if (movedRef.current) setGhost({ type, x: ev.clientX, y: ev.clientY });
    };

    const up = (ev: PointerEvent) => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      setGhost(null);
      const paper = document.getElementById('editor-paper');
      if (movedRef.current && paper && dragType.current) {
        const r = paper.getBoundingClientRect();
        if (ev.clientX >= r.left && ev.clientX <= r.right && ev.clientY >= r.top && ev.clientY <= r.bottom) {
          let x = (ev.clientX - r.left) / st.zoom;
          let y = (ev.clientY - r.top) / st.zoom;
          if (st.snapToGrid) { x = snapValue(x, st.gridSize); y = snapValue(y, st.gridSize); }
          st.addElementOfType(dragType.current, Math.max(0, x - 20), Math.max(0, y - 12));
          onAdded?.();
        }
      }
      dragType.current = null;
    };

    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const addToCenter = (type: ElementType) => {
    const page = getPagePx(st.document);
    st.addElementOfType(type, page.width / 2 - 90, Math.min(page.height - 60, 120 + st.elements.length * 8));
    onAdded?.();
  };

  return (
    <div className="p-2 space-y-3">
      {GROUPS.map(g => (
        <div key={g.title}>
          <p className="text-[10px] font-bold text-slate-400 px-1 mb-1.5">{g.title}</p>
          <div className={cx('grid gap-1.5', compact ? 'grid-cols-4' : 'grid-cols-2')}>
            {g.items.map(type => {
              const Icon = ICONS[type];
              return (
                <button
                  key={type}
                  onPointerDown={e => startDrag(e, type)}
                  onClick={() => { if (!movedRef.current) addToCenter(type); movedRef.current = false; }}
                  title={`${ELEMENT_LABELS[type]} — بکشید و رها کنید یا کلیک کنید`}
                  className="flex flex-col items-center justify-center gap-1 p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-teal-400 hover:bg-teal-50/60 dark:hover:bg-teal-900/20 cursor-grab active:cursor-grabbing active:scale-95 transition-all"
                >
                  <Icon className="w-4 h-4 text-teal-600" />
                  <span className="text-[9.5px] text-slate-600 dark:text-slate-300 text-center leading-tight">{ELEMENT_LABELS[type]}</span>
                </button>
              );
            })}
          </div>
        </div>
      ))}

      {ghost && (
        <div className="fixed z-[100] pointer-events-none px-3 py-2 rounded-xl bg-teal-600 text-white text-[11px] font-bold shadow-2xl opacity-80"
          style={{ left: ghost.x + 10, top: ghost.y + 10 }}>
          {ELEMENT_LABELS[ghost.type]}
        </div>
      )}
    </div>
  );
}

/* ================= Layers ================= */
function LayersPanel() {
  const st = useEditor();
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));
  const ordered = useMemo(() => [...st.elements].sort((a, b) => b.zIndex - a.zIndex), [st.elements]);

  const onDragEnd = (e: DragEndEvent) => {
    const { active, over } = e;
    if (!over || active.id === over.id) return;
    const ids = ordered.map(o => o.id);
    const from = ids.indexOf(String(active.id));
    const to = ids.indexOf(String(over.id));
    const next = [...ids];
    next.splice(to, 0, next.splice(from, 1)[0]);
    st.setLayerOrder(next);
  };

  if (ordered.length === 0) {
    return <div className="p-8 text-center text-[12px] text-slate-400">هیچ عنصری وجود ندارد</div>;
  }

  return (
    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
      <SortableContext items={ordered.map(o => o.id)} strategy={verticalListSortingStrategy}>
        <div className="p-1.5 space-y-1">
          {ordered.map(el => <LayerRow key={el.id} id={el.id} />)}
        </div>
      </SortableContext>
    </DndContext>
  );
}

function LayerRow({ id }: { id: string }) {
  const st = useEditor();
  const el = st.elements.find(e => e.id === id)!;
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });
  const [renaming, setRenaming] = useState(false);
  const Icon = ICONS[el.type] ?? Type;
  const selected = st.selectedElementIds.includes(id);

  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.6 : 1 }}
      onClick={e => (e.ctrlKey || e.metaKey ? st.multiSelectElement(id) : st.selectElement(id))}
      className={cx(
        'flex items-center gap-1 px-1.5 py-1.5 rounded-lg cursor-pointer border transition-colors',
        selected ? 'bg-teal-50 dark:bg-teal-900/25 border-teal-300 dark:border-teal-700' : 'border-transparent hover:bg-slate-50 dark:hover:bg-slate-800',
        el.hidden && 'opacity-50'
      )}
    >
      <button {...attributes} {...listeners} className="p-0.5 text-slate-300 hover:text-slate-500 cursor-grab touch-none">
        <GripVertical className="w-3.5 h-3.5" />
      </button>
      <button onClick={e => { e.stopPropagation(); st.toggleHidden(id); }} className="p-0.5 text-slate-400 hover:text-teal-600">
        {el.hidden ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
      </button>
      <button onClick={e => { e.stopPropagation(); st.toggleLock(id); }} className={cx('p-0.5 hover:text-teal-600', el.locked ? 'text-amber-500' : 'text-slate-300')}>
        {el.locked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
      </button>
      <Icon className="w-3.5 h-3.5 text-teal-600 shrink-0" />
      {renaming ? (
        <input
          autoFocus defaultValue={el.label}
          onBlur={e => { st.updateElement(id, { label: e.target.value || el.label }, 'تغییر نام لایه'); setRenaming(false); }}
          onKeyDown={e => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }}
          onClick={e => e.stopPropagation()}
          className="flex-1 min-w-0 text-[11px] px-1 py-0.5 rounded border border-teal-400 bg-white dark:bg-slate-900 outline-none"
        />
      ) : (
        <span onDoubleClick={e => { e.stopPropagation(); setRenaming(true); }}
          className="flex-1 min-w-0 truncate text-[11px] text-slate-700 dark:text-slate-200">
          {el.label}
        </span>
      )}
      {el.groupId && <span className="text-[8px] px-1 rounded bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300">گروه</span>}
      <button onClick={e => { e.stopPropagation(); st.deleteElement(id); }} className="p-0.5 text-slate-300 hover:text-rose-500">
        <Trash2 className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}

/* ================= Templates ================= */
// Merge design templates with the app's official printable-form templates.
const ALL_TEMPLATES: TemplateDef[] = [
  ...SYSTEM_FORM_TEMPLATES.map(t => ({
    id: t.id, name: t.name, category: t.printType === 'factor' ? 'فاکتور' : 'رسید',
    description: t.description, doc: t.doc, build: t.build,
  })),
  ...TEMPLATES,
];
const ALL_CATEGORIES = ['همه', ...Array.from(new Set([...TEMPLATE_CATEGORIES, 'رسید'].filter(c => c !== 'همه')))];

function TemplatesPanel() {
  const st = useEditor();
  const [cat, setCat] = useState('همه');
  const list = ALL_TEMPLATES.filter(t => cat === 'همه' || t.category === cat);
  const officialIds = new Set(SYSTEM_FORM_TEMPLATES.map(t => t.id));

  const load = (id: string) => {
    const tpl = ALL_TEMPLATES.find(t => t.id === id);
    if (!tpl) return;
    if (st.elements.length > 0 && !window.confirm('بارگذاری قالب، محتوای فعلی را جایگزین می‌کند. ادامه می‌دهید؟')) return;
    st.loadTemplate(tpl.doc, tpl.build());
  };

  return (
    <div className="p-2 space-y-3">
      <div className="flex flex-wrap gap-1">
        {ALL_CATEGORIES.map(c => (
          <button key={c} onClick={() => setCat(c)}
            className={cx('px-2 py-1 rounded-lg text-[10px] font-medium border transition-colors',
              cat === c ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-200 dark:border-slate-700 text-slate-500 hover:border-teal-300')}>
            {c}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-1 gap-2">
        {list.map(t => (
          <div key={t.id} className="relative rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden bg-white dark:bg-slate-800 hover:border-teal-400 transition-colors">
            {officialIds.has(t.id) && (
              <span className="absolute z-10 top-1.5 left-1.5 px-1.5 py-0.5 rounded-md bg-amber-500 text-white text-[8.5px] font-bold shadow">قالب چاپی رسمی</span>
            )}
            <div className="h-20 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900 flex items-center justify-center border-b border-slate-100 dark:border-slate-700">
              <div className="w-11 h-14 bg-white dark:bg-slate-700 rounded shadow-md border border-slate-200 dark:border-slate-600 p-1 space-y-0.5">
                <div className="h-1 bg-teal-500/70 rounded-full w-2/3" />
                <div className="h-0.5 bg-slate-300 rounded-full" />
                <div className="h-0.5 bg-slate-300 rounded-full w-4/5" />
                <div className="h-3 bg-slate-200 dark:bg-slate-600 rounded-sm mt-1" />
                <div className="h-0.5 bg-slate-300 rounded-full w-1/2" />
              </div>
            </div>
            <div className="p-2">
              <p className="text-[12px] font-bold text-slate-800 dark:text-slate-100">{t.name}</p>
              <p className="text-[10px] text-slate-500 leading-4 mt-0.5 line-clamp-2">{t.description}</p>
              <div className="flex items-center justify-between mt-2">
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-500">{t.category}</span>
                <button onClick={() => load(t.id)}
                  className="px-2.5 py-1 rounded-lg bg-teal-600 text-white text-[10px] font-bold active:scale-95 transition-transform">
                  بارگذاری
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      <p className="text-[10px] text-slate-400 text-center pt-1">{fa(list.length)} قالب آماده</p>
    </div>
  );
}
