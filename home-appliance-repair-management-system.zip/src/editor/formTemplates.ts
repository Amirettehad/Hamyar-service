// System form templates that replicate the app's printable forms exactly,
// using data-bound fields so they render real order data at print time.
import type { DocumentConfig, EditorElement, ElementProperties, ElementStyle, ElementType } from './types';
import { createElement, uuid } from './utils';

type Over = Omit<Partial<EditorElement>, 'style' | 'properties'> & {
  style?: Partial<ElementStyle>;
  properties?: Partial<ElementProperties>;
};

let z = 0;
function el(type: ElementType, x: number, y: number, w: number, h: number, over: Over = {}): EditorElement {
  z += 1;
  const base = createElement(type, x, y, z);
  const { style, properties, ...rest } = over;
  return { ...base, width: w, height: h, ...rest, style: { ...base.style, ...(style ?? {}) }, properties: { ...base.properties, ...(properties ?? {}) } };
}

const HEAD = { fontSize: 22, fontWeight: 'extrabold' as const, textAlign: 'center' as const };
const SUB = { fontSize: 11, color: '#475569', textAlign: 'center' as const };
const LABEL = { fontSize: 11, color: '#64748b' };
const VALUE = { fontSize: 12, fontWeight: 'medium' as const };
const SECTION = { fontSize: 12, fontWeight: 'bold' as const, color: '#0f766e' };
const BOX = { borderStyle: 'solid' as const, borderWidth: 1, borderColor: '#cbd5e1', borderRadius: 8, padding: 6 };
const FOOTER = { fontSize: 10, color: '#94a3b8', textAlign: 'center' as const };

export interface SystemFormTemplate {
  id: string;
  name: string;
  printType: 'factor' | 'receipt';
  description: string;
  doc: Partial<DocumentConfig>;
  build: () => EditorElement[];
}

// A4 portrait content box: x 28..766 (width 738)
function invoiceOfficial(): EditorElement[] {
  z = 0;
  return [
    // Header
    el('image', 28, 20, 72, 64, { label: 'لوگو', properties: { fit: 'contain' } }),
    el('heading', 110, 22, 300, 30, { label: 'نام تعمیرگاه', style: HEAD, properties: { content: '{shop.name}' } }),
    el('text', 110, 52, 320, 16, { label: 'آدرس تعمیرگاه', style: SUB, properties: { content: '{shop.address}' } }),
    el('text', 110, 68, 320, 16, { label: 'تلفن تعمیرگاه', style: SUB, properties: { content: 'تلفن: {shop.phone}  -  {shop.phone2}' } }),
    el('qr-code', 668, 20, 80, 80, { label: 'QR فاکتور', properties: { value: '{order.requestNumber}' } }),
    el('divider', 28, 108, 738, 2, { label: 'خط جدا' }),

    // Number & date box (left)
    el('text', 28, 118, 360, 18, { label: 'شماره فاکتور', style: LABEL, properties: { content: 'شماره فاکتور' } }),
    el('heading', 28, 134, 360, 24, { label: 'شماره', style: { fontSize: 14, fontWeight: 'bold', color: '#0f766e' }, properties: { content: '{order.invoiceNumber}' } }),
    el('text', 28, 160, 360, 16, { label: 'تاریخ ثبت', style: LABEL, properties: { content: 'تاریخ ثبت: {order.date}' } }),
    el('text', 28, 176, 360, 16, { label: 'تاریخ مراجعه', style: LABEL, properties: { content: 'تاریخ مراجعه: {order.visitDate} {order.visitTime}' } }),

    // Customer box (right)
    el('text', 406, 118, 360, 18, { label: 'مشتری', style: LABEL, properties: { content: 'مشتری' } }),
    el('heading', 406, 134, 360, 24, { label: 'نام مشتری', style: { fontSize: 14, fontWeight: 'bold' }, properties: { content: '{customer.fullName}' } }),
    el('text', 406, 160, 360, 16, { label: 'تلفن', style: LABEL, properties: { content: 'شماره تماس: {customer.phone}' } }),
    el('text', 406, 176, 360, 16, { label: 'آدرس', style: LABEL, properties: { content: 'آدرس: {customer.address}' } }),

    el('divider', 28, 200, 738, 2, { label: 'خط جدا' }),

    // Device info
    el('text', 28, 210, 738, 18, { label: 'اطلاعات دستگاه', style: SECTION, properties: { content: 'اطلاعات دستگاه' } }),
    el('container', 28, 230, 738, 64, {
      label: 'جدول دستگاه',
      style: BOX,
      properties: { direction: 'row', gap: 4, alignItems: 'stretch', justifyContent: 'start', wrap: true, childIds: [] },
    }),
    el('text-input', 32, 236, 178, 22, { label: 'نوع', style: VALUE, properties: { placeholder: 'نوع: {device.type}' } }),
    el('text-input', 214, 236, 178, 22, { label: 'برند', style: VALUE, properties: { placeholder: 'برند: {device.brand}' } }),
    el('text-input', 396, 236, 178, 22, { label: 'مدل', style: VALUE, properties: { placeholder: 'مدل: {device.model}' } }),
    el('text-input', 578, 236, 184, 22, { label: 'سریال', style: VALUE, properties: { placeholder: 'سریال: {device.serial}' } }),
    el('text-input', 32, 262, 365, 22, { label: 'سرویس', style: VALUE, properties: { placeholder: 'نوع سرویس: {order.serviceType}   وضعیت: {order.status}' } }),
    el('text-input', 401, 262, 361, 22, { label: 'گارانتی', style: VALUE, properties: { placeholder: 'گارانتی: {device.warranty}   سرویسکار: {technician.name}' } }),

    // Problem
    el('text', 28, 302, 738, 18, { label: 'شرح خرابی', style: SECTION, properties: { content: 'شرح خرابی اعلام شده توسط مشتری' } }),
    el('paragraph', 28, 322, 738, 48, { label: 'متن خرابی', style: { ...BOX, fontSize: 11 }, properties: { content: '{order.problem}' } }),

    // Report
    el('text', 28, 378, 738, 18, { label: 'گزارش', style: SECTION, properties: { content: 'گزارش عملیات انجام شده' } }),
    el('paragraph', 28, 398, 738, 48, { label: 'متن گزارش', style: { ...BOX, fontSize: 11 }, properties: { content: '{order.report}' } }),

    // Items table
    el('dynamic-table', 28, 456, 738, 230, {
      label: 'جدول اقلام',
      properties: {
        columns: [
          { id: uuid(), header: 'ردیف', width: 8, align: 'center', type: 'text', editable: false, dataField: 'item.row' },
          { id: uuid(), header: 'شرح کالا / خدمات', width: 42, align: 'right', type: 'text', editable: true, dataField: 'item.desc' },
          { id: uuid(), header: 'تعداد', width: 12, align: 'center', type: 'number', editable: true, dataField: 'item.qty' },
          { id: uuid(), header: 'فی (تومان)', width: 19, align: 'left', type: 'currency', editable: true, dataField: 'item.price' },
          { id: uuid(), header: 'جمع', width: 19, align: 'left', type: 'formula', editable: false, dataField: 'item.total' },
        ],
        rows: 4, showHeader: true, showFooter: true, dynamicRows: true, showRowNumbers: false,
        headerBg: '#0f766e', headerColor: '#ffffff', zebraStripes: true, altRowBg: '#f8fafc', cellPadding: 'normal', tableBorder: 'solid',
      },
    }),

    // Totals (right aligned)
    el('container', 406, 696, 360, 150, {
      label: 'خلاصه مالی',
      style: BOX,
      properties: { direction: 'column', gap: 4, alignItems: 'stretch', justifyContent: 'start', wrap: false, childIds: [] },
    }),
    el('text', 412, 702, 348, 18, { label: 'جمع قطعات و خدمات', style: { fontSize: 11, textAlign: 'left' }, properties: { content: 'جمع قطعات و خدمات: {amount.partsTotal.text}' } }),
    el('text', 412, 722, 348, 18, { label: 'ایاب و ذهاب', style: { fontSize: 11, textAlign: 'left' }, properties: { content: 'ایاب و ذهاب: {amount.transport.text}' } }),
    el('text', 412, 742, 348, 18, { label: 'تخفیف', style: { fontSize: 11, textAlign: 'left', color: '#dc2626' }, properties: { content: 'تخفیف: {amount.discount.text}' } }),
    el('text', 412, 762, 348, 18, { label: 'مالیات', style: { fontSize: 11, textAlign: 'left' }, properties: { content: 'مالیات: {amount.tax.text}' } }),
    el('text', 412, 786, 348, 26, { label: 'مبلغ نهایی', style: { fontSize: 14, fontWeight: 'bold', textAlign: 'left', color: '#065f46', backgroundColor: '#ecfdf5' }, properties: { content: 'مبلغ نهایی: {amount.total.text}' } }),
    el('text', 412, 816, 348, 18, { label: 'باقی‌مانده', style: { fontSize: 11, textAlign: 'left', color: '#b45309' }, properties: { content: 'باقی‌مانده: {amount.remaining.text}' } }),

    // Amount in words (left)
    el('amount-words', 28, 702, 366, 36, { label: 'مبلغ به حروف', style: { ...BOX, fontSize: 11 }, properties: { prefix: 'مبلغ به حروف: ', suffix: 'تومان', formula: '{amount.total}' } }),
    el('paragraph', 28, 744, 366, 96, { label: 'شرایط', style: { ...BOX, fontSize: 9, color: '#64748b' }, properties: { content: 'شرایط:\n• خدمات دارای گارانتی تعمیر می‌باشد.\n• قطعات اصلی و دارای گارانتی شرکتی هستند.\n• این فاکتور بدون مهر و امضا فاقد اعتبار است.' } }),

    // Signatures
    el('divider', 28, 852, 738, 2, { label: 'خط امضا' }),
    el('signature', 406, 864, 360, 80, { label: 'امضای تعمیرگاه', properties: { content: 'مهر و امضای تعمیرگاه' } }),
    el('signature', 217, 864, 180, 80, { label: 'امضای تکنسین', properties: { content: 'امضای تکنسین' } }),
    el('signature', 28, 864, 180, 80, { label: 'امضای مشتری', properties: { content: 'امضای مشتری' } }),

    el('text', 28, 952, 738, 16, { label: 'پانویس', style: FOOTER, properties: { content: 'این فاکتور با نرم‌افزار همیار سرویس اتحاد صادر گردیده است.' } }),
    el('text', 28, 970, 738, 16, { label: 'استعلام', style: FOOTER, properties: { content: 'استعلام آنلاین وضعیت: شماره سفارش {order.requestNumber}' } }),
  ];
}

// A5 portrait receipt replica: 148x210mm = 559x794px, content x 24..535 (width 511)
function receiptOfficial(): EditorElement[] {
  z = 0;
  return [
    el('heading', 120, 24, 320, 30, { label: 'عنوان', style: HEAD, properties: { content: 'رسید پذیرش تعمیرگاه' } }),
    el('qr-code', 451, 20, 64, 64, { label: 'QR', properties: { value: '{order.requestNumber}' } }),
    el('divider', 24, 92, 511, 2, { label: 'خط' }),

    el('text', 24, 102, 250, 16, { label: 'شماره', style: LABEL, properties: { content: 'شماره رسید' } }),
    el('heading', 24, 118, 250, 22, { label: 'شماره رسید', style: { fontSize: 13, fontWeight: 'bold', color: '#0f766e' }, properties: { content: '{order.invoiceNumber}' } }),
    el('text', 285, 102, 250, 16, { label: 'تاریخ', style: LABEL, properties: { content: 'تاریخ ثبت' } }),
    el('text', 285, 120, 250, 18, { label: 'تاریخ', style: VALUE, properties: { content: '{order.date}' } }),

    el('divider', 24, 148, 511, 2, { label: 'خط' }),

    el('text', 24, 158, 511, 18, { label: 'مشتری', style: SECTION, properties: { content: 'مشخصات مشتری' } }),
    el('text', 285, 182, 250, 18, { label: 'نام', style: VALUE, properties: { content: '{customer.fullName}' } }),
    el('text', 24, 182, 250, 18, { label: 'تلفن', style: VALUE, properties: { content: '{customer.phone}' } }),
    el('text', 24, 204, 511, 18, { label: 'آدرس', style: { fontSize: 11, color: '#64748b' }, properties: { content: '{customer.address}' } }),

    el('text', 24, 230, 511, 18, { label: 'دستگاه', style: SECTION, properties: { content: 'مشخصات دستگاه' } }),
    el('text', 24, 254, 255, 18, { label: 'نوع/برند', style: VALUE, properties: { content: '{device.type} - {device.brand}' } }),
    el('text', 281, 254, 254, 18, { label: 'مدل', style: VALUE, properties: { content: '{device.model}' } }),
    el('text', 24, 276, 255, 18, { label: 'سریال', style: VALUE, properties: { content: 'سریال: {device.serial}' } }),
    el('text', 281, 276, 254, 18, { label: 'گارانتی', style: VALUE, properties: { content: 'گارانتی: {device.warranty}' } }),
    el('text', 24, 298, 511, 18, { label: 'سرویس', style: VALUE, properties: { content: 'نوع سرویس: {order.serviceType}   وضعیت: {order.status}' } }),

    el('text', 24, 326, 511, 18, { label: 'شرح خرابی', style: SECTION, properties: { content: 'شرح خرابی اعلام شده' } }),
    el('paragraph', 24, 346, 511, 56, { label: 'خرابی', style: { ...BOX, fontSize: 11 }, properties: { content: '{order.problem}' } }),

    el('text', 24, 412, 511, 18, { label: 'اقلام', style: SECTION, properties: { content: 'قطعات و خدمات مصرفی' } }),
    el('dynamic-table', 24, 432, 511, 150, {
      label: 'جدول رسید',
      properties: {
        columns: [
          { id: uuid(), header: 'ردیف', width: 10, align: 'center', type: 'text', editable: false, dataField: 'item.row' },
          { id: uuid(), header: 'شرح', width: 50, align: 'right', type: 'text', editable: true, dataField: 'item.desc' },
          { id: uuid(), header: 'تعداد', width: 14, align: 'center', type: 'number', editable: true, dataField: 'item.qty' },
          { id: uuid(), header: 'مبلغ', width: 26, align: 'left', type: 'currency', editable: true, dataField: 'item.price' },
        ],
        rows: 3, showHeader: true, showFooter: true, dynamicRows: false, showRowNumbers: false,
        headerBg: '#0f766e', headerColor: '#ffffff', zebraStripes: true, altRowBg: '#f8fafc', cellPadding: 'compact', tableBorder: 'solid',
      },
    }),

    el('text', 290, 594, 245, 20, { label: 'مبلغ نهایی', style: { fontSize: 13, fontWeight: 'bold', textAlign: 'left', color: '#065f46', backgroundColor: '#ecfdf5' }, properties: { content: 'مبلغ: {amount.total.text}' } }),
    el('amount-words', 24, 594, 255, 30, { label: 'مبلغ به حروف', style: { ...BOX, fontSize: 10 }, properties: { prefix: 'مبلغ به حروف: ', suffix: 'تومان', formula: '{amount.total}' } }),

    el('divider', 24, 636, 511, 2, { label: 'خط امضا' }),
    el('signature', 281, 648, 254, 76, { label: 'امضای دریافت‌کننده', properties: { content: 'امضای دریافت‌کننده' } }),
    el('signature', 24, 648, 245, 76, { label: 'امضای مشتری', properties: { content: 'امضای مشتری' } }),

    el('text', 24, 734, 511, 16, { label: 'پانویس', style: FOOTER, properties: { content: 'این رسید ملاک تحویل دستگاه به تعمیرگاه می‌باشد.' } }),
  ];
}

export const SYSTEM_FORM_TEMPLATES: SystemFormTemplate[] = [
  {
    id: 'official-invoice',
    name: 'فاکتور رسمی (پیش‌فرض)',
    printType: 'factor',
    description: 'قالب رسمی فاکتور با لوگو، اطلاعات مشتری و دستگاه، جدول اقلام و امضا — قابل ویرایش',
    doc: { type: 'invoice', pageSize: 'A4', orientation: 'portrait', name: 'فاکتور رسمی' },
    build: invoiceOfficial,
  },
  {
    id: 'official-receipt',
    name: 'رسید پذیرش (پیش‌فرض)',
    printType: 'receipt',
    description: 'قالب رسید پذیرش A5 با اطلاعات دستگاه و شرح خرابی — قابل ویرایش',
    doc: { type: 'receipt', pageSize: 'A5', orientation: 'portrait', name: 'رسید پذیرش' },
    build: receiptOfficial,
  },
];
