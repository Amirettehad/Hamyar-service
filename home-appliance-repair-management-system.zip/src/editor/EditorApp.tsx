import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Check, FilePlus2, FileText, Import, Pencil, Printer, Sparkles,
  Trash2, X, Copy as CopyIcon, Settings2, Boxes, ArrowRight,
} from 'lucide-react';
import { useEditor, blankDocument } from './store';
import { Toolbar } from './components/Toolbar';
import { LeftPanel } from './components/LeftPanel';
import { PropertiesPanel } from './components/PropertiesPanel';
import { Canvas } from './components/Canvas';
import { ElementRenderer } from './components/ElementRenderer';
import { TEMPLATES } from './templates';
import { DOC_TYPE_LABELS, type DocumentType, type PageSize } from './types';
import { fa, getPagePx, resolveRect, download } from './utils';
import { cx } from './components/controls';

type Toast = { id: number; msg: string; type: 'success' | 'error' | 'info' };
type Sheet = 'closed' | 'half' | 'full';

export default function EditorApp() {
  const st = useEditor();
  const [route, setRoute] = useState<'home' | 'editor'>('home');
  const [leftOpen, setLeftOpen] = useState(true);
  const [rightOpen, setRightOpen] = useState(true);
  const [sheet, setSheet] = useState<Sheet>('closed');
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [printing, setPrinting] = useState(false);
  const [booting, setBooting] = useState(true);
  const autoSaveRef = useRef<number | null>(null);

  const toast = useCallback((msg: string, type: Toast['type'] = 'success') => {
    const id = Date.now() + Math.random();
    setToasts(t => [...t, { id, msg, type }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3200);
  }, []);

  useEffect(() => { const t = setTimeout(() => setBooting(false), 650); return () => clearTimeout(t); }, []);

  // Mobile-first: auto-fit the page to screen width on entering the editor
  useEffect(() => {
    if (route !== 'editor') return;
    if (window.innerWidth < 1024) {
      const s = useEditor.getState();
      const page = getPagePx(s.document);
      const availW = window.innerWidth - 24;
      const availH = window.innerHeight * 0.5;
      s.setZoom(Math.max(0.25, Math.min(availW / page.width, availH / page.height, 0.8)));
      s.setPan({ x: 0, y: 0 });
    }
  }, [route]);

  // Auto-fit when document page size / orientation changes (mobile)
  useEffect(() => {
    if (route !== 'editor') return;
    if (window.innerWidth < 1024) {
      const s = useEditor.getState();
      const page = getPagePx(s.document);
      const availW = window.innerWidth - 24;
      const availH = window.innerHeight * 0.5;
      s.setZoom(Math.max(0.25, Math.min(availW / page.width, availH / page.height, 0.8)));
    }
  }, [st.document.pageSize, st.document.orientation, st.document.customWidth, st.document.customHeight, route]);

  /* ---------- auto-save ---------- */
  useEffect(() => {
    if (route !== 'editor') return;
    autoSaveRef.current = window.setInterval(() => {
      if (useEditor.getState().dirty) {
        try { useEditor.getState().saveDocument(); toast('ذخیره خودکار انجام شد ✓', 'info'); } catch { /* ignore */ }
      }
    }, 60000);
    return () => { if (autoSaveRef.current) clearInterval(autoSaveRef.current); };
  }, [route, toast]);

  useEffect(() => {
    const before = (e: BeforeUnloadEvent) => {
      if (useEditor.getState().dirty) { try { useEditor.getState().saveDocument(); } catch { /* ignore */ } e.preventDefault(); }
    };
    window.addEventListener('beforeunload', before);
    return () => window.removeEventListener('beforeunload', before);
  }, []);

  /* ---------- keyboard shortcuts ---------- */
  useEffect(() => {
    if (route !== 'editor') return;
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
      const s = useEditor.getState();
      const mod = e.ctrlKey || e.metaKey;
      const step = e.shiftKey ? 10 : mod ? s.gridSize : 1;

      if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? s.redo() : s.undo(); return; }
      if (mod && e.key.toLowerCase() === 'c') { e.preventDefault(); s.copy(); return; }
      if (mod && e.key.toLowerCase() === 'v') { e.preventDefault(); s.paste(); toast('عنصر چسبانده شد ✓', 'info'); return; }
      if (mod && e.key.toLowerCase() === 'x') { e.preventDefault(); s.cut(); return; }
      if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); s.duplicateElement(); toast('عنصر کپی شد ✓', 'info'); return; }
      if (mod && e.key.toLowerCase() === 'a') { e.preventDefault(); s.selectAll(); return; }
      if (mod && e.key.toLowerCase() === 'g') { e.preventDefault(); e.shiftKey ? s.ungroupElements() : s.groupElements(); return; }
      if (mod && e.key.toLowerCase() === 'l') { e.preventDefault(); s.toggleLock(); return; }
      if (mod && e.key.toLowerCase() === 's') {
        e.preventDefault();
        try { s.saveDocument(); toast('سند ذخیره شد ✓'); } catch { toast('خطا در ذخیره‌سازی', 'error'); }
        return;
      }
      if (mod && e.key === '0') { e.preventDefault(); s.setZoom(0.75); s.setPan({ x: 0, y: 0 }); return; }
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (s.selectedElementIds.length) { e.preventDefault(); s.deleteElement(); toast('عنصر حذف شد', 'info'); }
        return;
      }
      if (e.key === 'Escape') { s.selectElement(null); return; }
      if (e.key === 'ArrowUp') { e.preventDefault(); s.nudge(0, -step); s.commit('جابجایی عنصر'); return; }
      if (e.key === 'ArrowDown') { e.preventDefault(); s.nudge(0, step); s.commit('جابجایی عنصر'); return; }
      if (e.key === 'ArrowRight') { e.preventDefault(); s.nudge(step, 0); s.commit('جابجایی عنصر'); return; }
      if (e.key === 'ArrowLeft') { e.preventDefault(); s.nudge(-step, 0); s.commit('جابجایی عنصر'); return; }
      if (e.key === '+' || e.key === '=') { s.setZoom(s.zoom + 0.1); return; }
      if (e.key === '-') { s.setZoom(s.zoom - 0.1); return; }
      if (e.key.toLowerCase() === 'g') { s.toggleGrid(); return; }
      if (e.key.toLowerCase() === 's') { s.toggleSnapGrid(); return; }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [route, toast]);

  /* ---------- element added → open sheet on mobile ---------- */
  const onElementAdded = () => {
    if (window.innerWidth < 1024) setSheet('half');
  };

  if (booting) return <BootScreen />;

  if (route === 'home') {
    return <HomePage onOpen={() => setRoute('editor')} toast={toast} />;
  }

  return (
    <div className="h-screen flex flex-col bg-slate-100 dark:bg-slate-950 overflow-hidden">
      <Toolbar
        onToggleLeft={() => (window.innerWidth < 1024 ? setSheet(s => (s === 'closed' ? 'half' : 'closed')) : setLeftOpen(o => !o))}
        onToggleRight={() => (window.innerWidth < 1024 ? setSheet(s => (s === 'closed' ? 'half' : 'closed')) : setRightOpen(o => !o))}
        onPrintPreview={() => setPrinting(true)}
        onHome={() => { st.refreshDocuments(); setRoute('home'); }}
        toast={toast}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Left panel (desktop) */}
        {leftOpen && (
          <aside className="hidden lg:block w-60 shrink-0 editor-sidebar animate-slide-in-right">
            <LeftPanel />
          </aside>
        )}

        <Canvas onOpenProps={() => setSheet('half')} />

        {/* Right panel (desktop) */}
        {rightOpen && (
          <aside className="hidden lg:block w-80 shrink-0 border-r border-slate-200 dark:border-slate-800 editor-panel animate-slide-in-left">
            <PropertiesPanel />
          </aside>
        )}
      </div>

      {/* Status bar */}
      <StatusBar />

      {/* Mobile tools strip: full panel with tabs (elements / layers / templates) */}
      <div className="lg:hidden shrink-0 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 editor-sidebar">
        <div className="h-[168px] overflow-hidden">
          <LeftPanel onAdded={onElementAdded} />
        </div>
      </div>

      {/* Mobile floating element controls */}
      {st.selectedElementId && !st.previewMode && <MobileElementBar onProps={() => setSheet('full')} />}

      {/* Mobile bottom sheet */}
      <BottomSheet state={sheet} setState={setSheet} />

      {/* Toasts */}
      <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[200] space-y-2 pointer-events-none w-[92%] max-w-sm">
        {toasts.map(t => (
          <div key={t.id} className={cx(
            'px-4 py-2.5 rounded-xl text-white text-[12px] font-bold shadow-2xl animate-slide-up flex items-center gap-2',
            t.type === 'success' ? 'bg-emerald-600' : t.type === 'error' ? 'bg-rose-600' : 'bg-slate-800'
          )}>
            {t.type === 'success' && <Check className="w-4 h-4" />}
            {t.type === 'error' && <X className="w-4 h-4" />}
            {t.msg}
          </div>
        ))}
      </div>

      {printing && <PrintPreview onClose={() => setPrinting(false)} />}
    </div>
  );
}

/* ================= Boot ================= */
function BootScreen() {
  return (
    <div className="h-screen flex flex-col items-center justify-center gap-6 bg-gradient-to-b from-teal-600 to-emerald-800">
      <div className="relative w-24 h-24 flex items-center justify-center">
        <div className="absolute inset-0 rounded-full border-2 border-white/20" />
        <div className="absolute inset-0 animate-orbit"><span className="absolute top-0 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-white" /></div>
        <div className="w-16 h-16 rounded-2xl bg-white/15 backdrop-blur border border-white/25 flex items-center justify-center animate-breathe">
          <Boxes className="w-8 h-8 text-white" />
        </div>
      </div>
      <div className="text-center">
        <h1 className="text-white font-extrabold text-lg">ویرایشگر قالب حرفه‌ای</h1>
        <p className="text-white/70 text-xs mt-1">در حال آماده‌سازی محیط طراحی…</p>
      </div>
    </div>
  );
}

/* ================= Home / document list ================= */
function HomePage({ onOpen, toast }: { onOpen: () => void; toast: (m: string, t?: 'success' | 'error' | 'info') => void }) {
  const st = useEditor();
  const [creating, setCreating] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => { st.refreshDocuments(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const createNew = (type: DocumentType, pageSize: PageSize, templateId?: string) => {
    st.newDocument({ ...blankDocument(), type, pageSize, name: templateId ? TEMPLATES.find(t => t.id === templateId)?.name ?? 'سند جدید' : 'سند بدون عنوان' });
    if (templateId) {
      const tpl = TEMPLATES.find(t => t.id === templateId);
      if (tpl) st.loadTemplate(tpl.doc, tpl.build());
    }
    setCreating(false);
    onOpen();
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
      <header className="app-bar sticky top-0 z-20 border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center gap-3">
          <a href="#/dashboard" className="h-9 w-9 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 active:scale-90 transition-transform shrink-0" title="بازگشت به پنل مدیریت">
            <ArrowRight className="w-4 h-4" />
          </a>
          <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white flex items-center justify-center font-black shrink-0">و</span>
          <div className="min-w-0">
            <h1 className="text-sm font-extrabold text-slate-800 dark:text-slate-100 truncate">ویرایشگر قالب حرفه‌ای</h1>
            <p className="text-[10px] text-slate-500 truncate">طراحی فاکتور، فرم ماموریت، سفارش و اسناد حسابداری</p>
          </div>
          <div className="flex-1" />
          <button onClick={() => fileRef.current?.click()}
            className="h-9 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-[12px] font-bold flex items-center gap-1.5 active:scale-95 transition-transform">
            <Import className="w-4 h-4" />ورودی
          </button>
          <button onClick={() => setCreating(true)}
            className="h-9 px-3 rounded-xl bg-teal-600 text-white text-[12px] font-bold flex items-center gap-1.5 shadow-lg shadow-teal-500/25 active:scale-95 transition-transform">
            <FilePlus2 className="w-4 h-4" />سند جدید
          </button>
          <input ref={fileRef} type="file" accept="application/json" hidden onChange={e => {
            const f = e.target.files?.[0]; if (!f) return;
            const r = new FileReader();
            r.onload = () => {
              const ok = st.importFromJSON(String(r.result));
              if (ok) { toast('سند بارگذاری شد ✓'); onOpen(); } else toast('فایل JSON نامعتبر است', 'error');
            };
            r.readAsText(f); e.target.value = '';
          }} />
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Templates */}
        <section>
          <h2 className="text-[13px] font-bold text-slate-700 dark:text-slate-200 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-teal-600" />شروع سریع با قالب آماده
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {TEMPLATES.map(t => (
              <button key={t.id} onClick={() => createNew(t.doc.type ?? 'custom', t.doc.pageSize ?? 'A4', t.id)}
                className="group text-right rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden hover:border-teal-400 hover:shadow-lg transition-all active:scale-95">
                <div className="h-24 bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-900 flex items-center justify-center">
                  <div className="w-12 h-16 bg-white dark:bg-slate-700 rounded shadow border border-slate-200 dark:border-slate-600 p-1 space-y-0.5 group-hover:scale-105 transition-transform">
                    <div className="h-1 bg-teal-500/70 rounded-full w-2/3" />
                    <div className="h-0.5 bg-slate-300 rounded-full" />
                    <div className="h-0.5 bg-slate-300 rounded-full w-4/5" />
                    <div className="h-4 bg-slate-200 dark:bg-slate-600 rounded-sm mt-1" />
                  </div>
                </div>
                <div className="p-2">
                  <p className="text-[12px] font-bold text-slate-800 dark:text-slate-100">{t.name}</p>
                  <p className="text-[10px] text-slate-500 line-clamp-2 leading-4 mt-0.5">{t.description}</p>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Saved documents */}
        <section>
          <h2 className="text-[13px] font-bold text-slate-700 dark:text-slate-200 mb-2 flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-teal-600" />اسناد من
            <span className="text-[10px] text-slate-400 font-normal">({fa(st.documents.length)})</span>
          </h2>
          {st.documents.length === 0 ? (
            <div className="rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 py-14 text-center">
              <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-[13px] font-bold text-slate-500">هنوز سندی نساخته‌اید</p>
              <p className="text-[11px] text-slate-400 mt-1 mb-3">یک قالب آماده انتخاب کنید یا سند خالی بسازید</p>
              <button onClick={() => setCreating(true)} className="px-4 py-2 rounded-xl bg-teal-600 text-white text-[12px] font-bold">➕ سند جدید</button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {st.documents.map(d => (
                <div key={d.id} className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="h-28 bg-gradient-to-br from-teal-50 to-emerald-50 dark:from-slate-800 dark:to-slate-900 flex items-center justify-center">
                    <div className="w-14 h-20 bg-white dark:bg-slate-700 rounded shadow-md border border-slate-200 dark:border-slate-600 p-1.5 space-y-1">
                      <div className="h-1 bg-teal-500/70 rounded-full w-2/3" />
                      <div className="h-0.5 bg-slate-300 rounded-full" />
                      <div className="h-5 bg-slate-200 dark:bg-slate-600 rounded-sm" />
                      <div className="h-0.5 bg-slate-300 rounded-full w-1/2" />
                    </div>
                  </div>
                  <div className="p-2.5">
                    <p className="text-[12px] font-bold text-slate-800 dark:text-slate-100 truncate">{d.name}</p>
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      {DOC_TYPE_LABELS[d.type as DocumentType] ?? d.type} • {fa(d.elementCount)} عنصر
                    </p>
                    <div className="flex items-center gap-1 mt-2">
                      <button onClick={() => { st.loadDocument(d.id); onOpen(); }}
                        className="flex-1 py-1.5 rounded-lg bg-teal-600 text-white text-[11px] font-bold active:scale-95 transition-transform">
                        <Pencil className="w-3 h-3 inline ml-1" />ویرایش
                      </button>
                      <button title="خروجی JSON" onClick={() => {
                        const raw = localStorage.getItem(`editor_doc_${d.id}`);
                        if (raw) { download(`${d.name}.json`, raw); toast('فایل دانلود شد ✓'); }
                      }} className="w-8 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500">
                        <CopyIcon className="w-3.5 h-3.5" />
                      </button>
                      <button title="حذف" onClick={() => { if (confirm('این سند حذف شود؟')) { st.deleteDocument(d.id); toast('سند حذف شد', 'info'); } }}
                        className="w-8 h-7 rounded-lg bg-rose-50 dark:bg-rose-900/25 flex items-center justify-center text-rose-500">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      {creating && <NewDocDialog onClose={() => setCreating(false)} onCreate={createNew} />}
    </div>
  );
}

function NewDocDialog({ onClose, onCreate }: { onClose: () => void; onCreate: (t: DocumentType, p: PageSize) => void }) {
  const [type, setType] = useState<DocumentType>('invoice');
  const [size, setSize] = useState<PageSize>('A4');
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-t-[28px] sm:rounded-3xl p-5 animate-sheet-up">
        <div className="sm:hidden w-10 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 mx-auto mb-4" />
        <h3 className="text-base font-extrabold mb-4">ایجاد سند جدید</h3>
        <p className="text-[11px] font-bold text-slate-500 mb-1.5">نوع سند</p>
        <div className="grid grid-cols-3 gap-1.5 mb-4">
          {(Object.keys(DOC_TYPE_LABELS) as DocumentType[]).map(k => (
            <button key={k} onClick={() => setType(k)}
              className={cx('py-2 rounded-xl text-[11px] font-bold border transition-all',
                type === k ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300')}>
              {DOC_TYPE_LABELS[k]}
            </button>
          ))}
        </div>
        <p className="text-[11px] font-bold text-slate-500 mb-1.5">اندازه صفحه</p>
        <div className="grid grid-cols-4 gap-1.5 mb-5">
          {(['A4', 'A5', 'A3', 'Letter'] as PageSize[]).map(s => (
            <button key={s} onClick={() => setSize(s)}
              className={cx('py-2 rounded-xl text-[11px] font-bold border transition-all',
                size === s ? 'bg-teal-600 text-white border-teal-600' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300')}>
              {s}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-[12px] font-bold">انصراف</button>
          <button onClick={() => onCreate(type, size)} className="flex-1 py-2.5 rounded-xl bg-teal-600 text-white text-[12px] font-bold">ایجاد سند</button>
        </div>
      </div>
    </div>
  );
}

/* ================= Status bar ================= */
function StatusBar() {
  const st = useEditor();
  const el = st.elements.find(e => e.id === st.selectedElementId);
  const r = el ? resolveRect(el, st.breakpoint) : null;
  const page = getPagePx(st.document);
  return (
    <div className="hidden md:flex shrink-0 items-center gap-3 h-7 px-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 text-[10px] text-slate-500 editor-panel">
      <span>{st.document.pageSize} • {st.document.orientation === 'portrait' ? 'عمودی' : 'افقی'} • {fa(page.width)}×{fa(page.height)}px</span>
      <span className="w-px h-3 bg-slate-200 dark:bg-slate-700" />
      <span>{fa(st.elements.length)} عنصر</span>
      {r && (
        <>
          <span className="w-px h-3 bg-slate-200 dark:bg-slate-700" />
          <span className="text-teal-600 font-bold">{el?.label}</span>
          <span>X: {fa(Math.round(r.x))} • Y: {fa(Math.round(r.y))} • {fa(Math.round(r.width))}×{fa(Math.round(r.height))}</span>
        </>
      )}
      <div className="flex-1" />
      <span>{st.snapToGrid ? '⊹ اسنپ شبکه' : ''} {st.snapToObject ? '🧲 اسنپ عناصر' : ''}</span>
      <span className="w-px h-3 bg-slate-200 dark:bg-slate-700" />
      {st.dirty
        ? <span className="text-amber-600">● تغییرات ذخیره نشده</span>
        : st.savedAt ? <span className="text-emerald-600">✓ ذخیره شد {new Date(st.savedAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}</span> : null}
    </div>
  );
}

/* ================= Mobile element bar ================= */
function MobileElementBar({ onProps }: { onProps: () => void }) {
  const st = useEditor();
  const [step, setStep] = useState(1);
  const id = st.selectedElementId!;
  const btn = 'w-10 h-10 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center active:scale-90 transition-transform shadow-sm';
  return (
    <div className="lg:hidden fixed bottom-[116px] left-1/2 -translate-x-1/2 z-40 flex items-center gap-1 p-1.5 rounded-2xl bg-white/95 dark:bg-slate-900/95 backdrop-blur border border-slate-200 dark:border-slate-700 shadow-2xl">
      <button className={btn} onClick={() => { st.nudge(0, -step); st.commit('جابجایی'); }}>↑</button>
      <button className={btn} onClick={() => { st.nudge(0, step); st.commit('جابجایی'); }}>↓</button>
      <button className={btn} onClick={() => { st.nudge(step, 0); st.commit('جابجایی'); }}>→</button>
      <button className={btn} onClick={() => { st.nudge(-step, 0); st.commit('جابجایی'); }}>←</button>
      <button onClick={() => setStep(s => (s === 1 ? 5 : s === 5 ? 10 : 1))}
        className="w-10 h-10 rounded-xl bg-teal-600 text-white text-[10px] font-bold">{fa(step)}px</button>
      <span className="w-px h-6 bg-slate-200 dark:bg-slate-700" />
      <button className={btn} onClick={() => st.duplicateElement(id)}><CopyIcon className="w-4 h-4" /></button>
      <button className={btn + ' text-rose-500'} onClick={() => st.deleteElement(id)}><Trash2 className="w-4 h-4" /></button>
      <button className="w-10 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center active:scale-90" onClick={onProps}>
        <Settings2 className="w-4 h-4" />
      </button>
    </div>
  );
}

/* ================= Bottom sheet ================= */
function BottomSheet({ state, setState }: { state: Sheet; setState: (s: Sheet) => void }) {
  const st = useEditor();
  const el = st.elements.find(e => e.id === st.selectedElementId);
  if (state === 'closed') return null;
  const height = state === 'full' ? '92vh' : '52vh';
  return (
    <div className="lg:hidden fixed inset-0 z-50 flex flex-col justify-end pointer-events-none">
      {/* No dark/blur backdrop — the canvas stays fully visible for live preview */}
      <div className="relative pointer-events-auto bg-white dark:bg-slate-900 rounded-t-[28px] shadow-2xl border-t border-slate-200 dark:border-slate-700 flex flex-col animate-sheet-up safe-bottom"
        style={{ height, transition: 'height 280ms cubic-bezier(0.22,1,0.36,1)', boxShadow: '0 -8px 40px rgba(0,0,0,0.25)' }}>
        {/* drag handle / toggle */}
        <button className="w-full pt-2.5 pb-1 shrink-0" onClick={() => setState(state === 'half' ? 'full' : 'half')}>
          <div className="w-10 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700 mx-auto" />
        </button>
        <div className="flex items-center justify-between px-4 pb-1.5 shrink-0">
          <p className="text-[12px] font-bold text-slate-700 dark:text-slate-200">
            {el ? `تنظیمات: ${el.label}` : 'تنظیمات سند'}
            {el && <span className="mr-1.5 text-[9px] px-1.5 py-0.5 rounded bg-teal-50 dark:bg-teal-900/30 text-teal-700 dark:text-teal-300">{el.type}</span>}
          </p>
          <div className="flex items-center gap-1">
            <button onClick={() => setState(state === 'half' ? 'full' : 'half')}
              className="px-2 py-1 rounded-lg text-[10px] text-teal-600 bg-teal-50 dark:bg-teal-900/25 font-bold">
              {state === 'half' ? 'تمام‌صفحه' : 'نیمه'}
            </button>
            <button onClick={() => setState('closed')} className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center active:scale-90 transition-transform">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
        <div className="flex-1 overflow-hidden border-t border-slate-100 dark:border-slate-800">
          <PropertiesPanel />
        </div>
      </div>
    </div>
  );
}

/* ================= Print preview ================= */
function PrintPreview({ onClose }: { onClose: () => void }) {
  const st = useEditor();
  const page = getPagePx(st.document);
  const sorted = [...st.elements].sort((a, b) => a.zIndex - b.zIndex);
  return (
    <div className="fixed inset-0 z-[300] bg-slate-800/95 overflow-auto print:bg-white print:static">
      <div className="sticky top-0 flex items-center justify-center gap-2 p-3 bg-slate-900/90 backdrop-blur no-print z-10">
        <button onClick={() => window.print()} className="px-4 py-2 rounded-xl bg-teal-600 text-white text-[12px] font-bold flex items-center gap-1.5">
          <Printer className="w-4 h-4" />چاپ / ذخیره PDF
        </button>
        <button onClick={onClose} className="px-4 py-2 rounded-xl bg-white/10 text-white text-[12px] font-bold flex items-center gap-1.5">
          <X className="w-4 h-4" />بستن
        </button>
      </div>
      <div className="flex justify-center p-6 print:p-0">
        <div id="print-area" className="relative bg-white shadow-2xl print:shadow-none"
          style={{
            width: page.width, height: page.height,
            background: st.document.backgroundColor,
            border: st.document.showBorder ? `${st.document.borderWidth}px ${st.document.borderStyle} ${st.document.borderColor}` : undefined,
          }}>
          {sorted.map(el => {
            const r = resolveRect(el, st.breakpoint);
            if (r.hidden) return null;
            return (
              <div key={el.id} className="absolute"
                style={{ left: r.x, top: r.y, width: r.width, height: r.height, zIndex: el.zIndex, transform: el.rotation ? `rotate(${el.rotation}deg)` : undefined }}>
                <ElementRenderer el={el} print />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
