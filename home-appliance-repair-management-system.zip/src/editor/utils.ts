import type {
  DocumentConfig, EditorElement, ElementStyle, ElementType,
  GuideLine, PageSize, Orientation, Breakpoint,
} from './types';
import { MM_TO_PX, PAGE_SIZES_MM, ELEMENT_LABELS } from './types';

/* ---------------- Persian helpers ---------------- */
const FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export const fa = (v: string | number | null | undefined): string => {
  if (v === null || v === undefined) return '';
  return String(v).replace(/\d/g, d => FA_DIGITS[+d]);
};

export const toEn = (v: string): string =>
  v.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
   .replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));

export const faNum = (n: number, decimals = 0): string =>
  fa(n.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals }));

export function uuid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

/* ---------------- Number → Persian words ---------------- */
const ONES = ['', 'یک', 'دو', 'سه', 'چهار', 'پنج', 'شش', 'هفت', 'هشت', 'نه'];
const TEENS = ['ده', 'یازده', 'دوازده', 'سیزده', 'چهارده', 'پانزده', 'شانزده', 'هفده', 'هجده', 'نوزده'];
const TENS = ['', '', 'بیست', 'سی', 'چهل', 'پنجاه', 'شصت', 'هفتاد', 'هشتاد', 'نود'];
const HUNDREDS = ['', 'صد', 'دویست', 'سیصد', 'چهارصد', 'پانصد', 'ششصد', 'هفتصد', 'هشتصد', 'نهصد'];
const SCALES = ['', ' هزار', ' میلیون', ' میلیارد', ' بیلیون'];

function threeDigitToWords(n: number): string {
  const parts: string[] = [];
  const h = Math.floor(n / 100);
  const rest = n % 100;
  if (h) parts.push(HUNDREDS[h]);
  if (rest >= 10 && rest < 20) parts.push(TEENS[rest - 10]);
  else {
    const t = Math.floor(rest / 10);
    const o = rest % 10;
    if (t) parts.push(TENS[t]);
    if (o) parts.push(ONES[o]);
  }
  return parts.join(' و ');
}

export function numberToPersianWords(num: number): string {
  if (!isFinite(num)) return '';
  if (num === 0) return 'صفر';
  const negative = num < 0;
  let n = Math.floor(Math.abs(num));
  const groups: number[] = [];
  while (n > 0) { groups.push(n % 1000); n = Math.floor(n / 1000); }
  const words: string[] = [];
  for (let i = groups.length - 1; i >= 0; i--) {
    if (groups[i] === 0) continue;
    words.push(threeDigitToWords(groups[i]) + SCALES[i]);
  }
  return (negative ? 'منفی ' : '') + words.join(' و ');
}

/* ---------------- Page geometry ---------------- */
export function getPagePx(doc: DocumentConfig): { width: number; height: number } {
  let w: number, h: number;
  if (doc.pageSize === 'custom') { w = doc.customWidth; h = doc.customHeight; }
  else { const s = PAGE_SIZES_MM[doc.pageSize]; w = s.w; h = s.h; }
  if (doc.orientation === 'landscape') [w, h] = [h, w];
  return { width: Math.round(w * MM_TO_PX), height: Math.round(h * MM_TO_PX) };
}

export const mmToPx = (mm: number) => mm * MM_TO_PX;
export const pxToMm = (px: number) => px / MM_TO_PX;

export function pageLabel(size: PageSize, o: Orientation): string {
  const or = o === 'portrait' ? 'عمودی' : 'افقی';
  return size === 'custom' ? `سفارشی (${or})` : `${size} ${or}`;
}

/* ---------------- Bounds & snapping ---------------- */
export interface Bounds {
  left: number; right: number; top: number; bottom: number;
  centerX: number; centerY: number; width: number; height: number;
}

export const getBounds = (e: { x: number; y: number; width: number; height: number }): Bounds => ({
  left: e.x, right: e.x + e.width, top: e.y, bottom: e.y + e.height,
  centerX: e.x + e.width / 2, centerY: e.y + e.height / 2,
  width: e.width, height: e.height,
});

export const snapValue = (v: number, grid: number) => Math.round(v / grid) * grid;

const EDGE_COLOR = '#FF1493';
const CENTER_COLOR = '#00BFFF';
const SPACING_COLOR = '#8B5CF6';

export interface SnapResult { x: number; y: number; guides: GuideLine[] }

/**
 * Snap a moving rect against grid, other elements and page geometry.
 * Returns adjusted x/y plus the guide lines that should be rendered.
 */
export function computeMoveSnap(
  rect: { x: number; y: number; width: number; height: number },
  others: EditorElement[],
  page: { width: number; height: number },
  margins: { top: number; right: number; bottom: number; left: number },
  opts: { snapToGrid: boolean; snapToObject: boolean; gridSize: number; threshold: number }
): SnapResult {
  let { x, y } = rect;
  const guides: GuideLine[] = [];

  if (opts.snapToGrid) {
    x = snapValue(x, opts.gridSize);
    y = snapValue(y, opts.gridSize);
  }

  if (!opts.snapToObject) return { x, y, guides };

  const w = rect.width, h = rect.height;
  const t = opts.threshold;

  const ml = mmToPx(margins.left), mr = mmToPx(margins.right);
  const mt = mmToPx(margins.top), mb = mmToPx(margins.bottom);

  // candidate vertical lines: [linePosition, alignOffsetWithinRect]
  const vCandidates: { pos: number; off: number; color: string }[] = [];
  const hCandidates: { pos: number; off: number; color: string }[] = [];

  const pushV = (pos: number, color: string) => {
    vCandidates.push({ pos, off: 0, color });
    vCandidates.push({ pos, off: w / 2, color });
    vCandidates.push({ pos, off: w, color });
  };
  const pushH = (pos: number, color: string) => {
    hCandidates.push({ pos, off: 0, color });
    hCandidates.push({ pos, off: h / 2, color });
    hCandidates.push({ pos, off: h, color });
  };

  // page guides
  pushV(ml, EDGE_COLOR);
  pushV(page.width - mr, EDGE_COLOR);
  pushV(page.width / 2, CENTER_COLOR);
  pushH(mt, EDGE_COLOR);
  pushH(page.height - mb, EDGE_COLOR);
  pushH(page.height / 2, CENTER_COLOR);

  // element guides
  for (const el of others) {
    const b = getBounds(el);
    pushV(b.left, EDGE_COLOR);
    pushV(b.right, EDGE_COLOR);
    pushV(b.centerX, CENTER_COLOR);
    pushH(b.top, EDGE_COLOR);
    pushH(b.bottom, EDGE_COLOR);
    pushH(b.centerY, CENTER_COLOR);
  }

  // pick best vertical
  let bestV: { pos: number; delta: number; color: string } | null = null;
  for (const c of vCandidates) {
    const target = c.pos - c.off;
    const d = Math.abs(target - x);
    if (d <= t && (!bestV || d < Math.abs(bestV.delta))) bestV = { pos: c.pos, delta: target - x, color: c.color };
  }
  if (bestV) { x += bestV.delta; guides.push({ type: 'vertical', position: bestV.pos, color: bestV.color }); }

  let bestH: { pos: number; delta: number; color: string } | null = null;
  for (const c of hCandidates) {
    const target = c.pos - c.off;
    const d = Math.abs(target - y);
    if (d <= t && (!bestH || d < Math.abs(bestH.delta))) bestH = { pos: c.pos, delta: target - y, color: c.color };
  }
  if (bestH) { y += bestH.delta; guides.push({ type: 'horizontal', position: bestH.pos, color: bestH.color }); }

  // equal-spacing detection (horizontal neighbours on the same row band)
  const moved = getBounds({ x, y, width: w, height: h });
  const rowMates = others.filter(o => {
    const b = getBounds(o);
    return b.top < moved.bottom && b.bottom > moved.top;
  }).sort((a, b) => a.x - b.x);
  if (rowMates.length >= 2) {
    for (let i = 0; i < rowMates.length - 1; i++) {
      const a = getBounds(rowMates[i]);
      const b = getBounds(rowMates[i + 1]);
      const gap = b.left - a.right;
      if (gap <= 0) continue;
      // gap to the right of moved element matching existing gap
      const gapAfter = rowMates.find(o => getBounds(o).left >= moved.right);
      if (gapAfter) {
        const g2 = getBounds(gapAfter).left - moved.right;
        if (Math.abs(g2 - gap) <= t) {
          guides.push({
            type: 'vertical', position: moved.right + gap, color: SPACING_COLOR,
            label: `${fa(Math.round(gap))} px`,
          });
        }
      }
    }
  }

  return { x, y, guides };
}

/* ---------------- Element factory ---------------- */
export function defaultStyle(overrides: Partial<ElementStyle> = {}): ElementStyle {
  return {
    fontFamily: 'Vazirmatn',
    fontSize: 13,
    fontWeight: 'normal',
    fontStyle: 'normal',
    textAlign: 'right',
    textDecoration: 'none',
    lineHeight: 1.7,
    letterSpacing: 0,
    color: '#0f172a',
    backgroundColor: 'transparent',
    backgroundOpacity: 100,
    borderWidth: 0,
    borderColor: '#cbd5e1',
    borderStyle: 'none',
    borderRadius: 6,
    borderTop: true, borderRight: true, borderBottom: true, borderLeft: true,
    paddingTop: 4, paddingRight: 8, paddingBottom: 4, paddingLeft: 8,
    marginTop: 0, marginRight: 0, marginBottom: 0, marginLeft: 0,
    shadowEnabled: false,
    shadowX: 0, shadowY: 2, shadowBlur: 8, shadowSpread: 0, shadowColor: 'rgba(15,23,42,0.15)',
    innerShadowEnabled: false,
    innerShadowX: 0, innerShadowY: 3, innerShadowBlur: 10, innerShadowSpread: 0, innerShadowColor: 'rgba(15,23,42,0.25)',
    strokeEnabled: false,
    strokeWidth: 1,
    strokeColor: '#0f172a',
    strokeTextOnly: false,
    effect: 'none',
    gradFrom: '#0d9488',
    gradTo: '#3b82f6',
    gradAngle: 135,
    gradType: 'linear',
    glassBlur: 10,
    textEffect: 'none',
    filterBlur: 0,
    filterBrightness: 100,
    filterContrast: 100,
    filterSaturate: 100,
    filterGrayscale: 0,
    filterHueRotate: 0,
    opacity: 100,
    ...overrides,
  };
}

const INPUT_STYLE = defaultStyle({
  borderStyle: 'solid', borderWidth: 1, borderColor: '#cbd5e1',
  backgroundColor: '#ffffff', paddingTop: 6, paddingBottom: 6,
});

interface Preset { width: number; height: number; style?: Partial<ElementStyle>; properties?: EditorElement['properties'] }

const PRESETS: Partial<Record<ElementType, Preset>> = {
  heading: { width: 260, height: 40, style: { fontSize: 20, fontWeight: 'bold' }, properties: { content: 'عنوان سند', isEditable: false } },
  text: { width: 160, height: 28, properties: { content: 'متن نمونه', isEditable: false } },
  paragraph: { width: 280, height: 80, style: { fontSize: 12 }, properties: { content: 'این یک پاراگراف نمونه است. متن مورد نظر خود را از پنل تنظیمات وارد کنید.', isEditable: false } },
  'text-input': { width: 200, height: 38 },
  textarea: { width: 260, height: 80 },
  'number-input': { width: 150, height: 38 },
  'currency-input': { width: 180, height: 38 },
  'date-input': { width: 160, height: 38 },
  select: { width: 180, height: 38 },
  checkbox: { width: 160, height: 32 },
  'radio-group': { width: 220, height: 70 },
  switch: { width: 160, height: 34 },
  container: { width: 300, height: 140, style: { borderStyle: 'dashed', borderWidth: 1, borderColor: '#94a3b8' } },
  row: { width: 320, height: 60, style: { borderStyle: 'dashed', borderWidth: 1, borderColor: '#94a3b8' } },
  column: { width: 140, height: 200, style: { borderStyle: 'dashed', borderWidth: 1, borderColor: '#94a3b8' } },
  divider: { width: 320, height: 2 },
  spacer: { width: 120, height: 40 },
  image: { width: 130, height: 130 },
  'image-upload': { width: 130, height: 130 },
  'qr-code': { width: 96, height: 96 },
  barcode: { width: 180, height: 60 },
  table: { width: 500, height: 150 },
  'dynamic-table': { width: 640, height: 200 },
  signature: { width: 180, height: 90 },
  stamp: { width: 120, height: 120 },
  watermark: { width: 300, height: 80, style: { fontSize: 42, color: '#94a3b8', opacity: 18, textAlign: 'center' } },
  'page-number': { width: 110, height: 28, style: { textAlign: 'center', fontSize: 11 } },
  formula: { width: 190, height: 36, style: { textAlign: 'left', fontWeight: 'bold' } },
  'amount-words': { width: 380, height: 40, style: { fontSize: 12 } },
  'auto-number': { width: 160, height: 34 },
  icon: { width: 44, height: 44, properties: { content: 'star' } },
  badge: { width: 120, height: 32, style: { backgroundColor: '#0d9488', color: '#ffffff', borderRadius: 999, textAlign: 'center', fontSize: 11, fontWeight: 'bold' }, properties: { content: 'جدید' } },
  'shape-circle': { width: 90, height: 90, style: { backgroundColor: '#0d9488', borderRadius: 999 } },
  kv: { width: 220, height: 28, properties: { content: 'مبلغ', fieldName: 'customer.fullName' } },
  pill: { width: 110, height: 30, style: { backgroundColor: '#fef3c7', color: '#b45309', borderRadius: 999, textAlign: 'center', fontSize: 11, fontWeight: 'medium' }, properties: { content: 'یادداشت' } },
  timeline: { width: 480, height: 60, properties: { timelineSteps: [{ title: 'پذیرش', done: true }, { title: 'عیب‌یابی', done: true }, { title: 'تأمین قطعه', done: false }, { title: 'تست نهایی', done: false }] } },
  rating: { width: 150, height: 36, properties: { ratingValue: 5, maxRating: 5, ratingIcon: 'star' } },
  checklist: { width: 240, height: 110, style: { borderStyle: 'solid', borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 8 }, properties: { checklistItems: [{ text: 'کابل و دوشاخه تست شد', checked: true }, { text: 'بدنه فاقد شکستگی', checked: true }, { text: 'تست نشتی آب/گاز انجام شد', checked: true }] } },
  'stat-box': { width: 160, height: 80, style: { borderStyle: 'solid', borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 12, backgroundColor: '#f8fafc' }, properties: { statNumber: '۱۰۰٪', statLabel: 'تست فنی موفق', statBadge: 'تضمین کیفیت' } },
  'dual-signature': { width: 440, height: 100, style: { borderStyle: 'dashed', borderWidth: 1, borderColor: '#cbd5e1', borderRadius: 8 }, properties: { leftSignLabel: 'امضای مشتری / تحویل‌گیرنده', rightSignLabel: 'مهر و امضای سرویسکار / تعمیرگاه' } },
  'seal-badge': { width: 100, height: 100, properties: { sealText: 'تضمین اصالت قطعات', sealColor: 'gold' } },
  'notes-box': { width: 400, height: 75, style: { borderStyle: 'solid', borderWidth: 1, borderColor: '#f59e0b', borderRadius: 10, backgroundColor: '#fffbeb' }, properties: { noteType: 'warning', content: 'توجه: خدمات و قطعات مصرفی تا ۶ ماه تحت پوشش گارانتی همیار سرویس اتحاد می‌باشد.' } },
  'device-specs': { width: 420, height: 85, style: { borderStyle: 'solid', borderWidth: 1, borderColor: '#cbd5e1', borderRadius: 8 }, properties: { content: 'شناسنامه فنی دستگاه' } },
  'price-tag': { width: 170, height: 42, style: { borderStyle: 'solid', borderWidth: 1, borderColor: '#10b981', borderRadius: 10, backgroundColor: '#ecfdf5', color: '#065f46', textAlign: 'center', fontWeight: 'bold' }, properties: { priceAmount: '۷۵۰,۰۰۰', priceCurrency: 'تومان' } },
};

function defaultProps(type: ElementType): EditorElement['properties'] {
  const validation = { type: 'none' as const, pattern: '', minLength: 0, maxLength: 0, min: 0, max: 0, errorMessage: '' };
  const base = PRESETS[type]?.properties ?? {};
  switch (type) {
    case 'text-input': case 'textarea':
      return { placeholder: 'متن را وارد کنید', defaultValue: '', required: false, readOnly: false, fieldName: `field_${Math.floor(Math.random() * 900 + 100)}`, validation, ...base };
    case 'number-input':
      return { placeholder: '۰', defaultValue: '', fieldName: 'number_field', step: 1, suffix: 'عدد', thousandSeparator: false, required: false, readOnly: false, validation, ...base };
    case 'currency-input':
      return { placeholder: '۰', defaultValue: '', fieldName: 'amount', step: 1000, suffix: 'تومان', thousandSeparator: true, required: false, readOnly: false, validation, ...base };
    case 'date-input':
      return { placeholder: '۱۴۰۴/۰۱/۰۱', fieldName: 'date', dateFormat: 'YYYY/MM/DD', required: false, readOnly: false, validation, ...base };
    case 'select':
      return { placeholder: 'انتخاب کنید', fieldName: 'select_field', options: [{ label: 'گزینه یک', value: '1' }, { label: 'گزینه دو', value: '2' }], validation, ...base };
    case 'radio-group':
      return { fieldName: 'radio_field', optionsLayout: 'vertical', options: [{ label: 'گزینه یک', value: '1' }, { label: 'گزینه دو', value: '2' }], validation, ...base };
    case 'checkbox':
      return { content: 'موافقم', fieldName: 'checkbox_field', validation, ...base };
    case 'switch':
      return { content: 'فعال باشد', fieldName: 'switch_field', validation, ...base };
    case 'table': case 'dynamic-table':
      return {
        columns: [
          { id: uuid(), header: 'ردیف', width: 10, align: 'center', type: 'text', editable: false },
          { id: uuid(), header: 'شرح', width: 45, align: 'right', type: 'text', editable: true },
          { id: uuid(), header: 'تعداد', width: 15, align: 'center', type: 'number', editable: true },
          { id: uuid(), header: 'مبلغ', width: 30, align: 'left', type: 'currency', editable: true },
        ],
        rows: 3, dynamicRows: type === 'dynamic-table', showRowNumbers: true,
        showHeader: true, showFooter: type === 'dynamic-table', zebraStripes: true,
        headerBg: '#0f766e', headerColor: '#ffffff', altRowBg: '#f1f5f9',
        cellPadding: 'normal', tableBorder: 'solid', ...base,
      };
    case 'image': case 'image-upload':
      return { src: '', alt: 'تصویر', fit: 'contain', ...base };
    case 'qr-code':
      return { value: 'https://example.com', ...base };
    case 'barcode':
      return { value: '1234567890', ...base };
    case 'formula':
      return { formula: '{quantity} * {price}', sourceFields: [], format: 'currency', decimalPlaces: 0, prefix: '', suffix: 'تومان', fieldName: 'total', ...base };
    case 'amount-words':
      return { formula: '{total}', prefix: 'مبلغ به حروف: ', suffix: 'تومان', content: '1250000', ...base };
    case 'auto-number':
      return { numberPrefix: 'INV-', startFrom: 1001, fieldName: 'doc_number', ...base };
    case 'container': case 'row': case 'column':
      return { direction: type === 'column' ? 'column' : 'row', gap: 8, alignItems: 'stretch', justifyContent: 'start', wrap: false, childIds: [], ...base };
    case 'divider':
      return { orientation: 'horizontal', ...base };
    case 'signature':
      return { content: 'محل امضا', ...base };
    case 'stamp':
      return { content: 'محل مهر', ...base };
    case 'watermark':
      return { content: 'نمونه', ...base };
    case 'page-number':
      return { content: 'صفحه {page} از {total}', ...base };
    case 'icon':
      return { content: 'star', ...base };
    case 'badge':
    case 'pill':
      return { content: 'برچسب', ...base };
    case 'kv':
      return { content: 'کلید', fieldName: 'customer.fullName', ...base };
    case 'shape-circle':
      return { ...base };
    case 'timeline':
      return { timelineSteps: [{ title: 'پذیرش', done: true }, { title: 'عیب‌یابی', done: true }, { title: 'تعمیر', done: false }, { title: 'تحویل', done: false }], ...base };
    case 'rating':
      return { ratingValue: 5, maxRating: 5, ratingIcon: 'star', ...base };
    case 'checklist':
      return { checklistItems: [{ text: 'تست اولیه برق', checked: true }, { text: 'بدنه سالم', checked: true }, { text: 'تست نهایی عملکرد', checked: false }], ...base };
    case 'stat-box':
      return { statNumber: '۱۰۰٪', statLabel: 'تست فنی موفق', statBadge: 'گارانتی', ...base };
    case 'dual-signature':
      return { leftSignLabel: 'امضای مشتری', rightSignLabel: 'امضای تعمیرگاه', ...base };
    case 'seal-badge':
      return { sealText: 'اصالت قطعات', sealColor: 'gold', ...base };
    case 'notes-box':
      return { noteType: 'warning', content: 'توجه: این فاکتور ملاک ضمانت خدمات می‌باشد.', ...base };
    case 'device-specs':
      return { content: 'مشخصات دستگاه', ...base };
    case 'price-tag':
      return { priceAmount: '۷۵۰,۰۰۰', priceCurrency: 'تومان', ...base };
    default:
      return { ...base };
  }
}

export function createElement(type: ElementType, x: number, y: number, zIndex: number, overrides: Partial<EditorElement> = {}): EditorElement {
  const preset = PRESETS[type] ?? { width: 180, height: 40 };
  const isInput = ['text-input', 'textarea', 'number-input', 'currency-input', 'date-input', 'select'].includes(type);
  return {
    id: uuid(),
    type,
    label: ELEMENT_LABELS[type],
    x: Math.round(x),
    y: Math.round(y),
    width: preset.width,
    height: preset.height,
    minWidth: 24,
    minHeight: 16,
    maxWidth: 2000,
    maxHeight: 2000,
    rotation: 0,
    zIndex,
    locked: false,
    hidden: false,
    groupId: null,
    responsive: { mobile: null, tablet: null, desktop: null },
    style: isInput ? { ...INPUT_STYLE, ...preset.style } : defaultStyle(preset.style),
    properties: defaultProps(type),
    ...overrides,
  };
}

/* ---------------- Responsive resolution ---------------- */
export function resolveRect(el: EditorElement, bp: Breakpoint): { x: number; y: number; width: number; height: number; hidden: boolean } {
  const r = el.responsive[bp];
  if (bp === 'desktop' || !r) {
    return { x: el.x, y: el.y, width: el.width, height: el.height, hidden: el.hidden };
  }
  return { x: r.x, y: r.y, width: r.width, height: r.height, hidden: el.hidden || r.hidden };
}

/* ---------------- Formula engine ---------------- */
const SAMPLE_VALUES: Record<string, number> = {
  quantity: 3, price: 250000, unitPrice: 250000, subtotal: 750000,
  discount: 50000, tax: 63000, total: 763000, amount: 1250000, labor: 400000,
};

export function evaluateFormula(formula: string, values: Record<string, number> = {}): number {
  if (!formula) return 0;
  try {
    let expr = formula;
    // functions over table columns → deterministic sample aggregate
    expr = expr.replace(/SUM\(([^)]*)\)/gi, '750000')
      .replace(/AVG\(([^)]*)\)/gi, '250000')
      .replace(/MIN\(([^)]*)\)/gi, '100000')
      .replace(/MAX\(([^)]*)\)/gi, '400000')
      .replace(/COUNT\(([^)]*)\)/gi, '3')
      .replace(/ROUND\(([^)]*)\)/gi, (_m, inner) => String(Math.round(evaluateFormula(inner, values))));
    expr = expr.replace(/\{([\w.]+)\}/g, (_m, key: string) => {
      const v = values[key] ?? SAMPLE_VALUES[key] ?? 0;
      return String(v);
    });
    if (!/^[\d\s+\-*/().]*$/.test(expr)) return 0;
    // eslint-disable-next-line no-new-func
    const result = Function(`"use strict"; return (${expr || 0});`)() as number;
    return isFinite(result) ? result : 0;
  } catch {
    return 0;
  }
}

export function formatFormulaResult(value: number, props: EditorElement['properties']): string {
  const d = props.decimalPlaces ?? 0;
  let out: string;
  switch (props.format) {
    case 'currency': out = faNum(value, d); break;
    case 'percent': out = `${faNum(value, d)}٪`; break;
    case 'text': out = fa(value); break;
    default: out = faNum(value, d);
  }
  return `${props.prefix ?? ''}${out}${props.suffix ? ' ' + props.suffix : ''}`;
}

/* ---------------- CSS builders ---------------- */
export function styleToCss(s: ElementStyle, forPrint = false): React.CSSProperties {
  const weights: Record<string, number> = { light: 300, normal: 400, medium: 500, bold: 700, extrabold: 800 };
  const border = s.borderStyle === 'none' ? undefined : `${s.borderWidth}px ${s.borderStyle} ${s.borderColor}`;
  const css: React.CSSProperties = {
    fontFamily: `'${s.fontFamily}', Vazirmatn, sans-serif`,
    fontSize: s.fontSize,
    fontWeight: weights[s.fontWeight] ?? 400,
    fontStyle: s.fontStyle,
    textAlign: s.textAlign,
    textDecoration: s.textDecoration,
    lineHeight: s.lineHeight,
    letterSpacing: s.letterSpacing,
    color: s.color,
    backgroundColor: s.backgroundColor === 'transparent' ? 'transparent' : hexWithAlpha(s.backgroundColor, s.backgroundOpacity),
    borderTop: s.borderTop ? border : 'none',
    borderRight: s.borderRight ? border : 'none',
    borderBottom: s.borderBottom ? border : 'none',
    borderLeft: s.borderLeft ? border : 'none',
    borderRadius: s.borderRadius,
    paddingTop: s.paddingTop, paddingRight: s.paddingRight,
    paddingBottom: s.paddingBottom, paddingLeft: s.paddingLeft,
    opacity: s.opacity / 100,
    boxShadow: s.shadowEnabled && !forPrint
      ? `${s.shadowX}px ${s.shadowY}px ${s.shadowBlur}px ${s.shadowSpread}px ${s.shadowColor}`
      : undefined,
    overflow: 'hidden',
  };

  // ===== Visual effect presets =====
  if (s.effect === 'gradient') {
    css.background = s.gradType === 'radial'
      ? `radial-gradient(circle, ${s.gradFrom}, ${s.gradTo})`
      : `linear-gradient(${s.gradAngle || 135}deg, ${s.gradFrom}, ${s.gradTo})`;
    css.backgroundColor = 'transparent';
  }
  if (s.effect === 'glass') {
    css.background = hexWithAlpha(s.backgroundColor === 'transparent' ? '#ffffff' : s.backgroundColor, 22);
    css.backdropFilter = `blur(${s.glassBlur}px) saturate(160%)`;
    css.WebkitBackdropFilter = `blur(${s.glassBlur}px) saturate(160%)`;
    if (s.borderStyle === 'none') { css.border = '1px solid rgba(255,255,255,0.5)'; }
  }
  if (s.effect === 'neu') {
    const base = s.backgroundColor === 'transparent' ? '#eef1f6' : s.backgroundColor;
    css.backgroundColor = base;
    if (s.borderStyle === 'none') css.border = 'none';
  }

  // Combine shadows: drop + inner
  const shadows: string[] = [];
  if (s.shadowEnabled && !forPrint) shadows.push(`${s.shadowX}px ${s.shadowY}px ${s.shadowBlur}px ${s.shadowSpread}px ${s.shadowColor}`);
  if (s.innerShadowEnabled) shadows.push(`inset ${s.innerShadowX}px ${s.innerShadowY}px ${s.innerShadowBlur}px ${s.innerShadowSpread}px ${s.innerShadowColor}`);
  if (s.effect === 'glass') shadows.push('0 8px 24px rgba(15,23,42,0.12)');
  if (s.effect === 'neu') shadows.push('-4px -4px 10px rgba(255,255,255,0.75)', '6px 6px 16px rgba(94,104,121,0.35)');
  if (shadows.length) css.boxShadow = shadows.join(', ');

  // Stroke / outline
  const anyCss = css as React.CSSProperties & Record<string, string | undefined>;
  if (s.strokeEnabled && !s.strokeTextOnly && s.strokeWidth > 0) {
    css.outline = `${s.strokeWidth}px solid ${s.strokeColor}`;
    css.outlineOffset = `-${s.strokeWidth}px`;
  }
  if (s.strokeEnabled && s.strokeTextOnly && s.strokeWidth > 0) {
    anyCss.WebkitTextStroke = `${s.strokeWidth}px ${s.strokeColor}`;
  }

  // Text effects
  if (s.textEffect === 'shadow') css.textShadow = '0 2px 10px rgba(0,0,0,0.28)';
  if (s.textEffect === 'glow') css.textShadow = `0 0 14px ${s.color}, 0 0 4px ${s.color}`;
  if (s.textEffect === 'outline' && !s.strokeEnabled) {
    anyCss.WebkitTextStroke = `1px ${s.color}`;
    css.color = 'transparent';
  }
  if (s.textEffect === 'gradient-text') {
    css.background = `linear-gradient(${s.gradAngle || 135}deg, ${s.gradFrom}, ${s.gradTo})`;
    anyCss.WebkitBackgroundClip = 'text';
    anyCss.WebkitTextFillColor = 'transparent';
    anyCss.backgroundClip = 'text';
    css.color = 'transparent';
  }

  // Filters (image/shape)
  if (!forPrint) {
    const f: string[] = [];
    if (s.filterBlur > 0) f.push(`blur(${s.filterBlur}px)`);
    if (s.filterBrightness !== 100) f.push(`brightness(${s.filterBrightness}%)`);
    if (s.filterContrast !== 100) f.push(`contrast(${s.filterContrast}%)`);
    if (s.filterSaturate !== 100) f.push(`saturate(${s.filterSaturate}%)`);
    if (s.filterGrayscale > 0) f.push(`grayscale(${s.filterGrayscale}%)`);
    if (s.filterHueRotate > 0) f.push(`hue-rotate(${s.filterHueRotate}deg)`);
    if (f.length) css.filter = f.join(' ');
  }
  return css;
}

export function hexWithAlpha(hex: string, opacity: number): string {
  if (!hex || hex === 'transparent') return 'transparent';
  if (opacity >= 100) return hex;
  if (hex.startsWith('rgb')) return hex;
  const h = hex.replace('#', '');
  const full = h.length === 3 ? h.split('').map(c => c + c).join('') : h;
  const r = parseInt(full.slice(0, 2), 16);
  const g = parseInt(full.slice(2, 4), 16);
  const b = parseInt(full.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${(opacity / 100).toFixed(2)})`;
}

/* ---------------- Misc ---------------- */
export function clamp(v: number, min: number, max: number) {
  return Math.min(max, Math.max(min, v));
}

export function download(filename: string, content: string, mime = 'application/json') {
  const blob = new Blob([content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = window.document.createElement('a');
  a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
