import type { DocumentConfig, EditorElement, ElementProperties, ElementStyle, ElementType } from './types';
import { createElement, uuid } from './utils';

type Over = Omit<Partial<EditorElement>, 'style' | 'properties'> & {
  style?: Partial<ElementStyle>;
  properties?: Partial<ElementProperties>;
};

let z = 0;
function el(type: ElementType, x: number, y: number, w: number, h: number, over: Over = {}): EditorElement {
  z += 1;
  const base = createElement(type, x, y, z);
  const { style, properties, ...rest } = over;
  return {
    ...base,
    width: w,
    height: h,
    ...rest,
    style: { ...base.style, ...(style ?? {}) },
    properties: { ...base.properties, ...(properties ?? {}) },
  };
}

const TITLE = { fontSize: 20, fontWeight: 'bold' as const, textAlign: 'center' as const };
const LABEL = { fontSize: 11, color: '#475569' };
const SECTION = { fontSize: 13, fontWeight: 'bold' as const, color: '#0f766e' };
const BOX = { borderStyle: 'solid' as const, borderWidth: 1, borderColor: '#cbd5e1', borderRadius: 8 };

export interface TemplateDef {
  id: string;
  name: string;
  category: string;
  description: string;
  doc: Partial<DocumentConfig>;
  build: () => EditorElement[];
}

/* ---------- 1) Sales invoice ---------- */
const salesInvoice = (): EditorElement[] => {
  z = 0;
  return [
    el('image', 620, 40, 110, 90, { label: 'لوگو', properties: { alt: 'لوگو شرکت' } }),
    el('heading', 250, 46, 340, 34, { label: 'نام کسب‌وکار', style: TITLE, properties: { content: 'فروشگاه نمونه ایرانیان' } }),
    el('text', 250, 82, 340, 22, { label: 'زیرعنوان', style: { ...LABEL, textAlign: 'center' }, properties: { content: 'تلفن: ۰۵۱-۳۸۰۰۰۰۰۰ — مشهد، بلوار وکیل‌آباد' } }),
    el('auto-number', 46, 44, 170, 32, { label: 'شماره فاکتور', style: { ...BOX, fontSize: 12 }, properties: { numberPrefix: 'INV-', startFrom: 1001 } }),
    el('date-input', 46, 84, 170, 32, { label: 'تاریخ فاکتور', properties: { fieldName: 'invoice_date' } }),
    el('divider', 46, 132, 684, 2, { label: 'خط جدا' }),

    el('text', 640, 146, 90, 24, { label: 'عنوان مشتری', style: SECTION, properties: { content: 'مشخصات خریدار' } }),
    el('text-input', 470, 176, 260, 34, { label: 'نام مشتری', properties: { placeholder: 'نام و نام خانوادگی', fieldName: 'customer_name' } }),
    el('text-input', 258, 176, 200, 34, { label: 'شماره تماس', properties: { placeholder: 'شماره تماس', fieldName: 'customer_phone' } }),
    el('text-input', 46, 176, 200, 34, { label: 'کد ملی', properties: { placeholder: 'کد ملی / اقتصادی', fieldName: 'national_code' } }),
    el('text-input', 46, 218, 684, 34, { label: 'آدرس', properties: { placeholder: 'نشانی کامل', fieldName: 'customer_address' } }),

    el('dynamic-table', 46, 272, 684, 210, {
      label: 'اقلام فاکتور',
      properties: {
        columns: [
          { id: uuid(), header: 'ردیف', width: 8, align: 'center', type: 'text', editable: false },
          { id: uuid(), header: 'شرح کالا / خدمات', width: 35, align: 'right', type: 'text', editable: true },
          { id: uuid(), header: 'تعداد', width: 10, align: 'center', type: 'number', editable: true },
          { id: uuid(), header: 'واحد', width: 9, align: 'center', type: 'text', editable: true },
          { id: uuid(), header: 'فی (تومان)', width: 15, align: 'left', type: 'currency', editable: true },
          { id: uuid(), header: 'تخفیف', width: 9, align: 'left', type: 'currency', editable: true },
          { id: uuid(), header: 'جمع', width: 14, align: 'left', type: 'formula', formula: '{qty}*{price}', editable: false },
        ],
        rows: 5, showFooter: true, dynamicRows: true,
      },
    }),

    el('text', 430, 500, 300, 24, { label: 'عنوان خلاصه مالی', style: SECTION, properties: { content: 'خلاصه مالی' } }),
    el('formula', 540, 530, 190, 32, { label: 'جمع کل', properties: { formula: 'SUM({items.total})', prefix: 'جمع کل: ', suffix: 'تومان' } }),
    el('currency-input', 540, 570, 190, 32, { label: 'تخفیف کل', properties: { fieldName: 'discount', placeholder: 'تخفیف' } }),
    el('currency-input', 540, 610, 190, 32, { label: 'مالیات', properties: { fieldName: 'tax', placeholder: 'مالیات ۹٪' } }),
    el('formula', 540, 650, 190, 38, {
      label: 'مبلغ پرداختی',
      style: { fontSize: 14, fontWeight: 'bold', backgroundColor: '#ecfdf5', borderStyle: 'solid', borderWidth: 1, borderColor: '#10b981', borderRadius: 8, textAlign: 'left', color: '#065f46' },
      properties: { formula: 'SUM({items.total}) - {discount} + {tax}', prefix: '', suffix: 'تومان' },
    }),
    el('amount-words', 46, 650, 470, 38, { label: 'مبلغ به حروف', style: { ...BOX, fontSize: 12, backgroundColor: '#f8fafc' } }),

    el('signature', 540, 730, 190, 90, { label: 'امضای فروشنده', properties: { content: 'مهر و امضای فروشنده' } }),
    el('signature', 300, 730, 190, 90, { label: 'امضای خریدار', properties: { content: 'امضای خریدار' } }),
    el('qr-code', 46, 730, 90, 90, { label: 'کد QR فاکتور' }),
    el('text', 46, 840, 684, 24, { label: 'پانویس', style: { fontSize: 11, color: '#64748b', textAlign: 'center' }, properties: { content: 'با تشکر از خرید شما — این فاکتور بدون مهر و امضا فاقد اعتبار است' } }),
  ];
};

/* ---------- 2) Repair invoice ---------- */
const repairInvoice = (): EditorElement[] => {
  z = 0;
  return [
    el('image', 630, 40, 100, 80, { label: 'لوگو' }),
    el('heading', 220, 44, 380, 32, { label: 'نام تعمیرگاه', style: TITLE, properties: { content: 'خدمات پس از فروش لوازم خانگی' } }),
    el('text', 220, 78, 380, 20, { label: 'زیرعنوان', style: { ...LABEL, textAlign: 'center' }, properties: { content: 'تعمیر تخصصی یخچال، لباسشویی، ظرفشویی و پکیج' } }),
    el('auto-number', 46, 44, 150, 30, { label: 'شماره پذیرش', properties: { numberPrefix: 'SRV-' }, style: BOX }),
    el('date-input', 46, 80, 150, 30, { label: 'تاریخ پذیرش' }),
    el('divider', 46, 122, 684, 2, { label: 'خط' }),

    el('text', 640, 134, 90, 22, { label: 'عنوان مشتری', style: SECTION, properties: { content: 'مشخصات مشتری' } }),
    el('text-input', 480, 162, 250, 32, { label: 'نام مشتری', properties: { placeholder: 'نام مشتری', fieldName: 'customer_name' } }),
    el('text-input', 262, 162, 206, 32, { label: 'تلفن همراه', properties: { placeholder: 'تلفن همراه', fieldName: 'phone' } }),
    el('text-input', 46, 162, 204, 32, { label: 'تلفن ثابت', properties: { placeholder: 'تلفن ثابت', fieldName: 'phone2' } }),
    el('text-input', 46, 200, 684, 32, { label: 'آدرس', properties: { placeholder: 'نشانی', fieldName: 'address' } }),

    el('text', 640, 244, 90, 22, { label: 'عنوان دستگاه', style: SECTION, properties: { content: 'مشخصات دستگاه' } }),
    el('select', 540, 272, 190, 32, { label: 'نوع دستگاه', properties: { fieldName: 'device_type', options: [{ label: 'یخچال', value: 'fridge' }, { label: 'لباسشویی', value: 'washer' }, { label: 'ظرفشویی', value: 'dish' }, { label: 'پکیج', value: 'boiler' }] } }),
    el('text-input', 366, 272, 164, 32, { label: 'برند', properties: { placeholder: 'برند', fieldName: 'brand' } }),
    el('text-input', 202, 272, 154, 32, { label: 'مدل', properties: { placeholder: 'مدل', fieldName: 'model' } }),
    el('text-input', 46, 272, 146, 32, { label: 'شماره سریال', properties: { placeholder: 'سریال', fieldName: 'serial' } }),
    el('textarea', 46, 316, 684, 60, { label: 'شرح خرابی', properties: { placeholder: 'شرح خرابی اعلام شده توسط مشتری', fieldName: 'complaint' } }),

    el('table', 46, 390, 684, 160, {
      label: 'قطعات و خدمات',
      properties: {
        columns: [
          { id: uuid(), header: 'ردیف', width: 8, align: 'center', type: 'text', editable: false },
          { id: uuid(), header: 'شرح قطعه / خدمت', width: 52, align: 'right', type: 'text', editable: true },
          { id: uuid(), header: 'تعداد', width: 12, align: 'center', type: 'number', editable: true },
          { id: uuid(), header: 'مبلغ (تومان)', width: 28, align: 'left', type: 'currency', editable: true },
        ],
        rows: 4, showFooter: true,
      },
    }),

    el('currency-input', 540, 566, 190, 32, { label: 'اجرت تعمیر', properties: { fieldName: 'labor', placeholder: 'اجرت تعمیر' } }),
    el('currency-input', 540, 604, 190, 32, { label: 'هزینه ایاب و ذهاب', properties: { fieldName: 'transport', placeholder: 'ایاب و ذهاب' } }),
    el('formula', 540, 642, 190, 38, {
      label: 'مبلغ نهایی',
      style: { fontSize: 14, fontWeight: 'bold', backgroundColor: '#ecfdf5', borderStyle: 'solid', borderWidth: 1, borderColor: '#10b981', borderRadius: 8, textAlign: 'left', color: '#065f46' },
      properties: { formula: 'SUM({parts}) + {labor} + {transport}', suffix: 'تومان' },
    }),
    el('text', 470, 566, 60, 22, { label: 'برچسب گارانتی', style: SECTION, properties: { content: 'گارانتی' } }),
    el('select', 280, 566, 180, 32, { label: 'مدت گارانتی', properties: { fieldName: 'warranty', options: [{ label: '۳ ماه', value: '3' }, { label: '۶ ماه', value: '6' }, { label: '۱۲ ماه', value: '12' }] } }),
    el('textarea', 46, 604, 414, 76, { label: 'شرایط گارانتی', properties: { placeholder: 'شرایط گارانتی و توضیحات', fieldName: 'warranty_terms' } }),

    el('signature', 540, 706, 190, 86, { label: 'امضای تکنسین', properties: { content: 'امضای تکنسین' } }),
    el('signature', 300, 706, 190, 86, { label: 'امضای مشتری', properties: { content: 'امضای مشتری' } }),
    el('stamp', 150, 706, 100, 86, { label: 'مهر تعمیرگاه' }),
    el('qr-code', 46, 706, 86, 86, { label: 'QR پیگیری' }),
  ];
};

/* ---------- 3) Mission form ---------- */
const missionForm = (): EditorElement[] => {
  z = 0;
  return [
    el('heading', 200, 44, 400, 34, { label: 'عنوان فرم', style: TITLE, properties: { content: 'فرم اعزام مأموریت' } }),
    el('text', 200, 80, 400, 20, { label: 'نام سازمان', style: { ...LABEL, textAlign: 'center' }, properties: { content: 'شرکت خدمات فنی و مهندسی' } }),
    el('auto-number', 46, 46, 160, 30, { label: 'شماره فرم', style: BOX, properties: { numberPrefix: 'MIS-' } }),
    el('date-input', 574, 46, 156, 30, { label: 'تاریخ صدور' }),
    el('divider', 46, 116, 684, 2, { label: 'خط' }),

    el('text', 640, 128, 90, 22, { label: 'عنوان پرسنل', style: SECTION, properties: { content: 'مشخصات پرسنل' } }),
    el('text-input', 500, 156, 230, 32, { label: 'نام و نام خانوادگی', properties: { placeholder: 'نام و نام خانوادگی', fieldName: 'employee_name' } }),
    el('text-input', 320, 156, 170, 32, { label: 'سمت', properties: { placeholder: 'سمت سازمانی', fieldName: 'position' } }),
    el('text-input', 180, 156, 130, 32, { label: 'کد پرسنلی', properties: { placeholder: 'کد پرسنلی', fieldName: 'employee_id' } }),
    el('text-input', 46, 156, 124, 32, { label: 'واحد', properties: { placeholder: 'واحد', fieldName: 'department' } }),

    el('text', 640, 204, 90, 22, { label: 'عنوان ماموریت', style: SECTION, properties: { content: 'اطلاعات مأموریت' } }),
    el('text-input', 540, 232, 190, 32, { label: 'مقصد', properties: { placeholder: 'شهر مقصد', fieldName: 'destination' } }),
    el('date-input', 356, 232, 176, 32, { label: 'تاریخ اعزام', properties: { fieldName: 'depart_date' } }),
    el('date-input', 172, 232, 176, 32, { label: 'تاریخ بازگشت', properties: { fieldName: 'return_date' } }),
    el('number-input', 46, 232, 118, 32, { label: 'مدت (روز)', properties: { fieldName: 'days', suffix: 'روز' } }),
    el('textarea', 46, 276, 684, 66, { label: 'شرح مأموریت', properties: { placeholder: 'موضوع و شرح مأموریت', fieldName: 'purpose' } }),

    el('text', 640, 356, 90, 22, { label: 'عنوان هزینه', style: SECTION, properties: { content: 'ریز هزینه‌ها' } }),
    el('table', 46, 384, 684, 176, {
      label: 'جدول هزینه‌ها',
      properties: {
        columns: [
          { id: uuid(), header: 'ردیف', width: 10, align: 'center', type: 'text', editable: false },
          { id: uuid(), header: 'شرح هزینه', width: 50, align: 'right', type: 'text', editable: true },
          { id: uuid(), header: 'تاریخ', width: 18, align: 'center', type: 'text', editable: true },
          { id: uuid(), header: 'مبلغ (تومان)', width: 22, align: 'left', type: 'currency', editable: true },
        ],
        rows: 5, showFooter: true,
      },
    }),
    el('formula', 500, 574, 230, 36, {
      label: 'جمع هزینه‌ها',
      style: { fontWeight: 'bold', backgroundColor: '#eff6ff', borderStyle: 'solid', borderWidth: 1, borderColor: '#3b82f6', borderRadius: 8, textAlign: 'left', color: '#1e40af' },
      properties: { formula: 'SUM({expenses})', prefix: 'جمع کل: ', suffix: 'تومان' },
    }),
    el('checkbox', 46, 578, 200, 30, { label: 'تأیید مدارک', properties: { content: 'مدارک پیوست تأیید شد' } }),

    el('signature', 540, 640, 190, 96, { label: 'امضای کارمند', properties: { content: 'امضای کارمند' } }),
    el('signature', 300, 640, 190, 96, { label: 'امضای سرپرست', properties: { content: 'امضای سرپرست' } }),
    el('signature', 60, 640, 190, 96, { label: 'امضای مدیر', properties: { content: 'امضای مدیرعامل' } }),
    el('watermark', 240, 400, 320, 80, { label: 'واترمارک', properties: { content: 'محرمانه' }, style: { opacity: 10 } }),
  ];
};

/* ---------- 4) Order form ---------- */
const orderForm = (): EditorElement[] => {
  z = 0;
  return [
    el('image', 630, 40, 100, 76, { label: 'لوگو' }),
    el('heading', 230, 46, 380, 32, { label: 'عنوان', style: TITLE, properties: { content: 'فرم ثبت سفارش' } }),
    el('auto-number', 46, 46, 160, 30, { label: 'شماره سفارش', style: BOX, properties: { numberPrefix: 'ORD-' } }),
    el('date-input', 46, 82, 160, 30, { label: 'تاریخ سفارش' }),
    el('divider', 46, 124, 684, 2, { label: 'خط' }),

    el('text', 640, 136, 90, 22, { label: 'عنوان مشتری', style: SECTION, properties: { content: 'اطلاعات مشتری' } }),
    el('text-input', 500, 164, 230, 32, { label: 'نام مشتری', properties: { placeholder: 'نام مشتری', fieldName: 'customer' } }),
    el('text-input', 300, 164, 190, 32, { label: 'تلفن', properties: { placeholder: 'تلفن تماس', fieldName: 'phone' } }),
    el('text-input', 46, 164, 244, 32, { label: 'ایمیل', properties: { placeholder: 'ایمیل', fieldName: 'email' } }),

    el('dynamic-table', 46, 214, 684, 190, {
      label: 'اقلام سفارش',
      properties: {
        columns: [
          { id: uuid(), header: 'ردیف', width: 8, align: 'center', type: 'text', editable: false },
          { id: uuid(), header: 'نام کالا', width: 40, align: 'right', type: 'text', editable: true },
          { id: uuid(), header: 'تعداد', width: 12, align: 'center', type: 'number', editable: true },
          { id: uuid(), header: 'قیمت واحد', width: 20, align: 'left', type: 'currency', editable: true },
          { id: uuid(), header: 'جمع', width: 20, align: 'left', type: 'formula', editable: false },
        ],
        rows: 4, showFooter: true, dynamicRows: true,
      },
    }),

    el('text', 640, 420, 90, 22, { label: 'عنوان ارسال', style: SECTION, properties: { content: 'اطلاعات ارسال' } }),
    el('textarea', 356, 448, 374, 62, { label: 'آدرس تحویل', properties: { placeholder: 'آدرس دقیق تحویل', fieldName: 'delivery_address' } }),
    el('date-input', 176, 448, 170, 32, { label: 'تاریخ تحویل', properties: { fieldName: 'delivery_date' } }),
    el('select', 46, 448, 120, 32, { label: 'نحوه ارسال', properties: { fieldName: 'shipping', options: [{ label: 'پیک', value: 'courier' }, { label: 'باربری', value: 'freight' }, { label: 'حضوری', value: 'pickup' }] } }),

    el('radio-group', 500, 528, 230, 84, { label: 'روش پرداخت', properties: { fieldName: 'payment', options: [{ label: 'نقدی', value: 'cash' }, { label: 'کارت‌خوان', value: 'pos' }, { label: 'انتقال بانکی', value: 'transfer' }] } }),
    el('formula', 300, 528, 180, 34, { label: 'جمع سفارش', properties: { formula: 'SUM({items})', prefix: 'جمع: ', suffix: 'تومان' } }),
    el('currency-input', 300, 570, 180, 32, { label: 'هزینه ارسال', properties: { fieldName: 'shipping_cost', placeholder: 'هزینه ارسال' } }),
    el('formula', 46, 528, 240, 40, {
      label: 'مبلغ نهایی',
      style: { fontSize: 14, fontWeight: 'bold', backgroundColor: '#ecfdf5', borderStyle: 'solid', borderWidth: 1, borderColor: '#10b981', borderRadius: 8, textAlign: 'left', color: '#065f46' },
      properties: { formula: 'SUM({items}) + {shipping_cost}', suffix: 'تومان' },
    }),
    el('checkbox', 46, 580, 240, 28, { label: 'پذیرش قوانین', properties: { content: 'شرایط و قوانین را می‌پذیرم' } }),
    el('signature', 540, 636, 190, 88, { label: 'امضای مشتری', properties: { content: 'امضای سفارش‌دهنده' } }),
    el('qr-code', 46, 636, 88, 88, { label: 'QR سفارش' }),
  ];
};

/* ---------- 5) Customer card ---------- */
const customerCard = (): EditorElement[] => {
  z = 0;
  return [
    el('heading', 220, 44, 400, 34, { label: 'عنوان', style: TITLE, properties: { content: 'کارتکس مشتری' } }),
    el('image-upload', 610, 44, 120, 130, { label: 'عکس مشتری' }),
    el('auto-number', 46, 46, 150, 30, { label: 'کد مشتری', style: BOX, properties: { numberPrefix: 'CUS-' } }),
    el('divider', 46, 186, 684, 2, { label: 'خط' }),

    el('text', 640, 198, 90, 22, { label: 'عنوان هویتی', style: SECTION, properties: { content: 'اطلاعات هویتی' } }),
    el('text-input', 500, 226, 230, 32, { label: 'نام و نام خانوادگی', properties: { placeholder: 'نام و نام خانوادگی', fieldName: 'full_name' } }),
    el('text-input', 330, 226, 160, 32, { label: 'نام پدر', properties: { placeholder: 'نام پدر', fieldName: 'father_name' } }),
    el('text-input', 172, 226, 148, 32, { label: 'کد ملی', properties: { placeholder: 'کد ملی', fieldName: 'national_code' } }),
    el('date-input', 46, 226, 116, 32, { label: 'تاریخ تولد', properties: { fieldName: 'birth_date' } }),

    el('text', 640, 272, 90, 22, { label: 'عنوان تماس', style: SECTION, properties: { content: 'اطلاعات تماس' } }),
    el('text-input', 540, 300, 190, 32, { label: 'موبایل', properties: { placeholder: 'تلفن همراه', fieldName: 'mobile' } }),
    el('text-input', 356, 300, 174, 32, { label: 'تلفن ثابت', properties: { placeholder: 'تلفن ثابت', fieldName: 'phone' } }),
    el('text-input', 46, 300, 300, 32, { label: 'ایمیل', properties: { placeholder: 'ایمیل', fieldName: 'email' } }),
    el('textarea', 46, 340, 684, 56, { label: 'آدرس', properties: { placeholder: 'نشانی کامل', fieldName: 'address' } }),

    el('text', 640, 410, 90, 22, { label: 'عنوان حساب', style: SECTION, properties: { content: 'وضعیت حساب' } }),
    el('select', 540, 438, 190, 32, { label: 'وضعیت مشتری', properties: { fieldName: 'status', options: [{ label: 'فعال', value: 'active' }, { label: 'غیرفعال', value: 'inactive' }, { label: 'ویژه (VIP)', value: 'vip' }] } }),
    el('currency-input', 346, 438, 184, 32, { label: 'سقف اعتبار', properties: { fieldName: 'credit_limit', placeholder: 'سقف اعتبار' } }),
    el('formula', 46, 438, 290, 32, { label: 'مانده حساب', properties: { formula: '{total}', prefix: 'مانده حساب: ', suffix: 'تومان' } }),

    el('table', 46, 490, 684, 210, {
      label: 'سوابق مالی',
      properties: {
        columns: [
          { id: uuid(), header: 'ردیف', width: 8, align: 'center', type: 'text', editable: false },
          { id: uuid(), header: 'تاریخ', width: 18, align: 'center', type: 'text', editable: true },
          { id: uuid(), header: 'شرح تراکنش', width: 40, align: 'right', type: 'text', editable: true },
          { id: uuid(), header: 'بدهکار', width: 17, align: 'left', type: 'currency', editable: true },
          { id: uuid(), header: 'بستانکار', width: 17, align: 'left', type: 'currency', editable: true },
        ],
        rows: 6, showFooter: true,
      },
    }),
    el('textarea', 46, 714, 500, 70, { label: 'یادداشت‌ها', properties: { placeholder: 'یادداشت‌های داخلی درباره مشتری', fieldName: 'notes' } }),
    el('qr-code', 640, 714, 90, 90, { label: 'QR کارتکس' }),
  ];
};

/* ---------- 6) Payment receipt (A5) ---------- */
const paymentReceipt = (): EditorElement[] => {
  z = 0;
  return [
    el('heading', 130, 34, 300, 32, { label: 'عنوان رسید', style: TITLE, properties: { content: 'رسید پرداخت وجه' } }),
    el('auto-number', 34, 36, 120, 28, { label: 'شماره رسید', style: { ...BOX, fontSize: 11 }, properties: { numberPrefix: 'RCT-' } }),
    el('date-input', 406, 36, 120, 28, { label: 'تاریخ' }),
    el('divider', 34, 78, 492, 2, { label: 'خط' }),

    el('text-input', 300, 94, 226, 32, { label: 'پرداخت‌کننده', properties: { placeholder: 'نام پرداخت‌کننده', fieldName: 'payer' } }),
    el('text-input', 34, 94, 250, 32, { label: 'دریافت‌کننده', properties: { placeholder: 'نام دریافت‌کننده', fieldName: 'payee' } }),

    el('currency-input', 300, 140, 226, 44, {
      label: 'مبلغ پرداختی',
      style: { fontSize: 17, fontWeight: 'bold', textAlign: 'center', backgroundColor: '#ecfdf5', borderStyle: 'solid', borderWidth: 1, borderColor: '#10b981', borderRadius: 10, color: '#065f46' },
      properties: { fieldName: 'amount', placeholder: 'مبلغ', suffix: 'تومان' },
    }),
    el('text', 34, 150, 250, 26, { label: 'برچسب مبلغ', style: { fontSize: 12, fontWeight: 'bold' }, properties: { content: 'مبلغ دریافتی (تومان):' } }),
    el('amount-words', 34, 196, 492, 36, { label: 'مبلغ به حروف', style: { ...BOX, fontSize: 11, backgroundColor: '#f8fafc' } }),

    el('radio-group', 300, 246, 226, 84, { label: 'روش پرداخت', properties: { fieldName: 'method', optionsLayout: 'vertical', options: [{ label: 'نقدی', value: 'cash' }, { label: 'کارت‌خوان', value: 'card' }, { label: 'انتقال بانکی', value: 'transfer' }, { label: 'چک', value: 'cheque' }] } }),
    el('text-input', 34, 246, 250, 32, { label: 'شماره پیگیری', properties: { placeholder: 'شماره پیگیری / چک', fieldName: 'reference' } }),
    el('textarea', 34, 286, 250, 60, { label: 'بابت', properties: { placeholder: 'بابت...', fieldName: 'description' } }),

    el('signature', 340, 356, 186, 78, { label: 'امضای دریافت‌کننده', properties: { content: 'امضای دریافت‌کننده' } }),
    el('stamp', 226, 356, 96, 78, { label: 'مهر' }),
    el('qr-code', 34, 356, 78, 78, { label: 'QR رسید' }),
    el('text', 34, 446, 492, 20, { label: 'پانویس', style: { fontSize: 10, color: '#64748b', textAlign: 'center' }, properties: { content: 'این رسید به منزله تأیید دریافت وجه فوق می‌باشد.' } }),
  ];
};

export const TEMPLATES: TemplateDef[] = [
  { id: 'sales-invoice', name: 'فاکتور فروش', category: 'فاکتور', description: 'فاکتور رسمی فروش کالا با جدول اقلام و خلاصه مالی', doc: { type: 'invoice', pageSize: 'A4', orientation: 'portrait', name: 'فاکتور فروش' }, build: salesInvoice },
  { id: 'repair-invoice', name: 'فاکتور تعمیرات', category: 'فاکتور', description: 'فاکتور خدمات تعمیر لوازم خانگی همراه با گارانتی', doc: { type: 'invoice', pageSize: 'A4', orientation: 'portrait', name: 'فاکتور تعمیرات' }, build: repairInvoice },
  { id: 'mission-form', name: 'فرم ماموریت', category: 'ماموریت', description: 'فرم اعزام پرسنل با ریز هزینه‌ها و سه امضا', doc: { type: 'mission', pageSize: 'A4', orientation: 'portrait', name: 'فرم اعزام مأموریت' }, build: missionForm },
  { id: 'order-form', name: 'فرم سفارش', category: 'سفارش', description: 'ثبت سفارش کالا با اطلاعات ارسال و پرداخت', doc: { type: 'order', pageSize: 'A4', orientation: 'portrait', name: 'فرم ثبت سفارش' }, build: orderForm },
  { id: 'customer-card', name: 'کارتکس مشتری', category: 'مشتری', description: 'پرونده کامل مشتری با سوابق مالی', doc: { type: 'customer-card', pageSize: 'A4', orientation: 'portrait', name: 'کارتکس مشتری' }, build: customerCard },
  { id: 'payment-receipt', name: 'رسید پرداخت', category: 'حسابداری', description: 'رسید وجه در قطع A5 با مبلغ به حروف', doc: { type: 'receipt', pageSize: 'A5', orientation: 'portrait', name: 'رسید پرداخت' }, build: paymentReceipt },
];

export const TEMPLATE_CATEGORIES = ['همه', 'فاکتور', 'سفارش', 'ماموریت', 'حسابداری', 'مشتری'];
