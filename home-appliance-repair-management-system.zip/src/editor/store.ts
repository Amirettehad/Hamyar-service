import { create } from 'zustand';
import type {
  AlignmentType, Breakpoint, DocumentConfig, DocumentMeta,
  EditorElement, ElementStyle, GuideLine, HistoryEntry,
} from './types';
import { uuid, getBounds, getPagePx, clamp, mmToPx, createElement } from './utils';

const DOCS_KEY = 'editor_documents';
const PREFS_KEY = 'editor_preferences';
const docKey = (id: string) => `editor_doc_${id}`;

export function blankDocument(name = 'سند بدون عنوان'): DocumentConfig {
  const now = new Date().toISOString();
  return {
    id: uuid(),
    name,
    type: 'custom',
    pageSize: 'A4',
    orientation: 'portrait',
    customWidth: 210,
    customHeight: 297,
    margins: { top: 12, right: 12, bottom: 12, left: 12 },
    backgroundColor: '#ffffff',
    backgroundImage: null,
    backgroundOpacity: 100,
    showBorder: false,
    borderColor: '#cbd5e1',
    borderWidth: 1,
    borderStyle: 'solid',
    gridColor: '#94a3b8',
    gridOpacity: 35,
    createdAt: now,
    updatedAt: now,
    version: 1,
    tags: [],
    description: '',
  };
}

interface Prefs {
  showGrid: boolean; showRulers: boolean; showGuides: boolean;
  snapToGrid: boolean; snapToObject: boolean; gridSize: number; snapThreshold: number;
}

function loadPrefs(): Prefs {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (raw) return { ...defaultPrefs, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return defaultPrefs;
}
const defaultPrefs: Prefs = {
  showGrid: true, showRulers: true, showGuides: true,
  snapToGrid: true, snapToObject: true, gridSize: 10, snapThreshold: 6,
};

export interface EditorState {
  document: DocumentConfig;
  elements: EditorElement[];
  selectedElementId: string | null;
  selectedElementIds: string[];

  history: HistoryEntry[];
  historyIndex: number;

  zoom: number;
  pan: { x: number; y: number };
  showGrid: boolean;
  showGuides: boolean;
  showRulers: boolean;
  snapToGrid: boolean;
  snapToObject: boolean;
  gridSize: number;
  snapThreshold: number;
  breakpoint: Breakpoint;
  previewMode: boolean;

  activeGuides: GuideLine[];
  clipboard: EditorElement[] | null;
  savedAt: string | null;
  dirty: boolean;
  documents: DocumentMeta[];

  // element ops
  addElement: (el: EditorElement, silent?: boolean) => void;
  addElementOfType: (type: EditorElement['type'], x: number, y: number) => string;
  updateElement: (id: string, updates: Partial<EditorElement>, record?: string | false) => void;
  updateStyle: (id: string, updates: Partial<ElementStyle>) => void;
  updateProperties: (id: string, updates: Partial<EditorElement['properties']>) => void;
  deleteElement: (id?: string) => void;
  duplicateElement: (id?: string) => void;
  selectElement: (id: string | null) => void;
  multiSelectElement: (id: string) => void;
  selectMany: (ids: string[]) => void;
  selectAll: () => void;
  moveElement: (id: string, x: number, y: number) => void;
  nudge: (dx: number, dy: number) => void;
  resizeElement: (id: string, w: number, h: number, x?: number, y?: number) => void;
  reorderElement: (id: string, direction: 'up' | 'down' | 'top' | 'bottom') => void;
  setLayerOrder: (orderedIdsTopFirst: string[]) => void;
  alignElements: (alignment: AlignmentType) => void;
  distributeElements: (direction: 'horizontal' | 'vertical') => void;
  groupElements: () => void;
  ungroupElements: () => void;
  toggleLock: (id?: string) => void;
  toggleHidden: (id?: string) => void;

  // history / clipboard
  commit: (action: string) => void;
  undo: () => void;
  redo: () => void;
  copy: () => void;
  paste: () => void;
  cut: () => void;

  // view
  setZoom: (z: number) => void;
  setPan: (p: { x: number; y: number }) => void;
  toggleGrid: () => void;
  toggleSnapGrid: () => void;
  toggleSnapObject: () => void;
  toggleRulers: () => void;
  toggleGuides: () => void;
  setGridSize: (n: number) => void;
  setSnapThreshold: (n: number) => void;
  setBreakpoint: (bp: Breakpoint) => void;
  setPreviewMode: (v: boolean) => void;
  setActiveGuides: (g: GuideLine[]) => void;

  // document
  updateDocument: (updates: Partial<DocumentConfig>) => void;
  newDocument: (partial?: Partial<DocumentConfig>) => void;
  loadTemplate: (doc: Partial<DocumentConfig>, elements: EditorElement[]) => void;
  saveDocument: () => void;
  loadDocument: (id: string) => void;
  deleteDocument: (id: string) => void;
  refreshDocuments: () => void;
  exportAsJSON: () => string;
  importFromJSON: (data: string) => boolean;
}

const MAX_HISTORY = 50;

function persistPrefs(s: EditorState) {
  const prefs: Prefs = {
    showGrid: s.showGrid, showRulers: s.showRulers, showGuides: s.showGuides,
    snapToGrid: s.snapToGrid, snapToObject: s.snapToObject,
    gridSize: s.gridSize, snapThreshold: s.snapThreshold,
  };
  try { localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); } catch { /* ignore */ }
}

function readDocs(): DocumentMeta[] {
  try {
    const raw = localStorage.getItem(DOCS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

const prefs = loadPrefs();

export const useEditor = create<EditorState>((set, get) => ({
  document: blankDocument(),
  elements: [],
  selectedElementId: null,
  selectedElementIds: [],
  history: [],
  historyIndex: -1,
  zoom: 0.75,
  pan: { x: 0, y: 0 },
  ...prefs,
  breakpoint: 'desktop',
  previewMode: false,
  activeGuides: [],
  clipboard: null,
  savedAt: null,
  dirty: false,
  documents: readDocs(),

  commit: (action) => {
    const { elements, document, history, historyIndex } = get();
    const entry: HistoryEntry = {
      timestamp: Date.now(),
      action,
      snapshot: { elements: JSON.parse(JSON.stringify(elements)), document: { ...document } },
    };
    const trimmed = history.slice(0, historyIndex + 1);
    trimmed.push(entry);
    const overflow = Math.max(0, trimmed.length - MAX_HISTORY);
    const next = trimmed.slice(overflow);
    set({ history: next, historyIndex: next.length - 1, dirty: true });
  },

  addElement: (el, silent) => {
    set(s => ({ elements: [...s.elements, el], selectedElementId: el.id, selectedElementIds: [el.id] }));
    if (!silent) get().commit(`افزودن ${el.label}`);
  },

  addElementOfType: (type, x, y) => {
    const { elements } = get();
    const maxZ = elements.reduce((m, e) => Math.max(m, e.zIndex), 0);
    const el = createElement(type, x, y, maxZ + 1);
    get().addElement(el);
    return el.id;
  },

  updateElement: (id, updates, record = 'ویرایش عنصر') => {
    set(s => ({ elements: s.elements.map(e => (e.id === id ? { ...e, ...updates } : e)), dirty: true }));
    if (record) get().commit(record as string);
  },

  updateStyle: (id, updates) => {
    set(s => ({
      elements: s.elements.map(e => (e.id === id ? { ...e, style: { ...e.style, ...updates } } : e)),
      dirty: true,
    }));
  },

  updateProperties: (id, updates) => {
    set(s => ({
      elements: s.elements.map(e => (e.id === id ? { ...e, properties: { ...e.properties, ...updates } } : e)),
      dirty: true,
    }));
  },

  deleteElement: (id) => {
    const ids = id ? [id] : get().selectedElementIds;
    if (ids.length === 0) return;
    set(s => ({
      elements: s.elements.filter(e => !ids.includes(e.id)),
      selectedElementId: null,
      selectedElementIds: [],
    }));
    get().commit('حذف عنصر');
  },

  duplicateElement: (id) => {
    const ids = id ? [id] : get().selectedElementIds;
    const { elements } = get();
    const maxZ = elements.reduce((m, e) => Math.max(m, e.zIndex), 0);
    const copies = elements
      .filter(e => ids.includes(e.id))
      .map((e, i) => ({ ...JSON.parse(JSON.stringify(e)), id: uuid(), x: e.x + 16, y: e.y + 16, zIndex: maxZ + i + 1 }));
    if (copies.length === 0) return;
    set(s => ({
      elements: [...s.elements, ...copies],
      selectedElementId: copies[0].id,
      selectedElementIds: copies.map(c => c.id),
    }));
    get().commit('کپی‌برداری عنصر');
  },

  selectElement: (id) => set({ selectedElementId: id, selectedElementIds: id ? [id] : [] }),

  multiSelectElement: (id) => set(s => {
    const has = s.selectedElementIds.includes(id);
    const ids = has ? s.selectedElementIds.filter(i => i !== id) : [...s.selectedElementIds, id];
    return { selectedElementIds: ids, selectedElementId: ids[ids.length - 1] ?? null };
  }),

  selectMany: (ids) => set({ selectedElementIds: ids, selectedElementId: ids[ids.length - 1] ?? null }),

  selectAll: () => set(s => ({
    selectedElementIds: s.elements.filter(e => !e.locked).map(e => e.id),
    selectedElementId: s.elements.length ? s.elements[s.elements.length - 1].id : null,
  })),

  moveElement: (id, x, y) => {
    const bp = get().breakpoint;
    set(s => ({
      elements: s.elements.map(e => {
        if (e.id !== id) return e;
        if (bp !== 'desktop') {
          const base = e.responsive[bp] ?? { x: e.x, y: e.y, width: e.width, height: e.height, hidden: false };
          return { ...e, responsive: { ...e.responsive, [bp]: { ...base, x: Math.round(x), y: Math.round(y) } } };
        }
        return { ...e, x: Math.round(x), y: Math.round(y) };
      }),
      dirty: true,
    }));
  },

  nudge: (dx, dy) => {
    const { selectedElementIds, breakpoint, elements } = get();
    if (!selectedElementIds.length) return;
    set({
      elements: elements.map(e => {
        if (!selectedElementIds.includes(e.id) || e.locked) return e;
        if (breakpoint !== 'desktop') {
          const base = e.responsive[breakpoint] ?? { x: e.x, y: e.y, width: e.width, height: e.height, hidden: false };
          return { ...e, responsive: { ...e.responsive, [breakpoint]: { ...base, x: base.x + dx, y: base.y + dy } } };
        }
        return { ...e, x: e.x + dx, y: e.y + dy };
      }),
      dirty: true,
    });
  },

  resizeElement: (id, w, h, x, y) => {
    const bp = get().breakpoint;
    set(s => ({
      elements: s.elements.map(e => {
        if (e.id !== id) return e;
        const width = Math.round(clamp(w, e.minWidth, e.maxWidth));
        const height = Math.round(clamp(h, e.minHeight, e.maxHeight));
        if (bp !== 'desktop') {
          const base = e.responsive[bp] ?? { x: e.x, y: e.y, width: e.width, height: e.height, hidden: false };
          return { ...e, responsive: { ...e.responsive, [bp]: { ...base, width, height, x: x ?? base.x, y: y ?? base.y } } };
        }
        return { ...e, width, height, x: x !== undefined ? Math.round(x) : e.x, y: y !== undefined ? Math.round(y) : e.y };
      }),
      dirty: true,
    }));
  },

  reorderElement: (id, direction) => {
    const sorted = [...get().elements].sort((a, b) => a.zIndex - b.zIndex);
    const idx = sorted.findIndex(e => e.id === id);
    if (idx === -1) return;
    const [item] = sorted.splice(idx, 1);
    if (direction === 'up') sorted.splice(Math.min(sorted.length, idx + 1), 0, item);
    else if (direction === 'down') sorted.splice(Math.max(0, idx - 1), 0, item);
    else if (direction === 'top') sorted.push(item);
    else sorted.unshift(item);
    set({ elements: sorted.map((e, i) => ({ ...e, zIndex: i + 1 })), dirty: true });
    get().commit('تغییر ترتیب لایه');
  },

  setLayerOrder: (orderedIdsTopFirst) => {
    const map = new Map(get().elements.map(e => [e.id, e]));
    const bottomFirst = [...orderedIdsTopFirst].reverse();
    const next = bottomFirst.map((id, i) => ({ ...(map.get(id) as EditorElement), zIndex: i + 1 })).filter(Boolean);
    set({ elements: next, dirty: true });
    get().commit('مرتب‌سازی لایه‌ها');
  },

  alignElements: (alignment) => {
    const { selectedElementIds, elements, document } = get();
    const page = getPagePx(document);
    const targets = elements.filter(e => selectedElementIds.includes(e.id) && !e.locked);
    if (targets.length === 0) return;

    let area: { left: number; right: number; top: number; bottom: number };
    if (targets.length === 1) {
      area = {
        left: mmToPx(document.margins.left),
        right: page.width - mmToPx(document.margins.right),
        top: mmToPx(document.margins.top),
        bottom: page.height - mmToPx(document.margins.bottom),
      };
    } else {
      const bs = targets.map(getBounds);
      area = {
        left: Math.min(...bs.map(b => b.left)),
        right: Math.max(...bs.map(b => b.right)),
        top: Math.min(...bs.map(b => b.top)),
        bottom: Math.max(...bs.map(b => b.bottom)),
      };
    }

    set({
      elements: elements.map(e => {
        if (!selectedElementIds.includes(e.id) || e.locked) return e;
        switch (alignment) {
          case 'left': return { ...e, x: Math.round(area.left) };
          case 'right': return { ...e, x: Math.round(area.right - e.width) };
          case 'center-h': return { ...e, x: Math.round((area.left + area.right) / 2 - e.width / 2) };
          case 'top': return { ...e, y: Math.round(area.top) };
          case 'bottom': return { ...e, y: Math.round(area.bottom - e.height) };
          case 'center-v': return { ...e, y: Math.round((area.top + area.bottom) / 2 - e.height / 2) };
          default: return e;
        }
      }),
    });
    get().commit('تراز عناصر');
  },

  distributeElements: (direction) => {
    const { selectedElementIds, elements } = get();
    const targets = elements.filter(e => selectedElementIds.includes(e.id));
    if (targets.length < 3) return;
    const sorted = [...targets].sort((a, b) => (direction === 'horizontal' ? a.x - b.x : a.y - b.y));
    const first = sorted[0], last = sorted[sorted.length - 1];
    const totalSize = sorted.reduce((s, e) => s + (direction === 'horizontal' ? e.width : e.height), 0);
    const span = direction === 'horizontal'
      ? (last.x + last.width) - first.x
      : (last.y + last.height) - first.y;
    const gap = (span - totalSize) / (sorted.length - 1);
    let cursor = direction === 'horizontal' ? first.x : first.y;
    const positions = new Map<string, number>();
    sorted.forEach(e => {
      positions.set(e.id, Math.round(cursor));
      cursor += (direction === 'horizontal' ? e.width : e.height) + gap;
    });
    set({
      elements: elements.map(e => positions.has(e.id)
        ? (direction === 'horizontal' ? { ...e, x: positions.get(e.id)! } : { ...e, y: positions.get(e.id)! })
        : e),
    });
    get().commit('توزیع یکنواخت');
  },

  groupElements: () => {
    const { selectedElementIds } = get();
    if (selectedElementIds.length < 2) return;
    const gid = uuid();
    set(s => ({ elements: s.elements.map(e => (selectedElementIds.includes(e.id) ? { ...e, groupId: gid } : e)) }));
    get().commit('گروه‌بندی');
  },

  ungroupElements: () => {
    const { selectedElementIds, elements } = get();
    const gids = new Set(elements.filter(e => selectedElementIds.includes(e.id)).map(e => e.groupId).filter(Boolean));
    if (!gids.size) return;
    set({ elements: elements.map(e => (e.groupId && gids.has(e.groupId) ? { ...e, groupId: null } : e)) });
    get().commit('آنگروه');
  },

  toggleLock: (id) => {
    const ids = id ? [id] : get().selectedElementIds;
    set(s => ({ elements: s.elements.map(e => (ids.includes(e.id) ? { ...e, locked: !e.locked } : e)) }));
    get().commit('تغییر قفل');
  },

  toggleHidden: (id) => {
    const ids = id ? [id] : get().selectedElementIds;
    set(s => ({ elements: s.elements.map(e => (ids.includes(e.id) ? { ...e, hidden: !e.hidden } : e)) }));
    get().commit('تغییر نمایش');
  },

  undo: () => {
    const { historyIndex, history } = get();
    if (historyIndex <= 0) return;
    const entry = history[historyIndex - 1];
    set({
      elements: JSON.parse(JSON.stringify(entry.snapshot.elements)),
      document: { ...entry.snapshot.document },
      historyIndex: historyIndex - 1,
      selectedElementId: null, selectedElementIds: [],
    });
  },

  redo: () => {
    const { historyIndex, history } = get();
    if (historyIndex >= history.length - 1) return;
    const entry = history[historyIndex + 1];
    set({
      elements: JSON.parse(JSON.stringify(entry.snapshot.elements)),
      document: { ...entry.snapshot.document },
      historyIndex: historyIndex + 1,
      selectedElementId: null, selectedElementIds: [],
    });
  },

  copy: () => {
    const { elements, selectedElementIds } = get();
    const picked = elements.filter(e => selectedElementIds.includes(e.id));
    if (picked.length) set({ clipboard: JSON.parse(JSON.stringify(picked)) });
  },

  paste: () => {
    const { clipboard, elements } = get();
    if (!clipboard?.length) return;
    const maxZ = elements.reduce((m, e) => Math.max(m, e.zIndex), 0);
    const copies = clipboard.map((e, i) => ({ ...JSON.parse(JSON.stringify(e)), id: uuid(), x: e.x + 20, y: e.y + 20, zIndex: maxZ + i + 1 }));
    set(s => ({ elements: [...s.elements, ...copies], selectedElementIds: copies.map(c => c.id), selectedElementId: copies[0].id }));
    get().commit('چسباندن');
  },

  cut: () => { get().copy(); get().deleteElement(); },

  setZoom: (z) => set({ zoom: clamp(z, 0.25, 2) }),
  setPan: (p) => set({ pan: p }),
  toggleGrid: () => { set(s => ({ showGrid: !s.showGrid })); persistPrefs(get()); },
  toggleSnapGrid: () => { set(s => ({ snapToGrid: !s.snapToGrid })); persistPrefs(get()); },
  toggleSnapObject: () => { set(s => ({ snapToObject: !s.snapToObject })); persistPrefs(get()); },
  toggleRulers: () => { set(s => ({ showRulers: !s.showRulers })); persistPrefs(get()); },
  toggleGuides: () => { set(s => ({ showGuides: !s.showGuides })); persistPrefs(get()); },
  setGridSize: (n) => { set({ gridSize: n }); persistPrefs(get()); },
  setSnapThreshold: (n) => { set({ snapThreshold: n }); persistPrefs(get()); },
  setBreakpoint: (bp) => set({ breakpoint: bp }),
  setPreviewMode: (v) => set({ previewMode: v, selectedElementId: null, selectedElementIds: [] }),
  setActiveGuides: (g) => set({ activeGuides: g }),

  updateDocument: (updates) => set(s => {
    const geoKeys = ['pageSize', 'orientation', 'customWidth', 'customHeight'];
    const geoChanged = geoKeys.some(k => k in updates && (updates as unknown as Record<string, unknown>)[k] !== s.document[k as keyof typeof s.document]);
    const oldDoc = { ...s.document, ...updates, updatedAt: new Date().toISOString() };
    if (!geoChanged) return { document: oldDoc, dirty: true };
    const oldPage = getPagePx(s.document);
    const newPage = getPagePx(oldDoc);
    if (oldPage.width === newPage.width && oldPage.height === newPage.height) return { document: oldDoc, dirty: true };
    const sx = newPage.width / oldPage.width;
    const sy = newPage.height / oldPage.height;
    const elements = s.elements.map(e => ({
      ...e,
      x: Math.round(e.x * sx),
      y: Math.round(e.y * sy),
      width: Math.round(e.width * sx),
      height: Math.round(e.height * sy),
    }));
    return { document: oldDoc, elements, dirty: true };
  }),

  newDocument: (partial) => {
    const doc = { ...blankDocument(), ...partial };
    set({
      document: doc, elements: [], selectedElementId: null, selectedElementIds: [],
      history: [], historyIndex: -1, dirty: false, savedAt: null,
    });
    get().commit('سند جدید');
  },

  loadTemplate: (docPartial, elements) => {
    set(s => ({
      document: { ...s.document, ...docPartial, id: s.document.id, updatedAt: new Date().toISOString() },
      elements: JSON.parse(JSON.stringify(elements)),
      selectedElementId: null, selectedElementIds: [],
    }));
    get().commit('بارگذاری قالب');
  },

  saveDocument: () => {
    const { document: doc, elements } = get();
    try {
      localStorage.setItem(docKey(doc.id), JSON.stringify({ document: doc, elements }));
      const metas = readDocs().filter(m => m.id !== doc.id);
      metas.unshift({
        id: doc.id, name: doc.name, type: doc.type,
        createdAt: doc.createdAt, updatedAt: new Date().toISOString(),
        elementCount: elements.length,
      });
      localStorage.setItem(DOCS_KEY, JSON.stringify(metas));
      set({ documents: metas, savedAt: new Date().toISOString(), dirty: false });
    } catch {
      throw new Error('storage');
    }
  },

  loadDocument: (id) => {
    try {
      const raw = localStorage.getItem(docKey(id));
      if (!raw) return;
      const parsed = JSON.parse(raw);
      set({
        document: parsed.document, elements: parsed.elements,
        selectedElementId: null, selectedElementIds: [],
        history: [], historyIndex: -1, dirty: false,
      });
      get().commit('بارگذاری سند');
    } catch { /* ignore */ }
  },

  deleteDocument: (id) => {
    localStorage.removeItem(docKey(id));
    const metas = readDocs().filter(m => m.id !== id);
    localStorage.setItem(DOCS_KEY, JSON.stringify(metas));
    set({ documents: metas });
  },

  refreshDocuments: () => set({ documents: readDocs() }),

  exportAsJSON: () => {
    const { document: doc, elements } = get();
    return JSON.stringify({ version: 1, document: doc, elements }, null, 2);
  },

  importFromJSON: (data) => {
    try {
      const parsed = JSON.parse(data);
      if (!parsed.document || !Array.isArray(parsed.elements)) return false;
      set({
        document: { ...parsed.document, id: parsed.document.id || uuid() },
        elements: parsed.elements,
        selectedElementId: null, selectedElementIds: [],
        history: [], historyIndex: -1,
      });
      get().commit('ورود از فایل');
      return true;
    } catch { return false; }
  },
}));


