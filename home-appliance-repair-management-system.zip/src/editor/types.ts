// ===== Core types for the Persian Template / Form Editor =====

export type DocumentType =
  | 'invoice' | 'mission' | 'order' | 'customer-card'
  | 'accounting' | 'receipt' | 'custom';

export type PageSize = 'A4' | 'A5' | 'A3' | 'Letter' | 'custom';
export type Orientation = 'portrait' | 'landscape';
export type Breakpoint = 'mobile' | 'tablet' | 'desktop';

export interface DocumentConfig {
  id: string;
  name: string;
  type: DocumentType;
  pageSize: PageSize;
  orientation: Orientation;
  customWidth: number;   // mm
  customHeight: number;  // mm
  margins: { top: number; right: number; bottom: number; left: number };
  backgroundColor: string;
  backgroundImage: string | null;
  backgroundOpacity: number;
  showBorder: boolean;
  borderColor: string;
  borderWidth: number;
  borderStyle: 'solid' | 'dashed' | 'dotted';
  gridColor: string;
  gridOpacity: number;
  createdAt: string;
  updatedAt: string;
  version: number;
  tags: string[];
  description: string;
}

export type ElementType =
  | 'text' | 'heading' | 'paragraph'
  | 'text-input' | 'textarea' | 'number-input' | 'currency-input'
  | 'date-input' | 'select' | 'checkbox' | 'radio-group' | 'switch'
  | 'container' | 'row' | 'column' | 'divider' | 'spacer'
  | 'image' | 'image-upload' | 'qr-code'
  | 'table' | 'dynamic-table'
  | 'signature' | 'stamp' | 'watermark' | 'page-number' | 'barcode'
  | 'formula' | 'amount-words' | 'auto-number'
  // advanced & business elements
  | 'icon' | 'badge' | 'shape-circle' | 'kv' | 'pill'
  | 'timeline' | 'rating' | 'checklist' | 'stat-box' | 'dual-signature'
  | 'seal-badge' | 'notes-box' | 'device-specs' | 'price-tag';

export interface ElementStyle {
  fontFamily: string;
  fontSize: number;
  fontWeight: 'light' | 'normal' | 'medium' | 'bold' | 'extrabold';
  fontStyle: 'normal' | 'italic';
  textAlign: 'right' | 'center' | 'left' | 'justify';
  textDecoration: 'none' | 'underline' | 'line-through';
  lineHeight: number;
  letterSpacing: number;
  color: string;

  backgroundColor: string;
  backgroundOpacity: number;

  borderWidth: number;
  borderColor: string;
  borderStyle: 'none' | 'solid' | 'dashed' | 'dotted' | 'double';
  borderRadius: number;
  borderTop: boolean;
  borderRight: boolean;
  borderBottom: boolean;
  borderLeft: boolean;

  paddingTop: number;
  paddingRight: number;
  paddingBottom: number;
  paddingLeft: number;
  marginTop: number;
  marginRight: number;
  marginBottom: number;
  marginLeft: number;

  // ===== Drop shadow =====
  shadowEnabled: boolean;
  shadowX: number;
  shadowY: number;
  shadowBlur: number;
  shadowSpread: number;
  shadowColor: string;

  // ===== Inner shadow =====
  innerShadowEnabled: boolean;
  innerShadowX: number;
  innerShadowY: number;
  innerShadowBlur: number;
  innerShadowSpread: number;
  innerShadowColor: string;

  // ===== Stroke (outline) on element or text =====
  strokeEnabled: boolean;
  strokeWidth: number;     // px
  strokeColor: string;
  strokeTextOnly: boolean; // if true → applies as text-stroke instead of box outline

  // ===== Advanced visual effect presets =====
  effect: 'none' | 'glass' | 'neu' | 'gradient';
  gradFrom: string;
  gradTo: string;
  gradAngle: number;          // degrees
  gradType: 'linear' | 'radial';
  glassBlur: number;          // px
  textEffect: 'none' | 'shadow' | 'outline' | 'glow' | 'gradient-text';

  // ===== Photo/shape filters =====
  filterBlur: number;        // px
  filterBrightness: number;  // 0-200 %
  filterContrast: number;    // 0-200 %
  filterSaturate: number;    // 0-200 %
  filterGrayscale: number;   // 0-100 %
  filterHueRotate: number;   // deg 0-360

  opacity: number;
}

export interface ValidationRule {
  type: 'none' | 'email' | 'phone' | 'nationalCode' | 'postalCode' | 'custom';
  pattern: string;
  minLength: number;
  maxLength: number;
  min: number;
  max: number;
  errorMessage: string;
}

export interface SelectOption { label: string; value: string }

export interface TableColumn {
  id: string;
  header: string;
  width: number;                       // percent
  align: 'right' | 'center' | 'left';
  type: 'text' | 'number' | 'currency' | 'select' | 'formula';
  formula?: string;
  editable: boolean;
  dataField?: string;                  // data binding for print: item.desc | item.qty | item.unit | item.price | item.discount | item.total | item.row
}

/** All optional so a single bag can serve every element type */
export interface ElementProperties {
  // text
  content?: string;
  isEditable?: boolean;
  // inputs
  placeholder?: string;
  defaultValue?: string;
  required?: boolean;
  readOnly?: boolean;
  fieldName?: string;
  validation?: ValidationRule;
  options?: SelectOption[];
  optionsLayout?: 'vertical' | 'horizontal';
  step?: number;
  suffix?: string;
  prefix?: string;
  thousandSeparator?: boolean;
  dateFormat?: string;
  // table
  columns?: TableColumn[];
  rows?: number;
  dynamicRows?: boolean;
  showRowNumbers?: boolean;
  showHeader?: boolean;
  showFooter?: boolean;
  zebraStripes?: boolean;
  headerBg?: string;
  headerColor?: string;
  altRowBg?: string;
  cellPadding?: 'compact' | 'normal' | 'relaxed';
  tableBorder?: 'solid' | 'dashed' | 'minimal' | 'none';
  // image
  src?: string;
  alt?: string;
  fit?: 'contain' | 'cover' | 'fill' | 'none';
  // formula
  formula?: string;
  sourceFields?: string[];
  format?: 'number' | 'currency' | 'percent' | 'text';
  decimalPlaces?: number;
  // container
  direction?: 'row' | 'column';
  gap?: number;
  alignItems?: 'start' | 'center' | 'end' | 'stretch';
  justifyContent?: 'start' | 'center' | 'end' | 'between' | 'around';
  wrap?: boolean;
  childIds?: string[];
  // divider
  orientation?: 'horizontal' | 'vertical';
  // qr / barcode
  value?: string;
  // auto number
  numberPrefix?: string;
  startFrom?: number;
  // new business elements
  timelineSteps?: { title: string; desc?: string; done?: boolean }[];
  ratingValue?: number;
  maxRating?: number;
  ratingIcon?: 'star' | 'heart';
  checklistItems?: { text: string; checked: boolean }[];
  statNumber?: string;
  statLabel?: string;
  statBadge?: string;
  leftSignLabel?: string;
  rightSignLabel?: string;
  sealText?: string;
  sealColor?: 'gold' | 'teal' | 'red' | 'blue';
  noteType?: 'info' | 'warning' | 'success' | 'danger';
  priceAmount?: string;
  priceCurrency?: string;
}

export interface ResponsiveRect {
  x: number; y: number; width: number; height: number; hidden: boolean;
}

export interface EditorElement {
  id: string;
  type: ElementType;
  label: string;
  x: number;
  y: number;
  width: number;
  height: number;
  minWidth: number;
  minHeight: number;
  maxWidth: number;
  maxHeight: number;
  rotation: number;
  zIndex: number;
  locked: boolean;
  hidden: boolean;
  groupId: string | null;
  responsive: Record<Breakpoint, ResponsiveRect | null>;
  style: ElementStyle;
  properties: ElementProperties;
}

export interface HistoryEntry {
  timestamp: number;
  action: string;
  snapshot: { elements: EditorElement[]; document: DocumentConfig };
}

export interface GuideLine {
  type: 'vertical' | 'horizontal';
  position: number;
  color: string;
  from?: number;
  to?: number;
  label?: string;
}

export interface DocumentMeta {
  id: string;
  name: string;
  type: DocumentType;
  createdAt: string;
  updatedAt: string;
  elementCount: number;
}

export type AlignmentType =
  | 'left' | 'center-h' | 'right' | 'top' | 'center-v' | 'bottom';

export const PAGE_SIZES_MM: Record<Exclude<PageSize, 'custom'>, { w: number; h: number }> = {
  A4: { w: 210, h: 297 },
  A5: { w: 148, h: 210 },
  A3: { w: 297, h: 420 },
  Letter: { w: 216, h: 279 },
};

export const MM_TO_PX = 96 / 25.4;

export const ELEMENT_LABELS: Record<ElementType, string> = {
  'text': 'متن',
  'heading': 'عنوان',
  'paragraph': 'پاراگراف',
  'text-input': 'ورودی متن',
  'textarea': 'ورودی چندخطی',
  'number-input': 'ورودی عدد',
  'currency-input': 'ورودی مبلغ',
  'date-input': 'تاریخ شمسی',
  'select': 'لیست انتخاب',
  'checkbox': 'چک‌باکس',
  'radio-group': 'دکمه رادیویی',
  'switch': 'کلید تغییر',
  'container': 'کانتینر',
  'row': 'ردیف',
  'column': 'ستون',
  'divider': 'خط جداکننده',
  'spacer': 'فضای خالی',
  'image': 'تصویر',
  'image-upload': 'آپلود تصویر',
  'qr-code': 'کد QR',
  'table': 'جدول ساده',
  'dynamic-table': 'جدول پویا',
  'signature': 'محل امضا',
  'stamp': 'محل مهر',
  'watermark': 'واترمارک',
  'page-number': 'شماره صفحه',
  'barcode': 'بارکد',
  'formula': 'فیلد محاسباتی',
  'amount-words': 'مبلغ به حروف',
  'auto-number': 'شماره خودکار',
  'icon': 'آیکون',
  'badge': 'نشان',
  'shape-circle': 'دایره',
  'kv': 'کلید و مقدار',
  'pill': 'برچسب گرد',
  'timeline': 'تایم‌لاین مراحل',
  'rating': 'رتبه‌بندی رضایت',
  'checklist': 'چک‌لیست اقلام',
  'stat-box': 'باکس شاخص آماری',
  'dual-signature': 'امضای دوطرفه',
  'seal-badge': 'مهر رسمی برجسته',
  'notes-box': 'کادر هشدار و یادداشت',
  'device-specs': 'شناسنامه دستگاه',
  'price-tag': 'برچسب قیمت',
};

export const DOC_TYPE_LABELS: Record<DocumentType, string> = {
  invoice: 'فاکتور',
  mission: 'فرم ماموریت',
  order: 'سفارش',
  'customer-card': 'کارتکس مشتری',
  accounting: 'حسابداری',
  receipt: 'رسید',
  custom: 'سفارشی',
};
